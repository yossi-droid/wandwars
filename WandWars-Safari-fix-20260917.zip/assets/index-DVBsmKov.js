(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const o of s)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&n(r)}).observe(document,{childList:!0,subtree:!0});function t(s){const o={};return s.integrity&&(o.integrity=s.integrity),s.referrerPolicy&&(o.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?o.credentials="include":s.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function n(s){if(s.ep)return;s.ep=!0;const o=t(s);fetch(s.href,o)}})();const Cn={radius:9300},rs={cx:0,cy:0,startRadius:9080,minRadius:300,shrinkPerSec:150,shrinkDelay:12,dps:11},Sg=3,Ct={radius:16,speed:220,runSpeed:390,maxHealth:100},Ds={max:6,drainPerSec:1,regenPerSec:1,partialDelay:1.5,emptyDelay:4},Un={countdown:3,chooseTime:15,portalCount:5,platformRadius:520,portalRing:430,portalOuterWidth:336,portalRadius:132,platformHeight:2600,dropHeight:1900,fallSpeed:155,steerSpeed:300},jr=[{name:"Enchanted Highlands",x:-4300,y:-4100,landingRadius:1250,color:"#34d399"},{name:"Crown Castle",x:-450,y:500,landingRadius:1100,color:"#c4b5fd"},{name:"Harvest Village",x:4300,y:-3200,landingRadius:1300,color:"#fbbf24"},{name:"Western Harbor",x:-5600,y:3500,landingRadius:1100,color:"#60a5fa"},{name:"Sunken Desert",x:4700,y:4700,landingRadius:1350,color:"#f59e0b"}];function bg(i){return{phase:i?"countdown":"complete",timer:i?Un.countdown:0,elapsed:0,portals:Array.from({length:Un.portalCount},(e,t)=>{const n=t/Un.portalCount*Math.PI*2;return{index:t,angle:n,x:Math.cos(n)*Un.portalRing,y:Math.sin(n)*Un.portalRing,destination:t%jr.length,unstable:t%4===2,nextShift:2.4+t%3*.8}})}}const Mf={velocity:420,gravity:1050},Fo={up:260,side:220,wallGap:22,gravity:950};function Ba(i){if(i.kind!=="house")return De(i.x,i.y);const e=Math.cos(i.angle),t=Math.sin(i.angle);let n=-1/0;for(const s of[-i.hw,0,i.hw])for(const o of[-i.hd,0,i.hd])n=Math.max(n,De(i.x+s*e-o*t,i.y+s*t+o*e));return n}const Sl={speed:850,vspeed:650},_i={cooldown:0,speed:6e3,life:2.1,radius:10,damage:22,castHeight:28},dr=124,Tg=168,Fs={bolt:{name:"Fire Stream",type:"projectile",cooldown:_i.cooldown,color:"#fb923c"},slash:{name:"Spell of Slashing",type:"melee",cooldown:0,damage:26,range:82,arc:Math.PI*.7,duration:.42,color:"#f0abfc"},heal:{name:"Spell of Healing",type:"self",cooldown:0,heal:40,color:"#4ade80"}},wg=["bolt","slash","heal"],fr=Object.freeze({"apprentice-wand":{name:"Apprentice Wand",description:"A balanced, nimble focus that feels natural with every kind of magic.",color:"#67e8f9"},"focusing-crystal-staff":{name:"Focusing Crystal Staff",description:"A precise two-handed focus made for patient, accurate casting.",color:"#a78bfa"},"thunderclap-gauntlet":{name:"Thunderclap Gauntlet",description:"A close-range conduit that channels magic through the caster’s fist.",color:"#38bdf8"},"arcane-spellbook":{name:"Arcane Spellbook",description:"A scholarly focus for runes, wards, and carefully controlled spellwork.",color:"#c084fc"},"enchanted-bow":{name:"Enchanted Bow",description:"A graceful ranged focus that shapes found attacks into magical arrows.",color:"#4ade80"},"chaos-orb":{name:"Chaos Orb",description:"An unstable floating focus that crackles with unpredictable power.",color:"#e879f9"}}),ka=Object.freeze(Object.keys(fr)),Mm=[{id:"focusing-crystal",name:"Focusing Crystal",description:"Charges and fires a powerful, accurate beam.",kind:"beam",cooldown:0,manaCost:28,chargeTime:1.05,damage:68,range:9e3,width:6,color:"#67e8f9"},{id:"triple-bolt",name:"Triple Bolt",description:"Fires three magical bolts in a quick burst.",kind:"projectile",cooldown:0,manaCost:18,damage:15,speed:4800,radius:8,life:2.2,count:3,spread:.055,color:"#a78bfa"},{id:"chaos-cube",name:"Chaos Cube",description:"Launches unpredictable magic with a random effect.",kind:"projectile",cooldown:0,manaCost:18,damage:24,speed:2700,radius:18,life:3,randomEffect:!0,color:"#d946ef"},{id:"dagger-magic",name:"Dagger Magic",description:"Fires quick magical daggers that work best nearby.",kind:"projectile",cooldown:0,manaCost:5,damage:12,speed:5200,radius:7,life:.72,pierce:1,color:"#e2e8f0"},{id:"ricochet-spell",name:"Ricochet Spell",description:"Bounces between walls or enemies.",kind:"projectile",cooldown:0,manaCost:16,damage:23,speed:3900,radius:11,life:4.2,bounces:5,chain:2,chainRange:260,color:"#fbbf24"},{id:"war-mage-barrage",name:"War Mage Barrage",description:"Continuously fires fast magical projectiles.",kind:"projectile",cooldown:0,manaCost:5,damage:7,speed:5e3,radius:7,life:1.8,trail:46,color:"#fb7185"},{id:"thunderclap",name:"Thunderclap",description:"A close shockwave that damages and pushes enemies.",kind:"nova",cooldown:0,manaCost:20,damage:28,range:185,knockback:330,color:"#38bdf8"},{id:"dragon-breath",name:"Dragon Breath",description:"Blasts a wide stream of fire directly ahead.",kind:"projectile",cooldown:0,manaCost:15,damage:8,speed:2100,radius:13,life:.85,count:9,spread:.52,burn:6,statusTime:3,color:"#f97316"},{id:"apprentice-bolt",name:"Apprentice Bolt",description:"A simple, balanced projectile that is easy to use.",kind:"projectile",cooldown:0,manaCost:8,damage:24,speed:4200,radius:11,life:2.4,color:"#818cf8"},{id:"wasp-swarm",name:"Wasp Swarm",description:"Releases small magical wasps that chase an enemy.",kind:"projectile",cooldown:0,manaCost:18,damage:6,speed:1800,radius:6,life:5,count:7,spread:.38,homing:7,color:"#facc15"},{id:"eagle-eye-shot",name:"Eagle-Eye Shot",description:"Fires a highly accurate long-range attack.",kind:"beam",cooldown:0,manaCost:26,damage:52,range:1e4,width:4,color:"#fde68a"},{id:"shifting-spell",name:"Shifting Spell",description:"Changes between different attack forms every cast.",kind:"projectile",cooldown:0,manaCost:16,damage:26,speed:3200,radius:14,life:2.8,shifting:!0,color:"#c084fc"},{id:"enchanted-gargoyle",name:"Enchanted Gargoyle",description:"Summons a gargoyle that hunts nearby enemies.",kind:"summon",cooldown:0,manaCost:32,damage:14,speed:950,radius:20,life:10,homing:8,pierce:8,color:"#94a3b8"},{id:"grappling-vine",name:"Grappling Vine",description:"Pulls you toward buildings, trees, or cliffs.",kind:"grapple",cooldown:0,manaCost:18,range:1100,speed:5600,color:"#4ade80"},{id:"void-kings-blast",name:"Void King’s Blast",description:"A huge void explosion that pulls enemies inward.",kind:"nova",cooldown:0,manaCost:60,damage:48,range:330,pull:420,color:"#6d28d9"},{id:"werewolf-claws",name:"Werewolf Claws",description:"Fast close-range claws that temporarily increase speed.",kind:"melee",cooldown:0,manaCost:40,damage:22,range:105,arc:1.35,haste:1.42,statusTime:5,color:"#d1d5db"},{id:"giants-focusing-beam",name:"Giant’s Focusing Beam",description:"Charges a massive beam that deals heavy damage.",kind:"beam",cooldown:0,manaCost:60,chargeTime:1.7,damage:105,range:7600,width:24,pierce:2,color:"#fef3c7"},{id:"baba-yagas-curse",name:"Baba Yaga’s Curse",description:"Curses an enemy so their magic behaves strangely.",kind:"projectile",cooldown:0,manaCost:45,damage:12,speed:3e3,radius:15,life:3.2,homing:3.5,curse:!0,statusTime:7,color:"#a855f7"},{id:"storm-kings-lightning",name:"Storm King’s Lightning",description:"Calls down powerful lightning that chains through enemies.",kind:"projectile",cooldown:0,manaCost:55,damage:42,speed:6500,radius:10,life:2.2,chain:5,chainRange:360,color:"#60a5fa"},{id:"twin-moon-barrage",name:"Twin Moon Barrage",description:"Fires two streams of moon projectiles simultaneously.",kind:"projectile",cooldown:0,manaCost:40,damage:8,speed:4600,radius:8,life:2.1,count:2,spread:.08,color:"#bfdbfe"},{id:"poison-mist",name:"Poison Mist",description:"Creates a poisonous cloud that damages anyone inside.",kind:"summon",cooldown:0,manaCost:45,zoneType:"poison",range:190,life:9,damagePerSecond:8,poison:3,statusTime:2,color:"#84cc16"},{id:"boots-of-endless-flight",name:"Boots of Endless Flight",description:"Allow controlled flight using limited magical energy.",kind:"movement",cooldown:0,manaCost:25,flightTime:8,launch:180,color:"#7dd3fc"},{id:"rocket-rune-boots",name:"Rocket Rune Boots",description:"Launch you forward and upward extremely quickly.",kind:"movement",cooldown:0,manaCost:20,dash:430,launch:380,color:"#fb923c"},{id:"thunder-stones",name:"Thunder Stones",description:"Throw you into the air with a lightning blast.",kind:"movement",cooldown:0,manaCost:22,launch:610,damage:18,range:145,knockback:190,color:"#38bdf8"},{id:"haste-orb",name:"Haste Orb",description:"Temporarily increases running speed.",kind:"movement",cooldown:0,manaCost:15,haste:1.65,statusTime:7,color:"#2dd4bf"},{id:"fairy-fizz",name:"Fairy Fizz",description:"Sprays nearby allies, restoring 50 protection over 5 seconds.",kind:"summon",cooldown:0,manaCost:0,consumable:!0,zoneType:"fairy-fizz",range:170,life:5,shieldPerSecond:10,friendlyOnly:!0,color:"#f0abfc"},{id:"golden-wizard-cake",name:"Golden Wizard Cake",description:"Restores lots of health and protection but takes time to eat.",kind:"heal",cooldown:0,manaCost:0,consumable:!0,channelTime:5,heal:50,shield:50,color:"#fbbf24"},{id:"healing-leaves",name:"Healing Leaves",description:"Quickly restore a small amount of health.",kind:"heal",cooldown:0,manaCost:0,consumable:!0,channelTime:1.5,heal:25,color:"#4ade80"},{id:"restoration-potion",name:"Restoration Potion",description:"Gradually restores health after drinking it.",kind:"heal",cooldown:0,manaCost:0,consumable:!0,healOverTime:75,duration:10,stopsOnDamage:!0,color:"#22c55e"},{id:"small-protection-potion",name:"Small Protection Potion",description:"Gives a small amount of magical protection.",kind:"shield",cooldown:0,manaCost:0,consumable:!0,shield:25,shieldCap:50,color:"#22d3ee"},{id:"greater-protection-potion",name:"Great Protection Potion",description:"Adds 50 protection and can fill protection to 100.",kind:"shield",cooldown:0,manaCost:0,consumable:!0,shield:50,shieldCap:100,color:"#0284c7"},{id:"cauldron-of-restoration",name:"Cauldron of Restoration",description:"Heals and protects every player standing nearby.",kind:"summon",cooldown:0,manaCost:0,consumable:!0,zoneType:"restoration",range:210,life:20,health:140,healPerSecond:5,shieldPerSecond:5,friendlyOnly:!0,color:"#10b981"},{id:"portable-summoning-circle",name:"Portable Summoning Circle",description:"Creates temporary magical cover around the caster.",kind:"summon",cooldown:0,manaCost:30,zoneType:"cover",range:150,life:11,shieldPerSecond:6,color:"#c084fc"},{id:"empowerment-beacon",name:"Empowerment Beacon",description:"Strengthens the attacks of nearby players.",kind:"summon",cooldown:0,manaCost:0,consumable:!0,zoneType:"empower",range:230,life:20,health:110,empower:1.2,friendlyOnly:!0,color:"#f59e0b"},{id:"rune-key",name:"Rune Key",description:"Unlocks special vaults containing rare attacks and items.",kind:"utility",cooldown:0,manaCost:0,consumable:!0,keyCount:1,color:"#facc15"}],Sm=[{id:"continuous-magic-beam",name:"Continuous Magic Beam",description:"A beam that fires continuously while held.",kind:"beam",weaponId:"apprentice-wand",tier:1,cooldown:0,manaPerSecond:12,damage:5,range:1800,width:12,color:"#67e8f9"},{id:"grappling-spell",name:"Grappling Spell",description:"Pulls you quickly toward the impact point.",kind:"grapple",weaponId:"apprentice-wand",tier:2,cooldown:0,manaCost:15,speed:5200,range:850,color:"#38bdf8"},{id:"precision-burst-spell",name:"Precision Burst",description:"Three accurate high-speed shots.",kind:"projectile",weaponId:"focusing-crystal-staff",tier:1,cooldown:0,manaCost:22,damage:13,speed:5200,radius:8,life:2.5,count:3,spread:.025,color:"#fbbf24"},{id:"rapid-fire-spell",name:"Rapid-Fire Spell",description:"Fast medium-range crystal fire.",kind:"projectile",weaponId:"focusing-crystal-staff",tier:2,cooldown:0,manaCost:6,damage:8,speed:4300,radius:8,life:1.8,color:"#38bdf8"},{id:"bouncing-magic-bomb",name:"Bouncing Magic Bomb",description:"Bounces twice, then explodes.",kind:"projectile",weaponId:"thunderclap-gauntlet",tier:1,cooldown:0,manaCost:28,damage:18,speed:1700,radius:22,life:3.2,bounces:2,gravity:900,upward:.2,explosionRadius:180,splashDamage:34,color:"#facc15"},{id:"repulsion-spell",name:"Repulsion Spell",description:"Blasts nearby enemies away from the gauntlet.",kind:"nova",weaponId:"thunderclap-gauntlet",tier:2,cooldown:0,manaCost:18,damage:18,range:190,knockback:520,color:"#38bdf8"},{id:"close-range-blast",name:"Close-Range Blast",description:"Heavy damage in a tight cone ahead.",kind:"melee",weaponId:"arcane-spellbook",tier:1,cooldown:0,manaCost:25,damage:45,range:115,arc:1.05,knockback:170,color:"#fb923c"},{id:"accurate-magic-shot",name:"Accurate Magic Shot",description:"A reliable perfectly straight shot.",kind:"projectile",weaponId:"arcane-spellbook",tier:2,cooldown:0,manaCost:8,damage:29,speed:6500,radius:8,life:2.2,color:"#38bdf8"},{id:"long-range-beam",name:"Long-Range Beam",description:"A slow-firing powerful sniper beam.",kind:"beam",weaponId:"enchanted-bow",tier:1,cooldown:0,manaCost:30,damage:72,range:9e3,width:7,color:"#fbbf24"},{id:"twin-magic-shot",name:"Twin Magic Shot",description:"Fires two magic arrows side by side.",kind:"projectile",weaponId:"enchanted-bow",tier:2,cooldown:0,manaCost:12,damage:18,speed:4400,radius:9,life:2.5,count:2,spread:.045,color:"#22d3ee"},{id:"explosive-spell",name:"Explosive Spell",description:"A slow shot with a huge explosion.",kind:"projectile",weaponId:"chaos-orb",tier:1,cooldown:0,manaCost:35,damage:28,speed:1550,radius:25,life:4,explosionRadius:240,splashDamage:46,knockback:260,color:"#f97316"},{id:"magic-barrage",name:"Magic Barrage",description:"Nine fast, weaker chaos projectiles.",kind:"projectile",weaponId:"chaos-orb",tier:2,cooldown:0,manaPerProjectile:5,damage:7,speed:3900,radius:8,life:2.2,count:9,spread:.28,color:"#d946ef"}],xc=Object.freeze(Mm.map(({id:i})=>i)),bm=Object.freeze(Sm.map(({id:i})=>i)),eh=Object.freeze(xc.slice(0,14)),Eg=Object.freeze(xc.slice(14,21)),Ag=Object.freeze(xc.slice(21,25)),Rg=Object.freeze(xc.slice(25,32)),Cg=Object.freeze(xc.slice(32,35)),Sf="weapon-upgrade-rune",$i=Object.freeze({catalyst:Object.freeze({name:"Catalyst Shards",max:500,pickup:60,color:"#e2e8f0"}),elemental:Object.freeze({name:"Elemental Essences",max:400,pickup:45,color:"#fb923c"}),burst:Object.freeze({name:"Burst Runes",max:120,pickup:18,color:"#facc15"}),cosmic:Object.freeze({name:"Cosmic Orbs",max:30,pickup:5,color:"#a78bfa"}),calamity:Object.freeze({name:"Calamity Cores",max:6,pickup:1,color:"#ef4444"})}),Ha=Object.freeze(Object.keys($i)),bf=Object.freeze({"focusing-crystal":"cosmic","eagle-eye-shot":"cosmic","giants-focusing-beam":"cosmic","storm-kings-lightning":"cosmic","void-kings-blast":"calamity","enchanted-gargoyle":"calamity","poison-mist":"calamity","portable-summoning-circle":"calamity","cauldron-of-restoration":null,"empowerment-beacon":null,thunderclap:"burst","werewolf-claws":"burst","thunder-stones":"burst","continuous-magic-beam":"catalyst","grappling-spell":"elemental","precision-burst-spell":"cosmic","rapid-fire-spell":"catalyst","bouncing-magic-bomb":"elemental","repulsion-spell":"burst","close-range-blast":"burst","accurate-magic-shot":"catalyst","long-range-beam":"cosmic","twin-magic-shot":"catalyst","explosive-spell":"calamity","magic-barrage":"catalyst"});function Tf(i){return i.consumable||(i.manaCost||0)===0&&!i.manaPerSecond&&!i.manaPerProjectile?null:Object.prototype.hasOwnProperty.call(bf,i.id)?bf[i.id]:i.kind==="projectile"||i.kind==="beam"?"elemental":i.kind==="melee"||i.kind==="nova"?"burst":i.kind==="summon"?"calamity":"elemental"}const Tm=.05,on=Object.freeze(Object.fromEntries([...Mm.map(i=>[i.id,{...i,ammoType:Tf(i),cooldown:0,spellId:i.kind==="heal"?"heal":i.kind==="melee"?"slash":"bolt",scope:"universal"}]),...Sm.map(i=>[i.id,{...i,ammoType:Tf(i),cooldown:0,spellId:i.kind==="heal"?"heal":i.kind==="melee"?"slash":"bolt",scope:"tier"}])])),vo=6,Hl=72;function th(i=Math.random){const e=i();return e<.52?"regular":e<.69?"healing-protection":e<.79?"movement":e<.87?"special":e<.905?"tier-1":e<.97?"tier-2":"mythic"}function Pg(i,e=Math.random){const t=Math.min(ka.length-1,Math.floor(e()*ka.length)),n=ka[t];return bm.find(s=>{const o=on[s];return o.weaponId===n&&o.tier===i})||null}const Kn=Object.freeze({common:{name:"Common",color:"#9ca3af",chance:.5,damage:1,projectileSpeed:1,energyUse:1,cooldown:0},rare:{name:"Rare",color:"#22c55e",chance:.25,damage:1.05,projectileSpeed:1,energyUse:1,cooldown:0},"super-rare":{name:"Super Rare",color:"#3b82f6",chance:.15,damage:1.1,projectileSpeed:1.08,energyUse:1,cooldown:0},epic:{name:"Epic",color:"#a855f7",chance:.08,damage:1.15,projectileSpeed:1,energyUse:.9,cooldown:0},legendary:{name:"Legendary",color:"#f59e0b",chance:.02,damage:1.2,projectileSpeed:1,energyUse:.8,cooldown:0}}),co=Object.freeze(Object.keys(Kn));function Ig(i=Math.random){const e=i();let t=0;for(const n of co)if(t+=Kn[n].chance,e<t)return n;return"legendary"}function pd(){return Object.fromEntries(Ha.map(i=>[i,0]))}function iu(i,e,t){const n=$i[e];if(!i||!n||t<=0)return 0;i.manaPouch||(i.manaPouch=pd());const s=i.manaPouch[e]||0;return i.manaPouch[e]=Math.min(n.max,s+t),i.manaPouch[e]-s}function wm(i,e){var n,s;const t=(n=on[e])==null?void 0:n.ammoType;return t?((s=i==null?void 0:i.manaPouch)==null?void 0:s[t])||0:1/0}function Lg(i,e,t){var s;const n=(s=on[e])==null?void 0:s.ammoType;return!n||t<=0?!0:(i.manaPouch||(i.manaPouch=pd()),(i.manaPouch[n]||0)+1e-9<t?!1:(i.manaPouch[n]=Math.max(0,i.manaPouch[n]-t),!0))}function cr(i,e){var s;const t=Kn[(s=i==null?void 0:i.attackRarities)==null?void 0:s[e]]?i.attackRarities[e]:"common",n=Kn[i==null?void 0:i.baseWeaponRarity]?i.baseWeaponRarity:"common";return co.indexOf(n)>co.indexOf(t)?n:t}function Dg(i,e="common"){if(!i)return null;const t=Kn[i.baseWeaponRarity]?i.baseWeaponRarity:"common",n=co.indexOf(t),s=co.indexOf(Kn[e]?e:"common"),o=Math.min(co.length-1,Math.max(n+1,s));return i.baseWeaponRarity=co[o],i.baseWeaponRarity}function md(i,e){const t=on[e];if(!t)return null;const n=cr(i,e),s=Kn[n],o={...t,rarity:n,rarityColor:s.color};for(const a of["damage","splashDamage","damagePerSecond","burn","poison"])typeof o[a]=="number"&&(o[a]*=s.damage);typeof o.speed=="number"&&(o.speed*=s.projectileSpeed),o.cooldown=0;let r=o.manaCost;return typeof o.manaPerSecond=="number"?r=o.manaPerSecond*Tm:typeof o.manaPerProjectile=="number"&&(r=o.manaPerProjectile*(o.count||1)),typeof r=="number"&&(o.manaCost=Math.max(0,Math.round(r*s.energyUse*100)/100)),o.ammoType==="calamity"&&o.manaCost>0&&(o.manaCost=1),o.ammoType==="cosmic"&&o.manaCost>0&&(o.manaCost=Math.min($i.cosmic.max,o.manaCost)),o}function tc(i,e){const t=on[e],n=typeof i=="string"?i:i==null?void 0:i.baseWeaponId;return!!t&&(t.scope==="universal"||t.weaponId===n)}function wf(i,e,t="common"){return!i||!on[e]||(i.attackInventory||(i.attackInventory=[]),i.attackInventory.includes(e))||on[e].scope==="tier"&&i.attackInventory.some(n=>{var s;return((s=on[n])==null?void 0:s.scope)==="tier"})?!1:(i.attackInventory.push(e),i.attackRarities||(i.attackRarities={}),i.attackRarities[e]=Kn[t]?t:"common",on[e].scope==="tier"&&(i.tierAttackId=e),!0)}function su(i,e,t=null){var s;if(!i||!((s=i.attackInventory)!=null&&s.includes(e))||!tc(i,e))return!1;i.attackSlots||(i.attackSlots=Array(vo).fill(null));let n=t;if(Number.isInteger(n)||(n=i.attackSlots.findIndex(o=>o==null)),n<0||n>=vo)return!1;for(let o=0;o<i.attackSlots.length;o++)i.attackSlots[o]===e&&(i.attackSlots[o]=null);return i.attackSlots[n]=e,!0}const Ef=["#38bdf8","#f472b6","#f43f5e","#facc15","#4ade80","#c084fc","#fb923c","#2dd4bf","#a3e635","#e879f9","#60a5fa","#fca5a5"];function Ws(i,e,t){return Math.max(e,Math.min(t,i))}function Kt(i,e,t,n){return Math.hypot(i-t,e-n)}function Pi(i,e){const t=Math.hypot(i,e);return t===0?{x:0,y:0}:{x:i/t,y:e/t}}function Em(i){for(;i>Math.PI;)i-=2*Math.PI;for(;i<-Math.PI;)i+=2*Math.PI;return i}function gd(){const i={};for(const e of wg)i[e]=0;return i}function xd(i){let e=i>>>0;return function(){e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}const Ng=6221075,Rs=Cn.radius,fi=[{biome:"mountain",x:-.28*Rs,y:-.62*Rs,r:2850},{biome:"forest",x:-.62*Rs,y:-.25*Rs,r:2850},{biome:"farm",x:.46*Rs,y:-.34*Rs,r:2450},{biome:"desert",x:.5*Rs,y:.5*Rs,r:3e3},{biome:"coast",x:-.61*Rs,y:.37*Rs,r:2550}],Ga=[[-900,-8500],[-520,-7100],[-760,-5750],[-1450,-4300],[-1320,-2850],[-850,-1500],[-650,-650],[-690,720],[-1250,1850],[-2250,2850],[-3600,3700],[-5050,4300]],yt={pond:{x:4300,y:-4300,r:620},bay:{x:-5900,y:5e3,r:2550},islet:{x:-6100,y:6100,r:680},mine:{x:5900,y:900}};function lr(i,e){let t=1/0,n=0,s=0;for(let o=0;o<Ga.length-1;o++){const r=Ga[o],a=Ga[o+1],c=a[0]-r[0],l=a[1]-r[1],u=c*c+l*l||1,h=Ws(((i-r[0])*c+(e-r[1])*l)/u,0,1),d=r[0]+c*h,f=r[1]+l*h,p=Math.hypot(i-d,e-f);p<t&&(t=p,n=o,s=h)}return{distance:t,segment:n,amount:s}}function _s(i,e){let t=1/0,n=null;for(const s of fi){const o=i-s.x,r=e-s.y,a=o*o+r*r;a<t&&(t=a,n=s)}return n&&t<n.r*n.r?n.biome:"grass"}function Cs(i,e,t){const n=Ws((i-e)/(t-e),0,1);return n*n*(3-2*n)}const Af=fi.find(i=>i.biome==="mountain"),Rf=fi.find(i=>i.biome==="desert");function De(i,e){const t=Math.hypot(i,e),n=Cn.radius,s=46*Math.sin(i*.00125+e*58e-5+1.1)+34*Math.sin(i*-72e-5+e*.00158-.6)+20*Math.sin(i*.0029+e*.0017+2.4)*Math.cos(e*.0021-.8)+10*Math.sin(i*.0071-e*.0062+3.7),o=.35+.65*Cs(t,700,3800);let r=150+s*o;const a=Math.hypot(i-Af.x,e-Af.y),c=1-Cs(a,180,2850),l=.68+.2*(1-Math.abs(Math.sin(i*.0017+e*.0011)))+.12*Math.sin(i*.0043-e*.0028);r+=c*(760+520*l);const u=Math.hypot(i-Rf.x,e-Rf.y);r-=(1-Cs(u,250,2500))*70;for(const[M,S,_,A]of[[yt.mine.x-430,yt.mine.y-280,1450,470],[yt.mine.x+520,yt.mine.y+260,1250,390]]){const E=Math.hypot(i-M,e-S);r+=(1-Cs(E,_*.18,_))*A}const h=Math.hypot(i-yt.bay.x,e-yt.bay.y);r-=(1-Cs(h,450,yt.bay.r))*420;const d=Math.hypot(i-yt.islet.x,e-yt.islet.y);r+=(1-Cs(d,80,yt.islet.r))*460;const f=lr(i,e).distance;r-=(1-Cs(f,75,230))*78,r-=(1-Cs(f,170,520))*34;const p=Math.hypot(i-yt.pond.x,e-yt.pond.y);r-=(1-Cs(p,yt.pond.r*.45,yt.pond.r*1.2))*58;const x=Math.atan2(e,i),m=1+.055*Math.sin(x*3+.4)+.035*Math.sin(x*7-1.1),g=n*1.03*m;return r-=Cs(t,g,g+n*.23)*930,r}function Ug(i,e,t){const n=.9+t()*t()*3.6;return{kind:"tree",x:i,y:e,scale:n,rot:t()*Math.PI,leaf:t()*4|0,r:15*n,top:200*n}}function Fg(i,e,t){const n=.8+t()*1;return{kind:"cactus",x:i,y:e,scale:n,rot:t()*Math.PI,arms:1+(t()*3|0),r:12*n,top:95*n}}function Cf(i,e,t,n){const s=(n?34:12)+t()*(n?95:40),o=n?.9+t()*1:.5+t()*.5;return{kind:"rock",x:i,y:e,s,sy:o,rx:t()*3,ry:t()*3,rz:t()*3,r:s*.9,top:s*(.3+o)}}function Og(i,e,t){const n=10+t()*16;return{kind:"bush",x:i,y:e,s:n,rot:t()*Math.PI,leaf:t()*4|0,soft:!0}}function Bg(i,e,t){const n=600+t()*400,s=600+t()*400,o=236+t()*128,r=Math.atan2(-e,-i)-Math.PI/2+(t()-.5)*.3;return{kind:"house",x:i,y:e,w:n,d:s,h:o,angle:r,wall:t()*4|0,roof:t()*4|0,hw:n/2,hd:s/2,top:o*1.8}}function nh(i=Ng){const e=xd(i),t=[],s=Cn.radius-80,o=(p,x)=>Kt(p,x,0,0)<700,r=(p,x,m,g)=>{for(let M=0;M<p;M++){const S=e()*Math.PI*2,_=Math.sqrt(x*x+e()*(m*m-x*x));g(Math.cos(S)*_,Math.sin(S)*_)}},a=(p,x,m,g,M)=>{for(let S=0;S<m;S++){const _=e()*Math.PI*2,A=Math.sqrt(e())*g;M(p+Math.cos(_)*A,x+Math.sin(_)*A)}};r(1500,300,s,(p,x)=>{if(o(p,x)||lr(p,x).distance<300||De(p,x)<7)return;const m=_s(p,x);if(m==="desert"){const M=e();M<.4?t.push(Fg(p,x,e)):M<.62&&t.push(Cf(p,x,e,!0));return}const g=m==="forest"?.92:m==="mountain"?.32:m==="farm"?.28:.55;e()<g?t.push(Ug(p,x,e)):e()<.28&&t.push(Og(p,x,e))}),r(520,300,s,(p,x)=>{if(o(p,x)||lr(p,x).distance<250||De(p,x)<4)return;const m=_s(p,x),g=m==="mountain"?.85:m==="desert"?.5:.25;e()<g&&t.push(Cf(p,x,e,m==="mountain"))});const c=fi.find(p=>p.biome==="coast"),l=fi.find(p=>p.biome==="farm"),u=fi.find(p=>p.biome==="desert"),h=(p,x)=>{if(lr(p,x).distance<520||De(p,x)<12||Kt(p,x,yt.pond.x,yt.pond.y)<yt.pond.r+220)return;const m=Bg(p,x,e),g=Math.max(m.hw,m.hd);t.some(S=>S.kind==="house"&&Kt(p,x,S.x,S.y)<g+Math.max(S.hw,S.hd)+70)||t.push(m)};a(c.x,c.y,34,2900,h),a(l.x,l.y,12,2100,h),a(u.x+300,u.y+520,14,1800,h),a(yt.mine.x,yt.mine.y+1250,8,1150,h),r(26,1600,s,(p,x)=>{const m=_s(p,x);!o(p,x)&&m!=="desert"&&m!=="mountain"&&h(p,x)});const d=fi.find(p=>p.biome==="mountain");for(const[p,x,m,g]of[[-1100,220,280,720],[-720,-440,360,930],[-280,160,310,820],[180,-520,390,1020],[620,80,300,780],[1050,-360,345,890],[-850,880,270,650],[-300,820,350,850],[300,900,290,690],[820,700,320,760],[-1250,-650,240,580],[1250,400,250,620]])t.push({kind:"rock",landmark:!0,x:d.x+p,y:d.y+x,r:m*.82,top:g});for(const[p,x,m,g]of[[-1700,450,340,620],[-700,1180,280,500],[450,600,390,690],[1450,1300,260,470],[1550,-200,310,560]])t.push({kind:"rock",landmark:!0,x:u.x+p,y:u.y+x,r:m*.9,top:g});for(const[p,x,m,g]of[[-430,-280,420,720],[520,260,360,620]])t.push({kind:"rock",landmark:!0,x:yt.mine.x+p,y:yt.mine.y+x,r:m,top:g});t.push({kind:"house",landmark:!0,x:yt.islet.x,y:yt.islet.y,w:250,d:190,h:250,hw:125,hd:95,top:250,angle:0});const f=t.filter(p=>p.kind==="house");return t.filter(p=>{if(p.kind==="house")return!0;for(const x of f){const[m,g]=yo(p.x,p.y,25,x);if(m!==p.x||g!==p.y)return!1}return!0})}function yo(i,e,t,n){if(n.soft)return[i,e];if(n.kind==="house"){const l=Math.cos(n.angle),u=Math.sin(n.angle),h=i-n.x,d=e-n.y;let f=h*l+d*u,p=-h*u+d*l;const x=Ws(f,-n.hw,n.hw),m=Ws(p,-n.hd,n.hd);if(x===f&&m===p){const M=n.hw-Math.abs(f),S=n.hd-Math.abs(p);M<S?f=(f<0?-1:1)*(n.hw+t):p=(p<0?-1:1)*(n.hd+t)}else{const M=f-x,S=p-m,_=M*M+S*S;if(_>=t*t)return[i,e];const A=Math.sqrt(_)||1,E=t-A;f+=M/A*E,p+=S/A*E}return[n.x+f*l-p*u,n.y+f*u+p*l]}const s=i-n.x,o=e-n.y,r=t+n.r,a=s*s+o*o;if(a>=r*r)return[i,e];const c=Math.sqrt(a);return c<1e-4?[n.x+r,n.y]:[n.x+s/c*r,n.y+o/c*r]}function Ho(i,e,t,n){if(!n)return[i,e];let s=i,o=e;for(const r of n){const a=yo(s,o,t,r);s=a[0],o=a[1]}return[s,o]}function Gl(i,e,t,n,s){if(!s)return!1;for(const o of s)if(!(o.soft||t>o.top)){if(o.kind==="house"){const r=Math.cos(o.angle),a=Math.sin(o.angle),c=i-o.x,l=e-o.y,u=c*r+l*a,h=-c*a+l*r;if(Math.abs(u)<=o.hw+n&&Math.abs(h)<=o.hd+n)return!0}else if(Kt(i,e,o.x,o.y)<=o.r+n)return!0}return!1}const Qr=Object.freeze([{id:"castle",name:"Crown Castle",x:0,y:0,radius:1450},{id:"highlands",name:"Enchanted Highlands",x:-4300,y:-4100,radius:1500},{id:"harvest",name:"Harvest Village",x:4300,y:-3200,radius:1500},{id:"harbor",name:"Western Harbor",x:-5600,y:3500,radius:1450},{id:"desert-town",name:"Sunken Desert",x:4700,y:4700,radius:1550},{id:"mine",name:"Eastern Mine",x:yt.mine.x,y:yt.mine.y,radius:1300}]),kg=Object.freeze(["castle","highlands","desert-town"]),as=Object.freeze({edgeMargin:620,riverMargin:250,pondMargin:95,obstacleMargin:26,minimumSpacing:175,maximumSlope:.72,majorPoolPerArea:34,activePerMajorArea:8,wildernessPool:110,activeWilderness:24});function Hg(i,e,t=42){const n=(De(i+t,e)-De(i-t,e))/(2*t),s=(De(i,e+t)-De(i,e-t))/(2*t);return Math.hypot(n,s)}function Gg(i,e){const t=Math.hypot(i,e);if(t<155||Math.abs(t-340)<78)return!0;const n=fi.find(c=>c.biome==="farm");if(Kt(i,e,n.x,n.y)<120)return!0;const s=fi.find(c=>c.biome==="coast"),o=Math.hypot(s.x,s.y)||1,r=s.x/o*(o+1400),a=s.y/o*(o+1400);return Kt(i,e,r,a)<105}function ih(i,e,t=[],n=[]){return Math.hypot(i,e)>Cn.radius-as.edgeMargin||De(i,e)<14||lr(i,e).distance<as.riverMargin||Kt(i,e,yt.pond.x,yt.pond.y)<yt.pond.r+as.pondMargin||Hg(i,e)>as.maximumSlope||Gg(i,e)||Gl(i,e,1,Hl+as.obstacleMargin,t)?!1:!n.some(o=>Kt(i,e,o.x,o.y)<as.minimumSpacing)}function Nc(i,e){for(let t=i.length-1;t>0;t--){const n=Math.floor(e()*(t+1));[i[t],i[n]]=[i[n],i[t]]}return i}const ou=1370480931;let ru=null,Pf=-1;function Vg(i=[],e=ou){if(e===ou&&i.length>0&&ru&&Pf===i.length)return ru.map(c=>({...c}));const t=xd(e),n=[];let s=0;const o=(c,l,u,h,d=!1)=>ih(c,l,i,n)?(n.push({id:`loot-spawn-${s++}`,x:c,y:l,groundHeight:De(c,l),areaId:u,density:h,core:d}),!0):!1;for(const c of Qr){let l=0,u=0;for(;l<as.majorPoolPerArea&&u++<9e3;){const h=c.id==="castle"&&l<4,d=h?175:90,f=h?250:c.radius,p=t()*Math.PI*2,x=Math.sqrt(d*d+t()*(f*f-d*d));o(c.x+Math.cos(p)*x,c.y+Math.sin(p)*x,c.id,"major",h)&&l++}}let r=0,a=0;for(;r<as.wildernessPool&&a++<18e3;){const c=t()*Math.PI*2,l=Math.sqrt(t())*(Cn.radius-as.edgeMargin-100),u=Math.cos(c)*l,h=Math.sin(c)*l;Qr.some(d=>Kt(u,h,d.x,d.y)<d.radius+as.minimumSpacing)||o(u,h,"wilderness","wilderness")&&r++}return e===ou&&i.length>0&&(ru=n.map(c=>({...c})),Pf=i.length),n}function dl(i){const e=on[i];return!!e&&(e.damage>0||e.splashDamage>0||e.damagePerSecond>0)}function Br(i,e){return i[Math.min(i.length-1,Math.floor(e()*i.length))]}function zg(i){let e=th(i);for(;e==="mythic";)e=th(i);return e}function Wg(i,e,t=!1){if(i==="regular"){const n=t?eh.filter(dl):eh;return{lootType:"attack",attackId:Br(n,e)}}if(i==="healing-protection")return{lootType:"attack",attackId:Br(Rg,e)};if(i==="movement")return{lootType:"attack",attackId:Br(Ag,e)};if(i==="special"){const n=[...Cg,Sf],s=Br(n,e);return s===Sf?{lootType:"weapon-upgrade-rune",attackId:null}:{lootType:"attack",attackId:s}}return i==="tier-1"||i==="tier-2"?{lootType:"tier-scroll",attackId:Pg(i==="tier-1"?1:2,e)}:{lootType:"attack",attackId:Br(Eg,e)}}const Xg=10975941;function qg(i=[],e=Xg){const t=xd(e),n=Vg(i),s=[];for(const f of Qr){const p=Nc(n.filter(x=>x.areaId===f.id),t);if(f.id==="castle"){const x=p.find(m=>m.core);x&&s.push(x)}for(const x of p){if(s.includes(x))continue;if(s.filter(g=>g.areaId===f.id).length>=as.activePerMajorArea)break;s.push(x)}}s.push(...Nc(n.filter(f=>f.areaId==="wilderness"),t).slice(0,as.activeWilderness));const o=s.map(()=>th(t)),r=Nc(s.map((f,p)=>kg.includes(f.areaId)?p:-1).filter(f=>f>=0),t),a=o.filter(f=>f==="mythic").length,c=Math.max(1,Math.min(3,a)),l=new Set(r.slice(0,c));for(let f=0;f<o.length;f++)l.has(f)?o[f]="mythic":o[f]==="mythic"&&(o[f]=zg(t));const u=s.map((f,p)=>{const x=o[p],m=Wg(x,t);return{id:p,spawnPointId:f.id,areaId:f.areaId,density:f.density,category:x.startsWith("tier-")?"tier":x,tier:x==="tier-1"?1:x==="tier-2"?2:null,lootType:m.lootType,attackId:m.attackId,rarity:Ig(t),x:f.x,y:f.y,groundHeight:f.groundHeight,collectedBy:null}}),h=new Set(s.map(f=>f.id)),d=Nc(n.filter(f=>!h.has(f.id)),t).slice(0,Ha.length*2);for(let f=0;f<d.length;f++){const p=d[f],x=Ha[f%Ha.length];u.push({id:u.length,spawnPointId:p.id,areaId:p.areaId,density:p.density,category:"mana-ammunition",tier:null,lootType:"mana-ammunition",attackId:null,ammoType:x,amount:$i[x].pickup,rarity:"common",x:p.x,y:p.y,groundHeight:p.groundHeight,collectedBy:null})}for(const f of Qr){const p=u.filter(g=>g.areaId===f.id);let x=p.filter(g=>dl(g.attackId)).length;const m=p.filter(g=>g.category!=="mythic"&&g.lootType!=="mana-ammunition"&&!dl(g.attackId));for(const g of m){if(x>=3)break;g.category="regular",g.tier=null,g.lootType="attack",g.attackId=Br(eh.filter(dl),t),x++}}return u}function Am(i,e){const t=on[e];return!i||(t==null?void 0:t.scope)!=="tier"?null:bm.find(n=>{const s=on[n];return s.weaponId===i.baseWeaponId&&s.tier===t.tier})||null}function Rm(i,e,t){var o,r,a,c,l;if(!i||!e||!t||t.collectedBy!=null)return!1;if(t.lootType==="mana-ammunition"){const u=iu(e,t.ammoType,t.amount);return u<=0?!1:(t.collectedBy=e.id,i.events.push({type:"mana-pickup",wizardId:e.id,ammoType:t.ammoType,amount:u}),!0)}if(t.lootType==="weapon-upgrade-rune"){const u=Kn[e.baseWeaponRarity]?e.baseWeaponRarity:"common",h=Dg(e,t.rarity);return t.collectedBy=e.id,i.events.push({type:"weapon-upgrade",wizardId:e.id,runeRarity:t.rarity,previousRarity:u,rarity:h,upgraded:h!==u}),!0}const n=on[t.attackId];if(!n)return!1;if(n.scope==="tier"){const u=Am(e,t.attackId);if(!u)return!1;const h=e.tierAttackId||((o=e.attackInventory)==null?void 0:o.find(x=>{var m;return((m=on[x])==null?void 0:m.scope)==="tier"}))||null;if(t.collectedBy=e.id,h){const x=on[h].ammoType,m=iu(e,x,((r=$i[x])==null?void 0:r.pickup)||0);return i.events.push({type:"attack-pickup",wizardId:e.id,attackId:h,originalAttackId:t.attackId,compatible:!0,equipped:!1,convertedToMana:!0,manaEnergy:m,ammoType:x}),!0}if(!wf(e,u,t.rarity))return!1;const d=on[u].ammoType,f=iu(e,d,((a=$i[d])==null?void 0:a.pickup)||0);let p=su(e,u);return p||(p=su(e,u,vo-1)),i.events.push({type:"attack-pickup",wizardId:e.id,attackId:u,originalAttackId:t.attackId,compatible:!0,equipped:p,tierClaimed:!0,manaEnergy:f,ammoType:d,rarity:cr(e,u)}),!0}if((c=e.attackInventory)!=null&&c.includes(t.attackId)){const u=cr(e,t.attackId),h=co.indexOf(u);return co.indexOf(t.rarity)<=h?!1:(e.attackRarities[t.attackId]=t.rarity,t.collectedBy=e.id,i.events.push({type:"attack-pickup",wizardId:e.id,attackId:t.attackId,compatible:!0,equipped:(l=e.attackSlots)==null?void 0:l.includes(t.attackId),upgraded:!0,rarity:t.rarity}),!0)}if(!wf(e,t.attackId,t.rarity))return!1;t.collectedBy=e.id;const s=su(e,t.attackId);return i.events.push({type:"attack-pickup",wizardId:e.id,attackId:t.attackId,compatible:!0,equipped:s,rarity:cr(e,t.attackId)}),!0}function Yg(i,e){let t=0;for(const n of i.attackPickups||[])n.collectedBy==null&&(Kt(e.x,e.y,n.x,n.y)>Hl+Ct.radius||Rm(i,e,n)&&t++);return t}function Kg(i,e){const t=_d(i,e);return!t||Kt(e.x,e.y,t.x,t.y)>Hl+Ct.radius?!1:Rm(i,e,t)}function _d(i,e,t=!1,n=!1){var r,a;let s=null,o=1/0;for(const c of i.attackPickups||[]){if(c.collectedBy!=null||n&&((r=on[c.attackId])==null?void 0:r.scope)!=="tier"||t&&((a=on[c.attackId])==null?void 0:a.scope)!=="tier"&&!tc(e,c.attackId))continue;const l=Kt(e.x,e.y,c.x,c.y);l<o&&(s=c,o=l)}return s}function Zg(i,e,t=null){let n=null,s=1/0;for(const o of i.attackPickups||[]){if(o.collectedBy!=null||o.lootType!=="mana-ammunition"||t&&o.ammoType!==t)continue;const r=Kt(e.x,e.y,o.x,o.y);r<s&&(n=o,s=r)}return n}function $g({players:i=1,bots:e=9,opening:t=!1,baseWeapon:n="apprentice-wand",lootSeed:s=null}={}){const o=fr[n]?n:"apprentice-wand",r=i+e,a=t?155:rs.startRadius*.72,c=nh(),l=[];for(let h=0;h<r;h++){const d=h/r*Math.PI*2,f=h<i,p=rs.cx+Math.cos(d)*a,x=rs.cy+Math.sin(d)*a,[m,g]=t?[p,x]:Ho(p,x,Ct.radius,c),M={id:h,isPlayer:f,playerIndex:f?h:-1,color:Ef[h%Ef.length],x:m,y:g,vx:0,vy:0,heading:d+Math.PI,health:Ct.maxHealth,shield:0,slowFactor:1,slowTimer:0,hasteFactor:1,hasteTimer:0,empowerFactor:1,empowerTimer:0,curseTimer:0,regenTimer:0,regenHealthPerSecond:0,regenShieldPerSecond:0,abilityFlightTimer:0,runeKeys:0,mana:0,manaMax:0,manaPouch:pd(),itemUse:null,tierAttackId:null,baseWeaponRarity:"common",attackRarities:{},dotDamage:0,dotTimer:0,cooldowns:gd(),slashTimer:0,castTimer:0,aiMoveX:0,aiMoveY:0,targetId:null,wantClimb:!1,climbState:null,climbOver:null,climbH:0,climbBlocked:!1,climbNearby:[],running:!1,stamina:Ds.max,staminaRegenDelay:0,staminaExhausted:!1,jumpH:0,jumpV:0,flying:!1,flyH:0,openingH:t?Un.platformHeight-De(m,g):0,slowFalling:!1,openingLanded:!t,chosenPortal:null,portalLandingX:null,portalLandingY:null,aimTargetId:null,bodyHeight:f?Tg:dr,weaponLocked:!0,attackInventory:[],attackSlots:Array(vo).fill(null),attack:null,alive:!0,placement:0},S=f?o:ka[(h-i)%ka.length];Object.defineProperty(M,"baseWeaponId",{value:S,enumerable:!0,writable:!1,configurable:!1}),l.push(M)}const u=Number.isInteger(s)?s>>>0:(Date.now()^Math.floor(Math.random()*4294967295))>>>0;return{wizards:l,obstacles:c,spells:[],storm:{cx:rs.cx,cy:rs.cy,radius:rs.startRadius},time:0,over:!1,winnerId:null,playerWon:!1,sandbox:e===0,events:[],baseWeaponId:o,attackPickups:qg(c,u),lootSeed:u,opening:bg(t)}}function Jg(i){return i.wizards.filter(e=>e.alive).length}function jg(i,e,t,n){if(i.staminaExhausted){if(i.running=!1,i.staminaRegenDelay>0){i.staminaRegenDelay=Math.max(0,i.staminaRegenDelay-n);return}i.staminaExhausted=!1,i.stamina=Math.min(Ds.max,i.stamina+Ds.regenPerSec*n);return}const s=e&&t&&i.stamina>0;if(i.running=s,s){i.stamina=Math.max(0,i.stamina-Ds.drainPerSec*n),i.stamina<=0?(i.stamina=0,i.staminaExhausted=!0,i.staminaRegenDelay=Ds.emptyDelay):i.staminaRegenDelay=Ds.partialDelay;return}i.stamina>=Ds.max||(i.staminaRegenDelay>0?i.staminaRegenDelay=Math.max(0,i.staminaRegenDelay-n):i.stamina=Math.min(Ds.max,i.stamina+Ds.regenPerSec*n))}function Cm(i){return i.kind==="house"?i.h*1.7:Math.min(i.top,150)}function vd(i){return Ba(i)+Cm(i)}function Pm(i,e,t){return vd(i)-De(e,t)}function If(i){return i.kind==="house"?Math.hypot(i.hw,i.hd):i.r||0}function Im(i,e){const t=If(i);return(e||[]).filter(n=>{if(n===i||n.soft)return!1;const s=t+If(n)+Ct.radius+Fo.wallGap+80;return Kt(i.x,i.y,n.x,n.y)<=s})}function Qg(i,e,t,n){for(const s of i.climbNearby||[]){if(Ba(s)+(s.top||Cm(s))<=n+6)continue;const[r,a]=yo(e,t,Ct.radius,s);if(r!==e||a!==t)return!0}return!1}function ex(i,e,t,n,s){if(i.flying){i.climbState=null,i.climbOver=null,i.climbBlocked=!1,i.climbNearby=[],i.jumpH=0,i.jumpV=0;const u=Pi(e,t);if(!u.x&&!u.y)return;let h=i.x+u.x*Sl.speed*n,d=i.y+u.y*Sl.speed*n;const f=Kt(h,d,0,0);f>Cn.radius&&(h=h/f*Cn.radius,d=d/f*Cn.radius),i.x=h,i.y=d;return}if(i.climbState==="wall")return tx(i,e,t,n);if(i.climbState==="top")return nx(i,e,t,n);const o=Pi(e,t);if(o.x===0&&o.y===0)return;const r=(i.running?Ct.runSpeed:Ct.speed)*(i.slowFactor||1)*(i.hasteFactor||1);let a=i.x+o.x*r*n,c=i.y+o.y*r*n;const l=Kt(a,c,0,0);if(l>Cn.radius&&(a=a/l*Cn.radius,c=c/l*Cn.radius),s){if(i.isPlayer&&i.wantClimb&&(i.jumpH||0)<=0&&(i.jumpV||0)<=0)for(const d of s){if(d.soft)continue;const[f,p]=yo(a,c,Ct.radius,d);if(f===a&&p===c)continue;const x=Pi(d.x-i.x,d.y-i.y);if(o.x*x.x+o.y*x.y>.4){i.climbState="wall",i.climbOver=d,i.climbBlocked=!1,i.climbNearby=Im(d,s);const[m,g]=Ho(a,c,Ct.radius,s),[M,S]=yo(m,g,Ct.radius+Fo.wallGap,d);i.x=M,i.y=S;return}}const[u,h]=Ho(a,c,Ct.radius,s);i.x=u,i.y=h;return}i.x=a,i.y=c}function tx(i,e,t,n){const s=i.climbOver;if(!s){i.climbState=null,i.climbBlocked=!1,i.climbNearby=[];return}if(i.climbBlocked){if(i.wantClimb)return;i.climbBlocked=!1}i.climbH+=(i.wantClimb?Fo.up:-260*.9)*n;const o=Pi(e,t);let r=i.x+o.x*Fo.side*n,a=i.y+o.y*Fo.side*n;[r,a]=yo(r,a,Ct.radius+Fo.wallGap,s);for(const u of i.climbNearby||[])[r,a]=yo(r,a,Ct.radius,u);i.x=r,i.y=a;const c=vd(s),l=c-De(i.x,i.y);if(i.climbH>=l){const u=Pi(s.x-i.x,s.y-i.y),h=Ct.radius*2+Fo.wallGap+8,d=i.x+u.x*h,f=i.y+u.y*h;if(Qg(i,d,f,c)){i.climbH=Math.max(0,l-1),i.climbBlocked=!0;return}i.climbH=Pm(s,d,f),i.climbState="top",i.climbBlocked=!1,i.x=d,i.y=f}else i.climbH<=0&&(i.climbH=0,i.climbState=null,i.climbOver=null,i.climbBlocked=!1,i.climbNearby=[])}function nx(i,e,t,n){const s=i.climbOver;if(!s){i.climbState=null,i.climbBlocked=!1,i.climbNearby=[];return}i.climbH=Pm(s,i.x,i.y);const o=Pi(e,t),r=(i.running?Ct.runSpeed:Ct.speed)*(i.slowFactor||1)*(i.hasteFactor||1);let a=i.x+o.x*r*n,c=i.y+o.y*r*n;const l=Kt(a,c,0,0);l>Cn.radius&&(a=a/l*Cn.radius,c=c/l*Cn.radius);for(const f of i.climbNearby||[]){const[p,x]=yo(a,c,Ct.radius,f);a=p,c=x}i.x=a,i.y=c;const[u,h]=yo(i.x,i.y,0,s);u!==i.x||h!==i.y||(i.climbState=null,i.climbOver=null,i.climbBlocked=!1,i.climbNearby=[])}function ix(i,e,t="bolt"){const n=Fs[t]||Fs.bolt,s=e.cooldowns||(e.cooldowns=gd());return n.type==="projectile"?mx(i,e):n.type==="melee"?gx(i,e,n):n.type==="self"&&(e.health=Math.min(Ct.maxHealth,e.health+n.heal),i.events.push({type:"heal",id:e.id,amount:n.heal})),s[t]=0,e.castTimer=1,!0}function sx(i,e,t,n=Tm){var d;const s=on[t];if(!s||!((d=e.attackSlots)!=null&&d.includes(t))||!tc(e,t)||e.itemUse)return!1;if(s.consumable&&s.channelTime>0)return e.itemUse={attackId:t,remaining:s.channelTime,total:s.channelTime},e.castTimer=1,i.events.push({type:"item-use-start",wizardId:e.id,attackId:t,duration:s.channelTime,color:s.color}),!0;const o=e.cooldowns||(e.cooldowns=gd()),r=`attack:${t}`,a=md(e,t),c=Kn[a.rarity],l=typeof a.manaPerSecond=="number"?Math.max(0,Math.round(a.manaPerSecond*Math.max(0,n)*c.energyUse*100)/100):a.manaCost||0;if(wm(e,t)<l)return!1;const u=rx(i,e,a);let h=!0;return a.kind==="projectile"?Dm(i,e,u):a.kind==="beam"?lx(i,e,u):a.kind==="melee"?Um(i,e,u):a.kind==="nova"?Sd(i,e,u):a.kind==="heal"?Fm(i,e,u):a.kind==="shield"?Om(i,e,u):a.kind==="dash"?ux(i,e,u):a.kind==="trap"?hx(i,e,u):a.kind==="grapple"?dx(i,e,u):a.kind==="movement"?fx(i,e,u):a.kind==="summon"?px(i,e,u):a.kind==="utility"?Bm(i,e,u):h=!1,!h||!Lg(e,t,l)?!1:(s.consumable&&Lm(e,t),o[r]=0,e.attack=s.consumable?null:t,e.castTimer=1,i.events.push({type:"attack-cast",wizardId:e.id,attackId:t,kind:s.kind,color:s.color,rarity:a.rarity,rarityColor:a.rarityColor,manaCost:l,ammoType:s.ammoType,consumed:!!s.consumable}),!0)}function Lm(i,e){i.attackInventory=(i.attackInventory||[]).filter(t=>t!==e),i.attackSlots=(i.attackSlots||[]).map(t=>t===e?null:t),i.attackRarities&&delete i.attackRarities[e],i.tierAttackId===e&&(i.tierAttackId=null)}function ox(i,e,t){var o;if(!e.itemUse||(e.itemUse.remaining=Math.max(0,e.itemUse.remaining-t),e.itemUse.remaining>0))return;const n=e.itemUse.attackId,s=on[n];if(e.itemUse=null,!(!s||!((o=e.attackInventory)!=null&&o.includes(n)))){if(s.kind==="heal")Fm(i,e,s);else if(s.kind==="shield")Om(i,e,s);else if(s.kind==="utility")Bm(i,e,s);else return;Lm(e,n),e.attack=null,i.events.push({type:"item-use-complete",wizardId:e.id,attackId:n,color:s.color})}}function rx(i,e,t){if(!t.shifting)return t;const n=[{form:"heavy",damage:t.damage*1.7,speed:t.speed*.72,radius:22},{form:"rapid",damage:t.damage*.58,speed:t.speed*1.5,count:3,spread:.12},{form:"seeking",damage:t.damage*.85,speed:t.speed*.8,homing:6},{form:"explosive",explosionRadius:150,splashDamage:t.damage*.7}],s=n[Math.floor(Math.random()*n.length)];return i.events.push({type:"shift-form",wizardId:e.id,attackId:t.id,form:s.form,color:t.color}),{...t,...s}}function yd(i){const e=i.heading,t=(i.climbH||0)+(i.flyH||0)+(i.jumpH||0);return{x:i.x+Math.cos(e)*(Ct.radius+8),y:i.y+Math.sin(e)*(Ct.radius+8),z:t+_i.castHeight}}function Md(i,e){const t=i.heading,n=i.aimX??i.x+Math.cos(t)*600,s=i.aimY??i.y+Math.sin(t)*600,o=i.aimZ??_i.castHeight,r=n-e.x,a=s-e.y,c=o-e.z,l=Math.hypot(r,a,c)||1;return{tx:n,ty:s,tz:o,dx:r/l,dy:a/l,dz:c/l,length:l}}function nc(i,e){return e*(i.empowerTimer>0&&i.empowerFactor||1)}function Dm(i,e,t){const n=yd(e),s=Md(e,n),o=t.count||1,r=t.spread||0;for(let a=0;a<o;a++){const c=e.curseTimer>0?(Math.random()-.5)*.65:0,l=(o===1?0:(a/(o-1)-.5)*r)+c,u=Math.cos(l),h=Math.sin(l),d=s.dx*u-s.dy*h,f=s.dx*h+s.dy*u,p=t.speed||_i.speed,m=o===1||Math.abs(l)<.001?i.wizards.find(g=>g.id===e.aimTargetId&&g.alive&&g.id!==e.id):null;i.spells.push({kind:"projectile",attackId:t.id,x:n.x,y:n.y,z:n.z,originX:n.x,originY:n.y,originGround:De(e.x,e.y),targetId:(m==null?void 0:m.id)??null,targetDistance:m?s.length:null,travelled:0,vx:d*p,vy:f*p,vz:s.dz*p+p*(t.upward||0),gravity:t.gravity||0,life:t.life||2.5,ownerId:e.id,radius:t.radius||10,damage:nc(e,t.damage||0),color:t.color,trail:t.trail||72,remainingPierce:t.pierce||0,bounces:t.bounces||0,hitIds:[],homing:t.homing||0,explosionRadius:t.explosionRadius||0,splashDamage:nc(e,t.splashDamage||0),knockback:t.knockback||0,pull:t.pull||0,slow:t.slow||0,poison:t.poison||0,burn:t.burn||0,statusTime:t.statusTime||0,chain:t.chain||0,chainRange:t.chainRange||0})}i.events.push({type:"cast",x:e.x,y:e.y,color:t.color})}function ax(i,e,t,n,s){const o=n-e,r=s-t,a=o*o+r*r||1,c=Ws(((i.x-e)*o+(i.y-t)*r)/a,0,1);return{distance:Kt(i.x,i.y,e+o*c,t+r*c),along:c}}function cx(i,e){e.slow&&(i.slowFactor=Math.min(i.slowFactor||1,e.slow),i.slowTimer=Math.max(i.slowTimer||0,e.statusTime||1.5)),(e.poison||e.burn)&&(i.dotDamage=Math.max(i.dotDamage||0,e.poison||e.burn),i.dotTimer=Math.max(i.dotTimer||0,e.statusTime||3)),e.curse&&(i.curseTimer=Math.max(i.curseTimer||0,e.statusTime||6))}function Lf(i,e,t,n,s){if(!s)return;const o=Pi(e.x-t,e.y-n),r=s<0?-1:1;let a=e.x+o.x*Math.abs(s)*r,c=e.y+o.y*Math.abs(s)*r;const l=Kt(a,c,0,0);l>Cn.radius&&(a=a/l*Cn.radius,c=c/l*Cn.radius),[e.x,e.y]=Ho(a,c,Ct.radius,i.obstacles)}function vr(i,e,t,n,s,o){if(!(e!=null&&e.alive)||t<=0)return 0;e.regenStopsOnDamage&&(e.regenTimer=0,e.regenHealthPerSecond=0,e.regenShieldPerSecond=0,e.regenStopsOnDamage=!1,i.events.push({type:"restoration-interrupted",wizardId:e.id}));let r=t;if((e.shield||0)>0){const a=Math.min(e.shield,r);e.shield-=a,r-=a,i.events.push({type:"shield-hit",victim:e.id,amount:a})}return e.health-=r,cx(e,n),n.knockback&&Lf(i,e,s,o,n.knockback),n.pull&&Lf(i,e,s,o,-n.pull),r}function lx(i,e,t){const n=yd(e),s=Md(e,n),o=t.range||4e3,r=n.x+s.dx*o,a=n.y+s.dy*o,c=i.wizards.filter(h=>h.alive&&h.id!==e.id).map(h=>({target:h,...ax(h,n.x,n.y,r,a)})).filter(({target:h,distance:d})=>d<=Ct.radius+(t.width||8)&&sh(e,h,i.obstacles)).sort((h,d)=>h.along-d.along),l=i.wizards.find(h=>h.id===e.aimTargetId&&h.alive&&h.id!==e.id);l&&!c.some(({target:h})=>h===l)&&Kt(e.x,e.y,l.x,l.y)<=o&&sh(e,l,i.obstacles)&&c.unshift({target:l,along:0,distance:0});const u=1+(t.pierce||0);for(const{target:h}of c.slice(0,u))vr(i,h,nc(e,t.damage),t,e.x,e.y),i.events.push({type:"hit",x:h.x,y:h.y,z:dr*.55,worldZ:De(h.x,h.y)+dr*.55,color:t.color,victim:h.id});i.events.push({type:"beam",x:n.x,y:n.y,z:n.z,endX:r,endY:a,endZ:n.z+s.dz*o,color:t.color,width:t.width||8})}function Nm(i,e,t,n=Math.PI*2){const s=n/2;return i.wizards.filter(o=>{if(!o.alive||o.id===e.id||Kt(e.x,e.y,o.x,o.y)>t+Ct.radius)return!1;if(n>=Math.PI*2-.001)return!0;const r=Math.atan2(o.y-e.y,o.x-e.x);return Math.abs(Em(r-e.heading))<=s})}function Um(i,e,t){e.slashTimer=.42,t.haste&&(e.hasteFactor=Math.max(e.hasteFactor||1,t.haste),e.hasteTimer=Math.max(e.hasteTimer||0,t.statusTime||4));for(const n of Nm(i,e,t.range,t.arc))vr(i,n,nc(e,t.damage),t,e.x,e.y),i.events.push({type:"slashhit",x:n.x,y:n.y,victim:n.id,color:t.color});i.events.push({type:"slash",x:e.x,y:e.y,dir:e.heading,color:t.color,range:t.range})}function Sd(i,e,t){for(const n of Nm(i,e,t.range))vr(i,n,nc(e,t.damage),t,e.x,e.y);i.events.push({type:"nova",x:e.x,y:e.y,range:t.range,color:t.color})}function Fm(i,e,t){if(e.health=Math.min(Ct.maxHealth,e.health+(t.heal||0)),t.shield&&(e.shield=Math.min(t.shieldCap||100,(e.shield||0)+t.shield)),t.healOverTime||t.shieldOverTime){const n=t.duration||6;e.regenTimer=Math.max(e.regenTimer||0,n),e.regenHealthPerSecond=Math.max(e.regenHealthPerSecond||0,(t.healOverTime||0)/n),e.regenShieldPerSecond=Math.max(e.regenShieldPerSecond||0,(t.shieldOverTime||0)/n),e.regenStopsOnDamage=!!t.stopsOnDamage}t.cleanse&&(e.slowTimer=0,e.slowFactor=1,e.dotTimer=0,e.dotDamage=0),i.events.push({type:"heal",id:e.id,amount:t.heal||0,color:t.color})}function Om(i,e,t){e.shield=Math.min(t.shieldCap||100,(e.shield||0)+(t.shield||0)),t.damage&&t.range&&Sd(i,e,t),i.events.push({type:"shield",id:e.id,x:e.x,y:e.y,radius:85,amount:t.shield,color:t.color})}function ux(i,e,t){const n=Math.cos(e.heading),s=Math.sin(e.heading),[o,r]=Ho(e.x+n*t.dash,e.y+s*t.dash,Ct.radius,i.obstacles);e.x=o,e.y=r,Um(i,e,t),i.events.push({type:"blink",x:o,y:r,color:t.color})}function hx(i,e,t){i.spells.push({kind:"trap",attackId:t.id,x:e.x,y:e.y,z:3,originX:e.x,originY:e.y,originGround:De(e.x,e.y),vx:0,vy:0,vz:0,life:t.life,armTime:t.armTime,ownerId:e.id,radius:16,damage:t.damage,explosionRadius:t.range,splashDamage:t.damage,color:t.color}),i.events.push({type:"trap",x:e.x,y:e.y,color:t.color})}function dx(i,e,t){const n=yd(e),s=Md(e,n),o=Math.min(t.range,s.length);let r=e.x+s.dx*o,a=e.y+s.dy*o;[r,a]=Ho(r,a,Ct.radius,i.obstacles),e.x=r,e.y=a,i.events.push({type:"grapple",x:n.x,y:n.y,endX:r,endY:a,color:t.color})}function fx(i,e,t){if(t.dash){const n=Math.cos(e.heading),s=Math.sin(e.heading);[e.x,e.y]=Ho(e.x+n*t.dash,e.y+s*t.dash,Ct.radius,i.obstacles)}t.launch&&(e.jumpV=Math.max(e.jumpV||0,t.launch),e.jumpH=Math.max(e.jumpH||0,1)),t.flightTime&&(e.abilityFlightTimer=Math.max(e.abilityFlightTimer||0,t.flightTime),e.flyH=Math.max(e.flyH||0,t.launch||150),e.flying=!0),t.haste&&(e.hasteFactor=Math.max(e.hasteFactor||1,t.haste),e.hasteTimer=Math.max(e.hasteTimer||0,t.statusTime||5)),t.damage&&t.range&&Sd(i,e,t),i.events.push({type:"movement-cast",wizardId:e.id,x:e.x,y:e.y,color:t.color})}function px(i,e,t){if(!t.zoneType){Dm(i,e,t),i.events.push({type:"summon",wizardId:e.id,summon:t.id,x:e.x,y:e.y,color:t.color});return}i.spells.push({kind:"zone",zoneType:t.zoneType,attackId:t.id,x:e.x,y:e.y,z:3,originX:e.x,originY:e.y,originGround:De(e.x,e.y),vx:0,vy:0,vz:0,life:t.life,ownerId:e.id,radius:t.range,damagePerSecond:t.damagePerSecond||0,healPerSecond:t.healPerSecond||0,shieldPerSecond:t.shieldPerSecond||0,empower:t.empower||0,poison:t.poison||0,statusTime:t.statusTime||0,health:t.health||0,friendlyOnly:!!t.friendlyOnly,color:t.color}),i.events.push({type:"summon-zone",wizardId:e.id,zoneType:t.zoneType,x:e.x,y:e.y,range:t.range,color:t.color})}function Bm(i,e,t){e.runeKeys=(e.runeKeys||0)+(t.keyCount||0),i.events.push({type:"rune-key",wizardId:e.id,keys:e.runeKeys,x:e.x,y:e.y,color:t.color})}function mx(i,e){const t=e.heading,n=e.x+Math.cos(t)*(Ct.radius+8),s=e.y+Math.sin(t)*(Ct.radius+8),r=(e.climbH||0)+(e.flyH||0)+(e.jumpH||0)+_i.castHeight,a=De(e.x,e.y),c=e.aimX??e.x+Math.cos(t)*300,l=e.aimY??e.y+Math.sin(t)*300,u=e.aimZ??_i.castHeight,h=c-n,d=l-s,f=u-r,p=Math.hypot(h,d,f)||1,x=i.wizards.find(m=>m.id===e.aimTargetId&&m.alive&&m.id!==e.id);i.spells.push({x:n,y:s,z:r,originX:n,originY:s,originGround:a,targetId:(x==null?void 0:x.id)??null,targetDistance:x?p:null,travelled:0,vx:h/p*_i.speed,vy:d/p*_i.speed,vz:f/p*_i.speed,life:_i.life,ownerId:e.id,radius:_i.radius,damage:_i.damage,color:Fs.bolt.color}),i.events.push({type:"cast",x:e.x,y:e.y})}function gx(i,e,t){e.slashTimer=t.duration||.42;const n=t.arc/2;for(const s of i.wizards){if(s===e||!s.alive||Kt(e.x,e.y,s.x,s.y)>t.range+Ct.radius)continue;const o=Math.atan2(s.y-e.y,s.x-e.x);Math.abs(Em(o-e.heading))>n||(s.health-=t.damage,i.events.push({type:"slashhit",x:s.x,y:s.y,victim:s.id,color:s.color}))}i.events.push({type:"slash",x:e.x,y:e.y,dir:e.heading})}function kr(i,e,t,n,s){if(!e.explosionRadius)return;const o=on[e.attackId]||e;for(const r of i.wizards){if(!r.alive||r.id===e.ownerId)continue;const a=Kt(t,n,r.x,r.y);if(a>e.explosionRadius+Ct.radius)continue;const c=1-Ws(a/e.explosionRadius,0,.7);vr(i,r,(e.splashDamage||e.damage)*c,o,t,n)}i.events.push({type:"explosion",x:t,y:n,worldZ:s,radius:e.explosionRadius,color:e.color})}function xx(i,e,t){let n=t;const s=new Set([e.ownerId,t.id]),o=on[e.attackId]||e;for(let r=0;r<(e.chain||0);r++){const a=i.wizards.filter(c=>c.alive&&!s.has(c.id)&&Kt(n.x,n.y,c.x,c.y)<=e.chainRange).sort((c,l)=>Kt(n.x,n.y,c.x,c.y)-Kt(n.x,n.y,l.x,l.y))[0];if(!a)break;s.add(a.id),vr(i,a,e.damage*Math.pow(.72,r+1),o,n.x,n.y),i.events.push({type:"chain",x:n.x,y:n.y,endX:a.x,endY:a.y,color:e.color}),n=a}}function Df(i,e,t,n,s,o){let r=on[e.attackId]||e,a=e.damage;if(r.randomEffect){const c=[{effect:"blast",damage:a*1.75,knockback:240},{effect:"gravity",damage:a*.7,pull:260},{effect:"frost",damage:a*.8,slow:.32,statusTime:3.5},{effect:"fire",damage:a*1.05,burn:7,statusTime:4},{effect:"chain",damage:a*.9,curse:!0,statusTime:5}],l=c[Math.floor(Math.random()*c.length)];a=l.damage,r={...r,...l},i.events.push({type:"chaos-effect",effect:l.effect,x:n,y:s,victim:t.id,color:e.color})}return vr(i,t,a,r,n,s),e.hitIds||(e.hitIds=[]),e.hitIds.push(t.id),xx(i,e,t),i.events.push({type:"hit",x:n,y:s,z:o-De(n,s),worldZ:o,color:e.color,victim:t.id}),kr(i,e,n,s,o),(e.remainingPierce||0)>0?(e.remainingPierce--,e.targetId=null,e.targetDistance=null,!1):!0}function _x(i,e,t){if(!e.homing)return;let n=i.wizards.find(u=>u.id===e.targetId&&u.alive&&u.id!==e.ownerId);if(n||(n=i.wizards.filter(u=>{var h;return u.alive&&u.id!==e.ownerId&&!((h=e.hitIds)!=null&&h.includes(u.id))}).sort((u,h)=>Kt(e.x,e.y,u.x,u.y)-Kt(e.x,e.y,h.x,h.y))[0]),!n||Kt(e.x,e.y,n.x,n.y)>1500)return;e.targetId=n.id,e.targetDistance=null;const s=(n.climbH||0)+(n.flyH||0)+(n.jumpH||0)+(n.openingH||0),o=De(n.x,n.y)+s+(n.bodyHeight||dr)*.5,r=e.originGround+e.z,a=vx(n.x-e.x,n.y-e.y,o-r),c=Math.hypot(e.vx,e.vy,e.vz||0),l=1-Math.exp(-e.homing*t);e.vx+=(a.x*c-e.vx)*l,e.vy+=(a.y*c-e.vy)*l,e.vz+=(a.z*c-(e.vz||0))*l}function vx(i,e,t){const n=Math.hypot(i,e,t)||1;return{x:i/n,y:e/n,z:t/n}}function yx(i,e){var n;const t=[];for(const s of i.spells){const o=s;if(Number.isFinite(o.originGround)||(o.originGround=De(o.originX??o.x,o.originY??o.y)),o.kind==="trap"){o.life-=e,o.armTime=Math.max(0,(o.armTime||0)-e),o.armTime<=0&&i.wizards.some(d=>d.alive&&d.id!==o.ownerId&&Kt(o.x,o.y,d.x,d.y)<=o.explosionRadius)||o.life<=0?kr(i,o,o.x,o.y,o.originGround+o.z):t.push(o);continue}if(o.kind==="zone"){o.life-=e;const h=on[o.attackId]||o;for(const d of i.wizards)!d.alive||Kt(o.x,o.y,d.x,d.y)>o.radius||o.friendlyOnly&&d.id!==o.ownerId||(o.damagePerSecond&&d.id!==o.ownerId&&vr(i,d,o.damagePerSecond*e,h,o.x,o.y),o.healPerSecond&&(d.health=Math.min(Ct.maxHealth,d.health+o.healPerSecond*e)),o.shieldPerSecond&&(d.shield=Math.min(100,(d.shield||0)+o.shieldPerSecond*e)),o.empower&&(d.empowerFactor=Math.max(d.empowerFactor||1,o.empower),d.empowerTimer=Math.max(d.empowerTimer||0,.2)));o.life>0?t.push(o):i.events.push({type:"zone-expire",x:o.x,y:o.y,zoneType:o.zoneType,color:o.color});continue}_x(i,o,e);const r=Math.hypot(o.vx,o.vy,o.vz||0),a=Ct.radius+o.radius,c=Math.max(1,Math.ceil(r*e/(a*.75))),l=e/c;let u=!1;for(let h=0;h<c&&!u;h++){const d=o.x,f=o.y;o.vz=(o.vz||0)-(o.gravity||0)*l,o.x+=o.vx*l,o.y+=o.vy*l,o.z=(o.z??_i.castHeight)+o.vz*l,o.travelled=(o.travelled||0)+r*l;const p=De(o.x,o.y),x=o.originGround+o.z,m=x-p;if(m<Math.max(0,o.radius*.25)){if((o.bounces||0)>0){o.bounces--,o.z=p-o.originGround+o.radius*.3,o.vz=Math.max(180,Math.abs(o.vz)*.62),o.vx*=.82,o.vy*=.82,i.events.push({type:"bounce",x:o.x,y:o.y,worldZ:p,color:o.color});continue}i.events.push({type:"block",x:o.x,y:o.y,z:o.z,worldZ:p,color:o.color}),kr(i,o,o.x,o.y,p),u=!0;break}if(Kt(o.x,o.y,0,0)>Cn.radius){u=!0;break}if(Gl(o.x,o.y,m,o.radius,i.obstacles)){if((o.bounces||0)>0){o.bounces--,o.x=d,o.y=f,o.vx*=-.72,o.vy*=-.72,i.events.push({type:"bounce",x:o.x,y:o.y,worldZ:x,color:o.color});continue}i.events.push({type:"block",x:o.x,y:o.y,z:o.z,worldZ:x,color:o.color}),kr(i,o,o.x,o.y,x),u=!0;break}const g=i.spells.find(S=>S.kind==="zone"&&S!==o&&S.ownerId!==o.ownerId&&(S.health||0)>0&&Kt(o.x,o.y,S.x,S.y)<=o.radius+Math.min(32,S.radius*.28)&&m<=58);if(g){g.health-=o.damage||0,i.events.push({type:"zone-hit",x:g.x,y:g.y,zoneType:g.zoneType,health:Math.max(0,g.health),color:g.color}),g.health<=0&&(g.life=0,i.events.push({type:"zone-destroyed",x:g.x,y:g.y,zoneType:g.zoneType,color:g.color})),kr(i,o,o.x,o.y,x),u=!0;break}const M=o.targetId==null?null:i.wizards.find(S=>{var _;return S.id===o.targetId&&S.alive&&!((_=o.hitIds)!=null&&_.includes(S.id))});if(M&&o.targetDistance!=null&&o.travelled>=o.targetDistance){const _=(M.climbH||0)+(M.flyH||0)+(M.jumpH||0)+(M.openingH||0)+(M.bodyHeight||dr)*.55;if(u=Df(i,o,M,M.x,M.y,De(M.x,M.y)+_),u)break}for(const S of i.wizards){if(!S.alive||S.id===o.ownerId||(n=o.hitIds)!=null&&n.includes(S.id))continue;const _=(S.climbH||0)+(S.flyH||0)+(S.jumpH||0)+(S.openingH||0),A=De(S.x,S.y)+_;if(x>=A&&x<=A+(S.bodyHeight||dr)&&Kt(o.x,o.y,S.x,S.y)<=a){u=Df(i,o,S,o.x,o.y,x);break}}}o.life-=e,!u&&o.life>0?t.push(o):!u&&o.explosionRadius&&kr(i,o,o.x,o.y,o.originGround+o.z)}i.spells=t}function Mx(i,e){const t=i.storm;for(const n of i.wizards)n.alive&&Kt(n.x,n.y,t.cx,t.cy)>t.radius&&(n.regenStopsOnDamage&&(n.regenTimer=0,n.regenHealthPerSecond=0,n.regenShieldPerSecond=0,n.regenStopsOnDamage=!1),n.health-=rs.dps*e,i.events.push({type:"storm",victim:n.id}))}function Sx(i){for(const e of i.wizards)e.alive&&e.health<=0&&(e.health=0,e.alive=!1,e.placement=Jg(i)+1,i.events.push({type:"death",x:e.x,y:e.y,color:e.color,id:e.id}))}function bx(i){if(i.over)return;const e=i.wizards.filter(t=>t.alive);if(e.length<=1){i.over=!0;const t=e[0]||null;i.winnerId=t?t.id:null,i.playerWon=!!(t&&t.isPlayer),t&&(t.placement=1),i.events.push({type:"over",winnerId:i.winnerId,playerWon:i.playerWon})}}function Tx(i,e){let t=1/0,n=null;for(const s of i.wizards){if(s===e||!s.alive)continue;const o=Kt(e.x,e.y,s.x,s.y);o<t&&(t=o,n=s)}return n}function wx(i,e,t){if(i.kind==="house"){const o=Math.cos(i.angle),r=Math.sin(i.angle),a=e-i.x,c=t-i.y,l=Ws(a*o+c*r,-i.hw,i.hw),u=Ws(-a*r+c*o,-i.hd,i.hd),h=i.x+l*o-u*r,d=i.y+l*r+u*o;return{x:h,y:d,gap:Kt(e,t,h,d)}}const n=Kt(e,t,i.x,i.y),s=n>1e-4?i.r/n:0;return{x:i.x+(e-i.x)*s,y:i.y+(t-i.y)*s,gap:Math.max(0,n-i.r)}}function sh(i,e,t,n,s){if(!s)return!0;const o=Kt(i,e,t,n),r=Math.max(1,Math.ceil(o/40));for(let a=1;a<r;a++){const c=a/r,l=i+(t-i)*c,u=e+(n-e)*c;if(Gl(l,u,_i.castHeight,_i.radius,s))return!1}return!0}function Ex(i,e,t,n,s){if(!s)return Pi(t,n);const o=120;let r=t,a=n;for(const c of s){if(c.soft)continue;const l=wx(c,i,e);if(l.gap>o)continue;let u=i-l.x,h=e-l.y,d=Math.hypot(u,h);d<.001&&(u=i-c.x,h=e-c.y,d=Math.hypot(u,h)||1);const f=(o-l.gap)/o,p=u/d,x=h/d;r+=p*f*2.2,a+=x*f*2.2;const m=-x,g=p,M=m*t+g*n>=0?1:-1;r+=m*M*f*1.4,a+=g*M*f*1.4}return Pi(r,a)}function Ax(i,e){const t=Tx(i,e),n=i.wizards.find(o=>o.id===e.targetId&&o.alive&&o!==e);let s=t;if(n){const o=Kt(e.x,e.y,n.x,n.y),r=t?Kt(e.x,e.y,t.x,t.y):1/0;o<r*1.3&&(s=n)}return e.targetId=s?s.id:null,s}function Rx(i,e,t=1/60){const n=i.storm,s=i.obstacles,o=Kt(e.x,e.y,n.cx,n.cy),r=Ax(i,e),a=Ws((o-n.radius*.75)/(n.radius*.25),0,1),c=Pi(n.cx-e.x,n.cy-e.y);let l=c.x,u=c.y,h=e.x+Math.cos(e.heading),d=e.y+Math.sin(e.heading),f=!1;if(r){h=r.x,d=r.y;const g=Kt(e.x,e.y,r.x,r.y),M=Pi(r.x-e.x,r.y-e.y),S=sh(e.x,e.y,r.x,r.y,s);let _=Ws((g-280)/120,-.7,1);S||(_=1);let A=M.x*_,E=M.y*_;if(S&&g>=200&&g<=420){const L=e.id%2===0?1:-1;A+=-M.y*L*.8,E+=M.x*L*.8}l=c.x*a+A*(1-a),u=c.y*a+E*(1-a),f=g<520&&a<.8&&S}const p=Ex(e.x,e.y,l,u,s),x=1-Math.exp(-8*t);e.aiMoveX=(e.aiMoveX??0)+(p.x-(e.aiMoveX??0))*x,e.aiMoveY=(e.aiMoveY??0)+(p.y-(e.aiMoveY??0))*x;const m=Math.hypot(e.aiMoveX,e.aiMoveY);return m<.06?{dx:0,dy:0,aimX:h,aimY:d,cast:f}:{dx:e.aiMoveX/m,dy:e.aiMoveY/m,aimX:h,aimY:d,cast:f}}function Cx(i,e,t,n,s=!1){const o=Pi(e,t),r=s?Ct.runSpeed:Ct.speed;i.x+=o.x*r*n,i.y+=o.y*r*n;const a=Math.hypot(i.x,i.y),c=Un.platformRadius-Ct.radius;a>c&&(i.x=i.x/a*c,i.y=i.y/a*c),i.openingH=Un.platformHeight-De(i.x,i.y)}function Nf(i,e,t){const n=jr[t.destination],s=i.wizards.filter(c=>c!==e&&c.slowFalling).map(c=>({x:c.x,y:c.y}));let o=n.x,r=n.y,a=!1;for(let c=0;c<100;c++){const l=Math.random()*Math.PI*2,u=Math.sqrt(Math.random())*n.landingRadius,h=n.x+Math.cos(l)*u,d=n.y+Math.sin(l)*u;if(ih(h,d,i.obstacles,s)){o=h,r=d,a=!0;break}}if(!a)for(let c=0;c<160;c++){const l=c*2.399963,u=Math.sqrt((c+1)/160)*n.landingRadius,h=n.x+Math.cos(l)*u,d=n.y+Math.sin(l)*u;if(ih(h,d,i.obstacles,s)){o=h,r=d;break}}[e.x,e.y]=Ho(o,r,Ct.radius,i.obstacles),e.portalLandingX=e.x,e.portalLandingY=e.y,e.openingH=Un.dropHeight,e.slowFalling=!0,e.openingLanded=!1,e.chosenPortal=t.index,e.heading=Math.atan2(-e.y,-e.x),i.events.push({type:"portal-enter",wizardId:e.id,portalIndex:t.index,destination:n.name,landingX:e.x,landingY:e.y})}function Px(i,e,t){let n=De(e.x,e.y),s=null;for(const o of i.obstacles||[]){if(o.soft||o.kind!=="house")continue;const r=Math.cos(o.angle||0),a=Math.sin(o.angle||0),c=e.x-o.x,l=e.y-o.y,u=c*r+l*a,h=-c*a+l*r,d=Ct.radius*.35;if(Math.abs(u)>Math.max(0,o.hw-d)||Math.abs(h)>Math.max(0,o.hd-d))continue;const f=vd(o);f>t+1||f<=n||(n=f,s=o)}return{height:n,obstacle:s}}function Ix(i,e,t){const n=i.opening,s=n.phase;if(n.elapsed+=t,n.timer=Math.max(0,n.timer-t),n.phase==="countdown"&&n.timer<=0&&(n.phase="choose",n.timer=Un.chooseTime,i.events.push({type:"portals-open"})),n.phase==="choose")for(const a of n.portals)!a.unstable||n.elapsed<a.nextShift||(a.destination=(a.destination+1+a.index)%jr.length,a.nextShift+=2.6+a.index%4*.45,i.events.push({type:"portal-shift",portalIndex:a.index}));for(const a of i.wizards){if(!a.alive||a.openingLanded)continue;if(a.slowFalling){const h=De(a.x,a.y)+a.openingH;let d=0,f=0;if(a.isPlayer){const g=e&&e[a.playerIndex]||{};d=g.dx||0,f=g.dy||0,typeof g.yaw=="number"&&(a.heading=g.yaw)}else{const g=n.portals[a.chosenPortal]||n.portals[0],M=jr[g.destination],S=Pi((a.portalLandingX??M.x)-a.x,(a.portalLandingY??M.y)-a.y);d=S.x,f=S.y,a.heading=Math.atan2(f,d)}const p=Pi(d,f);a.x+=p.x*Un.steerSpeed*t,a.y+=p.y*Un.steerSpeed*t;const x=Px(i,a,h),m=h-Un.fallSpeed*t;a.openingH=Math.max(0,m-De(a.x,a.y)),m<=x.height&&(a.openingH=0,a.slowFalling=!1,a.openingLanded=!0,x.obstacle?(a.climbOver=x.obstacle,a.climbState="top",a.climbH=x.height-De(a.x,a.y),a.climbBlocked=!1,a.climbNearby=Im(x.obstacle,i.obstacles)):(a.climbOver=null,a.climbState=null,a.climbH=0,a.climbBlocked=!1,a.climbNearby=[]),i.events.push({type:"slow-fall-land",wizardId:a.id}));continue}let c=0,l=0,u=!1;if(a.isPlayer){const h=e&&e[a.playerIndex]||{};(s==="choose"||s==="falling")&&(c=h.dx||0,l=h.dy||0,u=!!h.run),typeof h.yaw=="number"&&(a.heading=h.yaw)}else if(s==="choose"&&n.phase==="choose"){const h=n.portals[a.id%n.portals.length],d=Pi(h.x-a.x,h.y-a.y);c=d.x,l=d.y,a.heading=Math.atan2(l,c)}if(Cx(a,c,l,t,u),n.phase==="choose"){for(const h of n.portals)if(Kt(a.x,a.y,h.x,h.y)<=Un.portalRadius){Nf(i,a,h);break}}}const o=i.wizards.filter(a=>a.alive&&!a.openingLanded),r=o.some(a=>!a.slowFalling);if(n.phase==="choose"&&(n.timer<=0||!r)){for(const a of o)if(!a.slowFalling){const c=n.portals[a.id%n.portals.length];Nf(i,a,c)}n.phase="falling",n.timer=0}i.wizards.every(a=>!a.alive||a.openingLanded)&&(n.phase="complete",n.timer=0,i.time=0,i.events.push({type:"opening-complete"}))}function Lx(i,e,t){var n,s,o;if(i.over||(i.events=[],(n=i.opening)!=null&&n.phase&&i.opening.phase!=="complete"&&(Ix(i,e,t),i.opening.phase==="complete"||!i.wizards.filter(a=>a.isPlayer&&a.alive).every(a=>a.openingLanded))))return i;i.time+=t,!i.sandbox&&i.time>rs.shrinkDelay&&(i.storm.radius=Math.max(rs.minRadius,i.storm.radius-rs.shrinkPerSec*t));for(const r of i.wizards){if(!r.alive||((s=i.opening)==null?void 0:s.phase)!=="complete"&&!r.openingLanded)continue;if(r.slowTimer>0&&(r.slowTimer=Math.max(0,r.slowTimer-t),r.slowTimer===0&&(r.slowFactor=1)),r.hasteTimer>0&&(r.hasteTimer=Math.max(0,r.hasteTimer-t),r.hasteTimer===0&&(r.hasteFactor=1)),r.empowerTimer>0&&(r.empowerTimer=Math.max(0,r.empowerTimer-t),r.empowerTimer===0&&(r.empowerFactor=1)),r.curseTimer>0&&(r.curseTimer=Math.max(0,r.curseTimer-t)),r.abilityFlightTimer>0&&(r.abilityFlightTimer=Math.max(0,r.abilityFlightTimer-t)),ox(i,r,t),r.regenTimer>0){const m=Math.min(t,r.regenTimer);r.health=Math.min(Ct.maxHealth,r.health+(r.regenHealthPerSecond||0)*m),r.shield=Math.min(100,(r.shield||0)+(r.regenShieldPerSecond||0)*m),r.regenTimer=Math.max(0,r.regenTimer-t),r.regenTimer===0&&(r.regenHealthPerSecond=0,r.regenShieldPerSecond=0,r.regenStopsOnDamage=!1)}r.dotTimer>0&&(r.regenStopsOnDamage&&(r.regenTimer=0,r.regenHealthPerSecond=0,r.regenShieldPerSecond=0,r.regenStopsOnDamage=!1),r.dotTimer=Math.max(0,r.dotTimer-t),r.health-=(r.dotDamage||0)*t,r.dotTimer===0&&(r.dotDamage=0));let a={x:0,y:0},c=r.x+Math.cos(r.heading),l=r.y+Math.sin(r.heading),u=null,h=!1,d=!1,f=!1,p=!1;if(r.isPlayer){const m=e&&e[r.playerIndex]||{};a={x:m.dx||0,y:m.dy||0},typeof m.aimX=="number"&&(c=m.aimX),typeof m.aimY=="number"&&(l=m.aimY),r.aimX=c,r.aimY=l,r.aimZ=typeof m.aimZ=="number"?m.aimZ:_i.castHeight,r.aimTargetId=Number.isInteger(m.aimTargetId)?m.aimTargetId:null,typeof m.yaw=="number"?r.heading=m.yaw:(c!==r.x||l!==r.y)&&(r.heading=Math.atan2(l-r.y,c-r.x));const g=Object.prototype.hasOwnProperty.call(m,"attack");u=on[m.attack]?m.attack:null,g?u&&r.attackSlots.includes(u)&&tc(r,u)?(r.attack=u,r.spell=on[u].spellId):(r.attack=null,r.spell=null):(r.attack=null,r.spell=Fs[m.spell]?m.spell:"bolt"),r.wantClimb=!!m.up;const M=(r.abilityFlightTimer||0)>0;r.flying=M||i.sandbox&&!!m.flying;const S=Math.hypot(a.x,a.y)>.01;jg(r,!!m.run&&!r.flying,S,t),f=!!m.jump,p=!!m.pickup,d=!!m.dig&&(!((o=i.opening)!=null&&o.phase)||i.opening.phase==="complete"),r.digging=d,r.flying?r.flyH=Math.max(0,r.flyH+(m.flyUp||0)*Sl.vspeed*t):r.flyH>0&&(r.flyH=Math.max(0,r.flyH-Sl.vspeed*t)),h=!!m.cast&&!!r.spell}else{u=r.attackSlots.find(E=>E&&tc(r,E))||null;const m=u?md(r,u):null,g=!!u&&wm(r,u)<((m==null?void 0:m.manaCost)||0)&&!on[u].consumable,M=u?g?Zg(i,r,m==null?void 0:m.ammoType):null:_d(i,r,!0),S=M?{...Pi(M.x-r.x,M.y-r.y),aimX:M.x,aimY:M.y,cast:!1}:Rx(i,r,t);a={x:S.dx??S.x??0,y:S.dy??S.y??0},c=S.aimX,l=S.aimY,r.aimX=c,r.aimY=l,r.aimTargetId=null,r.aimZ=De(c,l)-De(r.x,r.y)+_i.castHeight,(c!==r.x||l!==r.y)&&(r.heading=Math.atan2(l-r.y,c-r.x)),r.attack=u,r.spell=u?on[u].spellId:null,r.running=!1,h=(!i.opening||i.opening.phase==="complete")&&!!u&&i.time>=Sg&&S.cast}for(const m in r.cooldowns)r.cooldowns[m]=0;r.slashTimer>0&&(r.slashTimer=Math.max(0,r.slashTimer-t)),r.castTimer>0&&(r.castTimer=Math.max(0,r.castTimer-t/.28));const x=r.climbState==="top"||r.climbState==null&&r.climbH<=0&&(r.flyH||0)<=0;if(f&&!r.flying&&x&&(r.jumpH||0)<=0&&(r.jumpV=Mf.velocity),h&&(u?sx(i,r,u,t):ix(i,r,r.spell)),d){if(r.nextDigTime=Math.max(0,r.nextDigTime||0),i.time>=r.nextDigTime){const m=r.x+Math.cos(r.heading)*42,g=r.y+Math.sin(r.heading)*42;i.events.push({type:"dig",x:m,y:g,worldZ:De(m,g)+6,color:"#b98b5c"}),r.nextDigTime=i.time+.24}}else r.nextDigTime=0,r.digging=!1;ex(r,a.x,a.y,t,i.obstacles),r.isPlayer?p&&Kg(i,r):Yg(i,r),r.flying||r.climbState==="wall"?(r.jumpH=0,r.jumpV=0):((r.jumpH||0)>0||(r.jumpV||0)>0)&&(r.jumpV-=Mf.gravity*t,r.jumpH+=r.jumpV*t,r.jumpH<=0&&(r.jumpH=0,r.jumpV=0)),!r.flying&&r.climbState==null&&r.climbH>0&&(r.climbH=Math.max(0,r.climbH-Fo.gravity*t))}return yx(i,t),i.sandbox||(Mx(i,t),Sx(i),bx(i)),i}/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const bd="185",Dx=0,Uf=1,Nx=2,Va=1,Ux=2,Da=3,Mo=0,Ii=1,xi=2,po=0,Xr=1,Ci=2,Ff=3,Of=4,Fx=5,nr=100,Ox=101,Bx=102,kx=103,Hx=104,Gx=200,Vx=201,zx=202,Wx=203,oh=204,rh=205,Xx=206,qx=207,Yx=208,Kx=209,Zx=210,$x=211,Jx=212,jx=213,Qx=214,ah=0,ch=1,lh=2,ea=3,uh=4,hh=5,dh=6,fh=7,Td=0,e_=1,t_=2,Vs=0,km=1,Hm=2,Gm=3,wd=4,Vm=5,zm=6,Wm=7,Bf="attached",n_="detached",Xm=300,pr=301,ta=302,au=303,cu=304,Vl=306,mr=1e3,ks=1001,bl=1002,vi=1003,qm=1004,Na=1005,mi=1006,fl=1007,Hs=1008,Yi=1009,Ym=1010,Km=1011,ic=1012,Ed=1013,Xs=1014,cs=1015,So=1016,Ad=1017,Rd=1018,sc=1020,Zm=35902,$m=35899,Jm=1021,jm=1022,Ki=1023,bo=1026,ar=1027,Cd=1028,Pd=1029,gr=1030,Id=1031,Ld=1033,pl=33776,ml=33777,gl=33778,xl=33779,ph=35840,mh=35841,gh=35842,xh=35843,_h=36196,vh=37492,yh=37496,Mh=37488,Sh=37489,Tl=37490,bh=37491,Th=37808,wh=37809,Eh=37810,Ah=37811,Rh=37812,Ch=37813,Ph=37814,Ih=37815,Lh=37816,Dh=37817,Nh=37818,Uh=37819,Fh=37820,Oh=37821,Bh=36492,kh=36494,Hh=36495,Gh=36283,Vh=36284,wl=36285,zh=36286,Qm=2200,Wh=2201,i_=2202,oc=2300,rc=2301,lu=2302,kf=2303,Vr=2400,zr=2401,El=2402,Dd=2500,s_=2501,o_=0,e0=1,Xh=2,r_=3200,Al=0,a_=1,ro="",Yn="srgb",Ji="srgb-linear",Rl="linear",Dn="srgb",Sr=7680,Hf=519,c_=512,l_=513,u_=514,Nd=515,h_=516,d_=517,Ud=518,f_=519,qh=35044,Gf="300 es",Gs=2e3,ac=2001;function p_(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function m_(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function cc(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function g_(){const i=cc("canvas");return i.style.display="block",i}const Vf={};function Cl(...i){const e="THREE."+i.shift();console.log(e,...i)}function t0(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function xt(...i){i=t0(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function Lt(...i){i=t0(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function qr(...i){const e=i.join(" ");e in Vf||(Vf[e]=!0,xt(...i))}function x_(i,e,t){return new Promise(function(n,s){function o(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(o,t);break;default:n()}}setTimeout(o,t)})}const __={[ah]:ch,[lh]:dh,[uh]:fh,[ea]:hh,[ch]:ah,[dh]:lh,[fh]:uh,[hh]:ea};class zo{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const o=s.indexOf(t);o!==-1&&s.splice(o,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let o=0,r=s.length;o<r;o++)s[o].call(this,e);e.target=null}}}const Ai=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let zf=1234567;const za=Math.PI/180,na=180/Math.PI;function us(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ai[i&255]+Ai[i>>8&255]+Ai[i>>16&255]+Ai[i>>24&255]+"-"+Ai[e&255]+Ai[e>>8&255]+"-"+Ai[e>>16&15|64]+Ai[e>>24&255]+"-"+Ai[t&63|128]+Ai[t>>8&255]+"-"+Ai[t>>16&255]+Ai[t>>24&255]+Ai[n&255]+Ai[n>>8&255]+Ai[n>>16&255]+Ai[n>>24&255]).toLowerCase()}function sn(i,e,t){return Math.max(e,Math.min(t,i))}function Fd(i,e){return(i%e+e)%e}function v_(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function y_(i,e,t){return i!==e?(t-i)/(e-i):0}function Wa(i,e,t){return(1-t)*i+t*e}function M_(i,e,t,n){return Wa(i,e,1-Math.exp(-t*n))}function S_(i,e=1){return e-Math.abs(Fd(i,e*2)-e)}function b_(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function T_(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function w_(i,e){return i+Math.floor(Math.random()*(e-i+1))}function E_(i,e){return i+Math.random()*(e-i)}function A_(i){return i*(.5-Math.random())}function R_(i){i!==void 0&&(zf=i);let e=zf+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function C_(i){return i*za}function P_(i){return i*na}function I_(i){return(i&i-1)===0&&i!==0}function L_(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function D_(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function N_(i,e,t,n,s){const o=Math.cos,r=Math.sin,a=o(t/2),c=r(t/2),l=o((e+n)/2),u=r((e+n)/2),h=o((e-n)/2),d=r((e-n)/2),f=o((n-e)/2),p=r((n-e)/2);switch(s){case"XYX":i.set(a*u,c*h,c*d,a*l);break;case"YZY":i.set(c*d,a*u,c*h,a*l);break;case"ZXZ":i.set(c*h,c*d,a*u,a*l);break;case"XZX":i.set(a*u,c*p,c*f,a*l);break;case"YXY":i.set(c*f,a*u,c*p,a*l);break;case"ZYZ":i.set(c*p,c*f,a*u,a*l);break;default:xt("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function vs(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function Nn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Ui={DEG2RAD:za,RAD2DEG:na,generateUUID:us,clamp:sn,euclideanModulo:Fd,mapLinear:v_,inverseLerp:y_,lerp:Wa,damp:M_,pingpong:S_,smoothstep:b_,smootherstep:T_,randInt:w_,randFloat:E_,randFloatSpread:A_,seededRandom:R_,degToRad:C_,radToDeg:P_,isPowerOfTwo:I_,ceilPowerOfTwo:L_,floorPowerOfTwo:D_,setQuaternionFromProperEuler:N_,normalize:Nn,denormalize:vs},lf=class lf{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=sn(this.x,e.x,t.x),this.y=sn(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=sn(this.x,e,t),this.y=sn(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(sn(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(sn(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),o=this.x-e.x,r=this.y-e.y;return this.x=o*n-r*s+e.x,this.y=o*s+r*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};lf.prototype.isVector2=!0;let _e=lf;class ci{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,o,r,a){let c=n[s+0],l=n[s+1],u=n[s+2],h=n[s+3],d=o[r+0],f=o[r+1],p=o[r+2],x=o[r+3];if(h!==x||c!==d||l!==f||u!==p){let m=c*d+l*f+u*p+h*x;m<0&&(d=-d,f=-f,p=-p,x=-x,m=-m);let g=1-a;if(m<.9995){const M=Math.acos(m),S=Math.sin(M);g=Math.sin(g*M)/S,a=Math.sin(a*M)/S,c=c*g+d*a,l=l*g+f*a,u=u*g+p*a,h=h*g+x*a}else{c=c*g+d*a,l=l*g+f*a,u=u*g+p*a,h=h*g+x*a;const M=1/Math.sqrt(c*c+l*l+u*u+h*h);c*=M,l*=M,u*=M,h*=M}}e[t]=c,e[t+1]=l,e[t+2]=u,e[t+3]=h}static multiplyQuaternionsFlat(e,t,n,s,o,r){const a=n[s],c=n[s+1],l=n[s+2],u=n[s+3],h=o[r],d=o[r+1],f=o[r+2],p=o[r+3];return e[t]=a*p+u*h+c*f-l*d,e[t+1]=c*p+u*d+l*h-a*f,e[t+2]=l*p+u*f+a*d-c*h,e[t+3]=u*p-a*h-c*d-l*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,o=e._z,r=e._order,a=Math.cos,c=Math.sin,l=a(n/2),u=a(s/2),h=a(o/2),d=c(n/2),f=c(s/2),p=c(o/2);switch(r){case"XYZ":this._x=d*u*h+l*f*p,this._y=l*f*h-d*u*p,this._z=l*u*p+d*f*h,this._w=l*u*h-d*f*p;break;case"YXZ":this._x=d*u*h+l*f*p,this._y=l*f*h-d*u*p,this._z=l*u*p-d*f*h,this._w=l*u*h+d*f*p;break;case"ZXY":this._x=d*u*h-l*f*p,this._y=l*f*h+d*u*p,this._z=l*u*p+d*f*h,this._w=l*u*h-d*f*p;break;case"ZYX":this._x=d*u*h-l*f*p,this._y=l*f*h+d*u*p,this._z=l*u*p-d*f*h,this._w=l*u*h+d*f*p;break;case"YZX":this._x=d*u*h+l*f*p,this._y=l*f*h+d*u*p,this._z=l*u*p-d*f*h,this._w=l*u*h-d*f*p;break;case"XZY":this._x=d*u*h-l*f*p,this._y=l*f*h-d*u*p,this._z=l*u*p+d*f*h,this._w=l*u*h+d*f*p;break;default:xt("Quaternion: .setFromEuler() encountered an unknown order: "+r)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],o=t[8],r=t[1],a=t[5],c=t[9],l=t[2],u=t[6],h=t[10],d=n+a+h;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(u-c)*f,this._y=(o-l)*f,this._z=(r-s)*f}else if(n>a&&n>h){const f=2*Math.sqrt(1+n-a-h);this._w=(u-c)/f,this._x=.25*f,this._y=(s+r)/f,this._z=(o+l)/f}else if(a>h){const f=2*Math.sqrt(1+a-n-h);this._w=(o-l)/f,this._x=(s+r)/f,this._y=.25*f,this._z=(c+u)/f}else{const f=2*Math.sqrt(1+h-n-a);this._w=(r-s)/f,this._x=(o+l)/f,this._y=(c+u)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(sn(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,o=e._z,r=e._w,a=t._x,c=t._y,l=t._z,u=t._w;return this._x=n*u+r*a+s*l-o*c,this._y=s*u+r*c+o*a-n*l,this._z=o*u+r*l+n*c-s*a,this._w=r*u-n*a-s*c-o*l,this._onChangeCallback(),this}slerp(e,t){let n=e._x,s=e._y,o=e._z,r=e._w,a=this.dot(e);a<0&&(n=-n,s=-s,o=-o,r=-r,a=-a);let c=1-t;if(a<.9995){const l=Math.acos(a),u=Math.sin(l);c=Math.sin(c*l)/u,t=Math.sin(t*l)/u,this._x=this._x*c+n*t,this._y=this._y*c+s*t,this._z=this._z*c+o*t,this._w=this._w*c+r*t,this._onChangeCallback()}else this._x=this._x*c+n*t,this._y=this._y*c+s*t,this._z=this._z*c+o*t,this._w=this._w*c+r*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),o=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),o*Math.sin(t),o*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const uf=class uf{constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Wf.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Wf.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,o=e.elements;return this.x=o[0]*t+o[3]*n+o[6]*s,this.y=o[1]*t+o[4]*n+o[7]*s,this.z=o[2]*t+o[5]*n+o[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,o=e.elements,r=1/(o[3]*t+o[7]*n+o[11]*s+o[15]);return this.x=(o[0]*t+o[4]*n+o[8]*s+o[12])*r,this.y=(o[1]*t+o[5]*n+o[9]*s+o[13])*r,this.z=(o[2]*t+o[6]*n+o[10]*s+o[14])*r,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,o=e.x,r=e.y,a=e.z,c=e.w,l=2*(r*s-a*n),u=2*(a*t-o*s),h=2*(o*n-r*t);return this.x=t+c*l+r*h-a*u,this.y=n+c*u+a*l-o*h,this.z=s+c*h+o*u-r*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s,this.y=o[1]*t+o[5]*n+o[9]*s,this.z=o[2]*t+o[6]*n+o[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=sn(this.x,e.x,t.x),this.y=sn(this.y,e.y,t.y),this.z=sn(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=sn(this.x,e,t),this.y=sn(this.y,e,t),this.z=sn(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(sn(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,o=e.z,r=t.x,a=t.y,c=t.z;return this.x=s*c-o*a,this.y=o*r-n*c,this.z=n*a-s*r,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return uu.copy(this).projectOnVector(e),this.sub(uu)}reflect(e){return this.sub(uu.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(sn(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};uf.prototype.isVector3=!0;let I=uf;const uu=new I,Wf=new ci,hf=class hf{constructor(e,t,n,s,o,r,a,c,l){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,o,r,a,c,l)}set(e,t,n,s,o,r,a,c,l){const u=this.elements;return u[0]=e,u[1]=s,u[2]=a,u[3]=t,u[4]=o,u[5]=c,u[6]=n,u[7]=r,u[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,o=this.elements,r=n[0],a=n[3],c=n[6],l=n[1],u=n[4],h=n[7],d=n[2],f=n[5],p=n[8],x=s[0],m=s[3],g=s[6],M=s[1],S=s[4],_=s[7],A=s[2],E=s[5],L=s[8];return o[0]=r*x+a*M+c*A,o[3]=r*m+a*S+c*E,o[6]=r*g+a*_+c*L,o[1]=l*x+u*M+h*A,o[4]=l*m+u*S+h*E,o[7]=l*g+u*_+h*L,o[2]=d*x+f*M+p*A,o[5]=d*m+f*S+p*E,o[8]=d*g+f*_+p*L,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],o=e[3],r=e[4],a=e[5],c=e[6],l=e[7],u=e[8];return t*r*u-t*a*l-n*o*u+n*a*c+s*o*l-s*r*c}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],o=e[3],r=e[4],a=e[5],c=e[6],l=e[7],u=e[8],h=u*r-a*l,d=a*c-u*o,f=l*o-r*c,p=t*h+n*d+s*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);const x=1/p;return e[0]=h*x,e[1]=(s*l-u*n)*x,e[2]=(a*n-s*r)*x,e[3]=d*x,e[4]=(u*t-s*c)*x,e[5]=(s*o-a*t)*x,e[6]=f*x,e[7]=(n*c-l*t)*x,e[8]=(r*t-n*o)*x,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,o,r,a){const c=Math.cos(o),l=Math.sin(o);return this.set(n*c,n*l,-n*(c*r+l*a)+r+e,-s*l,s*c,-s*(-l*r+c*a)+a+t,0,0,1),this}scale(e,t){return qr("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(hu.makeScale(e,t)),this}rotate(e){return qr("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(hu.makeRotation(-e)),this}translate(e,t){return qr("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(hu.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}};hf.prototype.isMatrix3=!0;let Yt=hf;const hu=new Yt,Xf=new Yt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),qf=new Yt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function U_(){const i={enabled:!0,workingColorSpace:Ji,spaces:{},convert:function(s,o,r){return this.enabled===!1||o===r||!o||!r||(this.spaces[o].transfer===Dn&&(s.r=mo(s.r),s.g=mo(s.g),s.b=mo(s.b)),this.spaces[o].primaries!==this.spaces[r].primaries&&(s.applyMatrix3(this.spaces[o].toXYZ),s.applyMatrix3(this.spaces[r].fromXYZ)),this.spaces[r].transfer===Dn&&(s.r=Yr(s.r),s.g=Yr(s.g),s.b=Yr(s.b))),s},workingToColorSpace:function(s,o){return this.convert(s,this.workingColorSpace,o)},colorSpaceToWorking:function(s,o){return this.convert(s,o,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===ro?Rl:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,o=this.workingColorSpace){return s.fromArray(this.spaces[o].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,o,r){return s.copy(this.spaces[o].toXYZ).multiply(this.spaces[r].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,o){return qr("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,o)},toWorkingColorSpace:function(s,o){return qr("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,o)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[Ji]:{primaries:e,whitePoint:n,transfer:Rl,toXYZ:Xf,fromXYZ:qf,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Yn},outputColorSpaceConfig:{drawingBufferColorSpace:Yn}},[Yn]:{primaries:e,whitePoint:n,transfer:Dn,toXYZ:Xf,fromXYZ:qf,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Yn}}}),i}const un=U_();function mo(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Yr(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let br;class F_{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{br===void 0&&(br=cc("canvas")),br.width=e.width,br.height=e.height;const s=br.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=br}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=cc("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),o=s.data;for(let r=0;r<o.length;r++)o[r]=mo(o[r]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(mo(t[n]/255)*255):t[n]=mo(t[n]);return{data:t,width:e.width,height:e.height}}else return xt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let O_=0;class Od{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:O_++}),this.uuid=us(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let o;if(Array.isArray(s)){o=[];for(let r=0,a=s.length;r<a;r++)s[r].isDataTexture?o.push(du(s[r].image)):o.push(du(s[r]))}else o=du(s);n.url=o}return t||(e.images[this.uuid]=n),n}}function du(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?F_.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(xt("Texture: Unable to serialize Texture."),{})}let B_=0;const fu=new I;class bi extends zo{constructor(e=bi.DEFAULT_IMAGE,t=bi.DEFAULT_MAPPING,n=ks,s=ks,o=mi,r=Hs,a=Ki,c=Yi,l=bi.DEFAULT_ANISOTROPY,u=ro){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:B_++}),this.uuid=us(),this.name="",this.source=new Od(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=o,this.minFilter=r,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new _e(0,0),this.repeat=new _e(1,1),this.center=new _e(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(fu).x}get height(){return this.source.getSize(fu).y}get depth(){return this.source.getSize(fu).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){xt(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){xt(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Xm)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case mr:e.x=e.x-Math.floor(e.x);break;case ks:e.x=e.x<0?0:1;break;case bl:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case mr:e.y=e.y-Math.floor(e.y);break;case ks:e.y=e.y<0?0:1;break;case bl:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}bi.DEFAULT_IMAGE=null;bi.DEFAULT_MAPPING=Xm;bi.DEFAULT_ANISOTROPY=1;const df=class df{constructor(e=0,t=0,n=0,s=1){this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,o=this.w,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s+r[12]*o,this.y=r[1]*t+r[5]*n+r[9]*s+r[13]*o,this.z=r[2]*t+r[6]*n+r[10]*s+r[14]*o,this.w=r[3]*t+r[7]*n+r[11]*s+r[15]*o,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,o;const c=e.elements,l=c[0],u=c[4],h=c[8],d=c[1],f=c[5],p=c[9],x=c[2],m=c[6],g=c[10];if(Math.abs(u-d)<.01&&Math.abs(h-x)<.01&&Math.abs(p-m)<.01){if(Math.abs(u+d)<.1&&Math.abs(h+x)<.1&&Math.abs(p+m)<.1&&Math.abs(l+f+g-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const S=(l+1)/2,_=(f+1)/2,A=(g+1)/2,E=(u+d)/4,L=(h+x)/4,v=(p+m)/4;return S>_&&S>A?S<.01?(n=0,s=.707106781,o=.707106781):(n=Math.sqrt(S),s=E/n,o=L/n):_>A?_<.01?(n=.707106781,s=0,o=.707106781):(s=Math.sqrt(_),n=E/s,o=v/s):A<.01?(n=.707106781,s=.707106781,o=0):(o=Math.sqrt(A),n=L/o,s=v/o),this.set(n,s,o,t),this}let M=Math.sqrt((m-p)*(m-p)+(h-x)*(h-x)+(d-u)*(d-u));return Math.abs(M)<.001&&(M=1),this.x=(m-p)/M,this.y=(h-x)/M,this.z=(d-u)/M,this.w=Math.acos((l+f+g-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=sn(this.x,e.x,t.x),this.y=sn(this.y,e.y,t.y),this.z=sn(this.z,e.z,t.z),this.w=sn(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=sn(this.x,e,t),this.y=sn(this.y,e,t),this.z=sn(this.z,e,t),this.w=sn(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(sn(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};df.prototype.isVector4=!0;let Bn=df;class k_ extends zo{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:mi,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Bn(0,0,e,t),this.scissorTest=!1,this.viewport=new Bn(0,0,e,t),this.textures=[];const s={width:e,height:t,depth:n.depth},o=new bi(s),r=n.count;for(let a=0;a<r;a++)this.textures[a]=o.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:mi,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,o=this.textures.length;s<o;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new Od(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class zs extends k_{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class n0 extends bi{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=vi,this.minFilter=vi,this.wrapR=ks,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class H_ extends bi{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=vi,this.minFilter=vi,this.wrapR=ks,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const kl=class kl{constructor(e,t,n,s,o,r,a,c,l,u,h,d,f,p,x,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,o,r,a,c,l,u,h,d,f,p,x,m)}set(e,t,n,s,o,r,a,c,l,u,h,d,f,p,x,m){const g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=s,g[1]=o,g[5]=r,g[9]=a,g[13]=c,g[2]=l,g[6]=u,g[10]=h,g[14]=d,g[3]=f,g[7]=p,g[11]=x,g[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new kl().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,n=e.elements,s=1/Tr.setFromMatrixColumn(e,0).length(),o=1/Tr.setFromMatrixColumn(e,1).length(),r=1/Tr.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*o,t[5]=n[5]*o,t[6]=n[6]*o,t[7]=0,t[8]=n[8]*r,t[9]=n[9]*r,t[10]=n[10]*r,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,o=e.z,r=Math.cos(n),a=Math.sin(n),c=Math.cos(s),l=Math.sin(s),u=Math.cos(o),h=Math.sin(o);if(e.order==="XYZ"){const d=r*u,f=r*h,p=a*u,x=a*h;t[0]=c*u,t[4]=-c*h,t[8]=l,t[1]=f+p*l,t[5]=d-x*l,t[9]=-a*c,t[2]=x-d*l,t[6]=p+f*l,t[10]=r*c}else if(e.order==="YXZ"){const d=c*u,f=c*h,p=l*u,x=l*h;t[0]=d+x*a,t[4]=p*a-f,t[8]=r*l,t[1]=r*h,t[5]=r*u,t[9]=-a,t[2]=f*a-p,t[6]=x+d*a,t[10]=r*c}else if(e.order==="ZXY"){const d=c*u,f=c*h,p=l*u,x=l*h;t[0]=d-x*a,t[4]=-r*h,t[8]=p+f*a,t[1]=f+p*a,t[5]=r*u,t[9]=x-d*a,t[2]=-r*l,t[6]=a,t[10]=r*c}else if(e.order==="ZYX"){const d=r*u,f=r*h,p=a*u,x=a*h;t[0]=c*u,t[4]=p*l-f,t[8]=d*l+x,t[1]=c*h,t[5]=x*l+d,t[9]=f*l-p,t[2]=-l,t[6]=a*c,t[10]=r*c}else if(e.order==="YZX"){const d=r*c,f=r*l,p=a*c,x=a*l;t[0]=c*u,t[4]=x-d*h,t[8]=p*h+f,t[1]=h,t[5]=r*u,t[9]=-a*u,t[2]=-l*u,t[6]=f*h+p,t[10]=d-x*h}else if(e.order==="XZY"){const d=r*c,f=r*l,p=a*c,x=a*l;t[0]=c*u,t[4]=-h,t[8]=l*u,t[1]=d*h+x,t[5]=r*u,t[9]=f*h-p,t[2]=p*h-f,t[6]=a*u,t[10]=x*h+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(G_,e,V_)}lookAt(e,t,n){const s=this.elements;return Xi.subVectors(e,t),Xi.lengthSq()===0&&(Xi.z=1),Xi.normalize(),Ro.crossVectors(n,Xi),Ro.lengthSq()===0&&(Math.abs(n.z)===1?Xi.x+=1e-4:Xi.z+=1e-4,Xi.normalize(),Ro.crossVectors(n,Xi)),Ro.normalize(),Uc.crossVectors(Xi,Ro),s[0]=Ro.x,s[4]=Uc.x,s[8]=Xi.x,s[1]=Ro.y,s[5]=Uc.y,s[9]=Xi.y,s[2]=Ro.z,s[6]=Uc.z,s[10]=Xi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,o=this.elements,r=n[0],a=n[4],c=n[8],l=n[12],u=n[1],h=n[5],d=n[9],f=n[13],p=n[2],x=n[6],m=n[10],g=n[14],M=n[3],S=n[7],_=n[11],A=n[15],E=s[0],L=s[4],v=s[8],R=s[12],D=s[1],N=s[5],B=s[9],ne=s[13],ae=s[2],V=s[6],se=s[10],K=s[14],he=s[3],me=s[7],Re=s[11],we=s[15];return o[0]=r*E+a*D+c*ae+l*he,o[4]=r*L+a*N+c*V+l*me,o[8]=r*v+a*B+c*se+l*Re,o[12]=r*R+a*ne+c*K+l*we,o[1]=u*E+h*D+d*ae+f*he,o[5]=u*L+h*N+d*V+f*me,o[9]=u*v+h*B+d*se+f*Re,o[13]=u*R+h*ne+d*K+f*we,o[2]=p*E+x*D+m*ae+g*he,o[6]=p*L+x*N+m*V+g*me,o[10]=p*v+x*B+m*se+g*Re,o[14]=p*R+x*ne+m*K+g*we,o[3]=M*E+S*D+_*ae+A*he,o[7]=M*L+S*N+_*V+A*me,o[11]=M*v+S*B+_*se+A*Re,o[15]=M*R+S*ne+_*K+A*we,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],o=e[12],r=e[1],a=e[5],c=e[9],l=e[13],u=e[2],h=e[6],d=e[10],f=e[14],p=e[3],x=e[7],m=e[11],g=e[15],M=c*f-l*d,S=a*f-l*h,_=a*d-c*h,A=r*f-l*u,E=r*d-c*u,L=r*h-a*u;return t*(x*M-m*S+g*_)-n*(p*M-m*A+g*E)+s*(p*S-x*A+g*L)-o*(p*_-x*E+m*L)}determinantAffine(){const e=this.elements,t=e[0],n=e[4],s=e[8],o=e[1],r=e[5],a=e[9],c=e[2],l=e[6],u=e[10];return t*(r*u-a*l)-n*(o*u-a*c)+s*(o*l-r*c)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],o=e[3],r=e[4],a=e[5],c=e[6],l=e[7],u=e[8],h=e[9],d=e[10],f=e[11],p=e[12],x=e[13],m=e[14],g=e[15],M=t*a-n*r,S=t*c-s*r,_=t*l-o*r,A=n*c-s*a,E=n*l-o*a,L=s*l-o*c,v=u*x-h*p,R=u*m-d*p,D=u*g-f*p,N=h*m-d*x,B=h*g-f*x,ne=d*g-f*m,ae=M*ne-S*B+_*N+A*D-E*R+L*v;if(ae===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const V=1/ae;return e[0]=(a*ne-c*B+l*N)*V,e[1]=(s*B-n*ne-o*N)*V,e[2]=(x*L-m*E+g*A)*V,e[3]=(d*E-h*L-f*A)*V,e[4]=(c*D-r*ne-l*R)*V,e[5]=(t*ne-s*D+o*R)*V,e[6]=(m*_-p*L-g*S)*V,e[7]=(u*L-d*_+f*S)*V,e[8]=(r*B-a*D+l*v)*V,e[9]=(n*D-t*B-o*v)*V,e[10]=(p*E-x*_+g*M)*V,e[11]=(h*_-u*E-f*M)*V,e[12]=(a*R-r*N-c*v)*V,e[13]=(t*N-n*R+s*v)*V,e[14]=(x*S-p*A-m*M)*V,e[15]=(u*A-h*S+d*M)*V,this}scale(e){const t=this.elements,n=e.x,s=e.y,o=e.z;return t[0]*=n,t[4]*=s,t[8]*=o,t[1]*=n,t[5]*=s,t[9]*=o,t[2]*=n,t[6]*=s,t[10]*=o,t[3]*=n,t[7]*=s,t[11]*=o,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),o=1-n,r=e.x,a=e.y,c=e.z,l=o*r,u=o*a;return this.set(l*r+n,l*a-s*c,l*c+s*a,0,l*a+s*c,u*a+n,u*c-s*r,0,l*c-s*a,u*c+s*r,o*c*c+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,o,r){return this.set(1,n,o,0,e,1,r,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,o=t._x,r=t._y,a=t._z,c=t._w,l=o+o,u=r+r,h=a+a,d=o*l,f=o*u,p=o*h,x=r*u,m=r*h,g=a*h,M=c*l,S=c*u,_=c*h,A=n.x,E=n.y,L=n.z;return s[0]=(1-(x+g))*A,s[1]=(f+_)*A,s[2]=(p-S)*A,s[3]=0,s[4]=(f-_)*E,s[5]=(1-(d+g))*E,s[6]=(m+M)*E,s[7]=0,s[8]=(p+S)*L,s[9]=(m-M)*L,s[10]=(1-(d+x))*L,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;e.x=s[12],e.y=s[13],e.z=s[14];const o=this.determinantAffine();if(o===0)return n.set(1,1,1),t.identity(),this;let r=Tr.set(s[0],s[1],s[2]).length();const a=Tr.set(s[4],s[5],s[6]).length(),c=Tr.set(s[8],s[9],s[10]).length();o<0&&(r=-r),fs.copy(this);const l=1/r,u=1/a,h=1/c;return fs.elements[0]*=l,fs.elements[1]*=l,fs.elements[2]*=l,fs.elements[4]*=u,fs.elements[5]*=u,fs.elements[6]*=u,fs.elements[8]*=h,fs.elements[9]*=h,fs.elements[10]*=h,t.setFromRotationMatrix(fs),n.x=r,n.y=a,n.z=c,this}makePerspective(e,t,n,s,o,r,a=Gs,c=!1){const l=this.elements,u=2*o/(t-e),h=2*o/(n-s),d=(t+e)/(t-e),f=(n+s)/(n-s);let p,x;if(c)p=o/(r-o),x=r*o/(r-o);else if(a===Gs)p=-(r+o)/(r-o),x=-2*r*o/(r-o);else if(a===ac)p=-r/(r-o),x=-r*o/(r-o);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=u,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=h,l[9]=f,l[13]=0,l[2]=0,l[6]=0,l[10]=p,l[14]=x,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,o,r,a=Gs,c=!1){const l=this.elements,u=2/(t-e),h=2/(n-s),d=-(t+e)/(t-e),f=-(n+s)/(n-s);let p,x;if(c)p=1/(r-o),x=r/(r-o);else if(a===Gs)p=-2/(r-o),x=-(r+o)/(r-o);else if(a===ac)p=-1/(r-o),x=-o/(r-o);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=u,l[4]=0,l[8]=0,l[12]=d,l[1]=0,l[5]=h,l[9]=0,l[13]=f,l[2]=0,l[6]=0,l[10]=p,l[14]=x,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}};kl.prototype.isMatrix4=!0;let Wt=kl;const Tr=new I,fs=new Wt,G_=new I(0,0,0),V_=new I(1,1,1),Ro=new I,Uc=new I,Xi=new I,Yf=new Wt,Kf=new ci;class ws{constructor(e=0,t=0,n=0,s=ws.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,o=s[0],r=s[4],a=s[8],c=s[1],l=s[5],u=s[9],h=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(sn(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,f),this._z=Math.atan2(-r,o)):(this._x=Math.atan2(d,l),this._z=0);break;case"YXZ":this._x=Math.asin(-sn(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-h,o),this._z=0);break;case"ZXY":this._x=Math.asin(sn(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-h,f),this._z=Math.atan2(-r,l)):(this._y=0,this._z=Math.atan2(c,o));break;case"ZYX":this._y=Math.asin(-sn(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(c,o)):(this._x=0,this._z=Math.atan2(-r,l));break;case"YZX":this._z=Math.asin(sn(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,l),this._y=Math.atan2(-h,o)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-sn(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(d,l),this._y=Math.atan2(a,o)):(this._x=Math.atan2(-u,f),this._y=0);break;default:xt("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Yf.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Yf,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Kf.setFromEuler(this),this.setFromQuaternion(Kf,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}ws.DEFAULT_ORDER="XYZ";class Bd{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let z_=0;const Zf=new I,wr=new ci,Qs=new Wt,Fc=new I,Sa=new I,W_=new I,X_=new ci,$f=new I(1,0,0),Jf=new I(0,1,0),jf=new I(0,0,1),Qf={type:"added"},q_={type:"removed"},Er={type:"childadded",child:null},pu={type:"childremoved",child:null};class kn extends zo{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:z_++}),this.uuid=us(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=kn.DEFAULT_UP.clone();const e=new I,t=new ws,n=new ci,s=new I(1,1,1);function o(){n.setFromEuler(t,!1)}function r(){t.setFromQuaternion(n,void 0,!1)}t._onChange(o),n._onChange(r),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Wt},normalMatrix:{value:new Yt}}),this.matrix=new Wt,this.matrixWorld=new Wt,this.matrixAutoUpdate=kn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=kn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Bd,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return wr.setFromAxisAngle(e,t),this.quaternion.multiply(wr),this}rotateOnWorldAxis(e,t){return wr.setFromAxisAngle(e,t),this.quaternion.premultiply(wr),this}rotateX(e){return this.rotateOnAxis($f,e)}rotateY(e){return this.rotateOnAxis(Jf,e)}rotateZ(e){return this.rotateOnAxis(jf,e)}translateOnAxis(e,t){return Zf.copy(e).applyQuaternion(this.quaternion),this.position.add(Zf.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis($f,e)}translateY(e){return this.translateOnAxis(Jf,e)}translateZ(e){return this.translateOnAxis(jf,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Qs.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Fc.copy(e):Fc.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Sa.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Qs.lookAt(Sa,Fc,this.up):Qs.lookAt(Fc,Sa,this.up),this.quaternion.setFromRotationMatrix(Qs),s&&(Qs.extractRotation(s.matrixWorld),wr.setFromRotationMatrix(Qs),this.quaternion.premultiply(wr.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(Lt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Qf),Er.child=e,this.dispatchEvent(Er),Er.child=null):Lt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(q_),pu.child=e,this.dispatchEvent(pu),pu.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Qs.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Qs.multiply(e.parent.matrixWorld)),e.applyMatrix4(Qs),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Qf),Er.child=e,this.dispatchEvent(Er),Er.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let o=0,r=s.length;o<r;o++)s[o].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Sa,e,W_),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Sa,X_,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,s=e.z,o=this.matrix.elements;o[12]+=t-o[0]*t-o[4]*n-o[8]*s,o[13]+=n-o[1]*t-o[5]*n-o[9]*s,o[14]+=s-o[2]*t-o[6]*n-o[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){const s=this.parent;if(e===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){const o=this.children;for(let r=0,a=o.length;r<a;r++)o[r].updateWorldMatrix(!1,!0,n)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),this.static!==!1&&(s.static=this.static),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(a=>({...a})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function o(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=o(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,u=c.length;l<u;l++){const h=c[l];o(e.shapes,h)}else o(e.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(o(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(o(e.materials,this.material[c]));s.material=a}else s.material=o(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];s.animations.push(o(e.animations,c))}}if(t){const a=r(e.geometries),c=r(e.materials),l=r(e.textures),u=r(e.images),h=r(e.shapes),d=r(e.skeletons),f=r(e.animations),p=r(e.nodes);a.length>0&&(n.geometries=a),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),u.length>0&&(n.images=u),h.length>0&&(n.shapes=h),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),p.length>0&&(n.nodes=p)}return n.object=s,n;function r(a){const c=[];for(const l in a){const u=a[l];delete u.metadata,c.push(u)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}}kn.DEFAULT_UP=new I(0,1,0);kn.DEFAULT_MATRIX_AUTO_UPDATE=!0;kn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class pn extends kn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Y_={type:"move"};class mu{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new pn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new pn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new I,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new I),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new pn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new I,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new I,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,o=null,r=null;const a=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){r=!0;for(const x of e.hand.values()){const m=t.getJointPose(x,n),g=this._getHandJoint(l,x);m!==null&&(g.matrix.fromArray(m.transform.matrix),g.matrix.decompose(g.position,g.rotation,g.scale),g.matrixWorldNeedsUpdate=!0,g.jointRadius=m.radius),g.visible=m!==null}const u=l.joints["index-finger-tip"],h=l.joints["thumb-tip"],d=u.position.distanceTo(h.position),f=.02,p=.005;l.inputState.pinching&&d>f+p?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&d<=f-p&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(o=t.getPose(e.gripSpace,n),o!==null&&(c.matrix.fromArray(o.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,o.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(o.linearVelocity)):c.hasLinearVelocity=!1,o.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(o.angularVelocity)):c.hasAngularVelocity=!1,c.eventsEnabled&&c.dispatchEvent({type:"gripUpdated",data:e,target:this})));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&o!==null&&(s=o),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Y_)))}return a!==null&&(a.visible=s!==null),c!==null&&(c.visible=o!==null),l!==null&&(l.visible=r!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new pn;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const i0={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Co={h:0,s:0,l:0},Oc={h:0,s:0,l:0};function gu(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Qe{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Yn){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,un.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=un.workingColorSpace){return this.r=e,this.g=t,this.b=n,un.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=un.workingColorSpace){if(e=Fd(e,1),t=sn(t,0,1),n=sn(n,0,1),t===0)this.r=this.g=this.b=n;else{const o=n<=.5?n*(1+t):n+t-n*t,r=2*n-o;this.r=gu(r,o,e+1/3),this.g=gu(r,o,e),this.b=gu(r,o,e-1/3)}return un.colorSpaceToWorking(this,s),this}setStyle(e,t=Yn){function n(o){o!==void 0&&parseFloat(o)<1&&xt("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let o;const r=s[1],a=s[2];switch(r){case"rgb":case"rgba":if(o=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(o[4]),this.setRGB(Math.min(255,parseInt(o[1],10))/255,Math.min(255,parseInt(o[2],10))/255,Math.min(255,parseInt(o[3],10))/255,t);if(o=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(o[4]),this.setRGB(Math.min(100,parseInt(o[1],10))/100,Math.min(100,parseInt(o[2],10))/100,Math.min(100,parseInt(o[3],10))/100,t);break;case"hsl":case"hsla":if(o=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(o[4]),this.setHSL(parseFloat(o[1])/360,parseFloat(o[2])/100,parseFloat(o[3])/100,t);break;default:xt("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const o=s[1],r=o.length;if(r===3)return this.setRGB(parseInt(o.charAt(0),16)/15,parseInt(o.charAt(1),16)/15,parseInt(o.charAt(2),16)/15,t);if(r===6)return this.setHex(parseInt(o,16),t);xt("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Yn){const n=i0[e.toLowerCase()];return n!==void 0?this.setHex(n,t):xt("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=mo(e.r),this.g=mo(e.g),this.b=mo(e.b),this}copyLinearToSRGB(e){return this.r=Yr(e.r),this.g=Yr(e.g),this.b=Yr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Yn){return un.workingToColorSpace(Ri.copy(this),e),Math.round(sn(Ri.r*255,0,255))*65536+Math.round(sn(Ri.g*255,0,255))*256+Math.round(sn(Ri.b*255,0,255))}getHexString(e=Yn){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=un.workingColorSpace){un.workingToColorSpace(Ri.copy(this),t);const n=Ri.r,s=Ri.g,o=Ri.b,r=Math.max(n,s,o),a=Math.min(n,s,o);let c,l;const u=(a+r)/2;if(a===r)c=0,l=0;else{const h=r-a;switch(l=u<=.5?h/(r+a):h/(2-r-a),r){case n:c=(s-o)/h+(s<o?6:0);break;case s:c=(o-n)/h+2;break;case o:c=(n-s)/h+4;break}c/=6}return e.h=c,e.s=l,e.l=u,e}getRGB(e,t=un.workingColorSpace){return un.workingToColorSpace(Ri.copy(this),t),e.r=Ri.r,e.g=Ri.g,e.b=Ri.b,e}getStyle(e=Yn){un.workingToColorSpace(Ri.copy(this),e);const t=Ri.r,n=Ri.g,s=Ri.b;return e!==Yn?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(Co),this.setHSL(Co.h+e,Co.s+t,Co.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Co),e.getHSL(Oc);const n=Wa(Co.h,Oc.h,t),s=Wa(Co.s,Oc.s,t),o=Wa(Co.l,Oc.l,t);return this.setHSL(n,s,o),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,o=e.elements;return this.r=o[0]*t+o[3]*n+o[6]*s,this.g=o[1]*t+o[4]*n+o[7]*s,this.b=o[2]*t+o[5]*n+o[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ri=new Qe;Qe.NAMES=i0;class K_ extends kn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new ws,this.environmentIntensity=1,this.environmentRotation=new ws,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}const ps=new I,eo=new I,xu=new I,to=new I,Ar=new I,Rr=new I,ep=new I,_u=new I,vu=new I,yu=new I,Mu=new Bn,Su=new Bn,bu=new Bn;class ys{constructor(e=new I,t=new I,n=new I){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),ps.subVectors(e,t),s.cross(ps);const o=s.lengthSq();return o>0?s.multiplyScalar(1/Math.sqrt(o)):s.set(0,0,0)}static getBarycoord(e,t,n,s,o){ps.subVectors(s,t),eo.subVectors(n,t),xu.subVectors(e,t);const r=ps.dot(ps),a=ps.dot(eo),c=ps.dot(xu),l=eo.dot(eo),u=eo.dot(xu),h=r*l-a*a;if(h===0)return o.set(0,0,0),null;const d=1/h,f=(l*c-a*u)*d,p=(r*u-a*c)*d;return o.set(1-f-p,p,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,to)===null?!1:to.x>=0&&to.y>=0&&to.x+to.y<=1}static getInterpolation(e,t,n,s,o,r,a,c){return this.getBarycoord(e,t,n,s,to)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(o,to.x),c.addScaledVector(r,to.y),c.addScaledVector(a,to.z),c)}static getInterpolatedAttribute(e,t,n,s,o,r){return Mu.setScalar(0),Su.setScalar(0),bu.setScalar(0),Mu.fromBufferAttribute(e,t),Su.fromBufferAttribute(e,n),bu.fromBufferAttribute(e,s),r.setScalar(0),r.addScaledVector(Mu,o.x),r.addScaledVector(Su,o.y),r.addScaledVector(bu,o.z),r}static isFrontFacing(e,t,n,s){return ps.subVectors(n,t),eo.subVectors(e,t),ps.cross(eo).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return ps.subVectors(this.c,this.b),eo.subVectors(this.a,this.b),ps.cross(eo).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return ys.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return ys.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,o){return ys.getInterpolation(e,this.a,this.b,this.c,t,n,s,o)}containsPoint(e){return ys.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return ys.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,o=this.c;let r,a;Ar.subVectors(s,n),Rr.subVectors(o,n),_u.subVectors(e,n);const c=Ar.dot(_u),l=Rr.dot(_u);if(c<=0&&l<=0)return t.copy(n);vu.subVectors(e,s);const u=Ar.dot(vu),h=Rr.dot(vu);if(u>=0&&h<=u)return t.copy(s);const d=c*h-u*l;if(d<=0&&c>=0&&u<=0)return r=c/(c-u),t.copy(n).addScaledVector(Ar,r);yu.subVectors(e,o);const f=Ar.dot(yu),p=Rr.dot(yu);if(p>=0&&f<=p)return t.copy(o);const x=f*l-c*p;if(x<=0&&l>=0&&p<=0)return a=l/(l-p),t.copy(n).addScaledVector(Rr,a);const m=u*p-f*h;if(m<=0&&h-u>=0&&f-p>=0)return ep.subVectors(o,s),a=(h-u)/(h-u+(f-p)),t.copy(s).addScaledVector(ep,a);const g=1/(m+x+d);return r=x*g,a=d*g,t.copy(n).addScaledVector(Ar,r).addScaledVector(Rr,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class qs{constructor(e=new I(1/0,1/0,1/0),t=new I(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(ms.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(ms.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=ms.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const o=n.getAttribute("position");if(t===!0&&o!==void 0&&e.isInstancedMesh!==!0)for(let r=0,a=o.count;r<a;r++)e.isMesh===!0?e.getVertexPosition(r,ms):ms.fromBufferAttribute(o,r),ms.applyMatrix4(e.matrixWorld),this.expandByPoint(ms);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Bc.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Bc.copy(n.boundingBox)),Bc.applyMatrix4(e.matrixWorld),this.union(Bc)}const s=e.children;for(let o=0,r=s.length;o<r;o++)this.expandByObject(s[o],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,ms),ms.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ba),kc.subVectors(this.max,ba),Cr.subVectors(e.a,ba),Pr.subVectors(e.b,ba),Ir.subVectors(e.c,ba),Po.subVectors(Pr,Cr),Io.subVectors(Ir,Pr),Zo.subVectors(Cr,Ir);let t=[0,-Po.z,Po.y,0,-Io.z,Io.y,0,-Zo.z,Zo.y,Po.z,0,-Po.x,Io.z,0,-Io.x,Zo.z,0,-Zo.x,-Po.y,Po.x,0,-Io.y,Io.x,0,-Zo.y,Zo.x,0];return!Tu(t,Cr,Pr,Ir,kc)||(t=[1,0,0,0,1,0,0,0,1],!Tu(t,Cr,Pr,Ir,kc))?!1:(Hc.crossVectors(Po,Io),t=[Hc.x,Hc.y,Hc.z],Tu(t,Cr,Pr,Ir,kc))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,ms).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(ms).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(no[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),no[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),no[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),no[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),no[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),no[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),no[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),no[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(no),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const no=[new I,new I,new I,new I,new I,new I,new I,new I],ms=new I,Bc=new qs,Cr=new I,Pr=new I,Ir=new I,Po=new I,Io=new I,Zo=new I,ba=new I,kc=new I,Hc=new I,$o=new I;function Tu(i,e,t,n,s){for(let o=0,r=i.length-3;o<=r;o+=3){$o.fromArray(i,o);const a=s.x*Math.abs($o.x)+s.y*Math.abs($o.y)+s.z*Math.abs($o.z),c=e.dot($o),l=t.dot($o),u=n.dot($o);if(Math.max(-Math.max(c,l,u),Math.min(c,l,u))>a)return!1}return!0}const hi=new I,Gc=new _e;let Z_=0;class Li extends zo{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Z_++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=qh,this.updateRanges=[],this.gpuType=cs,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,o=this.itemSize;s<o;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Gc.fromBufferAttribute(this,t),Gc.applyMatrix3(e),this.setXY(t,Gc.x,Gc.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)hi.fromBufferAttribute(this,t),hi.applyMatrix3(e),this.setXYZ(t,hi.x,hi.y,hi.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)hi.fromBufferAttribute(this,t),hi.applyMatrix4(e),this.setXYZ(t,hi.x,hi.y,hi.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)hi.fromBufferAttribute(this,t),hi.applyNormalMatrix(e),this.setXYZ(t,hi.x,hi.y,hi.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)hi.fromBufferAttribute(this,t),hi.transformDirection(e),this.setXYZ(t,hi.x,hi.y,hi.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=vs(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Nn(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=vs(t,this.array)),t}setX(e,t){return this.normalized&&(t=Nn(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=vs(t,this.array)),t}setY(e,t){return this.normalized&&(t=Nn(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=vs(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Nn(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=vs(t,this.array)),t}setW(e,t){return this.normalized&&(t=Nn(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Nn(t,this.array),n=Nn(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=Nn(t,this.array),n=Nn(n,this.array),s=Nn(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,o){return e*=this.itemSize,this.normalized&&(t=Nn(t,this.array),n=Nn(n,this.array),s=Nn(s,this.array),o=Nn(o,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=o,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==qh&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class s0 extends Li{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class o0 extends Li{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class Dt extends Li{constructor(e,t,n){super(new Float32Array(e),t,n)}}const $_=new qs,Ta=new I,wu=new I;class Ys{constructor(e=new I,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):$_.setFromPoints(e).getCenter(n);let s=0;for(let o=0,r=e.length;o<r;o++)s=Math.max(s,n.distanceToSquared(e[o]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ta.subVectors(e,this.center);const t=Ta.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Ta,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(wu.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ta.copy(e.center).add(wu)),this.expandByPoint(Ta.copy(e.center).sub(wu))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let J_=0;const is=new Wt,Eu=new kn,Lr=new I,qi=new qs,wa=new qs,Si=new I;class Tn extends zo{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:J_++}),this.uuid=us(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(p_(e)?o0:s0)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const o=new Yt().getNormalMatrix(e);n.applyNormalMatrix(o),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return is.makeRotationFromQuaternion(e),this.applyMatrix4(is),this}rotateX(e){return is.makeRotationX(e),this.applyMatrix4(is),this}rotateY(e){return is.makeRotationY(e),this.applyMatrix4(is),this}rotateZ(e){return is.makeRotationZ(e),this.applyMatrix4(is),this}translate(e,t,n){return is.makeTranslation(e,t,n),this.applyMatrix4(is),this}scale(e,t,n){return is.makeScale(e,t,n),this.applyMatrix4(is),this}lookAt(e){return Eu.lookAt(e),Eu.updateMatrix(),this.applyMatrix4(Eu.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Lr).negate(),this.translate(Lr.x,Lr.y,Lr.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,o=e.length;s<o;s++){const r=e[s];n.push(r.x,r.y,r.z||0)}this.setAttribute("position",new Dt(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const o=e[s];t.setXYZ(s,o.x,o.y,o.z||0)}e.length>t.count&&xt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new qs);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Lt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new I(-1/0,-1/0,-1/0),new I(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const o=t[n];qi.setFromBufferAttribute(o),this.morphTargetsRelative?(Si.addVectors(this.boundingBox.min,qi.min),this.boundingBox.expandByPoint(Si),Si.addVectors(this.boundingBox.max,qi.max),this.boundingBox.expandByPoint(Si)):(this.boundingBox.expandByPoint(qi.min),this.boundingBox.expandByPoint(qi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Lt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ys);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Lt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new I,1/0);return}if(e){const n=this.boundingSphere.center;if(qi.setFromBufferAttribute(e),t)for(let o=0,r=t.length;o<r;o++){const a=t[o];wa.setFromBufferAttribute(a),this.morphTargetsRelative?(Si.addVectors(qi.min,wa.min),qi.expandByPoint(Si),Si.addVectors(qi.max,wa.max),qi.expandByPoint(Si)):(qi.expandByPoint(wa.min),qi.expandByPoint(wa.max))}qi.getCenter(n);let s=0;for(let o=0,r=e.count;o<r;o++)Si.fromBufferAttribute(e,o),s=Math.max(s,n.distanceToSquared(Si));if(t)for(let o=0,r=t.length;o<r;o++){const a=t[o],c=this.morphTargetsRelative;for(let l=0,u=a.count;l<u;l++)Si.fromBufferAttribute(a,l),c&&(Lr.fromBufferAttribute(e,l),Si.add(Lr)),s=Math.max(s,n.distanceToSquared(Si))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&Lt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){Lt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,o=t.uv;let r=this.getAttribute("tangent");(r===void 0||r.count!==n.count)&&(r=new Li(new Float32Array(4*n.count),4),this.setAttribute("tangent",r));const a=[],c=[];for(let v=0;v<n.count;v++)a[v]=new I,c[v]=new I;const l=new I,u=new I,h=new I,d=new _e,f=new _e,p=new _e,x=new I,m=new I;function g(v,R,D){l.fromBufferAttribute(n,v),u.fromBufferAttribute(n,R),h.fromBufferAttribute(n,D),d.fromBufferAttribute(o,v),f.fromBufferAttribute(o,R),p.fromBufferAttribute(o,D),u.sub(l),h.sub(l),f.sub(d),p.sub(d);const N=1/(f.x*p.y-p.x*f.y);isFinite(N)&&(x.copy(u).multiplyScalar(p.y).addScaledVector(h,-f.y).multiplyScalar(N),m.copy(h).multiplyScalar(f.x).addScaledVector(u,-p.x).multiplyScalar(N),a[v].add(x),a[R].add(x),a[D].add(x),c[v].add(m),c[R].add(m),c[D].add(m))}let M=this.groups;M.length===0&&(M=[{start:0,count:e.count}]);for(let v=0,R=M.length;v<R;++v){const D=M[v],N=D.start,B=D.count;for(let ne=N,ae=N+B;ne<ae;ne+=3)g(e.getX(ne+0),e.getX(ne+1),e.getX(ne+2))}const S=new I,_=new I,A=new I,E=new I;function L(v){A.fromBufferAttribute(s,v),E.copy(A);const R=a[v];S.copy(R),S.sub(A.multiplyScalar(A.dot(R))).normalize(),_.crossVectors(E,R);const N=_.dot(c[v])<0?-1:1;r.setXYZW(v,S.x,S.y,S.z,N)}for(let v=0,R=M.length;v<R;++v){const D=M[v],N=D.start,B=D.count;for(let ne=N,ae=N+B;ne<ae;ne+=3)L(e.getX(ne+0)),L(e.getX(ne+1)),L(e.getX(ne+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new Li(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const s=new I,o=new I,r=new I,a=new I,c=new I,l=new I,u=new I,h=new I;if(e)for(let d=0,f=e.count;d<f;d+=3){const p=e.getX(d+0),x=e.getX(d+1),m=e.getX(d+2);s.fromBufferAttribute(t,p),o.fromBufferAttribute(t,x),r.fromBufferAttribute(t,m),u.subVectors(r,o),h.subVectors(s,o),u.cross(h),a.fromBufferAttribute(n,p),c.fromBufferAttribute(n,x),l.fromBufferAttribute(n,m),a.add(u),c.add(u),l.add(u),n.setXYZ(p,a.x,a.y,a.z),n.setXYZ(x,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),o.fromBufferAttribute(t,d+1),r.fromBufferAttribute(t,d+2),u.subVectors(r,o),h.subVectors(s,o),u.cross(h),n.setXYZ(d+0,u.x,u.y,u.z),n.setXYZ(d+1,u.x,u.y,u.z),n.setXYZ(d+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Si.fromBufferAttribute(e,t),Si.normalize(),e.setXYZ(t,Si.x,Si.y,Si.z)}toNonIndexed(){function e(a,c){const l=a.array,u=a.itemSize,h=a.normalized,d=new l.constructor(c.length*u);let f=0,p=0;for(let x=0,m=c.length;x<m;x++){a.isInterleavedBufferAttribute?f=c[x]*a.data.stride+a.offset:f=c[x]*u;for(let g=0;g<u;g++)d[p++]=l[f++]}return new Li(d,u,h)}if(this.index===null)return xt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Tn,n=this.index.array,s=this.attributes;for(const a in s){const c=s[a],l=e(c,n);t.setAttribute(a,l)}const o=this.morphAttributes;for(const a in o){const c=[],l=o[a];for(let u=0,h=l.length;u<h;u++){const d=l[u],f=e(d,n);c.push(f)}t.morphAttributes[a]=c}t.morphTargetsRelative=this.morphTargetsRelative;const r=this.groups;for(let a=0,c=r.length;a<c;a++){const l=r[a];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const c in n){const l=n[c];e.data.attributes[c]=l.toJSON(e.data)}const s={};let o=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],u=[];for(let h=0,d=l.length;h<d;h++){const f=l[h];u.push(f.toJSON(e.data))}u.length>0&&(s[c]=u,o=!0)}o&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const r=this.groups;r.length>0&&(e.data.groups=JSON.parse(JSON.stringify(r)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere=a.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const l in s){const u=s[l];this.setAttribute(l,u.clone(t))}const o=e.morphAttributes;for(const l in o){const u=[],h=o[l];for(let d=0,f=h.length;d<f;d++)u.push(h[d].clone(t));this.morphAttributes[l]=u}this.morphTargetsRelative=e.morphTargetsRelative;const r=e.groups;for(let l=0,u=r.length;l<u;l++){const h=r[l];this.addGroup(h.start,h.count,h.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class j_{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=qh,this.updateRanges=[],this.version=0,this.uuid=us()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,o=this.stride;s<o;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=us()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=us()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Ni=new I;class kd{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Ni.fromBufferAttribute(this,t),Ni.applyMatrix4(e),this.setXYZ(t,Ni.x,Ni.y,Ni.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Ni.fromBufferAttribute(this,t),Ni.applyNormalMatrix(e),this.setXYZ(t,Ni.x,Ni.y,Ni.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Ni.fromBufferAttribute(this,t),Ni.transformDirection(e),this.setXYZ(t,Ni.x,Ni.y,Ni.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=vs(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Nn(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=Nn(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=Nn(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=Nn(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=Nn(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=vs(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=vs(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=vs(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=vs(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=Nn(t,this.array),n=Nn(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=Nn(t,this.array),n=Nn(n,this.array),s=Nn(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,o){return e=e*this.data.stride+this.offset,this.normalized&&(t=Nn(t,this.array),n=Nn(n,this.array),s=Nn(s,this.array),o=Nn(o,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=o,this}clone(e){if(e===void 0){Cl("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let o=0;o<this.itemSize;o++)t.push(this.data.array[s+o])}return new Li(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new kd(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Cl("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let o=0;o<this.itemSize;o++)t.push(this.data.array[s+o])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}let Q_=0;class Ts extends zo{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Q_++}),this.uuid=us(),this.name="",this.type="Material",this.blending=Xr,this.side=Mo,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=oh,this.blendDst=rh,this.blendEquation=nr,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Qe(0,0,0),this.blendAlpha=0,this.depthFunc=ea,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Hf,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Sr,this.stencilZFail=Sr,this.stencilZPass=Sr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){xt(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){xt(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Xr&&(n.blending=this.blending),this.side!==Mo&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==oh&&(n.blendSrc=this.blendSrc),this.blendDst!==rh&&(n.blendDst=this.blendDst),this.blendEquation!==nr&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ea&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Hf&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Sr&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Sr&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Sr&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.allowOverride===!1&&(n.allowOverride=!1),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(o){const r=[];for(const a in o){const c=o[a];delete c.metadata,r.push(c)}return r}if(t){const o=s(e.textures),r=s(e.images);o.length>0&&(n.textures=o),r.length>0&&(n.images=r)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Qe().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new _e().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new _e().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let o=0;o!==s;++o)n[o]=t[o].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const io=new I,Au=new I,Vc=new I,Lo=new I,Ru=new I,zc=new I,Cu=new I;class _c{constructor(e=new I,t=new I(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,io)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=io.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(io.copy(this.origin).addScaledVector(this.direction,t),io.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Au.copy(e).add(t).multiplyScalar(.5),Vc.copy(t).sub(e).normalize(),Lo.copy(this.origin).sub(Au);const o=e.distanceTo(t)*.5,r=-this.direction.dot(Vc),a=Lo.dot(this.direction),c=-Lo.dot(Vc),l=Lo.lengthSq(),u=Math.abs(1-r*r);let h,d,f,p;if(u>0)if(h=r*c-a,d=r*a-c,p=o*u,h>=0)if(d>=-p)if(d<=p){const x=1/u;h*=x,d*=x,f=h*(h+r*d+2*a)+d*(r*h+d+2*c)+l}else d=o,h=Math.max(0,-(r*d+a)),f=-h*h+d*(d+2*c)+l;else d=-o,h=Math.max(0,-(r*d+a)),f=-h*h+d*(d+2*c)+l;else d<=-p?(h=Math.max(0,-(-r*o+a)),d=h>0?-o:Math.min(Math.max(-o,-c),o),f=-h*h+d*(d+2*c)+l):d<=p?(h=0,d=Math.min(Math.max(-o,-c),o),f=d*(d+2*c)+l):(h=Math.max(0,-(r*o+a)),d=h>0?o:Math.min(Math.max(-o,-c),o),f=-h*h+d*(d+2*c)+l);else d=r>0?-o:o,h=Math.max(0,-(r*d+a)),f=-h*h+d*(d+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,h),s&&s.copy(Au).addScaledVector(Vc,d),f}intersectSphere(e,t){io.subVectors(e.center,this.origin);const n=io.dot(this.direction),s=io.dot(io)-n*n,o=e.radius*e.radius;if(s>o)return null;const r=Math.sqrt(o-s),a=n-r,c=n+r;return c<0?null:a<0?this.at(c,t):this.at(a,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,o,r,a,c;const l=1/this.direction.x,u=1/this.direction.y,h=1/this.direction.z,d=this.origin;return l>=0?(n=(e.min.x-d.x)*l,s=(e.max.x-d.x)*l):(n=(e.max.x-d.x)*l,s=(e.min.x-d.x)*l),u>=0?(o=(e.min.y-d.y)*u,r=(e.max.y-d.y)*u):(o=(e.max.y-d.y)*u,r=(e.min.y-d.y)*u),n>r||o>s||((o>n||isNaN(n))&&(n=o),(r<s||isNaN(s))&&(s=r),h>=0?(a=(e.min.z-d.z)*h,c=(e.max.z-d.z)*h):(a=(e.max.z-d.z)*h,c=(e.min.z-d.z)*h),n>c||a>s)||((a>n||n!==n)&&(n=a),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,io)!==null}intersectTriangle(e,t,n,s,o){Ru.subVectors(t,e),zc.subVectors(n,e),Cu.crossVectors(Ru,zc);let r=this.direction.dot(Cu),a;if(r>0){if(s)return null;a=1}else if(r<0)a=-1,r=-r;else return null;Lo.subVectors(this.origin,e);const c=a*this.direction.dot(zc.crossVectors(Lo,zc));if(c<0)return null;const l=a*this.direction.dot(Ru.cross(Lo));if(l<0||c+l>r)return null;const u=-a*Lo.dot(Cu);return u<0?null:this.at(u/r,o)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class bn extends Ts{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new ws,this.combine=Td,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const tp=new Wt,Jo=new _c,Wc=new Ys,np=new I,Xc=new I,qc=new I,Yc=new I,Pu=new I,Kc=new I,ip=new I,Zc=new I;class W extends kn{constructor(e=new Tn,t=new bn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let o=0,r=s.length;o<r;o++){const a=s[o].name||String(o);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=o}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,o=n.morphAttributes.position,r=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const a=this.morphTargetInfluences;if(o&&a){Kc.set(0,0,0);for(let c=0,l=o.length;c<l;c++){const u=a[c],h=o[c];u!==0&&(Pu.fromBufferAttribute(h,e),r?Kc.addScaledVector(Pu,u):Kc.addScaledVector(Pu.sub(t),u))}t.add(Kc)}return t}raycast(e,t){const n=this.geometry,s=this.material,o=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Wc.copy(n.boundingSphere),Wc.applyMatrix4(o),Jo.copy(e.ray).recast(e.near),!(Wc.containsPoint(Jo.origin)===!1&&(Jo.intersectSphere(Wc,np)===null||Jo.origin.distanceToSquared(np)>(e.far-e.near)**2))&&(tp.copy(o).invert(),Jo.copy(e.ray).applyMatrix4(tp),!(n.boundingBox!==null&&Jo.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Jo)))}_computeIntersections(e,t,n){let s;const o=this.geometry,r=this.material,a=o.index,c=o.attributes.position,l=o.attributes.uv,u=o.attributes.uv1,h=o.attributes.normal,d=o.groups,f=o.drawRange;if(a!==null)if(Array.isArray(r))for(let p=0,x=d.length;p<x;p++){const m=d[p],g=r[m.materialIndex],M=Math.max(m.start,f.start),S=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let _=M,A=S;_<A;_+=3){const E=a.getX(_),L=a.getX(_+1),v=a.getX(_+2);s=$c(this,g,e,n,l,u,h,E,L,v),s&&(s.faceIndex=Math.floor(_/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const p=Math.max(0,f.start),x=Math.min(a.count,f.start+f.count);for(let m=p,g=x;m<g;m+=3){const M=a.getX(m),S=a.getX(m+1),_=a.getX(m+2);s=$c(this,r,e,n,l,u,h,M,S,_),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(c!==void 0)if(Array.isArray(r))for(let p=0,x=d.length;p<x;p++){const m=d[p],g=r[m.materialIndex],M=Math.max(m.start,f.start),S=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let _=M,A=S;_<A;_+=3){const E=_,L=_+1,v=_+2;s=$c(this,g,e,n,l,u,h,E,L,v),s&&(s.faceIndex=Math.floor(_/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const p=Math.max(0,f.start),x=Math.min(c.count,f.start+f.count);for(let m=p,g=x;m<g;m+=3){const M=m,S=m+1,_=m+2;s=$c(this,r,e,n,l,u,h,M,S,_),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function ev(i,e,t,n,s,o,r,a){let c;if(e.side===Ii?c=n.intersectTriangle(r,o,s,!0,a):c=n.intersectTriangle(s,o,r,e.side===Mo,a),c===null)return null;Zc.copy(a),Zc.applyMatrix4(i.matrixWorld);const l=t.ray.origin.distanceTo(Zc);return l<t.near||l>t.far?null:{distance:l,point:Zc.clone(),object:i}}function $c(i,e,t,n,s,o,r,a,c,l){i.getVertexPosition(a,Xc),i.getVertexPosition(c,qc),i.getVertexPosition(l,Yc);const u=ev(i,e,t,n,Xc,qc,Yc,ip);if(u){const h=new I;ys.getBarycoord(ip,Xc,qc,Yc,h),s&&(u.uv=ys.getInterpolatedAttribute(s,a,c,l,h,new _e)),o&&(u.uv1=ys.getInterpolatedAttribute(o,a,c,l,h,new _e)),r&&(u.normal=ys.getInterpolatedAttribute(r,a,c,l,h,new I),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));const d={a,b:c,c:l,normal:new I,materialIndex:0};ys.getNormal(Xc,qc,Yc,d.normal),u.face=d,u.barycoord=h}return u}const Ea=new Bn,sp=new Bn,op=new Bn,tv=new Bn,rp=new Wt,Jc=new I,Iu=new Ys,ap=new Wt,Lu=new _c;class nv extends W{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=Bf,this.bindMatrix=new Wt,this.bindMatrixInverse=new Wt,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new qs),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Jc),this.boundingBox.expandByPoint(Jc)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new Ys),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Jc),this.boundingSphere.expandByPoint(Jc)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Iu.copy(this.boundingSphere),Iu.applyMatrix4(s),e.ray.intersectsSphere(Iu)!==!1&&(ap.copy(s).invert(),Lu.copy(e.ray).applyMatrix4(ap),!(this.boundingBox!==null&&Lu.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Lu)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new Bn,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);const o=1/e.manhattanLength();o!==1/0?e.multiplyScalar(o):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===Bf?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===n_?this.bindMatrixInverse.copy(this.bindMatrix).invert():xt("SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,s=this.geometry;sp.fromBufferAttribute(s.attributes.skinIndex,e),op.fromBufferAttribute(s.attributes.skinWeight,e),t.isVector4?(Ea.copy(t),t.set(0,0,0,0)):(Ea.set(...t,1),t.set(0,0,0)),Ea.applyMatrix4(this.bindMatrix);for(let o=0;o<4;o++){const r=op.getComponent(o);if(r!==0){const a=sp.getComponent(o);rp.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(tv.copy(Ea).applyMatrix4(rp),r)}}return t.isVector4&&(t.w=Ea.w),t.applyMatrix4(this.bindMatrixInverse)}}class r0 extends kn{constructor(){super(),this.isBone=!0,this.type="Bone"}}class zl extends bi{constructor(e=null,t=1,n=1,s,o,r,a,c,l=vi,u=vi,h,d){super(null,r,a,c,l,u,s,o,h,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const cp=new Wt,iv=new Wt;class Hd{constructor(e=[],t=[]){this.uuid=us(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){xt("Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new Wt)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new Wt;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let o=0,r=e.length;o<r;o++){const a=e[o]?e[o].matrixWorld:iv;cp.multiplyMatrices(a,t[o]),cp.toArray(n,o*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new Hd(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new zl(t,e,e,Ki,cs);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){const o=e.bones[n];let r=t[o];r===void 0&&(xt("Skeleton: No bone found with UUID:",o),r=new r0),this.bones.push(r),this.boneInverses.push(new Wt().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let s=0,o=t.length;s<o;s++){const r=t[s];e.bones.push(r.uuid);const a=n[s];e.boneInverses.push(a.toArray())}return e}}class Yh extends Li{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Dr=new Wt,lp=new Wt,jc=[],up=new qs,sv=new Wt,Aa=new W,Ra=new Ys;class di extends W{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Yh(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,sv)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new qs),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Dr),up.copy(e.boundingBox).applyMatrix4(Dr),this.boundingBox.union(up)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ys),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Dr),Ra.copy(e.boundingSphere).applyMatrix4(Dr),this.boundingSphere.union(Ra)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,o=n.length+1,r=e*o+1;for(let a=0;a<n.length;a++)n[a]=s[r+a]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(Aa.geometry=this.geometry,Aa.material=this.material,Aa.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ra.copy(this.boundingSphere),Ra.applyMatrix4(n),e.ray.intersectsSphere(Ra)!==!1))for(let o=0;o<s;o++){this.getMatrixAt(o,Dr),lp.multiplyMatrices(n,Dr),Aa.matrixWorld=lp,Aa.raycast(e,jc);for(let r=0,a=jc.length;r<a;r++){const c=jc[r];c.instanceId=o,c.object=this,t.push(c)}jc.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new Yh(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new zl(new Float32Array(s*this.count),s,this.count,Cd,cs));const o=this.morphTexture.source.data.data;let r=0;for(let l=0;l<n.length;l++)r+=n[l];const a=this.geometry.morphTargetsRelative?1:1-r,c=s*e;return o[c]=a,o.set(n,c+1),this}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Du=new I,ov=new I,rv=new Yt;class Uo{constructor(e=new I(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=Du.subVectors(n,t).cross(ov.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){const s=e.delta(Du),o=this.normal.dot(s);if(o===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/o;return n===!0&&(r<0||r>1)?null:t.copy(e.start).addScaledVector(s,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||rv.getNormalMatrix(e),s=this.coplanarPoint(Du).applyMatrix4(e),o=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(o),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const jo=new Ys,av=new _e(.5,.5),Qc=new I;class Gd{constructor(e=new Uo,t=new Uo,n=new Uo,s=new Uo,o=new Uo,r=new Uo){this.planes=[e,t,n,s,o,r]}set(e,t,n,s,o,r){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(o),a[5].copy(r),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Gs,n=!1){const s=this.planes,o=e.elements,r=o[0],a=o[1],c=o[2],l=o[3],u=o[4],h=o[5],d=o[6],f=o[7],p=o[8],x=o[9],m=o[10],g=o[11],M=o[12],S=o[13],_=o[14],A=o[15];if(s[0].setComponents(l-r,f-u,g-p,A-M).normalize(),s[1].setComponents(l+r,f+u,g+p,A+M).normalize(),s[2].setComponents(l+a,f+h,g+x,A+S).normalize(),s[3].setComponents(l-a,f-h,g-x,A-S).normalize(),n)s[4].setComponents(c,d,m,_).normalize(),s[5].setComponents(l-c,f-d,g-m,A-_).normalize();else if(s[4].setComponents(l-c,f-d,g-m,A-_).normalize(),t===Gs)s[5].setComponents(l+c,f+d,g+m,A+_).normalize();else if(t===ac)s[5].setComponents(c,d,m,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),jo.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),jo.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(jo)}intersectsSprite(e){jo.center.set(0,0,0);const t=av.distanceTo(e.center);return jo.radius=.7071067811865476+t,jo.applyMatrix4(e.matrixWorld),this.intersectsSphere(jo)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let o=0;o<6;o++)if(t[o].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(Qc.x=s.normal.x>0?e.max.x:e.min.x,Qc.y=s.normal.y>0?e.max.y:e.min.y,Qc.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Qc)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Vd extends Ts{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Qe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Pl=new I,Il=new I,hp=new Wt,Ca=new _c,el=new Ys,Nu=new I,dp=new I;class Wl extends kn{constructor(e=new Tn,t=new Vd){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,o=t.count;s<o;s++)Pl.fromBufferAttribute(t,s-1),Il.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=Pl.distanceTo(Il);e.setAttribute("lineDistance",new Dt(n,1))}else xt("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,o=e.params.Line.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),el.copy(n.boundingSphere),el.applyMatrix4(s),el.radius+=o,e.ray.intersectsSphere(el)===!1)return;hp.copy(s).invert(),Ca.copy(e.ray).applyMatrix4(hp);const a=o/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=this.isLineSegments?2:1,u=n.index,d=n.attributes.position;if(u!==null){const f=Math.max(0,r.start),p=Math.min(u.count,r.start+r.count);for(let x=f,m=p-1;x<m;x+=l){const g=u.getX(x),M=u.getX(x+1),S=tl(this,e,Ca,c,g,M,x);S&&t.push(S)}if(this.isLineLoop){const x=u.getX(p-1),m=u.getX(f),g=tl(this,e,Ca,c,x,m,p-1);g&&t.push(g)}}else{const f=Math.max(0,r.start),p=Math.min(d.count,r.start+r.count);for(let x=f,m=p-1;x<m;x+=l){const g=tl(this,e,Ca,c,x,x+1,x);g&&t.push(g)}if(this.isLineLoop){const x=tl(this,e,Ca,c,p-1,f,p-1);x&&t.push(x)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let o=0,r=s.length;o<r;o++){const a=s[o].name||String(o);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=o}}}}}function tl(i,e,t,n,s,o,r){const a=i.geometry.attributes.position;if(Pl.fromBufferAttribute(a,s),Il.fromBufferAttribute(a,o),t.distanceSqToSegment(Pl,Il,Nu,dp)>n)return;Nu.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(Nu);if(!(l<e.near||l>e.far))return{distance:l,point:dp.clone().applyMatrix4(i.matrixWorld),index:r,face:null,faceIndex:null,barycoord:null,object:i}}const fp=new I,pp=new I;class cv extends Wl{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,o=t.count;s<o;s+=2)fp.fromBufferAttribute(t,s),pp.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+fp.distanceTo(pp);e.setAttribute("lineDistance",new Dt(n,1))}else xt("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class lv extends Wl{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}}class zd extends Ts{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Qe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const mp=new Wt,Kh=new _c,nl=new Ys,il=new I;class a0 extends kn{constructor(e=new Tn,t=new zd){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,o=e.params.Points.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),nl.copy(n.boundingSphere),nl.applyMatrix4(s),nl.radius+=o,e.ray.intersectsSphere(nl)===!1)return;mp.copy(s).invert(),Kh.copy(e.ray).applyMatrix4(mp);const a=o/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=n.index,h=n.attributes.position;if(l!==null){const d=Math.max(0,r.start),f=Math.min(l.count,r.start+r.count);for(let p=d,x=f;p<x;p++){const m=l.getX(p);il.fromBufferAttribute(h,m),gp(il,m,c,s,e,t,this)}}else{const d=Math.max(0,r.start),f=Math.min(h.count,r.start+r.count);for(let p=d,x=f;p<x;p++)il.fromBufferAttribute(h,p),gp(il,p,c,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let o=0,r=s.length;o<r;o++){const a=s[o].name||String(o);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=o}}}}}function gp(i,e,t,n,s,o,r){const a=Kh.distanceSqToPoint(i);if(a<t){const c=new I;Kh.closestPointToPoint(i,c),c.applyMatrix4(n);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;o.push({distance:l,distanceToRay:Math.sqrt(a),point:c,index:e,face:null,faceIndex:null,barycoord:null,object:r})}}class c0 extends bi{constructor(e=[],t=pr,n,s,o,r,a,c,l,u){super(e,t,n,s,o,r,a,c,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class ia extends bi{constructor(e,t,n=Xs,s,o,r,a=vi,c=vi,l,u=bo,h=1){if(u!==bo&&u!==ar)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:e,height:t,depth:h};super(d,s,o,r,a,c,u,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Od(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class uv extends ia{constructor(e,t=Xs,n=pr,s,o,r=vi,a=vi,c,l=bo){const u={width:e,height:e,depth:1},h=[u,u,u,u,u,u];super(e,e,t,n,s,o,r,a,c,l),this.image=h,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class l0 extends bi{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class fn extends Tn{constructor(e=1,t=1,n=1,s=1,o=1,r=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:o,depthSegments:r};const a=this;s=Math.floor(s),o=Math.floor(o),r=Math.floor(r);const c=[],l=[],u=[],h=[];let d=0,f=0;p("z","y","x",-1,-1,n,t,e,r,o,0),p("z","y","x",1,-1,n,t,-e,r,o,1),p("x","z","y",1,1,e,n,t,s,r,2),p("x","z","y",1,-1,e,n,-t,s,r,3),p("x","y","z",1,-1,e,t,n,s,o,4),p("x","y","z",-1,-1,e,t,-n,s,o,5),this.setIndex(c),this.setAttribute("position",new Dt(l,3)),this.setAttribute("normal",new Dt(u,3)),this.setAttribute("uv",new Dt(h,2));function p(x,m,g,M,S,_,A,E,L,v,R){const D=_/L,N=A/v,B=_/2,ne=A/2,ae=E/2,V=L+1,se=v+1;let K=0,he=0;const me=new I;for(let Re=0;Re<se;Re++){const we=Re*N-ne;for(let Xe=0;Xe<V;Xe++){const $t=Xe*D-B;me[x]=$t*M,me[m]=we*S,me[g]=ae,l.push(me.x,me.y,me.z),me[x]=0,me[m]=0,me[g]=E>0?1:-1,u.push(me.x,me.y,me.z),h.push(Xe/L),h.push(1-Re/v),K+=1}}for(let Re=0;Re<v;Re++)for(let we=0;we<L;we++){const Xe=d+we+V*Re,$t=d+we+V*(Re+1),hn=d+(we+1)+V*(Re+1),Qt=d+(we+1)+V*Re;c.push(Xe,$t,Qt),c.push($t,hn,Qt),he+=6}a.addGroup(f,he,R),f+=he,d+=K}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new fn(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Ll extends Tn{constructor(e=1,t=1,n=4,s=8,o=1){super(),this.type="CapsuleGeometry",this.parameters={radius:e,height:t,capSegments:n,radialSegments:s,heightSegments:o},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),s=Math.max(3,Math.floor(s)),o=Math.max(1,Math.floor(o));const r=[],a=[],c=[],l=[],u=t/2,h=Math.PI/2*e,d=t,f=2*h+d,p=n*2+o,x=s+1,m=new I,g=new I;for(let M=0;M<=p;M++){let S=0,_=0,A=0,E=0;if(M<=n){const R=M/n,D=R*Math.PI/2;_=-u-e*Math.cos(D),A=e*Math.sin(D),E=-e*Math.cos(D),S=R*h}else if(M<=n+o){const R=(M-n)/o;_=-u+R*t,A=e,E=0,S=h+R*d}else{const R=(M-n-o)/n,D=R*Math.PI/2;_=u+e*Math.sin(D),A=e*Math.cos(D),E=e*Math.sin(D),S=h+d+R*h}const L=Math.max(0,Math.min(1,S/f));let v=0;M===0?v=.5/s:M===p&&(v=-.5/s);for(let R=0;R<=s;R++){const D=R/s,N=D*Math.PI*2,B=Math.sin(N),ne=Math.cos(N);g.x=-A*ne,g.y=_,g.z=A*B,a.push(g.x,g.y,g.z),m.set(-A*ne,E,A*B),m.normalize(),c.push(m.x,m.y,m.z),l.push(D+v,L)}if(M>0){const R=(M-1)*x;for(let D=0;D<s;D++){const N=R+D,B=R+D+1,ne=M*x+D,ae=M*x+D+1;r.push(N,B,ne),r.push(B,ae,ne)}}}this.setIndex(r),this.setAttribute("position",new Dt(a,3)),this.setAttribute("normal",new Dt(c,3)),this.setAttribute("uv",new Dt(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ll(e.radius,e.height,e.capSegments,e.radialSegments,e.heightSegments)}}class ir extends Tn{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);const o=[],r=[],a=[],c=[],l=new I,u=new _e;r.push(0,0,0),a.push(0,0,1),c.push(.5,.5);for(let h=0,d=3;h<=t;h++,d+=3){const f=n+h/t*s;l.x=e*Math.cos(f),l.y=e*Math.sin(f),r.push(l.x,l.y,l.z),a.push(0,0,1),u.x=(r[d]/e+1)/2,u.y=(r[d+1]/e+1)/2,c.push(u.x,u.y)}for(let h=1;h<=t;h++)o.push(h,h+1,0);this.setIndex(o),this.setAttribute("position",new Dt(r,3)),this.setAttribute("normal",new Dt(a,3)),this.setAttribute("uv",new Dt(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ir(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Ot extends Tn{constructor(e=1,t=1,n=1,s=32,o=1,r=!1,a=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:o,openEnded:r,thetaStart:a,thetaLength:c};const l=this;s=Math.floor(s),o=Math.floor(o);const u=[],h=[],d=[],f=[];let p=0;const x=[],m=n/2;let g=0;M(),r===!1&&(e>0&&S(!0),t>0&&S(!1)),this.setIndex(u),this.setAttribute("position",new Dt(h,3)),this.setAttribute("normal",new Dt(d,3)),this.setAttribute("uv",new Dt(f,2));function M(){const _=new I,A=new I;let E=0;const L=(t-e)/n;for(let v=0;v<=o;v++){const R=[],D=v/o,N=D*(t-e)+e;for(let B=0;B<=s;B++){const ne=B/s,ae=ne*c+a,V=Math.sin(ae),se=Math.cos(ae);A.x=N*V,A.y=-D*n+m,A.z=N*se,h.push(A.x,A.y,A.z),_.set(V,L,se).normalize(),d.push(_.x,_.y,_.z),f.push(ne,1-D),R.push(p++)}x.push(R)}for(let v=0;v<s;v++)for(let R=0;R<o;R++){const D=x[R][v],N=x[R+1][v],B=x[R+1][v+1],ne=x[R][v+1];(e>0||R!==0)&&(u.push(D,N,ne),E+=3),(t>0||R!==o-1)&&(u.push(N,B,ne),E+=3)}l.addGroup(g,E,0),g+=E}function S(_){const A=p,E=new _e,L=new I;let v=0;const R=_===!0?e:t,D=_===!0?1:-1;for(let B=1;B<=s;B++)h.push(0,m*D,0),d.push(0,D,0),f.push(.5,.5),p++;const N=p;for(let B=0;B<=s;B++){const ae=B/s*c+a,V=Math.cos(ae),se=Math.sin(ae);L.x=R*se,L.y=m*D,L.z=R*V,h.push(L.x,L.y,L.z),d.push(0,D,0),E.x=V*.5+.5,E.y=se*.5*D+.5,f.push(E.x,E.y),p++}for(let B=0;B<s;B++){const ne=A+B,ae=N+B;_===!0?u.push(ae,ae+1,ne):u.push(ae+1,ae,ne),v+=3}l.addGroup(g,v,_===!0?1:2),g+=v}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ot(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Fi extends Ot{constructor(e=1,t=1,n=32,s=1,o=!1,r=0,a=Math.PI*2){super(0,e,t,n,s,o,r,a),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:o,thetaStart:r,thetaLength:a}}static fromJSON(e){return new Fi(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class la extends Tn{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const o=[],r=[];a(s),l(n),u(),this.setAttribute("position",new Dt(o,3)),this.setAttribute("normal",new Dt(o.slice(),3)),this.setAttribute("uv",new Dt(r,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(M){const S=new I,_=new I,A=new I;for(let E=0;E<t.length;E+=3)f(t[E+0],S),f(t[E+1],_),f(t[E+2],A),c(S,_,A,M)}function c(M,S,_,A){const E=A+1,L=[];for(let v=0;v<=E;v++){L[v]=[];const R=M.clone().lerp(_,v/E),D=S.clone().lerp(_,v/E),N=E-v;for(let B=0;B<=N;B++)B===0&&v===E?L[v][B]=R:L[v][B]=R.clone().lerp(D,B/N)}for(let v=0;v<E;v++)for(let R=0;R<2*(E-v)-1;R++){const D=Math.floor(R/2);R%2===0?(d(L[v][D+1]),d(L[v+1][D]),d(L[v][D])):(d(L[v][D+1]),d(L[v+1][D+1]),d(L[v+1][D]))}}function l(M){const S=new I;for(let _=0;_<o.length;_+=3)S.x=o[_+0],S.y=o[_+1],S.z=o[_+2],S.normalize().multiplyScalar(M),o[_+0]=S.x,o[_+1]=S.y,o[_+2]=S.z}function u(){const M=new I;for(let S=0;S<o.length;S+=3){M.x=o[S+0],M.y=o[S+1],M.z=o[S+2];const _=m(M)/2/Math.PI+.5,A=g(M)/Math.PI+.5;r.push(_,1-A)}p(),h()}function h(){for(let M=0;M<r.length;M+=6){const S=r[M+0],_=r[M+2],A=r[M+4],E=Math.max(S,_,A),L=Math.min(S,_,A);E>.9&&L<.1&&(S<.2&&(r[M+0]+=1),_<.2&&(r[M+2]+=1),A<.2&&(r[M+4]+=1))}}function d(M){o.push(M.x,M.y,M.z)}function f(M,S){const _=M*3;S.x=e[_+0],S.y=e[_+1],S.z=e[_+2]}function p(){const M=new I,S=new I,_=new I,A=new I,E=new _e,L=new _e,v=new _e;for(let R=0,D=0;R<o.length;R+=9,D+=6){M.set(o[R+0],o[R+1],o[R+2]),S.set(o[R+3],o[R+4],o[R+5]),_.set(o[R+6],o[R+7],o[R+8]),E.set(r[D+0],r[D+1]),L.set(r[D+2],r[D+3]),v.set(r[D+4],r[D+5]),A.copy(M).add(S).add(_).divideScalar(3);const N=m(A);x(E,D+0,M,N),x(L,D+2,S,N),x(v,D+4,_,N)}}function x(M,S,_,A){A<0&&M.x===1&&(r[S]=M.x-1),_.x===0&&_.z===0&&(r[S]=A/2/Math.PI+.5)}function m(M){return Math.atan2(M.z,-M.x)}function g(M){return Math.atan2(-M.y,Math.sqrt(M.x*M.x+M.z*M.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new la(e.vertices,e.indices,e.radius,e.detail)}}class Xa extends la{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=1/n,o=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],r=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(o,r,e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Xa(e.radius,e.detail)}}class Ks{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){xt("Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,s=this.getPoint(0),o=0;t.push(0);for(let r=1;r<=e;r++)n=this.getPoint(r/e),o+=n.distanceTo(s),t.push(o),s=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let s=0;const o=n.length;let r;t?r=t:r=e*n[o-1];let a=0,c=o-1,l;for(;a<=c;)if(s=Math.floor(a+(c-a)/2),l=n[s]-r,l<0)a=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,n[s]===r)return s/(o-1);const u=n[s],d=n[s+1]-u,f=(r-u)/d;return(s+f)/(o-1)}getTangent(e,t){let s=e-1e-4,o=e+1e-4;s<0&&(s=0),o>1&&(o=1);const r=this.getPoint(s),a=this.getPoint(o),c=t||(r.isVector2?new _e:new I);return c.copy(a).sub(r).normalize(),c}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new I,s=[],o=[],r=[],a=new I,c=new Wt;for(let f=0;f<=e;f++){const p=f/e;s[f]=this.getTangentAt(p,new I)}o[0]=new I,r[0]=new I;let l=Number.MAX_VALUE;const u=Math.abs(s[0].x),h=Math.abs(s[0].y),d=Math.abs(s[0].z);u<=l&&(l=u,n.set(1,0,0)),h<=l&&(l=h,n.set(0,1,0)),d<=l&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),o[0].crossVectors(s[0],a),r[0].crossVectors(s[0],o[0]);for(let f=1;f<=e;f++){if(o[f]=o[f-1].clone(),r[f]=r[f-1].clone(),a.crossVectors(s[f-1],s[f]),a.length()>Number.EPSILON){a.normalize();const p=Math.acos(sn(s[f-1].dot(s[f]),-1,1));o[f].applyMatrix4(c.makeRotationAxis(a,p))}r[f].crossVectors(s[f],o[f])}if(t===!0){let f=Math.acos(sn(o[0].dot(o[e]),-1,1));f/=e,s[0].dot(a.crossVectors(o[0],o[e]))>0&&(f=-f);for(let p=1;p<=e;p++)o[p].applyMatrix4(c.makeRotationAxis(s[p],f*p)),r[p].crossVectors(s[p],o[p])}return{tangents:s,normals:o,binormals:r}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Wd extends Ks{constructor(e=0,t=0,n=1,s=1,o=0,r=Math.PI*2,a=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=s,this.aStartAngle=o,this.aEndAngle=r,this.aClockwise=a,this.aRotation=c}getPoint(e,t=new _e){const n=t,s=Math.PI*2;let o=this.aEndAngle-this.aStartAngle;const r=Math.abs(o)<Number.EPSILON;for(;o<0;)o+=s;for(;o>s;)o-=s;o<Number.EPSILON&&(r?o=0:o=s),this.aClockwise===!0&&!r&&(o===s?o=-s:o=o-s);const a=this.aStartAngle+e*o;let c=this.aX+this.xRadius*Math.cos(a),l=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){const u=Math.cos(this.aRotation),h=Math.sin(this.aRotation),d=c-this.aX,f=l-this.aY;c=d*u-f*h+this.aX,l=d*h+f*u+this.aY}return n.set(c,l)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class hv extends Wd{constructor(e,t,n,s,o,r){super(e,t,n,n,s,o,r),this.isArcCurve=!0,this.type="ArcCurve"}}function Xd(){let i=0,e=0,t=0,n=0;function s(o,r,a,c){i=o,e=a,t=-3*o+3*r-2*a-c,n=2*o-2*r+a+c}return{initCatmullRom:function(o,r,a,c,l){s(r,a,l*(a-o),l*(c-r))},initNonuniformCatmullRom:function(o,r,a,c,l,u,h){let d=(r-o)/l-(a-o)/(l+u)+(a-r)/u,f=(a-r)/u-(c-r)/(u+h)+(c-a)/h;d*=u,f*=u,s(r,a,d,f)},calc:function(o){const r=o*o,a=r*o;return i+e*o+t*r+n*a}}}const xp=new I,_p=new I,Uu=new Xd,Fu=new Xd,Ou=new Xd;class er extends Ks{constructor(e=[],t=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=s}getPoint(e,t=new I){const n=t,s=this.points,o=s.length,r=(o-(this.closed?0:1))*e;let a=Math.floor(r),c=r-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/o)+1)*o:c===0&&a===o-1&&(a=o-2,c=1);let l,u;this.closed||a>0?l=s[(a-1)%o]:(_p.subVectors(s[0],s[1]).add(s[0]),l=_p);const h=s[a%o],d=s[(a+1)%o];if(this.closed||a+2<o?u=s[(a+2)%o]:(xp.subVectors(s[o-1],s[o-2]).add(s[o-1]),u=xp),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let p=Math.pow(l.distanceToSquared(h),f),x=Math.pow(h.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(u),f);x<1e-4&&(x=1),p<1e-4&&(p=x),m<1e-4&&(m=x),Uu.initNonuniformCatmullRom(l.x,h.x,d.x,u.x,p,x,m),Fu.initNonuniformCatmullRom(l.y,h.y,d.y,u.y,p,x,m),Ou.initNonuniformCatmullRom(l.z,h.z,d.z,u.z,p,x,m)}else this.curveType==="catmullrom"&&(Uu.initCatmullRom(l.x,h.x,d.x,u.x,this.tension),Fu.initCatmullRom(l.y,h.y,d.y,u.y,this.tension),Ou.initCatmullRom(l.z,h.z,d.z,u.z,this.tension));return n.set(Uu.calc(c),Fu.calc(c),Ou.calc(c)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new I().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function vp(i,e,t,n,s){const o=(n-e)*.5,r=(s-t)*.5,a=i*i,c=i*a;return(2*t-2*n+o+r)*c+(-3*t+3*n-2*o-r)*a+o*i+t}function dv(i,e){const t=1-i;return t*t*e}function fv(i,e){return 2*(1-i)*i*e}function pv(i,e){return i*i*e}function qa(i,e,t,n){return dv(i,e)+fv(i,t)+pv(i,n)}function mv(i,e){const t=1-i;return t*t*t*e}function gv(i,e){const t=1-i;return 3*t*t*i*e}function xv(i,e){return 3*(1-i)*i*i*e}function _v(i,e){return i*i*i*e}function Ya(i,e,t,n,s){return mv(i,e)+gv(i,t)+xv(i,n)+_v(i,s)}class u0 extends Ks{constructor(e=new _e,t=new _e,n=new _e,s=new _e){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new _e){const n=t,s=this.v0,o=this.v1,r=this.v2,a=this.v3;return n.set(Ya(e,s.x,o.x,r.x,a.x),Ya(e,s.y,o.y,r.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class vv extends Ks{constructor(e=new I,t=new I,n=new I,s=new I){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new I){const n=t,s=this.v0,o=this.v1,r=this.v2,a=this.v3;return n.set(Ya(e,s.x,o.x,r.x,a.x),Ya(e,s.y,o.y,r.y,a.y),Ya(e,s.z,o.z,r.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class h0 extends Ks{constructor(e=new _e,t=new _e){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new _e){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new _e){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class yv extends Ks{constructor(e=new I,t=new I){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new I){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new I){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class d0 extends Ks{constructor(e=new _e,t=new _e,n=new _e){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new _e){const n=t,s=this.v0,o=this.v1,r=this.v2;return n.set(qa(e,s.x,o.x,r.x),qa(e,s.y,o.y,r.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class f0 extends Ks{constructor(e=new I,t=new I,n=new I){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new I){const n=t,s=this.v0,o=this.v1,r=this.v2;return n.set(qa(e,s.x,o.x,r.x),qa(e,s.y,o.y,r.y),qa(e,s.z,o.z,r.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class p0 extends Ks{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new _e){const n=t,s=this.points,o=(s.length-1)*e,r=Math.floor(o),a=o-r,c=s[r===0?r:r-1],l=s[r],u=s[r>s.length-2?s.length-1:r+1],h=s[r>s.length-3?s.length-1:r+2];return n.set(vp(a,c.x,l.x,u.x,h.x),vp(a,c.y,l.y,u.y,h.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new _e().fromArray(s))}return this}}var Dl=Object.freeze({__proto__:null,ArcCurve:hv,CatmullRomCurve3:er,CubicBezierCurve:u0,CubicBezierCurve3:vv,EllipseCurve:Wd,LineCurve:h0,LineCurve3:yv,QuadraticBezierCurve:d0,QuadraticBezierCurve3:f0,SplineCurve:p0});class Mv extends Ks{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Dl[n](t,e))}return this}getPoint(e,t){const n=e*this.getLength(),s=this.getCurveLengths();let o=0;for(;o<s.length;){if(s[o]>=n){const r=s[o]-n,a=this.curves[o],c=a.getLength(),l=c===0?0:1-r/c;return a.getPointAt(l,t)}o++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let n=0,s=this.curves.length;n<s;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let n;for(let s=0,o=this.curves;s<o.length;s++){const r=o[s],a=r.isEllipseCurve?e*2:r.isLineCurve||r.isLineCurve3?1:r.isSplineCurve?e*r.points.length:e,c=r.getPoints(a);for(let l=0;l<c.length;l++){const u=c[l];n&&n.equals(u)||(t.push(u),n=u)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(new Dl[s.type]().fromJSON(s))}return this}}class yp extends Mv{constructor(e){super(),this.type="Path",this.currentPoint=new _e,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const n=new h0(this.currentPoint.clone(),new _e(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,s){const o=new d0(this.currentPoint.clone(),new _e(e,t),new _e(n,s));return this.curves.push(o),this.currentPoint.set(n,s),this}bezierCurveTo(e,t,n,s,o,r){const a=new u0(this.currentPoint.clone(),new _e(e,t),new _e(n,s),new _e(o,r));return this.curves.push(a),this.currentPoint.set(o,r),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),n=new p0(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,s,o,r){const a=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(e+a,t+c,n,s,o,r),this}absarc(e,t,n,s,o,r){return this.absellipse(e,t,n,n,s,o,r),this}ellipse(e,t,n,s,o,r,a,c){const l=this.currentPoint.x,u=this.currentPoint.y;return this.absellipse(e+l,t+u,n,s,o,r,a,c),this}absellipse(e,t,n,s,o,r,a,c){const l=new Wd(e,t,n,s,o,r,a,c);if(this.curves.length>0){const h=l.getPoint(0);h.equals(this.currentPoint)||this.lineTo(h.x,h.y)}this.curves.push(l);const u=l.getPoint(1);return this.currentPoint.copy(u),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Nl extends yp{constructor(e){super(e),this.uuid=us(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let n=0,s=this.holes.length;n<s;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(new yp().fromJSON(s))}return this}}function Sv(i,e,t=2){const n=e&&e.length,s=n?e[0]*t:i.length;let o=m0(i,0,s,t,!0);const r=[];if(!o||o.next===o.prev)return r;let a,c,l;if(n&&(o=Av(i,e,o,t)),i.length>80*t){a=i[0],c=i[1];let u=a,h=c;for(let d=t;d<s;d+=t){const f=i[d],p=i[d+1];f<a&&(a=f),p<c&&(c=p),f>u&&(u=f),p>h&&(h=p)}l=Math.max(u-a,h-c),l=l!==0?32767/l:0}return lc(o,r,t,a,c,l,0),r}function m0(i,e,t,n,s){let o;if(s===Bv(i,e,t,n)>0)for(let r=e;r<t;r+=n)o=Mp(r/n|0,i[r],i[r+1],o);else for(let r=t-n;r>=e;r-=n)o=Mp(r/n|0,i[r],i[r+1],o);return o&&sa(o,o.next)&&(hc(o),o=o.next),o}function xr(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(sa(t,t.next)||ti(t.prev,t,t.next)===0)){if(hc(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function lc(i,e,t,n,s,o,r){if(!i)return;!r&&o&&Lv(i,n,s,o);let a=i;for(;i.prev!==i.next;){const c=i.prev,l=i.next;if(o?Tv(i,n,s,o):bv(i)){e.push(c.i,i.i,l.i),hc(i),i=l.next,a=l.next;continue}if(i=l,i===a){r?r===1?(i=wv(xr(i),e),lc(i,e,t,n,s,o,2)):r===2&&Ev(i,e,t,n,s,o):lc(xr(i),e,t,n,s,o,1);break}}}function bv(i){const e=i.prev,t=i,n=i.next;if(ti(e,t,n)>=0)return!1;const s=e.x,o=t.x,r=n.x,a=e.y,c=t.y,l=n.y,u=Math.min(s,o,r),h=Math.min(a,c,l),d=Math.max(s,o,r),f=Math.max(a,c,l);let p=n.next;for(;p!==e;){if(p.x>=u&&p.x<=d&&p.y>=h&&p.y<=f&&Ua(s,a,o,c,r,l,p.x,p.y)&&ti(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function Tv(i,e,t,n){const s=i.prev,o=i,r=i.next;if(ti(s,o,r)>=0)return!1;const a=s.x,c=o.x,l=r.x,u=s.y,h=o.y,d=r.y,f=Math.min(a,c,l),p=Math.min(u,h,d),x=Math.max(a,c,l),m=Math.max(u,h,d),g=Zh(f,p,e,t,n),M=Zh(x,m,e,t,n);let S=i.prevZ,_=i.nextZ;for(;S&&S.z>=g&&_&&_.z<=M;){if(S.x>=f&&S.x<=x&&S.y>=p&&S.y<=m&&S!==s&&S!==r&&Ua(a,u,c,h,l,d,S.x,S.y)&&ti(S.prev,S,S.next)>=0||(S=S.prevZ,_.x>=f&&_.x<=x&&_.y>=p&&_.y<=m&&_!==s&&_!==r&&Ua(a,u,c,h,l,d,_.x,_.y)&&ti(_.prev,_,_.next)>=0))return!1;_=_.nextZ}for(;S&&S.z>=g;){if(S.x>=f&&S.x<=x&&S.y>=p&&S.y<=m&&S!==s&&S!==r&&Ua(a,u,c,h,l,d,S.x,S.y)&&ti(S.prev,S,S.next)>=0)return!1;S=S.prevZ}for(;_&&_.z<=M;){if(_.x>=f&&_.x<=x&&_.y>=p&&_.y<=m&&_!==s&&_!==r&&Ua(a,u,c,h,l,d,_.x,_.y)&&ti(_.prev,_,_.next)>=0)return!1;_=_.nextZ}return!0}function wv(i,e){let t=i;do{const n=t.prev,s=t.next.next;!sa(n,s)&&x0(n,t,t.next,s)&&uc(n,s)&&uc(s,n)&&(e.push(n.i,t.i,s.i),hc(t),hc(t.next),t=i=s),t=t.next}while(t!==i);return xr(t)}function Ev(i,e,t,n,s,o){let r=i;do{let a=r.next.next;for(;a!==r.prev;){if(r.i!==a.i&&Uv(r,a)){let c=_0(r,a);r=xr(r,r.next),c=xr(c,c.next),lc(r,e,t,n,s,o,0),lc(c,e,t,n,s,o,0);return}a=a.next}r=r.next}while(r!==i)}function Av(i,e,t,n){const s=[];for(let o=0,r=e.length;o<r;o++){const a=e[o]*n,c=o<r-1?e[o+1]*n:i.length,l=m0(i,a,c,n,!1);l===l.next&&(l.steiner=!0),s.push(Nv(l))}s.sort(Rv);for(let o=0;o<s.length;o++)t=Cv(s[o],t);return t}function Rv(i,e){let t=i.x-e.x;if(t===0&&(t=i.y-e.y,t===0)){const n=(i.next.y-i.y)/(i.next.x-i.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=n-s}return t}function Cv(i,e){const t=Pv(i,e);if(!t)return e;const n=_0(t,i);return xr(n,n.next),xr(t,t.next)}function Pv(i,e){let t=e;const n=i.x,s=i.y;let o=-1/0,r;if(sa(i,t))return t;do{if(sa(i,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){const h=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(h<=n&&h>o&&(o=h,r=t.x<t.next.x?t:t.next,h===n))return r}t=t.next}while(t!==e);if(!r)return null;const a=r,c=r.x,l=r.y;let u=1/0;t=r;do{if(n>=t.x&&t.x>=c&&n!==t.x&&g0(s<l?n:o,s,c,l,s<l?o:n,s,t.x,t.y)){const h=Math.abs(s-t.y)/(n-t.x);uc(t,i)&&(h<u||h===u&&(t.x>r.x||t.x===r.x&&Iv(r,t)))&&(r=t,u=h)}t=t.next}while(t!==a);return r}function Iv(i,e){return ti(i.prev,i,e.prev)<0&&ti(e.next,i,i.next)<0}function Lv(i,e,t,n){let s=i;do s.z===0&&(s.z=Zh(s.x,s.y,e,t,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,Dv(s)}function Dv(i){let e,t=1;do{let n=i,s;i=null;let o=null;for(e=0;n;){e++;let r=n,a=0;for(let l=0;l<t&&(a++,r=r.nextZ,!!r);l++);let c=t;for(;a>0||c>0&&r;)a!==0&&(c===0||!r||n.z<=r.z)?(s=n,n=n.nextZ,a--):(s=r,r=r.nextZ,c--),o?o.nextZ=s:i=s,s.prevZ=o,o=s;n=r}o.nextZ=null,t*=2}while(e>1);return i}function Zh(i,e,t,n,s){return i=(i-t)*s|0,e=(e-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function Nv(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function g0(i,e,t,n,s,o,r,a){return(s-r)*(e-a)>=(i-r)*(o-a)&&(i-r)*(n-a)>=(t-r)*(e-a)&&(t-r)*(o-a)>=(s-r)*(n-a)}function Ua(i,e,t,n,s,o,r,a){return!(i===r&&e===a)&&g0(i,e,t,n,s,o,r,a)}function Uv(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!Fv(i,e)&&(uc(i,e)&&uc(e,i)&&Ov(i,e)&&(ti(i.prev,i,e.prev)||ti(i,e.prev,e))||sa(i,e)&&ti(i.prev,i,i.next)>0&&ti(e.prev,e,e.next)>0)}function ti(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function sa(i,e){return i.x===e.x&&i.y===e.y}function x0(i,e,t,n){const s=ol(ti(i,e,t)),o=ol(ti(i,e,n)),r=ol(ti(t,n,i)),a=ol(ti(t,n,e));return!!(s!==o&&r!==a||s===0&&sl(i,t,e)||o===0&&sl(i,n,e)||r===0&&sl(t,i,n)||a===0&&sl(t,e,n))}function sl(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function ol(i){return i>0?1:i<0?-1:0}function Fv(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&x0(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function uc(i,e){return ti(i.prev,i,i.next)<0?ti(i,e,i.next)>=0&&ti(i,i.prev,e)>=0:ti(i,e,i.prev)<0||ti(i,i.next,e)<0}function Ov(i,e){let t=i,n=!1;const s=(i.x+e.x)/2,o=(i.y+e.y)/2;do t.y>o!=t.next.y>o&&t.next.y!==t.y&&s<(t.next.x-t.x)*(o-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function _0(i,e){const t=$h(i.i,i.x,i.y),n=$h(e.i,e.x,e.y),s=i.next,o=e.prev;return i.next=e,e.prev=i,t.next=s,s.prev=t,n.next=t,t.prev=n,o.next=n,n.prev=o,n}function Mp(i,e,t,n){const s=$h(i,e,t);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function hc(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function $h(i,e,t){return{i,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Bv(i,e,t,n){let s=0;for(let o=e,r=t-n;o<t;o+=n)s+=(i[r]-i[o])*(i[o+1]+i[r+1]),r=o;return s}class kv{static triangulate(e,t,n=2){return Sv(e,t,n)}}class lo{static area(e){const t=e.length;let n=0;for(let s=t-1,o=0;o<t;s=o++)n+=e[s].x*e[o].y-e[o].x*e[s].y;return n*.5}static isClockWise(e){return lo.area(e)<0}static triangulateShape(e,t){const n=[],s=[],o=[];Sp(e),bp(n,e);let r=e.length;t.forEach(Sp);for(let c=0;c<t.length;c++)s.push(r),r+=t[c].length,bp(n,t[c]);const a=kv.triangulate(n,s);for(let c=0;c<a.length;c+=3)o.push(a.slice(c,c+3));return o}}function Sp(i){const e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function bp(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}class qd extends Tn{constructor(e=new Nl([new _e(.5,.5),new _e(-.5,.5),new _e(-.5,-.5),new _e(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const n=this,s=[],o=[];for(let a=0,c=e.length;a<c;a++){const l=e[a];r(l)}this.setAttribute("position",new Dt(s,3)),this.setAttribute("uv",new Dt(o,2)),this.computeVertexNormals();function r(a){const c=[],l=t.curveSegments!==void 0?t.curveSegments:12,u=t.steps!==void 0?t.steps:1,h=t.depth!==void 0?t.depth:1;let d=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,p=t.bevelSize!==void 0?t.bevelSize:f-.1,x=t.bevelOffset!==void 0?t.bevelOffset:0,m=t.bevelSegments!==void 0?t.bevelSegments:3;const g=t.extrudePath,M=t.UVGenerator!==void 0?t.UVGenerator:Hv;let S,_=!1,A,E,L,v;if(g){S=g.getSpacedPoints(u),_=!0,d=!1;const pe=g.isCatmullRomCurve3?g.closed:!1;A=g.computeFrenetFrames(u,pe),E=new I,L=new I,v=new I}d||(m=0,f=0,p=0,x=0);const R=a.extractPoints(l);let D=R.shape;const N=R.holes;if(!lo.isClockWise(D)){D=D.reverse();for(let pe=0,ve=N.length;pe<ve;pe++){const ge=N[pe];lo.isClockWise(ge)&&(N[pe]=ge.reverse())}}function ne(pe){const ge=10000000000000001e-36;let Be=pe[0];for(let Fe=1;Fe<=pe.length;Fe++){const Et=Fe%pe.length,dt=pe[Et],Ut=dt.x-Be.x,Gt=dt.y-Be.y,F=Ut*Ut+Gt*Gt,wn=Math.max(Math.abs(dt.x),Math.abs(dt.y),Math.abs(Be.x),Math.abs(Be.y)),rn=ge*wn*wn;if(F<=rn){pe.splice(Et,1),Fe--;continue}Be=dt}}ne(D),N.forEach(ne);const ae=N.length,V=D;for(let pe=0;pe<ae;pe++){const ve=N[pe];D=D.concat(ve)}function se(pe,ve,ge){return ve||Lt("ExtrudeGeometry: vec does not exist"),pe.clone().addScaledVector(ve,ge)}const K=D.length;function he(pe,ve,ge){let Be,Fe,Et;const dt=pe.x-ve.x,Ut=pe.y-ve.y,Gt=ge.x-pe.x,F=ge.y-pe.y,wn=dt*dt+Ut*Ut,rn=dt*F-Ut*Gt;if(Math.abs(rn)>Number.EPSILON){const P=Math.sqrt(wn),y=Math.sqrt(Gt*Gt+F*F),z=ve.x-Ut/P,J=ve.y+dt/P,oe=ge.x-F/y,Ee=ge.y+Gt/y,Ae=((oe-z)*F-(Ee-J)*Gt)/(dt*F-Ut*Gt);Be=z+dt*Ae-pe.x,Fe=J+Ut*Ae-pe.y;const re=Be*Be+Fe*Fe;if(re<=2)return new _e(Be,Fe);Et=Math.sqrt(re/2)}else{let P=!1;dt>Number.EPSILON?Gt>Number.EPSILON&&(P=!0):dt<-Number.EPSILON?Gt<-Number.EPSILON&&(P=!0):Math.sign(Ut)===Math.sign(F)&&(P=!0),P?(Be=-Ut,Fe=dt,Et=Math.sqrt(wn)):(Be=dt,Fe=Ut,Et=Math.sqrt(wn/2))}return new _e(Be/Et,Fe/Et)}const me=[];for(let pe=0,ve=V.length,ge=ve-1,Be=pe+1;pe<ve;pe++,ge++,Be++)ge===ve&&(ge=0),Be===ve&&(Be=0),me[pe]=he(V[pe],V[ge],V[Be]);const Re=[];let we,Xe=me.concat();for(let pe=0,ve=ae;pe<ve;pe++){const ge=N[pe];we=[];for(let Be=0,Fe=ge.length,Et=Fe-1,dt=Be+1;Be<Fe;Be++,Et++,dt++)Et===Fe&&(Et=0),dt===Fe&&(dt=0),we[Be]=he(ge[Be],ge[Et],ge[dt]);Re.push(we),Xe=Xe.concat(we)}let $t;if(m===0)$t=lo.triangulateShape(V,N);else{const pe=[],ve=[];for(let ge=0;ge<m;ge++){const Be=ge/m,Fe=f*Math.cos(Be*Math.PI/2),Et=p*Math.sin(Be*Math.PI/2)+x;for(let dt=0,Ut=V.length;dt<Ut;dt++){const Gt=se(V[dt],me[dt],Et);ht(Gt.x,Gt.y,-Fe),Be===0&&pe.push(Gt)}for(let dt=0,Ut=ae;dt<Ut;dt++){const Gt=N[dt];we=Re[dt];const F=[];for(let wn=0,rn=Gt.length;wn<rn;wn++){const P=se(Gt[wn],we[wn],Et);ht(P.x,P.y,-Fe),Be===0&&F.push(P)}Be===0&&ve.push(F)}}$t=lo.triangulateShape(pe,ve)}const hn=$t.length,Qt=p+x;for(let pe=0;pe<K;pe++){const ve=d?se(D[pe],Xe[pe],Qt):D[pe];_?(L.copy(A.normals[0]).multiplyScalar(ve.x),E.copy(A.binormals[0]).multiplyScalar(ve.y),v.copy(S[0]).add(L).add(E),ht(v.x,v.y,v.z)):ht(ve.x,ve.y,0)}for(let pe=1;pe<=u;pe++)for(let ve=0;ve<K;ve++){const ge=d?se(D[ve],Xe[ve],Qt):D[ve];_?(L.copy(A.normals[pe]).multiplyScalar(ge.x),E.copy(A.binormals[pe]).multiplyScalar(ge.y),v.copy(S[pe]).add(L).add(E),ht(v.x,v.y,v.z)):ht(ge.x,ge.y,h/u*pe)}for(let pe=m-1;pe>=0;pe--){const ve=pe/m,ge=f*Math.cos(ve*Math.PI/2),Be=p*Math.sin(ve*Math.PI/2)+x;for(let Fe=0,Et=V.length;Fe<Et;Fe++){const dt=se(V[Fe],me[Fe],Be);ht(dt.x,dt.y,h+ge)}for(let Fe=0,Et=N.length;Fe<Et;Fe++){const dt=N[Fe];we=Re[Fe];for(let Ut=0,Gt=dt.length;Ut<Gt;Ut++){const F=se(dt[Ut],we[Ut],Be);_?ht(F.x,F.y+S[u-1].y,S[u-1].x+ge):ht(F.x,F.y,h+ge)}}}ce(),Ce();function ce(){const pe=s.length/3;if(d){let ve=0,ge=K*ve;for(let Be=0;Be<hn;Be++){const Fe=$t[Be];Nt(Fe[2]+ge,Fe[1]+ge,Fe[0]+ge)}ve=u+m*2,ge=K*ve;for(let Be=0;Be<hn;Be++){const Fe=$t[Be];Nt(Fe[0]+ge,Fe[1]+ge,Fe[2]+ge)}}else{for(let ve=0;ve<hn;ve++){const ge=$t[ve];Nt(ge[2],ge[1],ge[0])}for(let ve=0;ve<hn;ve++){const ge=$t[ve];Nt(ge[0]+K*u,ge[1]+K*u,ge[2]+K*u)}}n.addGroup(pe,s.length/3-pe,0)}function Ce(){const pe=s.length/3;let ve=0;ye(V,ve),ve+=V.length;for(let ge=0,Be=N.length;ge<Be;ge++){const Fe=N[ge];ye(Fe,ve),ve+=Fe.length}n.addGroup(pe,s.length/3-pe,1)}function ye(pe,ve){let ge=pe.length;for(;--ge>=0;){const Be=ge;let Fe=ge-1;Fe<0&&(Fe=pe.length-1);for(let Et=0,dt=u+m*2;Et<dt;Et++){const Ut=K*Et,Gt=K*(Et+1),F=ve+Be+Ut,wn=ve+Fe+Ut,rn=ve+Fe+Gt,P=ve+Be+Gt;bt(F,wn,rn,P)}}}function ht(pe,ve,ge){c.push(pe),c.push(ve),c.push(ge)}function Nt(pe,ve,ge){xn(pe),xn(ve),xn(ge);const Be=s.length/3,Fe=M.generateTopUV(n,s,Be-3,Be-2,Be-1);Bt(Fe[0]),Bt(Fe[1]),Bt(Fe[2])}function bt(pe,ve,ge,Be){xn(pe),xn(ve),xn(Be),xn(ve),xn(ge),xn(Be);const Fe=s.length/3,Et=M.generateSideWallUV(n,s,Fe-6,Fe-3,Fe-2,Fe-1);Bt(Et[0]),Bt(Et[1]),Bt(Et[3]),Bt(Et[1]),Bt(Et[2]),Bt(Et[3])}function xn(pe){s.push(c[pe*3+0]),s.push(c[pe*3+1]),s.push(c[pe*3+2])}function Bt(pe){o.push(pe.x),o.push(pe.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return Gv(t,n,e)}static fromJSON(e,t){const n=[];for(let o=0,r=e.shapes.length;o<r;o++){const a=t[e.shapes[o]];n.push(a)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new Dl[s.type]().fromJSON(s)),new qd(n,e.options)}}const Hv={generateTopUV:function(i,e,t,n,s){const o=e[t*3],r=e[t*3+1],a=e[n*3],c=e[n*3+1],l=e[s*3],u=e[s*3+1];return[new _e(o,r),new _e(a,c),new _e(l,u)]},generateSideWallUV:function(i,e,t,n,s,o){const r=e[t*3],a=e[t*3+1],c=e[t*3+2],l=e[n*3],u=e[n*3+1],h=e[n*3+2],d=e[s*3],f=e[s*3+1],p=e[s*3+2],x=e[o*3],m=e[o*3+1],g=e[o*3+2];return Math.abs(a-u)<Math.abs(r-l)?[new _e(r,1-c),new _e(l,1-h),new _e(d,1-p),new _e(x,1-g)]:[new _e(a,1-c),new _e(u,1-h),new _e(f,1-p),new _e(m,1-g)]}};function Gv(i,e,t){if(t.shapes=[],Array.isArray(i))for(let n=0,s=i.length;n<s;n++){const o=i[n];t.shapes.push(o.uuid)}else t.shapes.push(i.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class sr extends la{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],o=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,o,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new sr(e.radius,e.detail)}}class Yd extends Tn{constructor(e=[new _e(0,-.5),new _e(.5,0),new _e(0,.5)],t=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:s},t=Math.floor(t),s=sn(s,0,Math.PI*2);const o=[],r=[],a=[],c=[],l=[],u=1/t,h=new I,d=new _e,f=new I,p=new I,x=new I;let m=0,g=0;for(let M=0;M<=e.length-1;M++)switch(M){case 0:m=e[M+1].x-e[M].x,g=e[M+1].y-e[M].y,f.x=g*1,f.y=-m,f.z=g*0,x.copy(f),f.normalize(),c.push(f.x,f.y,f.z);break;case e.length-1:c.push(x.x,x.y,x.z);break;default:m=e[M+1].x-e[M].x,g=e[M+1].y-e[M].y,f.x=g*1,f.y=-m,f.z=g*0,p.copy(f),f.x+=x.x,f.y+=x.y,f.z+=x.z,f.normalize(),c.push(f.x,f.y,f.z),x.copy(p)}for(let M=0;M<=t;M++){const S=n+M*u*s,_=Math.sin(S),A=Math.cos(S);for(let E=0;E<=e.length-1;E++){h.x=e[E].x*_,h.y=e[E].y,h.z=e[E].x*A,r.push(h.x,h.y,h.z),d.x=M/t,d.y=E/(e.length-1),a.push(d.x,d.y);const L=c[3*E+0]*_,v=c[3*E+1],R=c[3*E+0]*A;l.push(L,v,R)}}for(let M=0;M<t;M++)for(let S=0;S<e.length-1;S++){const _=S+M*e.length,A=_,E=_+e.length,L=_+e.length+1,v=_+1;o.push(A,E,v),o.push(L,v,E)}this.setIndex(o),this.setAttribute("position",new Dt(r,3)),this.setAttribute("uv",new Dt(a,2)),this.setAttribute("normal",new Dt(l,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Yd(e.points,e.segments,e.phiStart,e.phiLength)}}class gs extends la{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new gs(e.radius,e.detail)}}class vc extends Tn{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const o=e/2,r=t/2,a=Math.floor(n),c=Math.floor(s),l=a+1,u=c+1,h=e/a,d=t/c,f=[],p=[],x=[],m=[];for(let g=0;g<u;g++){const M=g*d-r;for(let S=0;S<l;S++){const _=S*h-o;p.push(_,-M,0),x.push(0,0,1),m.push(S/a),m.push(1-g/c)}}for(let g=0;g<c;g++)for(let M=0;M<a;M++){const S=M+l*g,_=M+l*(g+1),A=M+1+l*(g+1),E=M+1+l*g;f.push(S,_,E),f.push(_,A,E)}this.setIndex(f),this.setAttribute("position",new Dt(p,3)),this.setAttribute("normal",new Dt(x,3)),this.setAttribute("uv",new Dt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new vc(e.width,e.height,e.widthSegments,e.heightSegments)}}class Kd extends Tn{constructor(e=new Nl([new _e(0,.5),new _e(-.5,-.5),new _e(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const n=[],s=[],o=[],r=[];let a=0,c=0;if(Array.isArray(e)===!1)l(e);else for(let u=0;u<e.length;u++)l(e[u]),this.addGroup(a,c,u),a+=c,c=0;this.setIndex(n),this.setAttribute("position",new Dt(s,3)),this.setAttribute("normal",new Dt(o,3)),this.setAttribute("uv",new Dt(r,2));function l(u){const h=s.length/3,d=u.extractPoints(t);let f=d.shape;const p=d.holes;lo.isClockWise(f)===!1&&(f=f.reverse());for(let m=0,g=p.length;m<g;m++){const M=p[m];lo.isClockWise(M)===!0&&(p[m]=M.reverse())}const x=lo.triangulateShape(f,p);for(let m=0,g=p.length;m<g;m++){const M=p[m];f=f.concat(M)}for(let m=0,g=f.length;m<g;m++){const M=f[m];s.push(M.x,M.y,0),o.push(0,0,1),r.push(M.x,M.y)}for(let m=0,g=x.length;m<g;m++){const M=x[m],S=M[0]+h,_=M[1]+h,A=M[2]+h;n.push(S,_,A),c+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Vv(t,e)}static fromJSON(e,t){const n=[];for(let s=0,o=e.shapes.length;s<o;s++){const r=t[e.shapes[s]];n.push(r)}return new Kd(n,e.curveSegments)}}function Vv(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){const s=i[t];e.shapes.push(s.uuid)}else e.shapes.push(i.uuid);return e}class Zn extends Tn{constructor(e=1,t=32,n=16,s=0,o=Math.PI*2,r=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:o,thetaStart:r,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const c=Math.min(r+a,Math.PI);let l=0;const u=[],h=new I,d=new I,f=[],p=[],x=[],m=[];for(let g=0;g<=n;g++){const M=[],S=g/n,_=r+S*a,A=e*Math.cos(_),E=Math.sqrt(e*e-A*A);let L=0;g===0&&r===0?L=.5/t:g===n&&c===Math.PI&&(L=-.5/t);for(let v=0;v<=t;v++){const R=v/t,D=s+R*o;h.x=-E*Math.cos(D),h.y=A,h.z=E*Math.sin(D),p.push(h.x,h.y,h.z),d.copy(h).normalize(),x.push(d.x,d.y,d.z),m.push(R+L,1-S),M.push(l++)}u.push(M)}for(let g=0;g<n;g++)for(let M=0;M<t;M++){const S=u[g][M+1],_=u[g][M],A=u[g+1][M],E=u[g+1][M+1];(g!==0||r>0)&&f.push(S,_,E),(g!==n-1||c<Math.PI)&&f.push(_,A,E)}this.setIndex(f),this.setAttribute("position",new Dt(p,3)),this.setAttribute("normal",new Dt(x,3)),this.setAttribute("uv",new Dt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Zn(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Zd extends la{constructor(e=1,t=0){const n=[1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],s=[2,1,0,0,3,2,1,3,0,2,3,1];super(n,s,e,t),this.type="TetrahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Zd(e.radius,e.detail)}}class ai extends Tn{constructor(e=1,t=.4,n=12,s=48,o=Math.PI*2,r=0,a=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:o,thetaStart:r,thetaLength:a},n=Math.floor(n),s=Math.floor(s);const c=[],l=[],u=[],h=[],d=new I,f=new I,p=new I;for(let x=0;x<=n;x++){const m=r+x/n*a;for(let g=0;g<=s;g++){const M=g/s*o;f.x=(e+t*Math.cos(m))*Math.cos(M),f.y=(e+t*Math.cos(m))*Math.sin(M),f.z=t*Math.sin(m),l.push(f.x,f.y,f.z),d.x=e*Math.cos(M),d.y=e*Math.sin(M),p.subVectors(f,d).normalize(),u.push(p.x,p.y,p.z),h.push(g/s),h.push(x/n)}}for(let x=1;x<=n;x++)for(let m=1;m<=s;m++){const g=(s+1)*x+m-1,M=(s+1)*(x-1)+m-1,S=(s+1)*(x-1)+m,_=(s+1)*x+m;c.push(g,M,_),c.push(M,S,_)}this.setIndex(c),this.setAttribute("position",new Dt(l,3)),this.setAttribute("normal",new Dt(u,3)),this.setAttribute("uv",new Dt(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ai(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class Ka extends Tn{constructor(e=new f0(new I(-1,-1,0),new I(-1,1,0),new I(1,1,0)),t=64,n=1,s=8,o=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:n,radialSegments:s,closed:o};const r=e.computeFrenetFrames(t,o);this.tangents=r.tangents,this.normals=r.normals,this.binormals=r.binormals;const a=new I,c=new I,l=new _e;let u=new I;const h=[],d=[],f=[],p=[];x(),this.setIndex(p),this.setAttribute("position",new Dt(h,3)),this.setAttribute("normal",new Dt(d,3)),this.setAttribute("uv",new Dt(f,2));function x(){for(let S=0;S<t;S++)m(S);m(o===!1?t:0),M(),g()}function m(S){u=e.getPointAt(S/t,u);const _=r.normals[S],A=r.binormals[S];for(let E=0;E<=s;E++){const L=E/s*Math.PI*2,v=Math.sin(L),R=-Math.cos(L);c.x=R*_.x+v*A.x,c.y=R*_.y+v*A.y,c.z=R*_.z+v*A.z,c.normalize(),d.push(c.x,c.y,c.z),a.x=u.x+n*c.x,a.y=u.y+n*c.y,a.z=u.z+n*c.z,h.push(a.x,a.y,a.z)}}function g(){for(let S=1;S<=t;S++)for(let _=1;_<=s;_++){const A=(s+1)*(S-1)+(_-1),E=(s+1)*S+(_-1),L=(s+1)*S+_,v=(s+1)*(S-1)+_;p.push(A,E,v),p.push(E,L,v)}}function M(){for(let S=0;S<=t;S++)for(let _=0;_<=s;_++)l.x=S/t,l.y=_/s,f.push(l.x,l.y)}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new Ka(new Dl[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}}function oa(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];if(Tp(s))s.isRenderTargetTexture?(xt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone();else if(Array.isArray(s))if(Tp(s[0])){const o=[];for(let r=0,a=s.length;r<a;r++)o[r]=s[r].clone();e[t][n]=o}else e[t][n]=s.slice();else e[t][n]=s}}return e}function Oi(i){const e={};for(let t=0;t<i.length;t++){const n=oa(i[t]);for(const s in n)e[s]=n[s]}return e}function Tp(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function zv(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function v0(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:un.workingColorSpace}const y0={clone:oa,merge:Oi};var Wv=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Xv=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class hs extends Ts{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Wv,this.fragmentShader=Xv,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=oa(e.uniforms),this.uniformsGroups=zv(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const r=this.uniforms[s].value;r&&r.isTexture?t.uniforms[s]={type:"t",value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[s]={type:"c",value:r.getHex()}:r&&r.isVector2?t.uniforms[s]={type:"v2",value:r.toArray()}:r&&r.isVector3?t.uniforms[s]={type:"v3",value:r.toArray()}:r&&r.isVector4?t.uniforms[s]={type:"v4",value:r.toArray()}:r&&r.isMatrix3?t.uniforms[s]={type:"m3",value:r.toArray()}:r&&r.isMatrix4?t.uniforms[s]={type:"m4",value:r.toArray()}:t.uniforms[s]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const n in e.uniforms){const s=e.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=t[s.value]||null;break;case"c":this.uniforms[n].value=new Qe().setHex(s.value);break;case"v2":this.uniforms[n].value=new _e().fromArray(s.value);break;case"v3":this.uniforms[n].value=new I().fromArray(s.value);break;case"v4":this.uniforms[n].value=new Bn().fromArray(s.value);break;case"m3":this.uniforms[n].value=new Yt().fromArray(s.value);break;case"m4":this.uniforms[n].value=new Wt().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class qv extends hs{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class lt extends Ts{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Qe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Qe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Al,this.normalScale=new _e(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new ws,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class pi extends lt{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new _e(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return sn(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Qe(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Qe(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Qe(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class wp extends Ts{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Qe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Al,this.normalScale=new _e(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new ws,this.combine=Td,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Yv extends Ts{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=r_,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Kv extends Ts{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function rl(i,e){return!i||i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function Zv(i){function e(s,o){return i[s]-i[o]}const t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function Ep(i,e,t){const n=i.length,s=new i.constructor(n);for(let o=0,r=0;r!==n;++o){const a=t[o]*e;for(let c=0;c!==e;++c)s[r++]=i[a+c]}return s}function $v(i,e,t,n){let s=1,o=i[0];for(;o!==void 0&&o[n]===void 0;)o=i[s++];if(o===void 0)return;let r=o[n];if(r!==void 0)if(Array.isArray(r))do r=o[n],r!==void 0&&(e.push(o.time),t.push(...r)),o=i[s++];while(o!==void 0);else if(r.toArray!==void 0)do r=o[n],r!==void 0&&(e.push(o.time),r.toArray(t,t.length)),o=i[s++];while(o!==void 0);else do r=o[n],r!==void 0&&(e.push(o.time),t.push(r)),o=i[s++];while(o!==void 0)}class ua{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,s=t[n],o=t[n-1];e:{t:{let r;n:{i:if(!(e<s)){for(let a=n+2;;){if(s===void 0){if(e<o)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(o=s,s=t[++n],e<s)break t}r=t.length;break n}if(!(e>=o)){const a=t[1];e<a&&(n=2,o=a);for(let c=n-2;;){if(o===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===c)break;if(s=o,o=t[--n-1],e>=o)break t}r=n,n=0;break n}break e}for(;n<r;){const a=n+r>>>1;e<t[a]?r=a:n=a+1}if(s=t[n],o=t[n-1],o===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,o,s)}return this.interpolate_(n,o,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,o=e*s;for(let r=0;r!==s;++r)t[r]=n[o+r];return t}interpolate_(){throw new Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}}class Jv extends ua{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Vr,endingEnd:Vr}}intervalChanged_(e,t,n){const s=this.parameterPositions;let o=e-2,r=e+1,a=s[o],c=s[r];if(a===void 0)switch(this.getSettings_().endingStart){case zr:o=e,a=2*t-n;break;case El:o=s.length-2,a=t+s[o]-s[o+1];break;default:o=e,a=n}if(c===void 0)switch(this.getSettings_().endingEnd){case zr:r=e,c=2*n-t;break;case El:r=1,c=n+s[1]-s[0];break;default:r=e-1,c=t}const l=(n-t)*.5,u=this.valueSize;this._weightPrev=l/(t-a),this._weightNext=l/(c-n),this._offsetPrev=o*u,this._offsetNext=r*u}interpolate_(e,t,n,s){const o=this.resultBuffer,r=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=this._offsetPrev,h=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(s-t),x=p*p,m=x*p,g=-d*m+2*d*x-d*p,M=(1+d)*m+(-1.5-2*d)*x+(-.5+d)*p+1,S=(-1-f)*m+(1.5+f)*x+.5*p,_=f*m-f*x;for(let A=0;A!==a;++A)o[A]=g*r[u+A]+M*r[l+A]+S*r[c+A]+_*r[h+A];return o}}class M0 extends ua{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){const o=this.resultBuffer,r=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=(n-t)/(s-t),h=1-u;for(let d=0;d!==a;++d)o[d]=r[l+d]*h+r[c+d]*u;return o}}class jv extends ua{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}}class Qv extends ua{interpolate_(e,t,n,s){const o=this.resultBuffer,r=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=this.inTangents,h=this.outTangents;if(!u||!h){const p=(n-t)/(s-t),x=1-p;for(let m=0;m!==a;++m)o[m]=r[l+m]*x+r[c+m]*p;return o}const d=a*2,f=e-1;for(let p=0;p!==a;++p){const x=r[l+p],m=r[c+p],g=f*d+p*2,M=h[g],S=h[g+1],_=e*d+p*2,A=u[_],E=u[_+1];let L=(n-t)/(s-t),v,R,D,N,B;for(let ne=0;ne<8;ne++){v=L*L,R=v*L,D=1-L,N=D*D,B=N*D;const V=B*t+3*N*L*M+3*D*v*A+R*s-n;if(Math.abs(V)<1e-10)break;const se=3*N*(M-t)+6*D*L*(A-M)+3*v*(s-A);if(Math.abs(se)<1e-10)break;L=L-V/se,L=Math.max(0,Math.min(1,L))}o[p]=B*x+3*N*L*S+3*D*v*E+R*m}return o}}class Es{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=rl(t,this.TimeBufferType),this.values=rl(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:rl(e.times,Array),values:rl(e.values,Array)};const s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new jv(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new M0(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Jv(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){const t=new Qv(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case oc:t=this.InterpolantFactoryMethodDiscrete;break;case rc:t=this.InterpolantFactoryMethodLinear;break;case lu:t=this.InterpolantFactoryMethodSmooth;break;case kf:t=this.InterpolantFactoryMethodBezier;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return xt("KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return oc;case this.InterpolantFactoryMethodLinear:return rc;case this.InterpolantFactoryMethodSmooth:return lu;case this.InterpolantFactoryMethodBezier:return kf}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e}return this}trim(e,t){const n=this.times,s=n.length;let o=0,r=s-1;for(;o!==s&&n[o]<e;)++o;for(;r!==-1&&n[r]>t;)--r;if(++r,o!==0||r!==s){o>=r&&(r=Math.max(r,1),o=r-1);const a=this.getValueSize();this.times=n.slice(o,r),this.values=this.values.slice(o*a,r*a)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(Lt("KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,s=this.values,o=n.length;o===0&&(Lt("KeyframeTrack: Track is empty.",this),e=!1);let r=null;for(let a=0;a!==o;a++){const c=n[a];if(typeof c=="number"&&isNaN(c)){Lt("KeyframeTrack: Time is not a valid number.",this,a,c),e=!1;break}if(r!==null&&r>c){Lt("KeyframeTrack: Out of order keys.",this,a,c,r),e=!1;break}r=c}if(s!==void 0&&m_(s))for(let a=0,c=s.length;a!==c;++a){const l=s[a];if(isNaN(l)){Lt("KeyframeTrack: Value is not a valid number.",this,a,l),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===lu,o=e.length-1;let r=1;for(let a=1;a<o;++a){let c=!1;const l=e[a],u=e[a+1];if(l!==u&&(a!==1||l!==e[0]))if(s)c=!0;else{const h=a*n,d=h-n,f=h+n;for(let p=0;p!==n;++p){const x=t[h+p];if(x!==t[d+p]||x!==t[f+p]){c=!0;break}}}if(c){if(a!==r){e[r]=e[a];const h=a*n,d=r*n;for(let f=0;f!==n;++f)t[d+f]=t[h+f]}++r}}if(o>0){e[r]=e[o];for(let a=o*n,c=r*n,l=0;l!==n;++l)t[c+l]=t[a+l];++r}return r!==e.length?(this.times=e.slice(0,r),this.values=t.slice(0,r*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,s}}Es.prototype.ValueTypeName="";Es.prototype.TimeBufferType=Float32Array;Es.prototype.ValueBufferType=Float32Array;Es.prototype.DefaultInterpolation=rc;class ha extends Es{constructor(e,t,n){super(e,t,n)}}ha.prototype.ValueTypeName="bool";ha.prototype.ValueBufferType=Array;ha.prototype.DefaultInterpolation=oc;ha.prototype.InterpolantFactoryMethodLinear=void 0;ha.prototype.InterpolantFactoryMethodSmooth=void 0;class S0 extends Es{constructor(e,t,n,s){super(e,t,n,s)}}S0.prototype.ValueTypeName="color";class dc extends Es{constructor(e,t,n,s){super(e,t,n,s)}}dc.prototype.ValueTypeName="number";class ey extends ua{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){const o=this.resultBuffer,r=this.sampleValues,a=this.valueSize,c=(n-t)/(s-t);let l=e*a;for(let u=l+a;l!==u;l+=4)ci.slerpFlat(o,0,r,l-a,r,l,c);return o}}class fc extends Es{constructor(e,t,n,s){super(e,t,n,s)}InterpolantFactoryMethodLinear(e){return new ey(this.times,this.values,this.getValueSize(),e)}}fc.prototype.ValueTypeName="quaternion";fc.prototype.InterpolantFactoryMethodSmooth=void 0;class da extends Es{constructor(e,t,n){super(e,t,n)}}da.prototype.ValueTypeName="string";da.prototype.ValueBufferType=Array;da.prototype.DefaultInterpolation=oc;da.prototype.InterpolantFactoryMethodLinear=void 0;da.prototype.InterpolantFactoryMethodSmooth=void 0;class Ul extends Es{constructor(e,t,n,s){super(e,t,n,s)}}Ul.prototype.ValueTypeName="vector";class Jh{constructor(e="",t=-1,n=[],s=Dd){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=us(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,s=1/(e.fps||1);for(let r=0,a=n.length;r!==a;++r)t.push(ny(n[r]).scale(s));const o=new this(e.name,e.duration,t,e.blendMode);return o.uuid=e.uuid,o.userData=JSON.parse(e.userData||"{}"),o}static toJSON(e){const t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let o=0,r=n.length;o!==r;++o)t.push(Es.toJSON(n[o]));return s}static CreateFromMorphTargetSequence(e,t,n,s){const o=t.length,r=[];for(let a=0;a<o;a++){let c=[],l=[];c.push((a+o-1)%o,a,(a+1)%o),l.push(0,1,0);const u=Zv(c);c=Ep(c,1,u),l=Ep(l,1,u),!s&&c[0]===0&&(c.push(o),l.push(l[0])),r.push(new dc(".morphTargetInfluences["+t[a].name+"]",c,l).scale(1/n))}return new this(e,-1,r)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const s={},o=/^([\w-]*?)([\d]+)$/;for(let a=0,c=e.length;a<c;a++){const l=e[a],u=l.name.match(o);if(u&&u.length>1){const h=u[1];let d=s[h];d||(s[h]=d=[]),d.push(l)}}const r=[];for(const a in s)r.push(this.CreateFromMorphTargetSequence(a,s[a],t,n));return r}resetDuration(){const e=this.tracks;let t=0;for(let n=0,s=e.length;n!==s;++n){const o=this.tracks[n];t=Math.max(t,o.times[o.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let n=0;n<this.tracks.length;n++)e.push(this.tracks[n].clone());const t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}}function ty(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return dc;case"vector":case"vector2":case"vector3":case"vector4":return Ul;case"color":return S0;case"quaternion":return fc;case"bool":case"boolean":return ha;case"string":return da}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function ny(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=ty(i.type);if(i.times===void 0){const t=[],n=[];$v(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}const uo={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(Ap(i)||(this.files[i]=e))},get:function(i){if(this.enabled!==!1&&!Ap(i))return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};function Ap(i){try{const e=i.slice(i.indexOf(":")+1);return new URL(e).protocol==="blob:"}catch{return!1}}class iy{constructor(e,t,n){const s=this;let o=!1,r=0,a=0,c;const l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this._abortController=null,this.itemStart=function(u){a++,o===!1&&s.onStart!==void 0&&s.onStart(u,r,a),o=!0},this.itemEnd=function(u){r++,s.onProgress!==void 0&&s.onProgress(u,r,a),r===a&&(o=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return u=u.normalize("NFC"),c?c(u):u},this.setURLModifier=function(u){return c=u,this},this.addHandler=function(u,h){return l.push(u,h),this},this.removeHandler=function(u){const h=l.indexOf(u);return h!==-1&&l.splice(h,2),this},this.getHandler=function(u){for(let h=0,d=l.length;h<d;h+=2){const f=l[h],p=l[h+1];if(f.global&&(f.lastIndex=0),f.test(u))return p}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const sy=new iy;class fa{constructor(e){this.manager=e!==void 0?e:sy,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(e,t){const n=this;return new Promise(function(s,o){n.load(e,s,t,o)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}fa.DEFAULT_MATERIAL_NAME="__DEFAULT";const so={};class oy extends Error{constructor(e,t){super(e),this.response=t}}class b0 extends fa{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const o=uo.get(`file:${e}`);if(o!==void 0){this.manager.itemStart(e),setTimeout(()=>{t&&t(o),this.manager.itemEnd(e)},0);return}if(so[e]!==void 0){so[e].push({onLoad:t,onProgress:n,onError:s});return}so[e]=[],so[e].push({onLoad:t,onProgress:n,onError:s});const r=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),a=this.mimeType,c=this.responseType;fetch(r).then(l=>{if(l.status===200||l.status===0){if(l.status===0&&xt("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;const u=so[e],h=l.body.getReader(),d=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),f=d?parseInt(d):0,p=f!==0;let x=0;const m=new ReadableStream({start(g){M();function M(){h.read().then(({done:S,value:_})=>{if(S)g.close();else{x+=_.byteLength;const A=new ProgressEvent("progress",{lengthComputable:p,loaded:x,total:f});for(let E=0,L=u.length;E<L;E++){const v=u[E];v.onProgress&&v.onProgress(A)}g.enqueue(_),M()}},S=>{g.error(S)})}}});return new Response(m)}else throw new oy(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then(l=>{switch(c){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then(u=>new DOMParser().parseFromString(u,a));case"json":return l.json();default:if(a==="")return l.text();{const h=/charset="?([^;"\s]*)"?/i.exec(a),d=h&&h[1]?h[1].toLowerCase():void 0,f=new TextDecoder(d);return l.arrayBuffer().then(p=>f.decode(p))}}}).then(l=>{uo.add(`file:${e}`,l);const u=so[e];delete so[e];for(let h=0,d=u.length;h<d;h++){const f=u[h];f.onLoad&&f.onLoad(l)}}).catch(l=>{const u=so[e];if(u===void 0)throw this.manager.itemError(e),l;delete so[e];for(let h=0,d=u.length;h<d;h++){const f=u[h];f.onError&&f.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const Nr=new WeakMap;class ry extends fa{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const o=this,r=uo.get(`image:${e}`);if(r!==void 0){if(r.complete===!0)o.manager.itemStart(e),setTimeout(function(){t&&t(r),o.manager.itemEnd(e)},0);else{let h=Nr.get(r);h===void 0&&(h=[],Nr.set(r,h)),h.push({onLoad:t,onError:s})}return r}const a=cc("img");function c(){u(),t&&t(this);const h=Nr.get(this)||[];for(let d=0;d<h.length;d++){const f=h[d];f.onLoad&&f.onLoad(this)}Nr.delete(this),o.manager.itemEnd(e)}function l(h){u(),s&&s(h),uo.remove(`image:${e}`);const d=Nr.get(this)||[];for(let f=0;f<d.length;f++){const p=d[f];p.onError&&p.onError(h)}Nr.delete(this),o.manager.itemError(e),o.manager.itemEnd(e)}function u(){a.removeEventListener("load",c,!1),a.removeEventListener("error",l,!1)}return a.addEventListener("load",c,!1),a.addEventListener("error",l,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),uo.add(`image:${e}`,a),o.manager.itemStart(e),a.src=e,a}}class ay extends fa{constructor(e){super(e)}load(e,t,n,s){const o=new bi,r=new ry(this.manager);return r.setCrossOrigin(this.crossOrigin),r.setPath(this.path),r.load(e,function(a){o.image=a,o.needsUpdate=!0,t!==void 0&&t(o)},n,s),o}}class yc extends kn{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Qe(e),this.intensity=t}dispose(){this.dispatchEvent({type:"dispose"})}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class cy extends yc{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(kn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Qe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){const t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}const Bu=new Wt,Rp=new I,Cp=new I;class $d{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new _e(512,512),this.mapType=Yi,this.map=null,this.mapPass=null,this.matrix=new Wt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Gd,this._frameExtents=new _e(1,1),this._viewportCount=1,this._viewports=[new Bn(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;Rp.setFromMatrixPosition(e.matrixWorld),t.position.copy(Rp),Cp.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Cp),t.updateMatrixWorld(),Bu.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Bu,t.coordinateSystem,t.reversedDepth),t.coordinateSystem===ac||t.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Bu)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const al=new I,cl=new ci,Ps=new I;class T0 extends kn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Wt,this.projectionMatrix=new Wt,this.projectionMatrixInverse=new Wt,this.coordinateSystem=Gs,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(al,cl,Ps),Ps.x===1&&Ps.y===1&&Ps.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(al,cl,Ps.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(al,cl,Ps),Ps.x===1&&Ps.y===1&&Ps.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(al,cl,Ps.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Do=new I,Pp=new _e,Ip=new _e;class Bi extends T0{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=na*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(za*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return na*2*Math.atan(Math.tan(za*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Do.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Do.x,Do.y).multiplyScalar(-e/Do.z),Do.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Do.x,Do.y).multiplyScalar(-e/Do.z)}getViewSize(e,t){return this.getViewBounds(e,Pp,Ip),t.subVectors(Ip,Pp)}setViewOffset(e,t,n,s,o,r){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=o,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(za*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,o=-.5*s;const r=this.view;if(this.view!==null&&this.view.enabled){const c=r.fullWidth,l=r.fullHeight;o+=r.offsetX*s/c,t-=r.offsetY*n/l,s*=r.width/c,n*=r.height/l}const a=this.filmOffset;a!==0&&(o+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(o,o+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class ly extends $d{constructor(){super(new Bi(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){const t=this.camera,n=na*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height*this.aspect,o=e.distance||t.far;(n!==t.fov||s!==t.aspect||o!==t.far)&&(t.fov=n,t.aspect=s,t.far=o,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class uy extends yc{constructor(e,t,n=0,s=Math.PI/3,o=0,r=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(kn.DEFAULT_UP),this.updateMatrix(),this.target=new kn,this.distance=n,this.angle=s,this.penumbra=o,this.decay=r,this.map=null,this.shadow=new ly}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.map=e.map,this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.distance=this.distance,t.object.angle=this.angle,t.object.decay=this.decay,t.object.penumbra=this.penumbra,t.object.target=this.target.uuid,this.map&&this.map.isTexture&&(t.object.map=this.map.toJSON(e).uuid),t.object.shadow=this.shadow.toJSON(),t}}class hy extends $d{constructor(){super(new Bi(90,1,.5,500)),this.isPointLightShadow=!0}}class w0 extends yc{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new hy}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}}class Xl extends T0{constructor(e=-1,t=1,n=1,s=-1,o=.1,r=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=o,this.far=r,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,o,r){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=o,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let o=n-e,r=n+e,a=s+t,c=s-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;o+=l*this.view.offsetX,r=o+l*this.view.width,a-=u*this.view.offsetY,c=a-u*this.view.height}this.projectionMatrix.makeOrthographic(o,r,a,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class dy extends $d{constructor(){super(new Xl(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class E0 extends yc{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(kn.DEFAULT_UP),this.updateMatrix(),this.target=new kn,this.shadow=new dy}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class fy extends yc{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}class Za{static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}const ku=new WeakMap;class py extends fa{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&xt("ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&xt("ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const o=this,r=uo.get(`image-bitmap:${e}`);if(r!==void 0){if(o.manager.itemStart(e),r.then){r.then(l=>{ku.has(r)===!0?(s&&s(ku.get(r)),o.manager.itemError(e),o.manager.itemEnd(e)):(t&&t(l),o.manager.itemEnd(e))});return}setTimeout(function(){t&&t(r),o.manager.itemEnd(e)},0);return}const a={};a.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",a.headers=this.requestHeader,a.signal=typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;const c=fetch(e,a).then(function(l){return l.blob()}).then(function(l){return createImageBitmap(l,Object.assign(o.options,{colorSpaceConversion:"none"}))}).then(function(l){uo.add(`image-bitmap:${e}`,l),t&&t(l),o.manager.itemEnd(e)}).catch(function(l){s&&s(l),ku.set(c,l),uo.remove(`image-bitmap:${e}`),o.manager.itemError(e),o.manager.itemEnd(e)});uo.add(`image-bitmap:${e}`,c),o.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const Ur=-90,Fr=1;class my extends kn{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Bi(Ur,Fr,e,t);s.layers=this.layers,this.add(s);const o=new Bi(Ur,Fr,e,t);o.layers=this.layers,this.add(o);const r=new Bi(Ur,Fr,e,t);r.layers=this.layers,this.add(r);const a=new Bi(Ur,Fr,e,t);a.layers=this.layers,this.add(a);const c=new Bi(Ur,Fr,e,t);c.layers=this.layers,this.add(c);const l=new Bi(Ur,Fr,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,o,r,a,c]=t;for(const l of t)this.remove(l);if(e===Gs)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),o.up.set(0,0,-1),o.lookAt(0,1,0),r.up.set(0,0,1),r.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===ac)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),o.up.set(0,0,1),o.lookAt(0,1,0),r.up.set(0,0,-1),r.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[o,r,a,c,l,u]=this.children,h=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;const x=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(n,0,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,1,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,r),e.setRenderTarget(n,2,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,3,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),e.setRenderTarget(n,4,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),n.texture.generateMipmaps=x,e.setRenderTarget(n,5,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,u),e.setRenderTarget(h,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}}class gy extends Bi{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class xy{constructor(e,t,n){this.binding=e,this.valueSize=n;let s,o,r;switch(t){case"quaternion":s=this._slerp,o=this._slerpAdditive,r=this._setAdditiveIdentityQuaternion,this.buffer=new Float64Array(n*6),this._workIndex=5;break;case"string":case"bool":s=this._select,o=this._select,r=this._setAdditiveIdentityOther,this.buffer=new Array(n*5);break;default:s=this._lerp,o=this._lerpAdditive,r=this._setAdditiveIdentityNumeric,this.buffer=new Float64Array(n*5)}this._mixBufferRegion=s,this._mixBufferRegionAdditive=o,this._setIdentity=r,this._origIndex=3,this._addIndex=4,this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,this.useCount=0,this.referenceCount=0}accumulate(e,t){const n=this.buffer,s=this.valueSize,o=e*s+s;let r=this.cumulativeWeight;if(r===0){for(let a=0;a!==s;++a)n[o+a]=n[a];r=t}else{r+=t;const a=t/r;this._mixBufferRegion(n,o,0,a,s)}this.cumulativeWeight=r}accumulateAdditive(e){const t=this.buffer,n=this.valueSize,s=n*this._addIndex;this.cumulativeWeightAdditive===0&&this._setIdentity(),this._mixBufferRegionAdditive(t,s,0,e,n),this.cumulativeWeightAdditive+=e}apply(e){const t=this.valueSize,n=this.buffer,s=e*t+t,o=this.cumulativeWeight,r=this.cumulativeWeightAdditive,a=this.binding;if(this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,o<1){const c=t*this._origIndex;this._mixBufferRegion(n,s,c,1-o,t)}r>0&&this._mixBufferRegionAdditive(n,s,this._addIndex*t,1,t);for(let c=t,l=t+t;c!==l;++c)if(n[c]!==n[c+t]){a.setValue(n,s);break}}saveOriginalState(){const e=this.binding,t=this.buffer,n=this.valueSize,s=n*this._origIndex;e.getValue(t,s);for(let o=n,r=s;o!==r;++o)t[o]=t[s+o%n];this._setIdentity(),this.cumulativeWeight=0,this.cumulativeWeightAdditive=0}restoreOriginalState(){const e=this.valueSize*3;this.binding.setValue(this.buffer,e)}_setAdditiveIdentityNumeric(){const e=this._addIndex*this.valueSize,t=e+this.valueSize;for(let n=e;n<t;n++)this.buffer[n]=0}_setAdditiveIdentityQuaternion(){this._setAdditiveIdentityNumeric(),this.buffer[this._addIndex*this.valueSize+3]=1}_setAdditiveIdentityOther(){const e=this._origIndex*this.valueSize,t=this._addIndex*this.valueSize;for(let n=0;n<this.valueSize;n++)this.buffer[t+n]=this.buffer[e+n]}_select(e,t,n,s,o){if(s>=.5)for(let r=0;r!==o;++r)e[t+r]=e[n+r]}_slerp(e,t,n,s){ci.slerpFlat(e,t,e,t,e,n,s)}_slerpAdditive(e,t,n,s,o){const r=this._workIndex*o;ci.multiplyQuaternionsFlat(e,r,e,t,e,n),ci.slerpFlat(e,t,e,t,e,r,s)}_lerp(e,t,n,s,o){const r=1-s;for(let a=0;a!==o;++a){const c=t+a;e[c]=e[c]*r+e[n+a]*s}}_lerpAdditive(e,t,n,s,o){for(let r=0;r!==o;++r){const a=t+r;e[a]=e[a]+e[n+r]*s}}}const Jd="\\[\\]\\.:\\/",_y=new RegExp("["+Jd+"]","g"),jd="[^"+Jd+"]",vy="[^"+Jd.replace("\\.","")+"]",yy=/((?:WC+[\/:])*)/.source.replace("WC",jd),My=/(WCOD+)?/.source.replace("WCOD",vy),Sy=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",jd),by=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",jd),Ty=new RegExp("^"+yy+My+Sy+by+"$"),wy=["material","materials","bones","map"];class Ey{constructor(e,t,n){const s=n||Rn.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,o=n.length;s!==o;++s)n[s].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class Rn{constructor(e,t,n){this.path=t,this.parsedPath=n||Rn.parseTrackName(t),this.node=Rn.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new Rn.Composite(e,t,n):new Rn(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(_y,"")}static parseTrackName(e){const t=Ty.exec(e);if(t===null)throw new Error("THREE.PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){const o=n.nodeName.substring(s+1);wy.indexOf(o)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=o)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(o){for(let r=0;r<o.length;r++){const a=o[r];if(a.name===t||a.uuid===t)return a;const c=n(a.children);if(c)return c}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let s=0,o=n.length;s!==o;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let s=0,o=n.length;s!==o;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let s=0,o=n.length;s!==o;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let s=0,o=n.length;s!==o;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,s=t.propertyName;let o=t.propertyIndex;if(e||(e=Rn.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){xt("PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let l=t.objectIndex;switch(n){case"materials":if(!e.material){Lt("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){Lt("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){Lt("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let u=0;u<e.length;u++)if(e[u].name===l){l=u;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){Lt("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){Lt("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){Lt("PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(l!==void 0){if(e[l]===void 0){Lt("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[l]}}const r=e[s];if(r===void 0){const l=t.nodeName;Lt("PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?a=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(o!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){Lt("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){Lt("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[o]!==void 0&&(o=e.morphTargetDictionary[o])}c=this.BindingType.ArrayElement,this.resolvedProperty=r,this.propertyIndex=o}else r.fromArray!==void 0&&r.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=r):Array.isArray(r)?(c=this.BindingType.EntireArray,this.resolvedProperty=r):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}Rn.Composite=Ey;Rn.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Rn.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Rn.prototype.GetterByBindingType=[Rn.prototype._getValue_direct,Rn.prototype._getValue_array,Rn.prototype._getValue_arrayElement,Rn.prototype._getValue_toArray];Rn.prototype.SetterByBindingTypeAndVersioning=[[Rn.prototype._setValue_direct,Rn.prototype._setValue_direct_setNeedsUpdate,Rn.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Rn.prototype._setValue_array,Rn.prototype._setValue_array_setNeedsUpdate,Rn.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Rn.prototype._setValue_arrayElement,Rn.prototype._setValue_arrayElement_setNeedsUpdate,Rn.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Rn.prototype._setValue_fromArray,Rn.prototype._setValue_fromArray_setNeedsUpdate,Rn.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];class Ay{constructor(e,t,n=null,s=t.blendMode){this._mixer=e,this._clip=t,this._localRoot=n,this.blendMode=s;const o=t.tracks,r=o.length,a=new Array(r),c={endingStart:Vr,endingEnd:Vr};for(let l=0;l!==r;++l){const u=o[l].createInterpolant(null);a[l]=u,u.settings=c}this._interpolantSettings=c,this._interpolants=a,this._propertyBindings=new Array(r),this._cacheIndex=null,this._byClipCacheIndex=null,this._timeScaleInterpolant=null,this._restoreTimeScale=null,this._weightInterpolant=null,this.loop=Wh,this._loopCount=-1,this._startTime=null,this.time=0,this.timeScale=1,this._effectiveTimeScale=1,this.weight=1,this._effectiveWeight=1,this.repetitions=1/0,this.paused=!1,this.enabled=!0,this.clampWhenFinished=!1,this.zeroSlopeAtStart=!0,this.zeroSlopeAtEnd=!0}play(){return this._mixer._activateAction(this),this}stop(){return this._mixer._deactivateAction(this),this.reset()}reset(){return this.paused=!1,this.enabled=!0,this.time=0,this._loopCount=-1,this._startTime=null,this.stopFading().stopWarping()}isRunning(){return this.enabled&&!this.paused&&this.timeScale!==0&&this._startTime===null&&this._mixer._isActiveAction(this)}isScheduled(){return this._mixer._isActiveAction(this)}startAt(e){return this._startTime=e,this}setLoop(e,t){return this.loop=e,this.repetitions=t,this}setEffectiveWeight(e){return this.weight=e,this._effectiveWeight=this.enabled?e:0,this.stopFading()}getEffectiveWeight(){return this._effectiveWeight}fadeIn(e){return this._scheduleFading(e,0,1)}fadeOut(e){return this._scheduleFading(e,1,0)}crossFadeFrom(e,t,n=!1){if(e.fadeOut(t),this.fadeIn(t),n===!0){const s=this._clip.duration,o=e._clip.duration,r=o/s,a=s/o;e._restoreTimeScale=e.timeScale,this._restoreTimeScale=this.timeScale,e.warp(1,r,t),this.warp(a,1,t)}return this}crossFadeTo(e,t,n=!1){return e.crossFadeFrom(this,t,n)}stopFading(){const e=this._weightInterpolant;return e!==null&&(this._weightInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this}setEffectiveTimeScale(e){return this.timeScale=e,this._effectiveTimeScale=this.paused?0:e,this.stopWarping()}getEffectiveTimeScale(){return this._effectiveTimeScale}setDuration(e){return this.timeScale=this._clip.duration/e,this.stopWarping()}syncWith(e){return this.time=e.time,this.timeScale=e.timeScale,this.stopWarping()}halt(e){return this.warp(this._effectiveTimeScale,0,e)}warp(e,t,n){const s=this._mixer,o=s.time,r=this.timeScale;let a=this._timeScaleInterpolant;a===null&&(a=s._lendControlInterpolant(),this._timeScaleInterpolant=a);const c=a.parameterPositions,l=a.sampleValues;return c[0]=o,c[1]=o+n,l[0]=e/r,l[1]=t/r,this}stopWarping(){const e=this._timeScaleInterpolant;return e!==null&&(this._timeScaleInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this._restoreTimeScale=null,this}getMixer(){return this._mixer}getClip(){return this._clip}getRoot(){return this._localRoot||this._mixer._root}_update(e,t,n,s){if(!this.enabled){this._updateWeight(e);return}const o=this._startTime;if(o!==null){const c=(e-o)*n;c<0||n===0?t=0:(this._startTime=null,t=n*c)}t*=this._updateTimeScale(e);const r=this._updateTime(t),a=this._updateWeight(e);if(a>0){const c=this._interpolants,l=this._propertyBindings;switch(this.blendMode){case s_:for(let u=0,h=c.length;u!==h;++u)c[u].evaluate(r),l[u].accumulateAdditive(a);break;case Dd:default:for(let u=0,h=c.length;u!==h;++u)c[u].evaluate(r),l[u].accumulate(s,a)}}}_updateWeight(e){let t=0;if(this.enabled){t=this.weight;const n=this._weightInterpolant;if(n!==null){const s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(this.stopFading(),s===0&&(this.enabled=!1))}}return this._effectiveWeight=t,t}_updateTimeScale(e){let t=0;if(!this.paused){t=this.timeScale;const n=this._timeScaleInterpolant;if(n!==null){const s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(t===0?this.paused=!0:(this._restoreTimeScale!==null&&(t=this._restoreTimeScale),this.timeScale=t),this.stopWarping())}}return this._effectiveTimeScale=t,t}_updateTime(e){const t=this._clip.duration,n=this.loop;let s=this.time+e,o=this._loopCount;const r=n===i_;if(e===0)return o===-1?s:r&&(o&1)===1?t-s:s;if(n===Qm){o===-1&&(this._loopCount=0,this._setEndings(!0,!0,!1));e:{if(s>=t)s=t;else if(s<0)s=0;else{this.time=s;break e}this.clampWhenFinished?this.paused=!0:this.enabled=!1,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e<0?-1:1})}}else{if(o===-1&&(e>=0?(o=0,this._setEndings(!0,this.repetitions===0,r)):this._setEndings(this.repetitions===0,!0,r)),s>=t||s<0){const a=Math.floor(s/t);s-=t*a,o+=Math.abs(a);const c=this.repetitions-o;if(c<=0)this.clampWhenFinished?this.paused=!0:this.enabled=!1,s=e>0?t:0,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e>0?1:-1});else{if(c===1){const l=e<0;this._setEndings(l,!l,r)}else this._setEndings(!1,!1,r);this._loopCount=o,this.time=s,this._mixer.dispatchEvent({type:"loop",action:this,loopDelta:a})}}else this._loopCount=o,this.time=s;if(r&&(o&1)===1)return t-s}return s}_setEndings(e,t,n){const s=this._interpolantSettings;n?(s.endingStart=zr,s.endingEnd=zr):(e?s.endingStart=this.zeroSlopeAtStart?zr:Vr:s.endingStart=El,t?s.endingEnd=this.zeroSlopeAtEnd?zr:Vr:s.endingEnd=El)}_scheduleFading(e,t,n){const s=this._mixer,o=s.time;let r=this._weightInterpolant;r===null&&(r=s._lendControlInterpolant(),this._weightInterpolant=r);const a=r.parameterPositions,c=r.sampleValues;return a[0]=o,c[0]=t,a[1]=o+e,c[1]=n,this}}const Ry=new Float32Array(1);class Cy extends zo{constructor(e){super(),this._root=e,this._initMemoryManager(),this._accuIndex=0,this.time=0,this.timeScale=1,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}_bindAction(e,t){const n=e._localRoot||this._root,s=e._clip.tracks,o=s.length,r=e._propertyBindings,a=e._interpolants,c=n.uuid,l=this._bindingsByRootAndName;let u=l[c];u===void 0&&(u={},l[c]=u);for(let h=0;h!==o;++h){const d=s[h],f=d.name;let p=u[f];if(p!==void 0)++p.referenceCount,r[h]=p;else{if(p=r[h],p!==void 0){p._cacheIndex===null&&(++p.referenceCount,this._addInactiveBinding(p,c,f));continue}const x=t&&t._propertyBindings[h].binding.parsedPath;p=new xy(Rn.create(n,f,x),d.ValueTypeName,d.getValueSize()),++p.referenceCount,this._addInactiveBinding(p,c,f),r[h]=p}a[h].resultBuffer=p.buffer}}_activateAction(e){if(!this._isActiveAction(e)){if(e._cacheIndex===null){const n=(e._localRoot||this._root).uuid,s=e._clip.uuid,o=this._actionsByClip[s];this._bindAction(e,o&&o.knownActions[0]),this._addInactiveAction(e,s,n)}const t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){const o=t[n];o.useCount++===0&&(this._lendBinding(o),o.saveOriginalState())}this._lendAction(e)}}_deactivateAction(e){if(this._isActiveAction(e)){const t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){const o=t[n];--o.useCount===0&&(o.restoreOriginalState(),this._takeBackBinding(o))}this._takeBackAction(e)}}_initMemoryManager(){this._actions=[],this._nActiveActions=0,this._actionsByClip={},this._bindings=[],this._nActiveBindings=0,this._bindingsByRootAndName={},this._controlInterpolants=[],this._nActiveControlInterpolants=0;const e=this;this.stats={actions:{get total(){return e._actions.length},get inUse(){return e._nActiveActions}},bindings:{get total(){return e._bindings.length},get inUse(){return e._nActiveBindings}},controlInterpolants:{get total(){return e._controlInterpolants.length},get inUse(){return e._nActiveControlInterpolants}}}}_isActiveAction(e){const t=e._cacheIndex;return t!==null&&t<this._nActiveActions}_addInactiveAction(e,t,n){const s=this._actions,o=this._actionsByClip;let r=o[t];if(r===void 0)r={knownActions:[e],actionByRoot:{}},e._byClipCacheIndex=0,o[t]=r;else{const a=r.knownActions;e._byClipCacheIndex=a.length,a.push(e)}e._cacheIndex=s.length,s.push(e),r.actionByRoot[n]=e}_removeInactiveAction(e){const t=this._actions,n=t[t.length-1],s=e._cacheIndex;n._cacheIndex=s,t[s]=n,t.pop(),e._cacheIndex=null;const o=e._clip.uuid,r=this._actionsByClip,a=r[o],c=a.knownActions,l=c[c.length-1],u=e._byClipCacheIndex;l._byClipCacheIndex=u,c[u]=l,c.pop(),e._byClipCacheIndex=null;const h=a.actionByRoot,d=(e._localRoot||this._root).uuid;delete h[d],c.length===0&&delete r[o],this._removeInactiveBindingsForAction(e)}_removeInactiveBindingsForAction(e){const t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){const o=t[n];--o.referenceCount===0&&this._removeInactiveBinding(o)}}_lendAction(e){const t=this._actions,n=e._cacheIndex,s=this._nActiveActions++,o=t[s];e._cacheIndex=s,t[s]=e,o._cacheIndex=n,t[n]=o}_takeBackAction(e){const t=this._actions,n=e._cacheIndex,s=--this._nActiveActions,o=t[s];e._cacheIndex=s,t[s]=e,o._cacheIndex=n,t[n]=o}_addInactiveBinding(e,t,n){const s=this._bindingsByRootAndName,o=this._bindings;let r=s[t];r===void 0&&(r={},s[t]=r),r[n]=e,e._cacheIndex=o.length,o.push(e)}_removeInactiveBinding(e){const t=this._bindings,n=e.binding,s=n.rootNode.uuid,o=n.path,r=this._bindingsByRootAndName,a=r[s],c=t[t.length-1],l=e._cacheIndex;c._cacheIndex=l,t[l]=c,t.pop(),delete a[o],Object.keys(a).length===0&&delete r[s]}_lendBinding(e){const t=this._bindings,n=e._cacheIndex,s=this._nActiveBindings++,o=t[s];e._cacheIndex=s,t[s]=e,o._cacheIndex=n,t[n]=o}_takeBackBinding(e){const t=this._bindings,n=e._cacheIndex,s=--this._nActiveBindings,o=t[s];e._cacheIndex=s,t[s]=e,o._cacheIndex=n,t[n]=o}_lendControlInterpolant(){const e=this._controlInterpolants,t=this._nActiveControlInterpolants++;let n=e[t];return n===void 0&&(n=new M0(new Float32Array(2),new Float32Array(2),1,Ry),n.__cacheIndex=t,e[t]=n),n}_takeBackControlInterpolant(e){const t=this._controlInterpolants,n=e.__cacheIndex,s=--this._nActiveControlInterpolants,o=t[s];e.__cacheIndex=s,t[s]=e,o.__cacheIndex=n,t[n]=o}clipAction(e,t,n){const s=t||this._root,o=s.uuid;let r=typeof e=="string"?Jh.findByName(s,e):e;const a=r!==null?r.uuid:e,c=this._actionsByClip[a];let l=null;if(n===void 0&&(r!==null?n=r.blendMode:n=Dd),c!==void 0){const h=c.actionByRoot[o];if(h!==void 0&&h.blendMode===n)return h;l=c.knownActions[0],r===null&&(r=l._clip)}if(r===null)return null;const u=new Ay(this,r,t,n);return this._bindAction(u,l),this._addInactiveAction(u,a,o),u}existingAction(e,t){const n=t||this._root,s=n.uuid,o=typeof e=="string"?Jh.findByName(n,e):e,r=o?o.uuid:e,a=this._actionsByClip[r];return a!==void 0&&a.actionByRoot[s]||null}stopAllAction(){const e=this._actions,t=this._nActiveActions;for(let n=t-1;n>=0;--n)e[n].stop();return this}update(e){e*=this.timeScale;const t=this._actions,n=this._nActiveActions,s=this.time+=e,o=Math.sign(e),r=this._accuIndex^=1;for(let l=0;l!==n;++l)t[l]._update(s,e,o,r);const a=this._bindings,c=this._nActiveBindings;for(let l=0;l!==c;++l)a[l].apply(r);return this}setTime(e){this.time=0;for(let t=0;t<this._actions.length;t++)this._actions[t].time=0;return this.update(e)}getRoot(){return this._root}uncacheClip(e){const t=this._actions,n=e.uuid,s=this._actionsByClip,o=s[n];if(o!==void 0){const r=o.knownActions;for(let a=0,c=r.length;a!==c;++a){const l=r[a];this._deactivateAction(l);const u=l._cacheIndex,h=t[t.length-1];l._cacheIndex=null,l._byClipCacheIndex=null,h._cacheIndex=u,t[u]=h,t.pop(),this._removeInactiveBindingsForAction(l)}delete s[n]}}uncacheRoot(e){const t=e.uuid,n=this._actionsByClip;for(const r in n){const a=n[r].actionByRoot,c=a[t];c!==void 0&&(this._deactivateAction(c),this._removeInactiveAction(c))}const s=this._bindingsByRootAndName,o=s[t];if(o!==void 0)for(const r in o){const a=o[r];a.restoreOriginalState(),this._removeInactiveBinding(a)}}uncacheAction(e,t){const n=this.existingAction(e,t);n!==null&&(this._deactivateAction(n),this._removeInactiveAction(n))}}const Lp=new Wt;class Py{constructor(e,t,n=0,s=1/0){this.ray=new _c(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new Bd,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):Lt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return Lp.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Lp),this}intersectObject(e,t=!0,n=[]){return jh(e,this,n,t),n.sort(Dp),n}intersectObjects(e,t=!0,n=[]){for(let s=0,o=e.length;s<o;s++)jh(e[s],this,n,t);return n.sort(Dp),n}}function Dp(i,e){return i.distance-e.distance}function jh(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const o=i.children;for(let r=0,a=o.length;r<a;r++)jh(o[r],e,t,!0)}}const ff=class ff{constructor(e,t,n,s){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,s)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,s){const o=this.elements;return o[0]=e,o[2]=t,o[1]=n,o[3]=s,this}};ff.prototype.isMatrix2=!0;let Np=ff;function Up(i,e,t,n){const s=Iy(n);switch(t){case Jm:return i*e;case Cd:return i*e/s.components*s.byteLength;case Pd:return i*e/s.components*s.byteLength;case gr:return i*e*2/s.components*s.byteLength;case Id:return i*e*2/s.components*s.byteLength;case jm:return i*e*3/s.components*s.byteLength;case Ki:return i*e*4/s.components*s.byteLength;case Ld:return i*e*4/s.components*s.byteLength;case pl:case ml:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case gl:case xl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case mh:case xh:return Math.max(i,16)*Math.max(e,8)/4;case ph:case gh:return Math.max(i,8)*Math.max(e,8)/2;case _h:case vh:case Mh:case Sh:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case yh:case Tl:case bh:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Th:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case wh:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Eh:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Ah:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Rh:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Ch:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Ph:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Ih:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Lh:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Dh:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Nh:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Uh:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Fh:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Oh:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Bh:case kh:case Hh:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Gh:case Vh:return Math.ceil(i/4)*Math.ceil(e/4)*8;case wl:case zh:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Iy(i){switch(i){case Yi:case Ym:return{byteLength:1,components:1};case ic:case Km:case So:return{byteLength:2,components:1};case Ad:case Rd:return{byteLength:2,components:4};case Xs:case Ed:case cs:return{byteLength:4,components:1};case Zm:case $m:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:bd}}));typeof window<"u"&&(window.__THREE__?xt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=bd);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function A0(){let i=null,e=!1,t=null,n=null;function s(o,r){t(o,r),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(o){t=o},setContext:function(o){i=o}}}function Ly(i){const e=new WeakMap;function t(a,c){const l=a.array,u=a.usage,h=l.byteLength,d=i.createBuffer();i.bindBuffer(c,d),i.bufferData(c,l,u),a.onUploadCallback();let f;if(l instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)f=i.HALF_FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(l instanceof Int16Array)f=i.SHORT;else if(l instanceof Uint32Array)f=i.UNSIGNED_INT;else if(l instanceof Int32Array)f=i.INT;else if(l instanceof Int8Array)f=i.BYTE;else if(l instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:d,type:f,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:h}}function n(a,c,l){const u=c.array,h=c.updateRanges;if(i.bindBuffer(l,a),h.length===0)i.bufferSubData(l,0,u);else{h.sort((f,p)=>f.start-p.start);let d=0;for(let f=1;f<h.length;f++){const p=h[d],x=h[f];x.start<=p.start+p.count+1?p.count=Math.max(p.count,x.start+x.count-p.start):(++d,h[d]=x)}h.length=d+1;for(let f=0,p=h.length;f<p;f++){const x=h[f];i.bufferSubData(l,x.start*u.BYTES_PER_ELEMENT,u,x.start,x.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function o(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=e.get(a);c&&(i.deleteBuffer(c.buffer),e.delete(a))}function r(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const u=e.get(a);(!u||u.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=e.get(a);if(l===void 0)e.set(a,t(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,a,c),l.version=a.version}}return{get:s,remove:o,update:r}}var Dy=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Ny=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Uy=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Fy=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Oy=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,By=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,ky=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Hy=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Gy=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,Vy=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,zy=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Wy=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Xy=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,qy=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Yy=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ky=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Zy=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,$y=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Jy=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,jy=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Qy=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,eM=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,tM=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,nM=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,iM=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,sM=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,oM=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,rM=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,aM=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,cM=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,lM="gl_FragColor = linearToOutputTexel( gl_FragColor );",uM=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,hM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,dM=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,fM=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,pM=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,mM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,gM=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,xM=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,_M=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,vM=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,yM=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,MM=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,SM=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,bM=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,TM=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,wM=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,EM=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,AM=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,RM=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,CM=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,PM=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,IM=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,LM=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,DM=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,NM=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,UM=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,FM=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,OM=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,BM=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,kM=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,HM=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,GM=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,VM=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,zM=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,WM=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,XM=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,qM=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,YM=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,KM=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ZM=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,$M=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,JM=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,jM=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,QM=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,eS=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,tS=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,nS=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,iS=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,sS=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,oS=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,rS=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,aS=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,cS=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,lS=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,uS=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,hS=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dS=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,fS=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,pS=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,mS=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,gS=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,xS=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,_S=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,vS=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,yS=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,MS=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,SS=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,bS=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,TS=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,wS=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ES=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,AS=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,RS=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,CS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,PS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,IS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,LS=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const DS=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,NS=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,US=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,FS=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,OS=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,BS=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kS=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,HS=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,GS=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,VS=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,zS=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,WS=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,XS=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,qS=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,YS=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,KS=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ZS=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,$S=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,JS=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,jS=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,QS=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,eb=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,tb=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,nb=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ib=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,sb=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ob=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rb=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ab=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,cb=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,lb=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ub=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,hb=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,db=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,nn={alphahash_fragment:Dy,alphahash_pars_fragment:Ny,alphamap_fragment:Uy,alphamap_pars_fragment:Fy,alphatest_fragment:Oy,alphatest_pars_fragment:By,aomap_fragment:ky,aomap_pars_fragment:Hy,batching_pars_vertex:Gy,batching_vertex:Vy,begin_vertex:zy,beginnormal_vertex:Wy,bsdfs:Xy,iridescence_fragment:qy,bumpmap_pars_fragment:Yy,clipping_planes_fragment:Ky,clipping_planes_pars_fragment:Zy,clipping_planes_pars_vertex:$y,clipping_planes_vertex:Jy,color_fragment:jy,color_pars_fragment:Qy,color_pars_vertex:eM,color_vertex:tM,common:nM,cube_uv_reflection_fragment:iM,defaultnormal_vertex:sM,displacementmap_pars_vertex:oM,displacementmap_vertex:rM,emissivemap_fragment:aM,emissivemap_pars_fragment:cM,colorspace_fragment:lM,colorspace_pars_fragment:uM,envmap_fragment:hM,envmap_common_pars_fragment:dM,envmap_pars_fragment:fM,envmap_pars_vertex:pM,envmap_physical_pars_fragment:wM,envmap_vertex:mM,fog_vertex:gM,fog_pars_vertex:xM,fog_fragment:_M,fog_pars_fragment:vM,gradientmap_pars_fragment:yM,lightmap_pars_fragment:MM,lights_lambert_fragment:SM,lights_lambert_pars_fragment:bM,lights_pars_begin:TM,lights_toon_fragment:EM,lights_toon_pars_fragment:AM,lights_phong_fragment:RM,lights_phong_pars_fragment:CM,lights_physical_fragment:PM,lights_physical_pars_fragment:IM,lights_fragment_begin:LM,lights_fragment_maps:DM,lights_fragment_end:NM,lightprobes_pars_fragment:UM,logdepthbuf_fragment:FM,logdepthbuf_pars_fragment:OM,logdepthbuf_pars_vertex:BM,logdepthbuf_vertex:kM,map_fragment:HM,map_pars_fragment:GM,map_particle_fragment:VM,map_particle_pars_fragment:zM,metalnessmap_fragment:WM,metalnessmap_pars_fragment:XM,morphinstance_vertex:qM,morphcolor_vertex:YM,morphnormal_vertex:KM,morphtarget_pars_vertex:ZM,morphtarget_vertex:$M,normal_fragment_begin:JM,normal_fragment_maps:jM,normal_pars_fragment:QM,normal_pars_vertex:eS,normal_vertex:tS,normalmap_pars_fragment:nS,clearcoat_normal_fragment_begin:iS,clearcoat_normal_fragment_maps:sS,clearcoat_pars_fragment:oS,iridescence_pars_fragment:rS,opaque_fragment:aS,packing:cS,premultiplied_alpha_fragment:lS,project_vertex:uS,dithering_fragment:hS,dithering_pars_fragment:dS,roughnessmap_fragment:fS,roughnessmap_pars_fragment:pS,shadowmap_pars_fragment:mS,shadowmap_pars_vertex:gS,shadowmap_vertex:xS,shadowmask_pars_fragment:_S,skinbase_vertex:vS,skinning_pars_vertex:yS,skinning_vertex:MS,skinnormal_vertex:SS,specularmap_fragment:bS,specularmap_pars_fragment:TS,tonemapping_fragment:wS,tonemapping_pars_fragment:ES,transmission_fragment:AS,transmission_pars_fragment:RS,uv_pars_fragment:CS,uv_pars_vertex:PS,uv_vertex:IS,worldpos_vertex:LS,background_vert:DS,background_frag:NS,backgroundCube_vert:US,backgroundCube_frag:FS,cube_vert:OS,cube_frag:BS,depth_vert:kS,depth_frag:HS,distance_vert:GS,distance_frag:VS,equirect_vert:zS,equirect_frag:WS,linedashed_vert:XS,linedashed_frag:qS,meshbasic_vert:YS,meshbasic_frag:KS,meshlambert_vert:ZS,meshlambert_frag:$S,meshmatcap_vert:JS,meshmatcap_frag:jS,meshnormal_vert:QS,meshnormal_frag:eb,meshphong_vert:tb,meshphong_frag:nb,meshphysical_vert:ib,meshphysical_frag:sb,meshtoon_vert:ob,meshtoon_frag:rb,points_vert:ab,points_frag:cb,shadow_vert:lb,shadow_frag:ub,sprite_vert:hb,sprite_frag:db},ze={common:{diffuse:{value:new Qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Yt}},envmap:{envMap:{value:null},envMapRotation:{value:new Yt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Yt},normalScale:{value:new _e(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new I},probesMax:{value:new I},probesResolution:{value:new I}},points:{diffuse:{value:new Qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0},uvTransform:{value:new Yt}},sprite:{diffuse:{value:new Qe(16777215)},opacity:{value:1},center:{value:new _e(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}}},Os={basic:{uniforms:Oi([ze.common,ze.specularmap,ze.envmap,ze.aomap,ze.lightmap,ze.fog]),vertexShader:nn.meshbasic_vert,fragmentShader:nn.meshbasic_frag},lambert:{uniforms:Oi([ze.common,ze.specularmap,ze.envmap,ze.aomap,ze.lightmap,ze.emissivemap,ze.bumpmap,ze.normalmap,ze.displacementmap,ze.fog,ze.lights,{emissive:{value:new Qe(0)},envMapIntensity:{value:1}}]),vertexShader:nn.meshlambert_vert,fragmentShader:nn.meshlambert_frag},phong:{uniforms:Oi([ze.common,ze.specularmap,ze.envmap,ze.aomap,ze.lightmap,ze.emissivemap,ze.bumpmap,ze.normalmap,ze.displacementmap,ze.fog,ze.lights,{emissive:{value:new Qe(0)},specular:{value:new Qe(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:nn.meshphong_vert,fragmentShader:nn.meshphong_frag},standard:{uniforms:Oi([ze.common,ze.envmap,ze.aomap,ze.lightmap,ze.emissivemap,ze.bumpmap,ze.normalmap,ze.displacementmap,ze.roughnessmap,ze.metalnessmap,ze.fog,ze.lights,{emissive:{value:new Qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:nn.meshphysical_vert,fragmentShader:nn.meshphysical_frag},toon:{uniforms:Oi([ze.common,ze.aomap,ze.lightmap,ze.emissivemap,ze.bumpmap,ze.normalmap,ze.displacementmap,ze.gradientmap,ze.fog,ze.lights,{emissive:{value:new Qe(0)}}]),vertexShader:nn.meshtoon_vert,fragmentShader:nn.meshtoon_frag},matcap:{uniforms:Oi([ze.common,ze.bumpmap,ze.normalmap,ze.displacementmap,ze.fog,{matcap:{value:null}}]),vertexShader:nn.meshmatcap_vert,fragmentShader:nn.meshmatcap_frag},points:{uniforms:Oi([ze.points,ze.fog]),vertexShader:nn.points_vert,fragmentShader:nn.points_frag},dashed:{uniforms:Oi([ze.common,ze.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:nn.linedashed_vert,fragmentShader:nn.linedashed_frag},depth:{uniforms:Oi([ze.common,ze.displacementmap]),vertexShader:nn.depth_vert,fragmentShader:nn.depth_frag},normal:{uniforms:Oi([ze.common,ze.bumpmap,ze.normalmap,ze.displacementmap,{opacity:{value:1}}]),vertexShader:nn.meshnormal_vert,fragmentShader:nn.meshnormal_frag},sprite:{uniforms:Oi([ze.sprite,ze.fog]),vertexShader:nn.sprite_vert,fragmentShader:nn.sprite_frag},background:{uniforms:{uvTransform:{value:new Yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:nn.background_vert,fragmentShader:nn.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Yt}},vertexShader:nn.backgroundCube_vert,fragmentShader:nn.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:nn.cube_vert,fragmentShader:nn.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:nn.equirect_vert,fragmentShader:nn.equirect_frag},distance:{uniforms:Oi([ze.common,ze.displacementmap,{referencePosition:{value:new I},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:nn.distance_vert,fragmentShader:nn.distance_frag},shadow:{uniforms:Oi([ze.lights,ze.fog,{color:{value:new Qe(0)},opacity:{value:1}}]),vertexShader:nn.shadow_vert,fragmentShader:nn.shadow_frag}};Os.physical={uniforms:Oi([Os.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Yt},clearcoatNormalScale:{value:new _e(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Yt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Yt},sheen:{value:0},sheenColor:{value:new Qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Yt},transmissionSamplerSize:{value:new _e},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Yt},attenuationDistance:{value:0},attenuationColor:{value:new Qe(0)},specularColor:{value:new Qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Yt},anisotropyVector:{value:new _e},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Yt}}]),vertexShader:nn.meshphysical_vert,fragmentShader:nn.meshphysical_frag};const ll={r:0,b:0,g:0},fb=new Wt,R0=new Yt;R0.set(-1,0,0,0,1,0,0,0,1);function pb(i,e,t,n,s,o){const r=new Qe(0);let a=s===!0?0:1,c,l,u=null,h=0,d=null;function f(M){let S=M.isScene===!0?M.background:null;if(S&&S.isTexture){const _=M.backgroundBlurriness>0;S=e.get(S,_)}return S}function p(M){let S=!1;const _=f(M);_===null?m(r,a):_&&_.isColor&&(m(_,1),S=!0);const A=i.xr.getEnvironmentBlendMode();A==="additive"?t.buffers.color.setClear(0,0,0,1,o):A==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,o),(i.autoClear||S)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function x(M,S){const _=f(S);_&&(_.isCubeTexture||_.mapping===Vl)?(l===void 0&&(l=new W(new fn(1,1,1),new hs({name:"BackgroundCubeMaterial",uniforms:oa(Os.backgroundCube.uniforms),vertexShader:Os.backgroundCube.vertexShader,fragmentShader:Os.backgroundCube.fragmentShader,side:Ii,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),l.geometry.deleteAttribute("uv"),l.onBeforeRender=function(A,E,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(l)),l.material.uniforms.envMap.value=_,l.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(fb.makeRotationFromEuler(S.backgroundRotation)).transpose(),_.isCubeTexture&&_.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(R0),l.material.toneMapped=un.getTransfer(_.colorSpace)!==Dn,(u!==_||h!==_.version||d!==i.toneMapping)&&(l.material.needsUpdate=!0,u=_,h=_.version,d=i.toneMapping),l.layers.enableAll(),M.unshift(l,l.geometry,l.material,0,0,null)):_&&_.isTexture&&(c===void 0&&(c=new W(new vc(2,2),new hs({name:"BackgroundMaterial",uniforms:oa(Os.background.uniforms),vertexShader:Os.background.vertexShader,fragmentShader:Os.background.fragmentShader,side:Mo,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(c)),c.material.uniforms.t2D.value=_,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.toneMapped=un.getTransfer(_.colorSpace)!==Dn,_.matrixAutoUpdate===!0&&_.updateMatrix(),c.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||h!==_.version||d!==i.toneMapping)&&(c.material.needsUpdate=!0,u=_,h=_.version,d=i.toneMapping),c.layers.enableAll(),M.unshift(c,c.geometry,c.material,0,0,null))}function m(M,S){M.getRGB(ll,v0(i)),t.buffers.color.setClear(ll.r,ll.g,ll.b,S,o)}function g(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return r},setClearColor:function(M,S=1){r.set(M),a=S,m(r,a)},getClearAlpha:function(){return a},setClearAlpha:function(M){a=M,m(r,a)},render:p,addToRenderList:x,dispose:g}}function mb(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null);let o=s,r=!1;function a(N,B,ne,ae,V){let se=!1;const K=h(N,ae,ne,B);o!==K&&(o=K,l(o.object)),se=f(N,ae,ne,V),se&&p(N,ae,ne,V),V!==null&&e.update(V,i.ELEMENT_ARRAY_BUFFER),(se||r)&&(r=!1,_(N,B,ne,ae),V!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(V).buffer))}function c(){return i.createVertexArray()}function l(N){return i.bindVertexArray(N)}function u(N){return i.deleteVertexArray(N)}function h(N,B,ne,ae){const V=ae.wireframe===!0;let se=n[B.id];se===void 0&&(se={},n[B.id]=se);const K=N.isInstancedMesh===!0?N.id:0;let he=se[K];he===void 0&&(he={},se[K]=he);let me=he[ne.id];me===void 0&&(me={},he[ne.id]=me);let Re=me[V];return Re===void 0&&(Re=d(c()),me[V]=Re),Re}function d(N){const B=[],ne=[],ae=[];for(let V=0;V<t;V++)B[V]=0,ne[V]=0,ae[V]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:ne,attributeDivisors:ae,object:N,attributes:{},index:null}}function f(N,B,ne,ae){const V=o.attributes,se=B.attributes;let K=0;const he=ne.getAttributes();for(const me in he)if(he[me].location>=0){const we=V[me];let Xe=se[me];if(Xe===void 0&&(me==="instanceMatrix"&&N.instanceMatrix&&(Xe=N.instanceMatrix),me==="instanceColor"&&N.instanceColor&&(Xe=N.instanceColor)),we===void 0||we.attribute!==Xe||Xe&&we.data!==Xe.data)return!0;K++}return o.attributesNum!==K||o.index!==ae}function p(N,B,ne,ae){const V={},se=B.attributes;let K=0;const he=ne.getAttributes();for(const me in he)if(he[me].location>=0){let we=se[me];we===void 0&&(me==="instanceMatrix"&&N.instanceMatrix&&(we=N.instanceMatrix),me==="instanceColor"&&N.instanceColor&&(we=N.instanceColor));const Xe={};Xe.attribute=we,we&&we.data&&(Xe.data=we.data),V[me]=Xe,K++}o.attributes=V,o.attributesNum=K,o.index=ae}function x(){const N=o.newAttributes;for(let B=0,ne=N.length;B<ne;B++)N[B]=0}function m(N){g(N,0)}function g(N,B){const ne=o.newAttributes,ae=o.enabledAttributes,V=o.attributeDivisors;ne[N]=1,ae[N]===0&&(i.enableVertexAttribArray(N),ae[N]=1),V[N]!==B&&(i.vertexAttribDivisor(N,B),V[N]=B)}function M(){const N=o.newAttributes,B=o.enabledAttributes;for(let ne=0,ae=B.length;ne<ae;ne++)B[ne]!==N[ne]&&(i.disableVertexAttribArray(ne),B[ne]=0)}function S(N,B,ne,ae,V,se,K){K===!0?i.vertexAttribIPointer(N,B,ne,V,se):i.vertexAttribPointer(N,B,ne,ae,V,se)}function _(N,B,ne,ae){x();const V=ae.attributes,se=ne.getAttributes(),K=B.defaultAttributeValues;for(const he in se){const me=se[he];if(me.location>=0){let Re=V[he];if(Re===void 0&&(he==="instanceMatrix"&&N.instanceMatrix&&(Re=N.instanceMatrix),he==="instanceColor"&&N.instanceColor&&(Re=N.instanceColor)),Re!==void 0){const we=Re.normalized,Xe=Re.itemSize,$t=e.get(Re);if($t===void 0)continue;const hn=$t.buffer,Qt=$t.type,ce=$t.bytesPerElement,Ce=Qt===i.INT||Qt===i.UNSIGNED_INT||Re.gpuType===Ed;if(Re.isInterleavedBufferAttribute){const ye=Re.data,ht=ye.stride,Nt=Re.offset;if(ye.isInstancedInterleavedBuffer){for(let bt=0;bt<me.locationSize;bt++)g(me.location+bt,ye.meshPerAttribute);N.isInstancedMesh!==!0&&ae._maxInstanceCount===void 0&&(ae._maxInstanceCount=ye.meshPerAttribute*ye.count)}else for(let bt=0;bt<me.locationSize;bt++)m(me.location+bt);i.bindBuffer(i.ARRAY_BUFFER,hn);for(let bt=0;bt<me.locationSize;bt++)S(me.location+bt,Xe/me.locationSize,Qt,we,ht*ce,(Nt+Xe/me.locationSize*bt)*ce,Ce)}else{if(Re.isInstancedBufferAttribute){for(let ye=0;ye<me.locationSize;ye++)g(me.location+ye,Re.meshPerAttribute);N.isInstancedMesh!==!0&&ae._maxInstanceCount===void 0&&(ae._maxInstanceCount=Re.meshPerAttribute*Re.count)}else for(let ye=0;ye<me.locationSize;ye++)m(me.location+ye);i.bindBuffer(i.ARRAY_BUFFER,hn);for(let ye=0;ye<me.locationSize;ye++)S(me.location+ye,Xe/me.locationSize,Qt,we,Xe*ce,Xe/me.locationSize*ye*ce,Ce)}}else if(K!==void 0){const we=K[he];if(we!==void 0)switch(we.length){case 2:i.vertexAttrib2fv(me.location,we);break;case 3:i.vertexAttrib3fv(me.location,we);break;case 4:i.vertexAttrib4fv(me.location,we);break;default:i.vertexAttrib1fv(me.location,we)}}}}M()}function A(){R();for(const N in n){const B=n[N];for(const ne in B){const ae=B[ne];for(const V in ae){const se=ae[V];for(const K in se)u(se[K].object),delete se[K];delete ae[V]}}delete n[N]}}function E(N){if(n[N.id]===void 0)return;const B=n[N.id];for(const ne in B){const ae=B[ne];for(const V in ae){const se=ae[V];for(const K in se)u(se[K].object),delete se[K];delete ae[V]}}delete n[N.id]}function L(N){for(const B in n){const ne=n[B];for(const ae in ne){const V=ne[ae];if(V[N.id]===void 0)continue;const se=V[N.id];for(const K in se)u(se[K].object),delete se[K];delete V[N.id]}}}function v(N){for(const B in n){const ne=n[B],ae=N.isInstancedMesh===!0?N.id:0,V=ne[ae];if(V!==void 0){for(const se in V){const K=V[se];for(const he in K)u(K[he].object),delete K[he];delete V[se]}delete ne[ae],Object.keys(ne).length===0&&delete n[B]}}}function R(){D(),r=!0,o!==s&&(o=s,l(o.object))}function D(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:R,resetDefaultState:D,dispose:A,releaseStatesOfGeometry:E,releaseStatesOfObject:v,releaseStatesOfProgram:L,initAttributes:x,enableAttribute:m,disableUnusedAttributes:M}}function gb(i,e,t){let n;function s(c){n=c}function o(c,l){i.drawArrays(n,c,l),t.update(l,n,1)}function r(c,l,u){u!==0&&(i.drawArraysInstanced(n,c,l,u),t.update(l,n,u))}function a(c,l,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,l,0,u);let d=0;for(let f=0;f<u;f++)d+=l[f];t.update(d,n,1)}this.setMode=s,this.render=o,this.renderInstances=r,this.renderMultiDraw=a}function xb(i,e,t,n){let s;function o(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const L=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function r(L){return!(L!==Ki&&n.convert(L)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(L){const v=L===So&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(L!==Yi&&n.convert(L)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&L!==cs&&!v)}function c(L){if(L==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=t.precision!==void 0?t.precision:"highp";const u=c(l);u!==l&&(xt("WebGLRenderer:",l,"not supported, using",u,"instead."),l=u);const h=t.logarithmicDepthBuffer===!0,d=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&d===!1&&xt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),p=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),g=i.getParameter(i.MAX_VERTEX_ATTRIBS),M=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),S=i.getParameter(i.MAX_VARYING_VECTORS),_=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),A=i.getParameter(i.MAX_SAMPLES),E=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:o,getMaxPrecision:c,textureFormatReadable:r,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:h,reversedDepthBuffer:d,maxTextures:f,maxVertexTextures:p,maxTextureSize:x,maxCubemapSize:m,maxAttributes:g,maxVertexUniforms:M,maxVaryings:S,maxFragmentUniforms:_,maxSamples:A,samples:E}}function _b(i){const e=this;let t=null,n=0,s=!1,o=!1;const r=new Uo,a=new Yt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(h,d){const f=h.length!==0||d||n!==0||s;return s=d,n=h.length,f},this.beginShadows=function(){o=!0,u(null)},this.endShadows=function(){o=!1},this.setGlobalState=function(h,d){t=u(h,d,0)},this.setState=function(h,d,f){const p=h.clippingPlanes,x=h.clipIntersection,m=h.clipShadows,g=i.get(h);if(!s||p===null||p.length===0||o&&!m)o?u(null):l();else{const M=o?0:n,S=M*4;let _=g.clippingState||null;c.value=_,_=u(p,d,S,f);for(let A=0;A!==S;++A)_[A]=t[A];g.clippingState=_,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=M}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function u(h,d,f,p){const x=h!==null?h.length:0;let m=null;if(x!==0){if(m=c.value,p!==!0||m===null){const g=f+x*4,M=d.matrixWorldInverse;a.getNormalMatrix(M),(m===null||m.length<g)&&(m=new Float32Array(g));for(let S=0,_=f;S!==x;++S,_+=4)r.copy(h[S]).applyMatrix4(M,a),r.normal.toArray(m,_),m[_+3]=r.constant}c.value=m,c.needsUpdate=!0}return e.numPlanes=x,e.numIntersection=0,m}}const Bo=4,Fp=[.125,.215,.35,.446,.526,.582],or=20,vb=256,Pa=new Xl,Op=new Qe;let Hu=null,Gu=0,Vu=0,zu=!1;const yb=new I;class Bp{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,s=100,o={}){const{size:r=256,position:a=yb}=o;Hu=this._renderer.getRenderTarget(),Gu=this._renderer.getActiveCubeFace(),Vu=this._renderer.getActiveMipmapLevel(),zu=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(r);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(e,n,s,c,a),t>0&&this._blur(c,0,0,t),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Gp(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Hp(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Hu,Gu,Vu),this._renderer.xr.enabled=zu,e.scissorTest=!1,Or(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===pr||e.mapping===ta?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Hu=this._renderer.getRenderTarget(),Gu=this._renderer.getActiveCubeFace(),Vu=this._renderer.getActiveMipmapLevel(),zu=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:mi,minFilter:mi,generateMipmaps:!1,type:So,format:Ki,colorSpace:Ji,depthBuffer:!1},s=kp(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=kp(e,t,n);const{_lodMax:o}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Mb(o)),this._blurMaterial=bb(o,e,t),this._ggxMaterial=Sb(o,e,t)}return s}_compileMaterial(e){const t=new W(new Tn,e);this._renderer.compile(t,Pa)}_sceneToCubeUV(e,t,n,s,o){const c=new Bi(90,1,t,n),l=[1,-1,1,1,1,1],u=[1,1,1,-1,-1,-1],h=this._renderer,d=h.autoClear,f=h.toneMapping;h.getClearColor(Op),h.toneMapping=Vs,h.autoClear=!1,h.state.buffers.depth.getReversed()&&(h.setRenderTarget(s),h.clearDepth(),h.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new W(new fn,new bn({name:"PMREM.Background",side:Ii,depthWrite:!1,depthTest:!1})));const x=this._backgroundBox,m=x.material;let g=!1;const M=e.background;M?M.isColor&&(m.color.copy(M),e.background=null,g=!0):(m.color.copy(Op),g=!0);for(let S=0;S<6;S++){const _=S%3;_===0?(c.up.set(0,l[S],0),c.position.set(o.x,o.y,o.z),c.lookAt(o.x+u[S],o.y,o.z)):_===1?(c.up.set(0,0,l[S]),c.position.set(o.x,o.y,o.z),c.lookAt(o.x,o.y+u[S],o.z)):(c.up.set(0,l[S],0),c.position.set(o.x,o.y,o.z),c.lookAt(o.x,o.y,o.z+u[S]));const A=this._cubeSize;Or(s,_*A,S>2?A:0,A,A),h.setRenderTarget(s),g&&h.render(x,c),h.render(e,c)}h.toneMapping=f,h.autoClear=d,e.background=M}_textureToCubeUV(e,t){const n=this._renderer,s=e.mapping===pr||e.mapping===ta;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Gp()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Hp());const o=s?this._cubemapMaterial:this._equirectMaterial,r=this._lodMeshes[0];r.material=o;const a=o.uniforms;a.envMap.value=e;const c=this._cubeSize;Or(t,0,0,3*c,2*c),n.setRenderTarget(t),n.render(r,Pa)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const s=this._lodMeshes.length;for(let o=1;o<s;o++)this._applyGGXFilter(e,o-1,o);t.autoClear=n}_applyGGXFilter(e,t,n){const s=this._renderer,o=this._pingPongRenderTarget,r=this._ggxMaterial,a=this._lodMeshes[n];a.material=r;const c=r.uniforms,l=n/(this._lodMeshes.length-1),u=t/(this._lodMeshes.length-1),h=Math.sqrt(l*l-u*u),d=0+l*1.25,f=h*d,{_lodMax:p}=this,x=this._sizeLods[n],m=3*x*(n>p-Bo?n-p+Bo:0),g=4*(this._cubeSize-x);c.envMap.value=e.texture,c.roughness.value=f,c.mipInt.value=p-t,Or(o,m,g,3*x,2*x),s.setRenderTarget(o),s.render(a,Pa),c.envMap.value=o.texture,c.roughness.value=0,c.mipInt.value=p-n,Or(e,m,g,3*x,2*x),s.setRenderTarget(e),s.render(a,Pa)}_blur(e,t,n,s,o){const r=this._pingPongRenderTarget;this._halfBlur(e,r,t,n,s,"latitudinal",o),this._halfBlur(r,e,n,n,s,"longitudinal",o)}_halfBlur(e,t,n,s,o,r,a){const c=this._renderer,l=this._blurMaterial;r!=="latitudinal"&&r!=="longitudinal"&&Lt("blur direction must be either latitudinal or longitudinal!");const u=3,h=this._lodMeshes[s];h.material=l;const d=l.uniforms,f=this._sizeLods[n]-1,p=isFinite(o)?Math.PI/(2*f):2*Math.PI/(2*or-1),x=o/p,m=isFinite(o)?1+Math.floor(u*x):or;m>or&&xt(`sigmaRadians, ${o}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${or}`);const g=[];let M=0;for(let L=0;L<or;++L){const v=L/x,R=Math.exp(-v*v/2);g.push(R),L===0?M+=R:L<m&&(M+=2*R)}for(let L=0;L<g.length;L++)g[L]=g[L]/M;d.envMap.value=e.texture,d.samples.value=m,d.weights.value=g,d.latitudinal.value=r==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:S}=this;d.dTheta.value=p,d.mipInt.value=S-n;const _=this._sizeLods[s],A=3*_*(s>S-Bo?s-S+Bo:0),E=4*(this._cubeSize-_);Or(t,A,E,3*_,2*_),c.setRenderTarget(t),c.render(h,Pa)}}function Mb(i){const e=[],t=[],n=[];let s=i;const o=i-Bo+1+Fp.length;for(let r=0;r<o;r++){const a=Math.pow(2,s);e.push(a);let c=1/a;r>i-Bo?c=Fp[r-i+Bo-1]:r===0&&(c=0),t.push(c);const l=1/(a-2),u=-l,h=1+l,d=[u,u,h,u,h,h,u,u,h,h,u,h],f=6,p=6,x=3,m=2,g=1,M=new Float32Array(x*p*f),S=new Float32Array(m*p*f),_=new Float32Array(g*p*f);for(let E=0;E<f;E++){const L=E%3*2/3-1,v=E>2?0:-1,R=[L,v,0,L+2/3,v,0,L+2/3,v+1,0,L,v,0,L+2/3,v+1,0,L,v+1,0];M.set(R,x*p*E),S.set(d,m*p*E);const D=[E,E,E,E,E,E];_.set(D,g*p*E)}const A=new Tn;A.setAttribute("position",new Li(M,x)),A.setAttribute("uv",new Li(S,m)),A.setAttribute("faceIndex",new Li(_,g)),n.push(new W(A,null)),s>Bo&&s--}return{lodMeshes:n,sizeLods:e,sigmas:t}}function kp(i,e,t){const n=new zs(i,e,t);return n.texture.mapping=Vl,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Or(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function Sb(i,e,t){return new hs({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:vb,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:ql(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:po,depthTest:!1,depthWrite:!1})}function bb(i,e,t){const n=new Float32Array(or),s=new I(0,1,0);return new hs({name:"SphericalGaussianBlur",defines:{n:or,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:ql(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:po,depthTest:!1,depthWrite:!1})}function Hp(){return new hs({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ql(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:po,depthTest:!1,depthWrite:!1})}function Gp(){return new hs({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ql(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:po,depthTest:!1,depthWrite:!1})}function ql(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class C0 extends zs{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new c0(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new fn(5,5,5),o=new hs({name:"CubemapFromEquirect",uniforms:oa(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ii,blending:po});o.uniforms.tEquirect.value=t;const r=new W(s,o),a=t.minFilter;return t.minFilter===Hs&&(t.minFilter=mi),new my(1,10,this).update(e,r),t.minFilter=a,r.geometry.dispose(),r.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const o=e.getRenderTarget();for(let r=0;r<6;r++)e.setRenderTarget(this,r),e.clear(t,n,s);e.setRenderTarget(o)}}function Tb(i){let e=new WeakMap,t=new WeakMap,n=null;function s(d,f=!1){return d==null?null:f?r(d):o(d)}function o(d){if(d&&d.isTexture){const f=d.mapping;if(f===au||f===cu)if(e.has(d)){const p=e.get(d).texture;return a(p,d.mapping)}else{const p=d.image;if(p&&p.height>0){const x=new C0(p.height);return x.fromEquirectangularTexture(i,d),e.set(d,x),d.addEventListener("dispose",l),a(x.texture,d.mapping)}else return null}}return d}function r(d){if(d&&d.isTexture){const f=d.mapping,p=f===au||f===cu,x=f===pr||f===ta;if(p||x){let m=t.get(d);const g=m!==void 0?m.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==g)return n===null&&(n=new Bp(i)),m=p?n.fromEquirectangular(d,m):n.fromCubemap(d,m),m.texture.pmremVersion=d.pmremVersion,t.set(d,m),m.texture;if(m!==void 0)return m.texture;{const M=d.image;return p&&M&&M.height>0||x&&M&&c(M)?(n===null&&(n=new Bp(i)),m=p?n.fromEquirectangular(d):n.fromCubemap(d),m.texture.pmremVersion=d.pmremVersion,t.set(d,m),d.addEventListener("dispose",u),m.texture):null}}}return d}function a(d,f){return f===au?d.mapping=pr:f===cu&&(d.mapping=ta),d}function c(d){let f=0;const p=6;for(let x=0;x<p;x++)d[x]!==void 0&&f++;return f===p}function l(d){const f=d.target;f.removeEventListener("dispose",l);const p=e.get(f);p!==void 0&&(e.delete(f),p.dispose())}function u(d){const f=d.target;f.removeEventListener("dispose",u);const p=t.get(f);p!==void 0&&(t.delete(f),p.dispose())}function h(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:h}}function wb(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const s=i.getExtension(n);return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&qr("WebGLRenderer: "+n+" extension not supported."),s}}}function Eb(i,e,t,n){const s={},o=new WeakMap;function r(h){const d=h.target;d.index!==null&&e.remove(d.index);for(const p in d.attributes)e.remove(d.attributes[p]);d.removeEventListener("dispose",r),delete s[d.id];const f=o.get(d);f&&(e.remove(f),o.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(h,d){return s[d.id]===!0||(d.addEventListener("dispose",r),s[d.id]=!0,t.memory.geometries++),d}function c(h){const d=h.attributes;for(const f in d)e.update(d[f],i.ARRAY_BUFFER)}function l(h){const d=[],f=h.index,p=h.attributes.position;let x=0;if(p===void 0)return;if(f!==null){const M=f.array;x=f.version;for(let S=0,_=M.length;S<_;S+=3){const A=M[S+0],E=M[S+1],L=M[S+2];d.push(A,E,E,L,L,A)}}else{const M=p.array;x=p.version;for(let S=0,_=M.length/3-1;S<_;S+=3){const A=S+0,E=S+1,L=S+2;d.push(A,E,E,L,L,A)}}const m=new(p.count>=65535?o0:s0)(d,1);m.version=x;const g=o.get(h);g&&e.remove(g),o.set(h,m)}function u(h){const d=o.get(h);if(d){const f=h.index;f!==null&&d.version<f.version&&l(h)}else l(h);return o.get(h)}return{get:a,update:c,getWireframeAttribute:u}}function Ab(i,e,t){let n;function s(h){n=h}let o,r;function a(h){o=h.type,r=h.bytesPerElement}function c(h,d){i.drawElements(n,d,o,h*r),t.update(d,n,1)}function l(h,d,f){f!==0&&(i.drawElementsInstanced(n,d,o,h*r,f),t.update(d,n,f))}function u(h,d,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,o,h,0,f);let x=0;for(let m=0;m<f;m++)x+=d[m];t.update(x,n,1)}this.setMode=s,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function Rb(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(o,r,a){switch(t.calls++,r){case i.TRIANGLES:t.triangles+=a*(o/3);break;case i.LINES:t.lines+=a*(o/2);break;case i.LINE_STRIP:t.lines+=a*(o-1);break;case i.LINE_LOOP:t.lines+=a*o;break;case i.POINTS:t.points+=a*o;break;default:Lt("WebGLInfo: Unknown draw mode:",r);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function Cb(i,e,t){const n=new WeakMap,s=new Bn;function o(r,a,c){const l=r.morphTargetInfluences,u=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,h=u!==void 0?u.length:0;let d=n.get(a);if(d===void 0||d.count!==h){let D=function(){v.dispose(),n.delete(a),a.removeEventListener("dispose",D)};var f=D;d!==void 0&&d.texture.dispose();const p=a.morphAttributes.position!==void 0,x=a.morphAttributes.normal!==void 0,m=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],M=a.morphAttributes.normal||[],S=a.morphAttributes.color||[];let _=0;p===!0&&(_=1),x===!0&&(_=2),m===!0&&(_=3);let A=a.attributes.position.count*_,E=1;A>e.maxTextureSize&&(E=Math.ceil(A/e.maxTextureSize),A=e.maxTextureSize);const L=new Float32Array(A*E*4*h),v=new n0(L,A,E,h);v.type=cs,v.needsUpdate=!0;const R=_*4;for(let N=0;N<h;N++){const B=g[N],ne=M[N],ae=S[N],V=A*E*4*N;for(let se=0;se<B.count;se++){const K=se*R;p===!0&&(s.fromBufferAttribute(B,se),L[V+K+0]=s.x,L[V+K+1]=s.y,L[V+K+2]=s.z,L[V+K+3]=0),x===!0&&(s.fromBufferAttribute(ne,se),L[V+K+4]=s.x,L[V+K+5]=s.y,L[V+K+6]=s.z,L[V+K+7]=0),m===!0&&(s.fromBufferAttribute(ae,se),L[V+K+8]=s.x,L[V+K+9]=s.y,L[V+K+10]=s.z,L[V+K+11]=ae.itemSize===4?s.w:1)}}d={count:h,texture:v,size:new _e(A,E)},n.set(a,d),a.addEventListener("dispose",D)}if(r.isInstancedMesh===!0&&r.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",r.morphTexture,t);else{let p=0;for(let m=0;m<l.length;m++)p+=l[m];const x=a.morphTargetsRelative?1:1-p;c.getUniforms().setValue(i,"morphTargetBaseInfluence",x),c.getUniforms().setValue(i,"morphTargetInfluences",l)}c.getUniforms().setValue(i,"morphTargetsTexture",d.texture,t),c.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:o}}function Pb(i,e,t,n,s){let o=new WeakMap;function r(l){const u=s.render.frame,h=l.geometry,d=e.get(l,h);if(o.get(d)!==u&&(e.update(d),o.set(d,u)),l.isInstancedMesh&&(l.hasEventListener("dispose",c)===!1&&l.addEventListener("dispose",c),o.get(l)!==u&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),o.set(l,u))),l.isSkinnedMesh){const f=l.skeleton;o.get(f)!==u&&(f.update(),o.set(f,u))}return d}function a(){o=new WeakMap}function c(l){const u=l.target;u.removeEventListener("dispose",c),n.releaseStatesOfObject(u),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:r,dispose:a}}const Ib={[km]:"LINEAR_TONE_MAPPING",[Hm]:"REINHARD_TONE_MAPPING",[Gm]:"CINEON_TONE_MAPPING",[wd]:"ACES_FILMIC_TONE_MAPPING",[zm]:"AGX_TONE_MAPPING",[Wm]:"NEUTRAL_TONE_MAPPING",[Vm]:"CUSTOM_TONE_MAPPING"};function Lb(i,e,t,n,s,o){const r=new zs(e,t,{type:i,depthBuffer:s,stencilBuffer:o,samples:n?4:0,depthTexture:s?new ia(e,t):void 0}),a=new zs(e,t,{type:So,depthBuffer:!1,stencilBuffer:!1}),c=new Tn;c.setAttribute("position",new Dt([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute("uv",new Dt([0,2,0,0,2,0],2));const l=new qv({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new W(c,l),h=new Xl(-1,1,1,-1,0,1);let d=null,f=null,p=!1,x,m=null,g=[],M=!1;this.setSize=function(S,_){r.setSize(S,_),a.setSize(S,_);for(let A=0;A<g.length;A++){const E=g[A];E.setSize&&E.setSize(S,_)}},this.setEffects=function(S){g=S,M=g.length>0&&g[0].isRenderPass===!0;const _=r.width,A=r.height;for(let E=0;E<g.length;E++){const L=g[E];L.setSize&&L.setSize(_,A)}},this.begin=function(S,_){if(p||S.toneMapping===Vs&&g.length===0)return!1;if(m=_,_!==null){const A=_.width,E=_.height;(r.width!==A||r.height!==E)&&this.setSize(A,E)}return M===!1&&S.setRenderTarget(r),x=S.toneMapping,S.toneMapping=Vs,!0},this.hasRenderPass=function(){return M},this.end=function(S,_){S.toneMapping=x,p=!0;let A=r,E=a;for(let L=0;L<g.length;L++){const v=g[L];if(v.enabled!==!1&&(v.render(S,E,A,_),v.needsSwap!==!1)){const R=A;A=E,E=R}}if(d!==S.outputColorSpace||f!==S.toneMapping){d=S.outputColorSpace,f=S.toneMapping,l.defines={},un.getTransfer(d)===Dn&&(l.defines.SRGB_TRANSFER="");const L=Ib[f];L&&(l.defines[L]=""),l.needsUpdate=!0}l.uniforms.tDiffuse.value=A.texture,S.setRenderTarget(m),S.render(u,h),m=null,p=!1},this.isCompositing=function(){return p},this.dispose=function(){r.depthTexture&&r.depthTexture.dispose(),r.dispose(),a.dispose(),c.dispose(),l.dispose()}}const P0=new bi,Qh=new ia(1,1),I0=new n0,L0=new H_,D0=new c0,Vp=[],zp=[],Wp=new Float32Array(16),Xp=new Float32Array(9),qp=new Float32Array(4);function pa(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let o=Vp[s];if(o===void 0&&(o=new Float32Array(s),Vp[s]=o),e!==0){n.toArray(o,0);for(let r=1,a=0;r!==e;++r)a+=t,i[r].toArray(o,a)}return o}function yi(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Mi(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function Yl(i,e){let t=zp[e];t===void 0&&(t=new Int32Array(e),zp[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Db(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Nb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(yi(t,e))return;i.uniform2fv(this.addr,e),Mi(t,e)}}function Ub(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(yi(t,e))return;i.uniform3fv(this.addr,e),Mi(t,e)}}function Fb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(yi(t,e))return;i.uniform4fv(this.addr,e),Mi(t,e)}}function Ob(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(yi(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Mi(t,e)}else{if(yi(t,n))return;qp.set(n),i.uniformMatrix2fv(this.addr,!1,qp),Mi(t,n)}}function Bb(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(yi(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Mi(t,e)}else{if(yi(t,n))return;Xp.set(n),i.uniformMatrix3fv(this.addr,!1,Xp),Mi(t,n)}}function kb(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(yi(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Mi(t,e)}else{if(yi(t,n))return;Wp.set(n),i.uniformMatrix4fv(this.addr,!1,Wp),Mi(t,n)}}function Hb(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function Gb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(yi(t,e))return;i.uniform2iv(this.addr,e),Mi(t,e)}}function Vb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(yi(t,e))return;i.uniform3iv(this.addr,e),Mi(t,e)}}function zb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(yi(t,e))return;i.uniform4iv(this.addr,e),Mi(t,e)}}function Wb(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function Xb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(yi(t,e))return;i.uniform2uiv(this.addr,e),Mi(t,e)}}function qb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(yi(t,e))return;i.uniform3uiv(this.addr,e),Mi(t,e)}}function Yb(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(yi(t,e))return;i.uniform4uiv(this.addr,e),Mi(t,e)}}function Kb(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let o;this.type===i.SAMPLER_2D_SHADOW?(Qh.compareFunction=t.isReversedDepthBuffer()?Ud:Nd,o=Qh):o=P0,t.setTexture2D(e||o,s)}function Zb(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||L0,s)}function $b(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||D0,s)}function Jb(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||I0,s)}function jb(i){switch(i){case 5126:return Db;case 35664:return Nb;case 35665:return Ub;case 35666:return Fb;case 35674:return Ob;case 35675:return Bb;case 35676:return kb;case 5124:case 35670:return Hb;case 35667:case 35671:return Gb;case 35668:case 35672:return Vb;case 35669:case 35673:return zb;case 5125:return Wb;case 36294:return Xb;case 36295:return qb;case 36296:return Yb;case 35678:case 36198:case 36298:case 36306:case 35682:return Kb;case 35679:case 36299:case 36307:return Zb;case 35680:case 36300:case 36308:case 36293:return $b;case 36289:case 36303:case 36311:case 36292:return Jb}}function Qb(i,e){i.uniform1fv(this.addr,e)}function e1(i,e){const t=pa(e,this.size,2);i.uniform2fv(this.addr,t)}function t1(i,e){const t=pa(e,this.size,3);i.uniform3fv(this.addr,t)}function n1(i,e){const t=pa(e,this.size,4);i.uniform4fv(this.addr,t)}function i1(i,e){const t=pa(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function s1(i,e){const t=pa(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function o1(i,e){const t=pa(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function r1(i,e){i.uniform1iv(this.addr,e)}function a1(i,e){i.uniform2iv(this.addr,e)}function c1(i,e){i.uniform3iv(this.addr,e)}function l1(i,e){i.uniform4iv(this.addr,e)}function u1(i,e){i.uniform1uiv(this.addr,e)}function h1(i,e){i.uniform2uiv(this.addr,e)}function d1(i,e){i.uniform3uiv(this.addr,e)}function f1(i,e){i.uniform4uiv(this.addr,e)}function p1(i,e,t){const n=this.cache,s=e.length,o=Yl(t,s);yi(n,o)||(i.uniform1iv(this.addr,o),Mi(n,o));let r;this.type===i.SAMPLER_2D_SHADOW?r=Qh:r=P0;for(let a=0;a!==s;++a)t.setTexture2D(e[a]||r,o[a])}function m1(i,e,t){const n=this.cache,s=e.length,o=Yl(t,s);yi(n,o)||(i.uniform1iv(this.addr,o),Mi(n,o));for(let r=0;r!==s;++r)t.setTexture3D(e[r]||L0,o[r])}function g1(i,e,t){const n=this.cache,s=e.length,o=Yl(t,s);yi(n,o)||(i.uniform1iv(this.addr,o),Mi(n,o));for(let r=0;r!==s;++r)t.setTextureCube(e[r]||D0,o[r])}function x1(i,e,t){const n=this.cache,s=e.length,o=Yl(t,s);yi(n,o)||(i.uniform1iv(this.addr,o),Mi(n,o));for(let r=0;r!==s;++r)t.setTexture2DArray(e[r]||I0,o[r])}function _1(i){switch(i){case 5126:return Qb;case 35664:return e1;case 35665:return t1;case 35666:return n1;case 35674:return i1;case 35675:return s1;case 35676:return o1;case 5124:case 35670:return r1;case 35667:case 35671:return a1;case 35668:case 35672:return c1;case 35669:case 35673:return l1;case 5125:return u1;case 36294:return h1;case 36295:return d1;case 36296:return f1;case 35678:case 36198:case 36298:case 36306:case 35682:return p1;case 35679:case 36299:case 36307:return m1;case 35680:case 36300:case 36308:case 36293:return g1;case 36289:case 36303:case 36311:case 36292:return x1}}class v1{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=jb(t.type)}}class y1{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=_1(t.type)}}class M1{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let o=0,r=s.length;o!==r;++o){const a=s[o];a.setValue(e,t[a.id],n)}}}const Wu=/(\w+)(\])?(\[|\.)?/g;function Yp(i,e){i.seq.push(e),i.map[e.id]=e}function S1(i,e,t){const n=i.name,s=n.length;for(Wu.lastIndex=0;;){const o=Wu.exec(n),r=Wu.lastIndex;let a=o[1];const c=o[2]==="]",l=o[3];if(c&&(a=a|0),l===void 0||l==="["&&r+2===s){Yp(t,l===void 0?new v1(a,i,e):new y1(a,i,e));break}else{let h=t.map[a];h===void 0&&(h=new M1(a),Yp(t,h)),t=h}}}class _l{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const a=e.getActiveUniform(t,r),c=e.getUniformLocation(t,a.name);S1(a,c,this)}const s=[],o=[];for(const r of this.seq)r.type===e.SAMPLER_2D_SHADOW||r.type===e.SAMPLER_CUBE_SHADOW||r.type===e.SAMPLER_2D_ARRAY_SHADOW?s.push(r):o.push(r);s.length>0&&(this.seq=s.concat(o))}setValue(e,t,n,s){const o=this.map[t];o!==void 0&&o.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let o=0,r=t.length;o!==r;++o){const a=t[o],c=n[a.id];c.needsUpdate!==!1&&a.setValue(e,c.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,o=e.length;s!==o;++s){const r=e[s];r.id in t&&n.push(r)}return n}}function Kp(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const b1=37297;let T1=0;function w1(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),o=Math.min(e+6,t.length);for(let r=s;r<o;r++){const a=r+1;n.push(`${a===e?">":" "} ${a}: ${t[r]}`)}return n.join(`
`)}const Zp=new Yt;function E1(i){un._getMatrix(Zp,un.workingColorSpace,i);const e=`mat3( ${Zp.elements.map(t=>t.toFixed(4))} )`;switch(un.getTransfer(i)){case Rl:return[e,"LinearTransferOETF"];case Dn:return[e,"sRGBTransferOETF"];default:return xt("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function $p(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),o=(i.getShaderInfoLog(e)||"").trim();if(n&&o==="")return"";const r=/ERROR: 0:(\d+)/.exec(o);if(r){const a=parseInt(r[1]);return t.toUpperCase()+`

`+o+`

`+w1(i.getShaderSource(e),a)}else return o}function A1(i,e){const t=E1(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const R1={[km]:"Linear",[Hm]:"Reinhard",[Gm]:"Cineon",[wd]:"ACESFilmic",[zm]:"AgX",[Wm]:"Neutral",[Vm]:"Custom"};function C1(i,e){const t=R1[e];return t===void 0?(xt("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const ul=new I;function P1(){un.getLuminanceCoefficients(ul);const i=ul.x.toFixed(4),e=ul.y.toFixed(4),t=ul.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function I1(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Fa).join(`
`)}function L1(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function D1(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const o=i.getActiveAttrib(e,s),r=o.name;let a=1;o.type===i.FLOAT_MAT2&&(a=2),o.type===i.FLOAT_MAT3&&(a=3),o.type===i.FLOAT_MAT4&&(a=4),t[r]={type:o.type,location:i.getAttribLocation(e,r),locationSize:a}}return t}function Fa(i){return i!==""}function Jp(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function jp(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const N1=/^[ \t]*#include +<([\w\d./]+)>/gm;function ed(i){return i.replace(N1,F1)}const U1=new Map;function F1(i,e){let t=nn[e];if(t===void 0){const n=U1.get(e);if(n!==void 0)t=nn[n],xt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return ed(t)}const O1=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Qp(i){return i.replace(O1,B1)}function B1(i,e,t,n){let s="";for(let o=parseInt(e);o<parseInt(t);o++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+o+" ]").replace(/UNROLLED_LOOP_INDEX/g,o);return s}function em(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const k1={[Va]:"SHADOWMAP_TYPE_PCF",[Da]:"SHADOWMAP_TYPE_VSM"};function H1(i){return k1[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const G1={[pr]:"ENVMAP_TYPE_CUBE",[ta]:"ENVMAP_TYPE_CUBE",[Vl]:"ENVMAP_TYPE_CUBE_UV"};function V1(i){return i.envMap===!1?"ENVMAP_TYPE_CUBE":G1[i.envMapMode]||"ENVMAP_TYPE_CUBE"}const z1={[ta]:"ENVMAP_MODE_REFRACTION"};function W1(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":z1[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const X1={[Td]:"ENVMAP_BLENDING_MULTIPLY",[e_]:"ENVMAP_BLENDING_MIX",[t_]:"ENVMAP_BLENDING_ADD"};function q1(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":X1[i.combine]||"ENVMAP_BLENDING_NONE"}function Y1(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function K1(i,e,t,n){const s=i.getContext(),o=t.defines;let r=t.vertexShader,a=t.fragmentShader;const c=H1(t),l=V1(t),u=W1(t),h=q1(t),d=Y1(t),f=I1(t),p=L1(o),x=s.createProgram();let m,g,M=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Fa).join(`
`),m.length>0&&(m+=`
`),g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Fa).join(`
`),g.length>0&&(g+=`
`)):(m=[em(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Fa).join(`
`),g=[em(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+u:"",t.envMap?"#define "+h:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Vs?"#define TONE_MAPPING":"",t.toneMapping!==Vs?nn.tonemapping_pars_fragment:"",t.toneMapping!==Vs?C1("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",nn.colorspace_pars_fragment,A1("linearToOutputTexel",t.outputColorSpace),P1(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Fa).join(`
`)),r=ed(r),r=Jp(r,t),r=jp(r,t),a=ed(a),a=Jp(a,t),a=jp(a,t),r=Qp(r),a=Qp(a),t.isRawShaderMaterial!==!0&&(M=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,g=["#define varying in",t.glslVersion===Gf?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Gf?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+g);const S=M+m+r,_=M+g+a,A=Kp(s,s.VERTEX_SHADER,S),E=Kp(s,s.FRAGMENT_SHADER,_);s.attachShader(x,A),s.attachShader(x,E),t.index0AttributeName!==void 0?s.bindAttribLocation(x,0,t.index0AttributeName):t.hasPositionAttribute===!0&&s.bindAttribLocation(x,0,"position"),s.linkProgram(x);function L(N){if(i.debug.checkShaderErrors){const B=s.getProgramInfoLog(x)||"",ne=s.getShaderInfoLog(A)||"",ae=s.getShaderInfoLog(E)||"",V=B.trim(),se=ne.trim(),K=ae.trim();let he=!0,me=!0;if(s.getProgramParameter(x,s.LINK_STATUS)===!1)if(he=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,x,A,E);else{const Re=$p(s,A,"vertex"),we=$p(s,E,"fragment");Lt("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(x,s.VALIDATE_STATUS)+`

Material Name: `+N.name+`
Material Type: `+N.type+`

Program Info Log: `+V+`
`+Re+`
`+we)}else V!==""?xt("WebGLProgram: Program Info Log:",V):(se===""||K==="")&&(me=!1);me&&(N.diagnostics={runnable:he,programLog:V,vertexShader:{log:se,prefix:m},fragmentShader:{log:K,prefix:g}})}s.deleteShader(A),s.deleteShader(E),v=new _l(s,x),R=D1(s,x)}let v;this.getUniforms=function(){return v===void 0&&L(this),v};let R;this.getAttributes=function(){return R===void 0&&L(this),R};let D=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return D===!1&&(D=s.getProgramParameter(x,b1)),D},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(x),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=T1++,this.cacheKey=e,this.usedTimes=1,this.program=x,this.vertexShader=A,this.fragmentShader=E,this}let Z1=0;class $1{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){const s=this._getShaderCacheForMaterial(e);return s.has(t)===!1&&(s.add(t),t.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new J1(e),t.set(e,n)),n}}class J1{constructor(e){this.id=Z1++,this.code=e,this.usedTimes=0}}function j1(i){return i===gr||i===Tl||i===wl}function Q1(i,e,t,n,s,o){const r=new Bd,a=new $1,c=new Set,l=[],u=new Map,h=n.logarithmicDepthBuffer;let d=n.precision;const f={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(v){return c.add(v),v===0?"uv":`uv${v}`}function x(v,R,D,N,B,ne){const ae=N.fog,V=B.geometry,se=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?N.environment:null,K=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap,he=e.get(v.envMap||se,K),me=he&&he.mapping===Vl?he.image.height:null,Re=f[v.type];v.precision!==null&&(d=n.getMaxPrecision(v.precision),d!==v.precision&&xt("WebGLProgram.getParameters:",v.precision,"not supported, using",d,"instead."));const we=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,Xe=we!==void 0?we.length:0;let $t=0;V.morphAttributes.position!==void 0&&($t=1),V.morphAttributes.normal!==void 0&&($t=2),V.morphAttributes.color!==void 0&&($t=3);let hn,Qt,ce,Ce;if(Re){const ot=Os[Re];hn=ot.vertexShader,Qt=ot.fragmentShader}else{hn=v.vertexShader,Qt=v.fragmentShader;const ot=a.getVertexShaderStage(v),zn=a.getFragmentShaderStage(v);a.update(v,ot,zn),ce=ot.id,Ce=zn.id}const ye=i.getRenderTarget(),ht=i.state.buffers.depth.getReversed(),Nt=B.isInstancedMesh===!0,bt=B.isBatchedMesh===!0,xn=!!v.map,Bt=!!v.matcap,pe=!!he,ve=!!v.aoMap,ge=!!v.lightMap,Be=!!v.bumpMap&&v.wireframe===!1,Fe=!!v.normalMap,Et=!!v.displacementMap,dt=!!v.emissiveMap,Ut=!!v.metalnessMap,Gt=!!v.roughnessMap,F=v.anisotropy>0,wn=v.clearcoat>0,rn=v.dispersion>0,P=v.iridescence>0,y=v.sheen>0,z=v.transmission>0,J=F&&!!v.anisotropyMap,oe=wn&&!!v.clearcoatMap,Ee=wn&&!!v.clearcoatNormalMap,Ae=wn&&!!v.clearcoatRoughnessMap,re=P&&!!v.iridescenceMap,ue=P&&!!v.iridescenceThicknessMap,Ne=y&&!!v.sheenColorMap,ft=y&&!!v.sheenRoughnessMap,Oe=!!v.specularMap,Ue=!!v.specularColorMap,vt=!!v.specularIntensityMap,Tt=z&&!!v.transmissionMap,Vt=z&&!!v.thicknessMap,k=!!v.gradientMap,Pe=!!v.alphaMap,le=v.alphaTest>0,Ie=!!v.alphaHash,ke=!!v.extensions;let fe=Vs;v.toneMapped&&(ye===null||ye.isXRRenderTarget===!0)&&(fe=i.toneMapping);const ut={shaderID:Re,shaderType:v.type,shaderName:v.name,vertexShader:hn,fragmentShader:Qt,defines:v.defines,customVertexShaderID:ce,customFragmentShaderID:Ce,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:d,batching:bt,batchingColor:bt&&B._colorsTexture!==null,instancing:Nt,instancingColor:Nt&&B.instanceColor!==null,instancingMorph:Nt&&B.morphTexture!==null,outputColorSpace:ye===null?i.outputColorSpace:ye.isXRRenderTarget===!0?ye.texture.colorSpace:un.workingColorSpace,alphaToCoverage:!!v.alphaToCoverage,map:xn,matcap:Bt,envMap:pe,envMapMode:pe&&he.mapping,envMapCubeUVHeight:me,aoMap:ve,lightMap:ge,bumpMap:Be,normalMap:Fe,displacementMap:Et,emissiveMap:dt,normalMapObjectSpace:Fe&&v.normalMapType===a_,normalMapTangentSpace:Fe&&v.normalMapType===Al,packedNormalMap:Fe&&v.normalMapType===Al&&j1(v.normalMap.format),metalnessMap:Ut,roughnessMap:Gt,anisotropy:F,anisotropyMap:J,clearcoat:wn,clearcoatMap:oe,clearcoatNormalMap:Ee,clearcoatRoughnessMap:Ae,dispersion:rn,iridescence:P,iridescenceMap:re,iridescenceThicknessMap:ue,sheen:y,sheenColorMap:Ne,sheenRoughnessMap:ft,specularMap:Oe,specularColorMap:Ue,specularIntensityMap:vt,transmission:z,transmissionMap:Tt,thicknessMap:Vt,gradientMap:k,opaque:v.transparent===!1&&v.blending===Xr&&v.alphaToCoverage===!1,alphaMap:Pe,alphaTest:le,alphaHash:Ie,combine:v.combine,mapUv:xn&&p(v.map.channel),aoMapUv:ve&&p(v.aoMap.channel),lightMapUv:ge&&p(v.lightMap.channel),bumpMapUv:Be&&p(v.bumpMap.channel),normalMapUv:Fe&&p(v.normalMap.channel),displacementMapUv:Et&&p(v.displacementMap.channel),emissiveMapUv:dt&&p(v.emissiveMap.channel),metalnessMapUv:Ut&&p(v.metalnessMap.channel),roughnessMapUv:Gt&&p(v.roughnessMap.channel),anisotropyMapUv:J&&p(v.anisotropyMap.channel),clearcoatMapUv:oe&&p(v.clearcoatMap.channel),clearcoatNormalMapUv:Ee&&p(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ae&&p(v.clearcoatRoughnessMap.channel),iridescenceMapUv:re&&p(v.iridescenceMap.channel),iridescenceThicknessMapUv:ue&&p(v.iridescenceThicknessMap.channel),sheenColorMapUv:Ne&&p(v.sheenColorMap.channel),sheenRoughnessMapUv:ft&&p(v.sheenRoughnessMap.channel),specularMapUv:Oe&&p(v.specularMap.channel),specularColorMapUv:Ue&&p(v.specularColorMap.channel),specularIntensityMapUv:vt&&p(v.specularIntensityMap.channel),transmissionMapUv:Tt&&p(v.transmissionMap.channel),thicknessMapUv:Vt&&p(v.thicknessMap.channel),alphaMapUv:Pe&&p(v.alphaMap.channel),vertexTangents:!!V.attributes.tangent&&(Fe||F),vertexNormals:!!V.attributes.normal,vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,pointsUvs:B.isPoints===!0&&!!V.attributes.uv&&(xn||Pe),fog:!!ae,useFog:v.fog===!0,fogExp2:!!ae&&ae.isFogExp2,flatShading:v.wireframe===!1&&(v.flatShading===!0||V.attributes.normal===void 0&&Fe===!1&&(v.isMeshLambertMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isMeshPhysicalMaterial)),sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:ht,skinning:B.isSkinnedMesh===!0,hasPositionAttribute:V.attributes.position!==void 0,morphTargets:V.morphAttributes.position!==void 0,morphNormals:V.morphAttributes.normal!==void 0,morphColors:V.morphAttributes.color!==void 0,morphTargetsCount:Xe,morphTextureStride:$t,numDirLights:R.directional.length,numPointLights:R.point.length,numSpotLights:R.spot.length,numSpotLightMaps:R.spotLightMap.length,numRectAreaLights:R.rectArea.length,numHemiLights:R.hemi.length,numDirLightShadows:R.directionalShadowMap.length,numPointLightShadows:R.pointShadowMap.length,numSpotLightShadows:R.spotShadowMap.length,numSpotLightShadowsWithMaps:R.numSpotLightShadowsWithMaps,numLightProbes:R.numLightProbes,numLightProbeGrids:ne.length,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:v.dithering,shadowMapEnabled:i.shadowMap.enabled&&D.length>0,shadowMapType:i.shadowMap.type,toneMapping:fe,decodeVideoTexture:xn&&v.map.isVideoTexture===!0&&un.getTransfer(v.map.colorSpace)===Dn,decodeVideoTextureEmissive:dt&&v.emissiveMap.isVideoTexture===!0&&un.getTransfer(v.emissiveMap.colorSpace)===Dn,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===xi,flipSided:v.side===Ii,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:ke&&v.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ke&&v.extensions.multiDraw===!0||bt)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return ut.vertexUv1s=c.has(1),ut.vertexUv2s=c.has(2),ut.vertexUv3s=c.has(3),c.clear(),ut}function m(v){const R=[];if(v.shaderID?R.push(v.shaderID):(R.push(v.customVertexShaderID),R.push(v.customFragmentShaderID)),v.defines!==void 0)for(const D in v.defines)R.push(D),R.push(v.defines[D]);return v.isRawShaderMaterial===!1&&(g(R,v),M(R,v),R.push(i.outputColorSpace)),R.push(v.customProgramCacheKey),R.join()}function g(v,R){v.push(R.precision),v.push(R.outputColorSpace),v.push(R.envMapMode),v.push(R.envMapCubeUVHeight),v.push(R.mapUv),v.push(R.alphaMapUv),v.push(R.lightMapUv),v.push(R.aoMapUv),v.push(R.bumpMapUv),v.push(R.normalMapUv),v.push(R.displacementMapUv),v.push(R.emissiveMapUv),v.push(R.metalnessMapUv),v.push(R.roughnessMapUv),v.push(R.anisotropyMapUv),v.push(R.clearcoatMapUv),v.push(R.clearcoatNormalMapUv),v.push(R.clearcoatRoughnessMapUv),v.push(R.iridescenceMapUv),v.push(R.iridescenceThicknessMapUv),v.push(R.sheenColorMapUv),v.push(R.sheenRoughnessMapUv),v.push(R.specularMapUv),v.push(R.specularColorMapUv),v.push(R.specularIntensityMapUv),v.push(R.transmissionMapUv),v.push(R.thicknessMapUv),v.push(R.combine),v.push(R.fogExp2),v.push(R.sizeAttenuation),v.push(R.morphTargetsCount),v.push(R.morphAttributeCount),v.push(R.numDirLights),v.push(R.numPointLights),v.push(R.numSpotLights),v.push(R.numSpotLightMaps),v.push(R.numHemiLights),v.push(R.numRectAreaLights),v.push(R.numDirLightShadows),v.push(R.numPointLightShadows),v.push(R.numSpotLightShadows),v.push(R.numSpotLightShadowsWithMaps),v.push(R.numLightProbes),v.push(R.shadowMapType),v.push(R.toneMapping),v.push(R.numClippingPlanes),v.push(R.numClipIntersection),v.push(R.depthPacking)}function M(v,R){r.disableAll(),R.instancing&&r.enable(0),R.instancingColor&&r.enable(1),R.instancingMorph&&r.enable(2),R.matcap&&r.enable(3),R.envMap&&r.enable(4),R.normalMapObjectSpace&&r.enable(5),R.normalMapTangentSpace&&r.enable(6),R.clearcoat&&r.enable(7),R.iridescence&&r.enable(8),R.alphaTest&&r.enable(9),R.vertexColors&&r.enable(10),R.vertexAlphas&&r.enable(11),R.vertexUv1s&&r.enable(12),R.vertexUv2s&&r.enable(13),R.vertexUv3s&&r.enable(14),R.vertexTangents&&r.enable(15),R.anisotropy&&r.enable(16),R.alphaHash&&r.enable(17),R.batching&&r.enable(18),R.dispersion&&r.enable(19),R.batchingColor&&r.enable(20),R.gradientMap&&r.enable(21),R.packedNormalMap&&r.enable(22),R.vertexNormals&&r.enable(23),v.push(r.mask),r.disableAll(),R.fog&&r.enable(0),R.useFog&&r.enable(1),R.flatShading&&r.enable(2),R.logarithmicDepthBuffer&&r.enable(3),R.reversedDepthBuffer&&r.enable(4),R.skinning&&r.enable(5),R.morphTargets&&r.enable(6),R.morphNormals&&r.enable(7),R.morphColors&&r.enable(8),R.premultipliedAlpha&&r.enable(9),R.shadowMapEnabled&&r.enable(10),R.doubleSided&&r.enable(11),R.flipSided&&r.enable(12),R.useDepthPacking&&r.enable(13),R.dithering&&r.enable(14),R.transmission&&r.enable(15),R.sheen&&r.enable(16),R.opaque&&r.enable(17),R.pointsUvs&&r.enable(18),R.decodeVideoTexture&&r.enable(19),R.decodeVideoTextureEmissive&&r.enable(20),R.alphaToCoverage&&r.enable(21),R.numLightProbeGrids>0&&r.enable(22),R.hasPositionAttribute&&r.enable(23),v.push(r.mask)}function S(v){const R=f[v.type];let D;if(R){const N=Os[R];D=y0.clone(N.uniforms)}else D=v.uniforms;return D}function _(v,R){let D=u.get(R);return D!==void 0?++D.usedTimes:(D=new K1(i,R,v,s),l.push(D),u.set(R,D)),D}function A(v){if(--v.usedTimes===0){const R=l.indexOf(v);l[R]=l[l.length-1],l.pop(),u.delete(v.cacheKey),v.destroy()}}function E(v){a.remove(v)}function L(){a.dispose()}return{getParameters:x,getProgramCacheKey:m,getUniforms:S,acquireProgram:_,releaseProgram:A,releaseShaderCache:E,programs:l,dispose:L}}function eT(){let i=new WeakMap;function e(r){return i.has(r)}function t(r){let a=i.get(r);return a===void 0&&(a={},i.set(r,a)),a}function n(r){i.delete(r)}function s(r,a,c){i.get(r)[a]=c}function o(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:o}}function tT(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function tm(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function nm(){const i=[];let e=0;const t=[],n=[],s=[];function o(){e=0,t.length=0,n.length=0,s.length=0}function r(d){let f=0;return d.isInstancedMesh&&(f+=2),d.isSkinnedMesh&&(f+=1),f}function a(d,f,p,x,m,g){let M=i[e];return M===void 0?(M={id:d.id,object:d,geometry:f,material:p,materialVariant:r(d),groupOrder:x,renderOrder:d.renderOrder,z:m,group:g},i[e]=M):(M.id=d.id,M.object=d,M.geometry=f,M.material=p,M.materialVariant=r(d),M.groupOrder=x,M.renderOrder=d.renderOrder,M.z=m,M.group=g),e++,M}function c(d,f,p,x,m,g){const M=a(d,f,p,x,m,g);p.transmission>0?n.push(M):p.transparent===!0?s.push(M):t.push(M)}function l(d,f,p,x,m,g){const M=a(d,f,p,x,m,g);p.transmission>0?n.unshift(M):p.transparent===!0?s.unshift(M):t.unshift(M)}function u(d,f,p){t.length>1&&t.sort(d||tT),n.length>1&&n.sort(f||tm),s.length>1&&s.sort(f||tm),p&&(t.reverse(),n.reverse(),s.reverse())}function h(){for(let d=e,f=i.length;d<f;d++){const p=i[d];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:n,transparent:s,init:o,push:c,unshift:l,finish:h,sort:u}}function nT(){let i=new WeakMap;function e(n,s){const o=i.get(n);let r;return o===void 0?(r=new nm,i.set(n,[r])):s>=o.length?(r=new nm,o.push(r)):r=o[s],r}function t(){i=new WeakMap}return{get:e,dispose:t}}function iT(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new I,color:new Qe};break;case"SpotLight":t={position:new I,direction:new I,color:new Qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new I,color:new Qe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new I,skyColor:new Qe,groundColor:new Qe};break;case"RectAreaLight":t={color:new Qe,position:new I,halfWidth:new I,halfHeight:new I};break}return i[e.id]=t,t}}}function sT(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _e};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _e};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _e,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let oT=0;function rT(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function aT(i){const e=new iT,t=sT(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new I);const s=new I,o=new Wt,r=new Wt;function a(l){let u=0,h=0,d=0;for(let R=0;R<9;R++)n.probe[R].set(0,0,0);let f=0,p=0,x=0,m=0,g=0,M=0,S=0,_=0,A=0,E=0,L=0;l.sort(rT);for(let R=0,D=l.length;R<D;R++){const N=l[R],B=N.color,ne=N.intensity,ae=N.distance;let V=null;if(N.shadow&&N.shadow.map&&(N.shadow.map.texture.format===gr?V=N.shadow.map.texture:V=N.shadow.map.depthTexture||N.shadow.map.texture),N.isAmbientLight)u+=B.r*ne,h+=B.g*ne,d+=B.b*ne;else if(N.isLightProbe){for(let se=0;se<9;se++)n.probe[se].addScaledVector(N.sh.coefficients[se],ne);L++}else if(N.isDirectionalLight){const se=e.get(N);if(se.color.copy(N.color).multiplyScalar(N.intensity),N.castShadow){const K=N.shadow,he=t.get(N);he.shadowIntensity=K.intensity,he.shadowBias=K.bias,he.shadowNormalBias=K.normalBias,he.shadowRadius=K.radius,he.shadowMapSize=K.mapSize,n.directionalShadow[f]=he,n.directionalShadowMap[f]=V,n.directionalShadowMatrix[f]=N.shadow.matrix,M++}n.directional[f]=se,f++}else if(N.isSpotLight){const se=e.get(N);se.position.setFromMatrixPosition(N.matrixWorld),se.color.copy(B).multiplyScalar(ne),se.distance=ae,se.coneCos=Math.cos(N.angle),se.penumbraCos=Math.cos(N.angle*(1-N.penumbra)),se.decay=N.decay,n.spot[x]=se;const K=N.shadow;if(N.map&&(n.spotLightMap[A]=N.map,A++,K.updateMatrices(N),N.castShadow&&E++),n.spotLightMatrix[x]=K.matrix,N.castShadow){const he=t.get(N);he.shadowIntensity=K.intensity,he.shadowBias=K.bias,he.shadowNormalBias=K.normalBias,he.shadowRadius=K.radius,he.shadowMapSize=K.mapSize,n.spotShadow[x]=he,n.spotShadowMap[x]=V,_++}x++}else if(N.isRectAreaLight){const se=e.get(N);se.color.copy(B).multiplyScalar(ne),se.halfWidth.set(N.width*.5,0,0),se.halfHeight.set(0,N.height*.5,0),n.rectArea[m]=se,m++}else if(N.isPointLight){const se=e.get(N);if(se.color.copy(N.color).multiplyScalar(N.intensity),se.distance=N.distance,se.decay=N.decay,N.castShadow){const K=N.shadow,he=t.get(N);he.shadowIntensity=K.intensity,he.shadowBias=K.bias,he.shadowNormalBias=K.normalBias,he.shadowRadius=K.radius,he.shadowMapSize=K.mapSize,he.shadowCameraNear=K.camera.near,he.shadowCameraFar=K.camera.far,n.pointShadow[p]=he,n.pointShadowMap[p]=V,n.pointShadowMatrix[p]=N.shadow.matrix,S++}n.point[p]=se,p++}else if(N.isHemisphereLight){const se=e.get(N);se.skyColor.copy(N.color).multiplyScalar(ne),se.groundColor.copy(N.groundColor).multiplyScalar(ne),n.hemi[g]=se,g++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ze.LTC_FLOAT_1,n.rectAreaLTC2=ze.LTC_FLOAT_2):(n.rectAreaLTC1=ze.LTC_HALF_1,n.rectAreaLTC2=ze.LTC_HALF_2)),n.ambient[0]=u,n.ambient[1]=h,n.ambient[2]=d;const v=n.hash;(v.directionalLength!==f||v.pointLength!==p||v.spotLength!==x||v.rectAreaLength!==m||v.hemiLength!==g||v.numDirectionalShadows!==M||v.numPointShadows!==S||v.numSpotShadows!==_||v.numSpotMaps!==A||v.numLightProbes!==L)&&(n.directional.length=f,n.spot.length=x,n.rectArea.length=m,n.point.length=p,n.hemi.length=g,n.directionalShadow.length=M,n.directionalShadowMap.length=M,n.pointShadow.length=S,n.pointShadowMap.length=S,n.spotShadow.length=_,n.spotShadowMap.length=_,n.directionalShadowMatrix.length=M,n.pointShadowMatrix.length=S,n.spotLightMatrix.length=_+A-E,n.spotLightMap.length=A,n.numSpotLightShadowsWithMaps=E,n.numLightProbes=L,v.directionalLength=f,v.pointLength=p,v.spotLength=x,v.rectAreaLength=m,v.hemiLength=g,v.numDirectionalShadows=M,v.numPointShadows=S,v.numSpotShadows=_,v.numSpotMaps=A,v.numLightProbes=L,n.version=oT++)}function c(l,u){let h=0,d=0,f=0,p=0,x=0;const m=u.matrixWorldInverse;for(let g=0,M=l.length;g<M;g++){const S=l[g];if(S.isDirectionalLight){const _=n.directional[h];_.direction.setFromMatrixPosition(S.matrixWorld),s.setFromMatrixPosition(S.target.matrixWorld),_.direction.sub(s),_.direction.transformDirection(m),h++}else if(S.isSpotLight){const _=n.spot[f];_.position.setFromMatrixPosition(S.matrixWorld),_.position.applyMatrix4(m),_.direction.setFromMatrixPosition(S.matrixWorld),s.setFromMatrixPosition(S.target.matrixWorld),_.direction.sub(s),_.direction.transformDirection(m),f++}else if(S.isRectAreaLight){const _=n.rectArea[p];_.position.setFromMatrixPosition(S.matrixWorld),_.position.applyMatrix4(m),r.identity(),o.copy(S.matrixWorld),o.premultiply(m),r.extractRotation(o),_.halfWidth.set(S.width*.5,0,0),_.halfHeight.set(0,S.height*.5,0),_.halfWidth.applyMatrix4(r),_.halfHeight.applyMatrix4(r),p++}else if(S.isPointLight){const _=n.point[d];_.position.setFromMatrixPosition(S.matrixWorld),_.position.applyMatrix4(m),d++}else if(S.isHemisphereLight){const _=n.hemi[x];_.direction.setFromMatrixPosition(S.matrixWorld),_.direction.transformDirection(m),x++}}}return{setup:a,setupView:c,state:n}}function im(i){const e=new aT(i),t=[],n=[],s=[];function o(d){h.camera=d,t.length=0,n.length=0,s.length=0}function r(d){t.push(d)}function a(d){n.push(d)}function c(d){s.push(d)}function l(){e.setup(t)}function u(d){e.setupView(t,d)}const h={lightsArray:t,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:o,state:h,setupLights:l,setupLightsView:u,pushLight:r,pushShadow:a,pushLightProbeGrid:c}}function cT(i){let e=new WeakMap;function t(s,o=0){const r=e.get(s);let a;return r===void 0?(a=new im(i),e.set(s,[a])):o>=r.length?(a=new im(i),r.push(a)):a=r[o],a}function n(){e=new WeakMap}return{get:t,dispose:n}}const lT=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,uT=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,hT=[new I(1,0,0),new I(-1,0,0),new I(0,1,0),new I(0,-1,0),new I(0,0,1),new I(0,0,-1)],dT=[new I(0,-1,0),new I(0,-1,0),new I(0,0,1),new I(0,0,-1),new I(0,-1,0),new I(0,-1,0)],sm=new Wt,Ia=new I,Xu=new I;function fT(i,e,t){let n=new Gd;const s=new _e,o=new _e,r=new Bn,a=new Yv,c=new Kv,l={},u=t.maxTextureSize,h={[Mo]:Ii,[Ii]:Mo,[xi]:xi},d=new hs({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new _e},radius:{value:4}},vertexShader:lT,fragmentShader:uT}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const p=new Tn;p.setAttribute("position",new Li(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const x=new W(p,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Va;let g=this.type;this.render=function(E,L,v){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;this.type===Ux&&(xt("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=Va);const R=i.getRenderTarget(),D=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),B=i.state;B.setBlending(po),B.buffers.depth.getReversed()===!0?B.buffers.color.setClear(0,0,0,0):B.buffers.color.setClear(1,1,1,1),B.buffers.depth.setTest(!0),B.setScissorTest(!1);const ne=g!==this.type;ne&&L.traverse(function(ae){ae.material&&(Array.isArray(ae.material)?ae.material.forEach(V=>V.needsUpdate=!0):ae.material.needsUpdate=!0)});for(let ae=0,V=E.length;ae<V;ae++){const se=E[ae],K=se.shadow;if(K===void 0){xt("WebGLShadowMap:",se,"has no shadow.");continue}if(K.autoUpdate===!1&&K.needsUpdate===!1)continue;s.copy(K.mapSize);const he=K.getFrameExtents();s.multiply(he),o.copy(K.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(o.x=Math.floor(u/he.x),s.x=o.x*he.x,K.mapSize.x=o.x),s.y>u&&(o.y=Math.floor(u/he.y),s.y=o.y*he.y,K.mapSize.y=o.y));const me=i.state.buffers.depth.getReversed();if(K.camera._reversedDepth=me,K.map===null||ne===!0){if(K.map!==null&&(K.map.depthTexture!==null&&(K.map.depthTexture.dispose(),K.map.depthTexture=null),K.map.dispose()),this.type===Da){if(se.isPointLight){xt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}K.map=new zs(s.x,s.y,{format:gr,type:So,minFilter:mi,magFilter:mi,generateMipmaps:!1}),K.map.texture.name=se.name+".shadowMap",K.map.depthTexture=new ia(s.x,s.y,cs),K.map.depthTexture.name=se.name+".shadowMapDepth",K.map.depthTexture.format=bo,K.map.depthTexture.compareFunction=null,K.map.depthTexture.minFilter=vi,K.map.depthTexture.magFilter=vi}else se.isPointLight?(K.map=new C0(s.x),K.map.depthTexture=new uv(s.x,Xs)):(K.map=new zs(s.x,s.y),K.map.depthTexture=new ia(s.x,s.y,Xs)),K.map.depthTexture.name=se.name+".shadowMap",K.map.depthTexture.format=bo,this.type===Va?(K.map.depthTexture.compareFunction=me?Ud:Nd,K.map.depthTexture.minFilter=mi,K.map.depthTexture.magFilter=mi):(K.map.depthTexture.compareFunction=null,K.map.depthTexture.minFilter=vi,K.map.depthTexture.magFilter=vi);K.camera.updateProjectionMatrix()}const Re=K.map.isWebGLCubeRenderTarget?6:1;for(let we=0;we<Re;we++){if(K.map.isWebGLCubeRenderTarget)i.setRenderTarget(K.map,we),i.clear();else{we===0&&(i.setRenderTarget(K.map),i.clear());const Xe=K.getViewport(we);r.set(o.x*Xe.x,o.y*Xe.y,o.x*Xe.z,o.y*Xe.w),B.viewport(r)}if(se.isPointLight){const Xe=K.camera,$t=K.matrix,hn=se.distance||Xe.far;hn!==Xe.far&&(Xe.far=hn,Xe.updateProjectionMatrix()),Ia.setFromMatrixPosition(se.matrixWorld),Xe.position.copy(Ia),Xu.copy(Xe.position),Xu.add(hT[we]),Xe.up.copy(dT[we]),Xe.lookAt(Xu),Xe.updateMatrixWorld(),$t.makeTranslation(-Ia.x,-Ia.y,-Ia.z),sm.multiplyMatrices(Xe.projectionMatrix,Xe.matrixWorldInverse),K._frustum.setFromProjectionMatrix(sm,Xe.coordinateSystem,Xe.reversedDepth)}else K.updateMatrices(se);n=K.getFrustum(),_(L,v,K.camera,se,this.type)}K.isPointLightShadow!==!0&&this.type===Da&&M(K,v),K.needsUpdate=!1}g=this.type,m.needsUpdate=!1,i.setRenderTarget(R,D,N)};function M(E,L){const v=e.update(x);d.defines.VSM_SAMPLES!==E.blurSamples&&(d.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new zs(s.x,s.y,{format:gr,type:So})),d.uniforms.shadow_pass.value=E.map.depthTexture,d.uniforms.resolution.value=E.mapSize,d.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(L,null,v,d,x,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(L,null,v,f,x,null)}function S(E,L,v,R){let D=null;const N=v.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(N!==void 0)D=N;else if(D=v.isPointLight===!0?c:a,i.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0||L.alphaToCoverage===!0){const B=D.uuid,ne=L.uuid;let ae=l[B];ae===void 0&&(ae={},l[B]=ae);let V=ae[ne];V===void 0&&(V=D.clone(),ae[ne]=V,L.addEventListener("dispose",A)),D=V}if(D.visible=L.visible,D.wireframe=L.wireframe,R===Da?D.side=L.shadowSide!==null?L.shadowSide:L.side:D.side=L.shadowSide!==null?L.shadowSide:h[L.side],D.alphaMap=L.alphaMap,D.alphaTest=L.alphaToCoverage===!0?.5:L.alphaTest,D.map=L.map,D.clipShadows=L.clipShadows,D.clippingPlanes=L.clippingPlanes,D.clipIntersection=L.clipIntersection,D.displacementMap=L.displacementMap,D.displacementScale=L.displacementScale,D.displacementBias=L.displacementBias,D.wireframeLinewidth=L.wireframeLinewidth,D.linewidth=L.linewidth,v.isPointLight===!0&&D.isMeshDistanceMaterial===!0){const B=i.properties.get(D);B.light=v}return D}function _(E,L,v,R,D){if(E.visible===!1)return;if(E.layers.test(L.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&D===Da)&&(!E.frustumCulled||n.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(v.matrixWorldInverse,E.matrixWorld);const ne=e.update(E),ae=E.material;if(Array.isArray(ae)){const V=ne.groups;for(let se=0,K=V.length;se<K;se++){const he=V[se],me=ae[he.materialIndex];if(me&&me.visible){const Re=S(E,me,R,D);E.onBeforeShadow(i,E,L,v,ne,Re,he),i.renderBufferDirect(v,null,ne,Re,E,he),E.onAfterShadow(i,E,L,v,ne,Re,he)}}}else if(ae.visible){const V=S(E,ae,R,D);E.onBeforeShadow(i,E,L,v,ne,V,null),i.renderBufferDirect(v,null,ne,V,E,null),E.onAfterShadow(i,E,L,v,ne,V,null)}}const B=E.children;for(let ne=0,ae=B.length;ne<ae;ne++)_(B[ne],L,v,R,D)}function A(E){E.target.removeEventListener("dispose",A);for(const v in l){const R=l[v],D=E.target.uuid;D in R&&(R[D].dispose(),delete R[D])}}}function pT(i,e){function t(){let k=!1;const Pe=new Bn;let le=null;const Ie=new Bn(0,0,0,0);return{setMask:function(ke){le!==ke&&!k&&(i.colorMask(ke,ke,ke,ke),le=ke)},setLocked:function(ke){k=ke},setClear:function(ke,fe,ut,ot,zn){zn===!0&&(ke*=ot,fe*=ot,ut*=ot),Pe.set(ke,fe,ut,ot),Ie.equals(Pe)===!1&&(i.clearColor(ke,fe,ut,ot),Ie.copy(Pe))},reset:function(){k=!1,le=null,Ie.set(-1,0,0,0)}}}function n(){let k=!1,Pe=!1,le=null,Ie=null,ke=null;return{setReversed:function(fe){if(Pe!==fe){const ut=e.get("EXT_clip_control");fe?ut.clipControlEXT(ut.LOWER_LEFT_EXT,ut.ZERO_TO_ONE_EXT):ut.clipControlEXT(ut.LOWER_LEFT_EXT,ut.NEGATIVE_ONE_TO_ONE_EXT),Pe=fe;const ot=ke;ke=null,this.setClear(ot)}},getReversed:function(){return Pe},setTest:function(fe){fe?ye(i.DEPTH_TEST):ht(i.DEPTH_TEST)},setMask:function(fe){le!==fe&&!k&&(i.depthMask(fe),le=fe)},setFunc:function(fe){if(Pe&&(fe=__[fe]),Ie!==fe){switch(fe){case ah:i.depthFunc(i.NEVER);break;case ch:i.depthFunc(i.ALWAYS);break;case lh:i.depthFunc(i.LESS);break;case ea:i.depthFunc(i.LEQUAL);break;case uh:i.depthFunc(i.EQUAL);break;case hh:i.depthFunc(i.GEQUAL);break;case dh:i.depthFunc(i.GREATER);break;case fh:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Ie=fe}},setLocked:function(fe){k=fe},setClear:function(fe){ke!==fe&&(ke=fe,Pe&&(fe=1-fe),i.clearDepth(fe))},reset:function(){k=!1,le=null,Ie=null,ke=null,Pe=!1}}}function s(){let k=!1,Pe=null,le=null,Ie=null,ke=null,fe=null,ut=null,ot=null,zn=null;return{setTest:function(Fn){k||(Fn?ye(i.STENCIL_TEST):ht(i.STENCIL_TEST))},setMask:function(Fn){Pe!==Fn&&!k&&(i.stencilMask(Fn),Pe=Fn)},setFunc:function(Fn,Hi,Gi){(le!==Fn||Ie!==Hi||ke!==Gi)&&(i.stencilFunc(Fn,Hi,Gi),le=Fn,Ie=Hi,ke=Gi)},setOp:function(Fn,Hi,Gi){(fe!==Fn||ut!==Hi||ot!==Gi)&&(i.stencilOp(Fn,Hi,Gi),fe=Fn,ut=Hi,ot=Gi)},setLocked:function(Fn){k=Fn},setClear:function(Fn){zn!==Fn&&(i.clearStencil(Fn),zn=Fn)},reset:function(){k=!1,Pe=null,le=null,Ie=null,ke=null,fe=null,ut=null,ot=null,zn=null}}}const o=new t,r=new n,a=new s,c=new WeakMap,l=new WeakMap;let u={},h={},d={},f=new WeakMap,p=[],x=null,m=!1,g=null,M=null,S=null,_=null,A=null,E=null,L=null,v=new Qe(0,0,0),R=0,D=!1,N=null,B=null,ne=null,ae=null,V=null;const se=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let K=!1,he=0;const me=i.getParameter(i.VERSION);me.indexOf("WebGL")!==-1?(he=parseFloat(/^WebGL (\d)/.exec(me)[1]),K=he>=1):me.indexOf("OpenGL ES")!==-1&&(he=parseFloat(/^OpenGL ES (\d)/.exec(me)[1]),K=he>=2);let Re=null,we={};const Xe=i.getParameter(i.SCISSOR_BOX),$t=i.getParameter(i.VIEWPORT),hn=new Bn().fromArray(Xe),Qt=new Bn().fromArray($t);function ce(k,Pe,le,Ie){const ke=new Uint8Array(4),fe=i.createTexture();i.bindTexture(k,fe),i.texParameteri(k,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(k,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let ut=0;ut<le;ut++)k===i.TEXTURE_3D||k===i.TEXTURE_2D_ARRAY?i.texImage3D(Pe,0,i.RGBA,1,1,Ie,0,i.RGBA,i.UNSIGNED_BYTE,ke):i.texImage2D(Pe+ut,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ke);return fe}const Ce={};Ce[i.TEXTURE_2D]=ce(i.TEXTURE_2D,i.TEXTURE_2D,1),Ce[i.TEXTURE_CUBE_MAP]=ce(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Ce[i.TEXTURE_2D_ARRAY]=ce(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Ce[i.TEXTURE_3D]=ce(i.TEXTURE_3D,i.TEXTURE_3D,1,1),o.setClear(0,0,0,1),r.setClear(1),a.setClear(0),ye(i.DEPTH_TEST),r.setFunc(ea),Be(!1),Fe(Uf),ye(i.CULL_FACE),ve(po);function ye(k){u[k]!==!0&&(i.enable(k),u[k]=!0)}function ht(k){u[k]!==!1&&(i.disable(k),u[k]=!1)}function Nt(k,Pe){return d[k]!==Pe?(i.bindFramebuffer(k,Pe),d[k]=Pe,k===i.DRAW_FRAMEBUFFER&&(d[i.FRAMEBUFFER]=Pe),k===i.FRAMEBUFFER&&(d[i.DRAW_FRAMEBUFFER]=Pe),!0):!1}function bt(k,Pe){let le=p,Ie=!1;if(k){le=f.get(Pe),le===void 0&&(le=[],f.set(Pe,le));const ke=k.textures;if(le.length!==ke.length||le[0]!==i.COLOR_ATTACHMENT0){for(let fe=0,ut=ke.length;fe<ut;fe++)le[fe]=i.COLOR_ATTACHMENT0+fe;le.length=ke.length,Ie=!0}}else le[0]!==i.BACK&&(le[0]=i.BACK,Ie=!0);Ie&&i.drawBuffers(le)}function xn(k){return x!==k?(i.useProgram(k),x=k,!0):!1}const Bt={[nr]:i.FUNC_ADD,[Ox]:i.FUNC_SUBTRACT,[Bx]:i.FUNC_REVERSE_SUBTRACT};Bt[kx]=i.MIN,Bt[Hx]=i.MAX;const pe={[Gx]:i.ZERO,[Vx]:i.ONE,[zx]:i.SRC_COLOR,[oh]:i.SRC_ALPHA,[Zx]:i.SRC_ALPHA_SATURATE,[Yx]:i.DST_COLOR,[Xx]:i.DST_ALPHA,[Wx]:i.ONE_MINUS_SRC_COLOR,[rh]:i.ONE_MINUS_SRC_ALPHA,[Kx]:i.ONE_MINUS_DST_COLOR,[qx]:i.ONE_MINUS_DST_ALPHA,[$x]:i.CONSTANT_COLOR,[Jx]:i.ONE_MINUS_CONSTANT_COLOR,[jx]:i.CONSTANT_ALPHA,[Qx]:i.ONE_MINUS_CONSTANT_ALPHA};function ve(k,Pe,le,Ie,ke,fe,ut,ot,zn,Fn){if(k===po){m===!0&&(ht(i.BLEND),m=!1);return}if(m===!1&&(ye(i.BLEND),m=!0),k!==Fx){if(k!==g||Fn!==D){if((M!==nr||A!==nr)&&(i.blendEquation(i.FUNC_ADD),M=nr,A=nr),Fn)switch(k){case Xr:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Ci:i.blendFunc(i.ONE,i.ONE);break;case Ff:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Of:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:Lt("WebGLState: Invalid blending: ",k);break}else switch(k){case Xr:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Ci:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Ff:Lt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Of:Lt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Lt("WebGLState: Invalid blending: ",k);break}S=null,_=null,E=null,L=null,v.set(0,0,0),R=0,g=k,D=Fn}return}ke=ke||Pe,fe=fe||le,ut=ut||Ie,(Pe!==M||ke!==A)&&(i.blendEquationSeparate(Bt[Pe],Bt[ke]),M=Pe,A=ke),(le!==S||Ie!==_||fe!==E||ut!==L)&&(i.blendFuncSeparate(pe[le],pe[Ie],pe[fe],pe[ut]),S=le,_=Ie,E=fe,L=ut),(ot.equals(v)===!1||zn!==R)&&(i.blendColor(ot.r,ot.g,ot.b,zn),v.copy(ot),R=zn),g=k,D=!1}function ge(k,Pe){k.side===xi?ht(i.CULL_FACE):ye(i.CULL_FACE);let le=k.side===Ii;Pe&&(le=!le),Be(le),k.blending===Xr&&k.transparent===!1?ve(po):ve(k.blending,k.blendEquation,k.blendSrc,k.blendDst,k.blendEquationAlpha,k.blendSrcAlpha,k.blendDstAlpha,k.blendColor,k.blendAlpha,k.premultipliedAlpha),r.setFunc(k.depthFunc),r.setTest(k.depthTest),r.setMask(k.depthWrite),o.setMask(k.colorWrite);const Ie=k.stencilWrite;a.setTest(Ie),Ie&&(a.setMask(k.stencilWriteMask),a.setFunc(k.stencilFunc,k.stencilRef,k.stencilFuncMask),a.setOp(k.stencilFail,k.stencilZFail,k.stencilZPass)),dt(k.polygonOffset,k.polygonOffsetFactor,k.polygonOffsetUnits),k.alphaToCoverage===!0?ye(i.SAMPLE_ALPHA_TO_COVERAGE):ht(i.SAMPLE_ALPHA_TO_COVERAGE)}function Be(k){N!==k&&(k?i.frontFace(i.CW):i.frontFace(i.CCW),N=k)}function Fe(k){k!==Dx?(ye(i.CULL_FACE),k!==B&&(k===Uf?i.cullFace(i.BACK):k===Nx?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):ht(i.CULL_FACE),B=k}function Et(k){k!==ne&&(K&&i.lineWidth(k),ne=k)}function dt(k,Pe,le){k?(ye(i.POLYGON_OFFSET_FILL),(ae!==Pe||V!==le)&&(ae=Pe,V=le,r.getReversed()&&(Pe=-Pe),i.polygonOffset(Pe,le))):ht(i.POLYGON_OFFSET_FILL)}function Ut(k){k?ye(i.SCISSOR_TEST):ht(i.SCISSOR_TEST)}function Gt(k){k===void 0&&(k=i.TEXTURE0+se-1),Re!==k&&(i.activeTexture(k),Re=k)}function F(k,Pe,le){le===void 0&&(Re===null?le=i.TEXTURE0+se-1:le=Re);let Ie=we[le];Ie===void 0&&(Ie={type:void 0,texture:void 0},we[le]=Ie),(Ie.type!==k||Ie.texture!==Pe)&&(Re!==le&&(i.activeTexture(le),Re=le),i.bindTexture(k,Pe||Ce[k]),Ie.type=k,Ie.texture=Pe)}function wn(){const k=we[Re];k!==void 0&&k.type!==void 0&&(i.bindTexture(k.type,null),k.type=void 0,k.texture=void 0)}function rn(){try{i.compressedTexImage2D(...arguments)}catch(k){Lt("WebGLState:",k)}}function P(){try{i.compressedTexImage3D(...arguments)}catch(k){Lt("WebGLState:",k)}}function y(){try{i.texSubImage2D(...arguments)}catch(k){Lt("WebGLState:",k)}}function z(){try{i.texSubImage3D(...arguments)}catch(k){Lt("WebGLState:",k)}}function J(){try{i.compressedTexSubImage2D(...arguments)}catch(k){Lt("WebGLState:",k)}}function oe(){try{i.compressedTexSubImage3D(...arguments)}catch(k){Lt("WebGLState:",k)}}function Ee(){try{i.texStorage2D(...arguments)}catch(k){Lt("WebGLState:",k)}}function Ae(){try{i.texStorage3D(...arguments)}catch(k){Lt("WebGLState:",k)}}function re(){try{i.texImage2D(...arguments)}catch(k){Lt("WebGLState:",k)}}function ue(){try{i.texImage3D(...arguments)}catch(k){Lt("WebGLState:",k)}}function Ne(k){return h[k]!==void 0?h[k]:i.getParameter(k)}function ft(k,Pe){h[k]!==Pe&&(i.pixelStorei(k,Pe),h[k]=Pe)}function Oe(k){hn.equals(k)===!1&&(i.scissor(k.x,k.y,k.z,k.w),hn.copy(k))}function Ue(k){Qt.equals(k)===!1&&(i.viewport(k.x,k.y,k.z,k.w),Qt.copy(k))}function vt(k,Pe){let le=l.get(Pe);le===void 0&&(le=new WeakMap,l.set(Pe,le));let Ie=le.get(k);Ie===void 0&&(Ie=i.getUniformBlockIndex(Pe,k.name),le.set(k,Ie))}function Tt(k,Pe){const Ie=l.get(Pe).get(k);c.get(Pe)!==Ie&&(i.uniformBlockBinding(Pe,Ie,k.__bindingPointIndex),c.set(Pe,Ie))}function Vt(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),r.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),u={},h={},Re=null,we={},d={},f=new WeakMap,p=[],x=null,m=!1,g=null,M=null,S=null,_=null,A=null,E=null,L=null,v=new Qe(0,0,0),R=0,D=!1,N=null,B=null,ne=null,ae=null,V=null,hn.set(0,0,i.canvas.width,i.canvas.height),Qt.set(0,0,i.canvas.width,i.canvas.height),o.reset(),r.reset(),a.reset()}return{buffers:{color:o,depth:r,stencil:a},enable:ye,disable:ht,bindFramebuffer:Nt,drawBuffers:bt,useProgram:xn,setBlending:ve,setMaterial:ge,setFlipSided:Be,setCullFace:Fe,setLineWidth:Et,setPolygonOffset:dt,setScissorTest:Ut,activeTexture:Gt,bindTexture:F,unbindTexture:wn,compressedTexImage2D:rn,compressedTexImage3D:P,texImage2D:re,texImage3D:ue,pixelStorei:ft,getParameter:Ne,updateUBOMapping:vt,uniformBlockBinding:Tt,texStorage2D:Ee,texStorage3D:Ae,texSubImage2D:y,texSubImage3D:z,compressedTexSubImage2D:J,compressedTexSubImage3D:oe,scissor:Oe,viewport:Ue,reset:Vt}}function mT(i,e,t,n,s,o,r){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new _e,u=new WeakMap,h=new Set;let d;const f=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function x(P,y){return p?new OffscreenCanvas(P,y):cc("canvas")}function m(P,y,z){let J=1;const oe=rn(P);if((oe.width>z||oe.height>z)&&(J=z/Math.max(oe.width,oe.height)),J<1)if(typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&P instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&P instanceof ImageBitmap||typeof VideoFrame<"u"&&P instanceof VideoFrame){const Ee=Math.floor(J*oe.width),Ae=Math.floor(J*oe.height);d===void 0&&(d=x(Ee,Ae));const re=y?x(Ee,Ae):d;return re.width=Ee,re.height=Ae,re.getContext("2d").drawImage(P,0,0,Ee,Ae),xt("WebGLRenderer: Texture has been resized from ("+oe.width+"x"+oe.height+") to ("+Ee+"x"+Ae+")."),re}else return"data"in P&&xt("WebGLRenderer: Image in DataTexture is too big ("+oe.width+"x"+oe.height+")."),P;return P}function g(P){return P.generateMipmaps}function M(P){i.generateMipmap(P)}function S(P){return P.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:P.isWebGL3DRenderTarget?i.TEXTURE_3D:P.isWebGLArrayRenderTarget||P.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function _(P,y,z,J,oe,Ee=!1){if(P!==null){if(i[P]!==void 0)return i[P];xt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+P+"'")}let Ae;J&&(Ae=e.get("EXT_texture_norm16"),Ae||xt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let re=y;if(y===i.RED&&(z===i.FLOAT&&(re=i.R32F),z===i.HALF_FLOAT&&(re=i.R16F),z===i.UNSIGNED_BYTE&&(re=i.R8),z===i.UNSIGNED_SHORT&&Ae&&(re=Ae.R16_EXT),z===i.SHORT&&Ae&&(re=Ae.R16_SNORM_EXT)),y===i.RED_INTEGER&&(z===i.UNSIGNED_BYTE&&(re=i.R8UI),z===i.UNSIGNED_SHORT&&(re=i.R16UI),z===i.UNSIGNED_INT&&(re=i.R32UI),z===i.BYTE&&(re=i.R8I),z===i.SHORT&&(re=i.R16I),z===i.INT&&(re=i.R32I)),y===i.RG&&(z===i.FLOAT&&(re=i.RG32F),z===i.HALF_FLOAT&&(re=i.RG16F),z===i.UNSIGNED_BYTE&&(re=i.RG8),z===i.UNSIGNED_SHORT&&Ae&&(re=Ae.RG16_EXT),z===i.SHORT&&Ae&&(re=Ae.RG16_SNORM_EXT)),y===i.RG_INTEGER&&(z===i.UNSIGNED_BYTE&&(re=i.RG8UI),z===i.UNSIGNED_SHORT&&(re=i.RG16UI),z===i.UNSIGNED_INT&&(re=i.RG32UI),z===i.BYTE&&(re=i.RG8I),z===i.SHORT&&(re=i.RG16I),z===i.INT&&(re=i.RG32I)),y===i.RGB_INTEGER&&(z===i.UNSIGNED_BYTE&&(re=i.RGB8UI),z===i.UNSIGNED_SHORT&&(re=i.RGB16UI),z===i.UNSIGNED_INT&&(re=i.RGB32UI),z===i.BYTE&&(re=i.RGB8I),z===i.SHORT&&(re=i.RGB16I),z===i.INT&&(re=i.RGB32I)),y===i.RGBA_INTEGER&&(z===i.UNSIGNED_BYTE&&(re=i.RGBA8UI),z===i.UNSIGNED_SHORT&&(re=i.RGBA16UI),z===i.UNSIGNED_INT&&(re=i.RGBA32UI),z===i.BYTE&&(re=i.RGBA8I),z===i.SHORT&&(re=i.RGBA16I),z===i.INT&&(re=i.RGBA32I)),y===i.RGB&&(z===i.UNSIGNED_SHORT&&Ae&&(re=Ae.RGB16_EXT),z===i.SHORT&&Ae&&(re=Ae.RGB16_SNORM_EXT),z===i.UNSIGNED_INT_5_9_9_9_REV&&(re=i.RGB9_E5),z===i.UNSIGNED_INT_10F_11F_11F_REV&&(re=i.R11F_G11F_B10F)),y===i.RGBA){const ue=Ee?Rl:un.getTransfer(oe);z===i.FLOAT&&(re=i.RGBA32F),z===i.HALF_FLOAT&&(re=i.RGBA16F),z===i.UNSIGNED_BYTE&&(re=ue===Dn?i.SRGB8_ALPHA8:i.RGBA8),z===i.UNSIGNED_SHORT&&Ae&&(re=Ae.RGBA16_EXT),z===i.SHORT&&Ae&&(re=Ae.RGBA16_SNORM_EXT),z===i.UNSIGNED_SHORT_4_4_4_4&&(re=i.RGBA4),z===i.UNSIGNED_SHORT_5_5_5_1&&(re=i.RGB5_A1)}return(re===i.R16F||re===i.R32F||re===i.RG16F||re===i.RG32F||re===i.RGBA16F||re===i.RGBA32F)&&e.get("EXT_color_buffer_float"),re}function A(P,y){let z;return P?y===null||y===Xs||y===sc?z=i.DEPTH24_STENCIL8:y===cs?z=i.DEPTH32F_STENCIL8:y===ic&&(z=i.DEPTH24_STENCIL8,xt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):y===null||y===Xs||y===sc?z=i.DEPTH_COMPONENT24:y===cs?z=i.DEPTH_COMPONENT32F:y===ic&&(z=i.DEPTH_COMPONENT16),z}function E(P,y){return g(P)===!0||P.isFramebufferTexture&&P.minFilter!==vi&&P.minFilter!==mi?Math.log2(Math.max(y.width,y.height))+1:P.mipmaps!==void 0&&P.mipmaps.length>0?P.mipmaps.length:P.isCompressedTexture&&Array.isArray(P.image)?y.mipmaps.length:1}function L(P){const y=P.target;y.removeEventListener("dispose",L),R(y),y.isVideoTexture&&u.delete(y),y.isHTMLTexture&&h.delete(y)}function v(P){const y=P.target;y.removeEventListener("dispose",v),N(y)}function R(P){const y=n.get(P);if(y.__webglInit===void 0)return;const z=P.source,J=f.get(z);if(J){const oe=J[y.__cacheKey];oe.usedTimes--,oe.usedTimes===0&&D(P),Object.keys(J).length===0&&f.delete(z)}n.remove(P)}function D(P){const y=n.get(P);i.deleteTexture(y.__webglTexture);const z=P.source,J=f.get(z);delete J[y.__cacheKey],r.memory.textures--}function N(P){const y=n.get(P);if(P.depthTexture&&(P.depthTexture.dispose(),n.remove(P.depthTexture)),P.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(y.__webglFramebuffer[J]))for(let oe=0;oe<y.__webglFramebuffer[J].length;oe++)i.deleteFramebuffer(y.__webglFramebuffer[J][oe]);else i.deleteFramebuffer(y.__webglFramebuffer[J]);y.__webglDepthbuffer&&i.deleteRenderbuffer(y.__webglDepthbuffer[J])}else{if(Array.isArray(y.__webglFramebuffer))for(let J=0;J<y.__webglFramebuffer.length;J++)i.deleteFramebuffer(y.__webglFramebuffer[J]);else i.deleteFramebuffer(y.__webglFramebuffer);if(y.__webglDepthbuffer&&i.deleteRenderbuffer(y.__webglDepthbuffer),y.__webglMultisampledFramebuffer&&i.deleteFramebuffer(y.__webglMultisampledFramebuffer),y.__webglColorRenderbuffer)for(let J=0;J<y.__webglColorRenderbuffer.length;J++)y.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(y.__webglColorRenderbuffer[J]);y.__webglDepthRenderbuffer&&i.deleteRenderbuffer(y.__webglDepthRenderbuffer)}const z=P.textures;for(let J=0,oe=z.length;J<oe;J++){const Ee=n.get(z[J]);Ee.__webglTexture&&(i.deleteTexture(Ee.__webglTexture),r.memory.textures--),n.remove(z[J])}n.remove(P)}let B=0;function ne(){B=0}function ae(){return B}function V(P){B=P}function se(){const P=B;return P>=s.maxTextures&&xt("WebGLTextures: Trying to use "+P+" texture units while this GPU supports only "+s.maxTextures),B+=1,P}function K(P){const y=[];return y.push(P.wrapS),y.push(P.wrapT),y.push(P.wrapR||0),y.push(P.magFilter),y.push(P.minFilter),y.push(P.anisotropy),y.push(P.internalFormat),y.push(P.format),y.push(P.type),y.push(P.generateMipmaps),y.push(P.premultiplyAlpha),y.push(P.flipY),y.push(P.unpackAlignment),y.push(P.colorSpace),y.join()}function he(P,y){const z=n.get(P);if(P.isVideoTexture&&F(P),P.isRenderTargetTexture===!1&&P.isExternalTexture!==!0&&P.version>0&&z.__version!==P.version){const J=P.image;if(J===null)xt("WebGLRenderer: Texture marked for update but no image data found.");else if(J.complete===!1)xt("WebGLRenderer: Texture marked for update but image is incomplete");else{ht(z,P,y);return}}else P.isExternalTexture&&(z.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,z.__webglTexture,i.TEXTURE0+y)}function me(P,y){const z=n.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&z.__version!==P.version){ht(z,P,y);return}else P.isExternalTexture&&(z.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,z.__webglTexture,i.TEXTURE0+y)}function Re(P,y){const z=n.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&z.__version!==P.version){ht(z,P,y);return}t.bindTexture(i.TEXTURE_3D,z.__webglTexture,i.TEXTURE0+y)}function we(P,y){const z=n.get(P);if(P.isCubeDepthTexture!==!0&&P.version>0&&z.__version!==P.version){Nt(z,P,y);return}t.bindTexture(i.TEXTURE_CUBE_MAP,z.__webglTexture,i.TEXTURE0+y)}const Xe={[mr]:i.REPEAT,[ks]:i.CLAMP_TO_EDGE,[bl]:i.MIRRORED_REPEAT},$t={[vi]:i.NEAREST,[qm]:i.NEAREST_MIPMAP_NEAREST,[Na]:i.NEAREST_MIPMAP_LINEAR,[mi]:i.LINEAR,[fl]:i.LINEAR_MIPMAP_NEAREST,[Hs]:i.LINEAR_MIPMAP_LINEAR},hn={[c_]:i.NEVER,[f_]:i.ALWAYS,[l_]:i.LESS,[Nd]:i.LEQUAL,[u_]:i.EQUAL,[Ud]:i.GEQUAL,[h_]:i.GREATER,[d_]:i.NOTEQUAL};function Qt(P,y){if(y.type===cs&&e.has("OES_texture_float_linear")===!1&&(y.magFilter===mi||y.magFilter===fl||y.magFilter===Na||y.magFilter===Hs||y.minFilter===mi||y.minFilter===fl||y.minFilter===Na||y.minFilter===Hs)&&xt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(P,i.TEXTURE_WRAP_S,Xe[y.wrapS]),i.texParameteri(P,i.TEXTURE_WRAP_T,Xe[y.wrapT]),(P===i.TEXTURE_3D||P===i.TEXTURE_2D_ARRAY)&&i.texParameteri(P,i.TEXTURE_WRAP_R,Xe[y.wrapR]),i.texParameteri(P,i.TEXTURE_MAG_FILTER,$t[y.magFilter]),i.texParameteri(P,i.TEXTURE_MIN_FILTER,$t[y.minFilter]),y.compareFunction&&(i.texParameteri(P,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(P,i.TEXTURE_COMPARE_FUNC,hn[y.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(y.magFilter===vi||y.minFilter!==Na&&y.minFilter!==Hs||y.type===cs&&e.has("OES_texture_float_linear")===!1)return;if(y.anisotropy>1||n.get(y).__currentAnisotropy){const z=e.get("EXT_texture_filter_anisotropic");i.texParameterf(P,z.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,s.getMaxAnisotropy())),n.get(y).__currentAnisotropy=y.anisotropy}}}function ce(P,y){let z=!1;P.__webglInit===void 0&&(P.__webglInit=!0,y.addEventListener("dispose",L));const J=y.source;let oe=f.get(J);oe===void 0&&(oe={},f.set(J,oe));const Ee=K(y);if(Ee!==P.__cacheKey){oe[Ee]===void 0&&(oe[Ee]={texture:i.createTexture(),usedTimes:0},r.memory.textures++,z=!0),oe[Ee].usedTimes++;const Ae=oe[P.__cacheKey];Ae!==void 0&&(oe[P.__cacheKey].usedTimes--,Ae.usedTimes===0&&D(y)),P.__cacheKey=Ee,P.__webglTexture=oe[Ee].texture}return z}function Ce(P,y,z){return Math.floor(Math.floor(P/z)/y)}function ye(P,y,z,J){const Ee=P.updateRanges;if(Ee.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,y.width,y.height,z,J,y.data);else{Ee.sort((ft,Oe)=>ft.start-Oe.start);let Ae=0;for(let ft=1;ft<Ee.length;ft++){const Oe=Ee[Ae],Ue=Ee[ft],vt=Oe.start+Oe.count,Tt=Ce(Ue.start,y.width,4),Vt=Ce(Oe.start,y.width,4);Ue.start<=vt+1&&Tt===Vt&&Ce(Ue.start+Ue.count-1,y.width,4)===Tt?Oe.count=Math.max(Oe.count,Ue.start+Ue.count-Oe.start):(++Ae,Ee[Ae]=Ue)}Ee.length=Ae+1;const re=t.getParameter(i.UNPACK_ROW_LENGTH),ue=t.getParameter(i.UNPACK_SKIP_PIXELS),Ne=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,y.width);for(let ft=0,Oe=Ee.length;ft<Oe;ft++){const Ue=Ee[ft],vt=Math.floor(Ue.start/4),Tt=Math.ceil(Ue.count/4),Vt=vt%y.width,k=Math.floor(vt/y.width),Pe=Tt,le=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,Vt),t.pixelStorei(i.UNPACK_SKIP_ROWS,k),t.texSubImage2D(i.TEXTURE_2D,0,Vt,k,Pe,le,z,J,y.data)}P.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,re),t.pixelStorei(i.UNPACK_SKIP_PIXELS,ue),t.pixelStorei(i.UNPACK_SKIP_ROWS,Ne)}}function ht(P,y,z){let J=i.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(J=i.TEXTURE_2D_ARRAY),y.isData3DTexture&&(J=i.TEXTURE_3D);const oe=ce(P,y),Ee=y.source;t.bindTexture(J,P.__webglTexture,i.TEXTURE0+z);const Ae=n.get(Ee);if(Ee.version!==Ae.__version||oe===!0){if(t.activeTexture(i.TEXTURE0+z),(typeof ImageBitmap<"u"&&y.image instanceof ImageBitmap)===!1){const le=un.getPrimaries(un.workingColorSpace),Ie=y.colorSpace===ro?null:un.getPrimaries(y.colorSpace),ke=y.colorSpace===ro||le===Ie?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,y.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ke)}t.pixelStorei(i.UNPACK_ALIGNMENT,y.unpackAlignment);let ue=m(y.image,!1,s.maxTextureSize);ue=wn(y,ue);const Ne=o.convert(y.format,y.colorSpace),ft=o.convert(y.type);let Oe=_(y.internalFormat,Ne,ft,y.normalized,y.colorSpace,y.isVideoTexture);Qt(J,y);let Ue;const vt=y.mipmaps,Tt=y.isVideoTexture!==!0,Vt=Ae.__version===void 0||oe===!0,k=Ee.dataReady,Pe=E(y,ue);if(y.isDepthTexture)Oe=A(y.format===ar,y.type),Vt&&(Tt?t.texStorage2D(i.TEXTURE_2D,1,Oe,ue.width,ue.height):t.texImage2D(i.TEXTURE_2D,0,Oe,ue.width,ue.height,0,Ne,ft,null));else if(y.isDataTexture)if(vt.length>0){Tt&&Vt&&t.texStorage2D(i.TEXTURE_2D,Pe,Oe,vt[0].width,vt[0].height);for(let le=0,Ie=vt.length;le<Ie;le++)Ue=vt[le],Tt?k&&t.texSubImage2D(i.TEXTURE_2D,le,0,0,Ue.width,Ue.height,Ne,ft,Ue.data):t.texImage2D(i.TEXTURE_2D,le,Oe,Ue.width,Ue.height,0,Ne,ft,Ue.data);y.generateMipmaps=!1}else Tt?(Vt&&t.texStorage2D(i.TEXTURE_2D,Pe,Oe,ue.width,ue.height),k&&ye(y,ue,Ne,ft)):t.texImage2D(i.TEXTURE_2D,0,Oe,ue.width,ue.height,0,Ne,ft,ue.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){Tt&&Vt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Pe,Oe,vt[0].width,vt[0].height,ue.depth);for(let le=0,Ie=vt.length;le<Ie;le++)if(Ue=vt[le],y.format!==Ki)if(Ne!==null)if(Tt){if(k)if(y.layerUpdates.size>0){const ke=Up(Ue.width,Ue.height,y.format,y.type);for(const fe of y.layerUpdates){const ut=Ue.data.subarray(fe*ke/Ue.data.BYTES_PER_ELEMENT,(fe+1)*ke/Ue.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,le,0,0,fe,Ue.width,Ue.height,1,Ne,ut)}y.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,le,0,0,0,Ue.width,Ue.height,ue.depth,Ne,Ue.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,le,Oe,Ue.width,Ue.height,ue.depth,0,Ue.data,0,0);else xt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Tt?k&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,le,0,0,0,Ue.width,Ue.height,ue.depth,Ne,ft,Ue.data):t.texImage3D(i.TEXTURE_2D_ARRAY,le,Oe,Ue.width,Ue.height,ue.depth,0,Ne,ft,Ue.data)}else{Tt&&Vt&&t.texStorage2D(i.TEXTURE_2D,Pe,Oe,vt[0].width,vt[0].height);for(let le=0,Ie=vt.length;le<Ie;le++)Ue=vt[le],y.format!==Ki?Ne!==null?Tt?k&&t.compressedTexSubImage2D(i.TEXTURE_2D,le,0,0,Ue.width,Ue.height,Ne,Ue.data):t.compressedTexImage2D(i.TEXTURE_2D,le,Oe,Ue.width,Ue.height,0,Ue.data):xt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Tt?k&&t.texSubImage2D(i.TEXTURE_2D,le,0,0,Ue.width,Ue.height,Ne,ft,Ue.data):t.texImage2D(i.TEXTURE_2D,le,Oe,Ue.width,Ue.height,0,Ne,ft,Ue.data)}else if(y.isDataArrayTexture)if(Tt){if(Vt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Pe,Oe,ue.width,ue.height,ue.depth),k)if(y.layerUpdates.size>0){const le=Up(ue.width,ue.height,y.format,y.type);for(const Ie of y.layerUpdates){const ke=ue.data.subarray(Ie*le/ue.data.BYTES_PER_ELEMENT,(Ie+1)*le/ue.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Ie,ue.width,ue.height,1,Ne,ft,ke)}y.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ue.width,ue.height,ue.depth,Ne,ft,ue.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Oe,ue.width,ue.height,ue.depth,0,Ne,ft,ue.data);else if(y.isData3DTexture)Tt?(Vt&&t.texStorage3D(i.TEXTURE_3D,Pe,Oe,ue.width,ue.height,ue.depth),k&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ue.width,ue.height,ue.depth,Ne,ft,ue.data)):t.texImage3D(i.TEXTURE_3D,0,Oe,ue.width,ue.height,ue.depth,0,Ne,ft,ue.data);else if(y.isFramebufferTexture){if(Vt)if(Tt)t.texStorage2D(i.TEXTURE_2D,Pe,Oe,ue.width,ue.height);else{let le=ue.width,Ie=ue.height;for(let ke=0;ke<Pe;ke++)t.texImage2D(i.TEXTURE_2D,ke,Oe,le,Ie,0,Ne,ft,null),le>>=1,Ie>>=1}}else if(y.isHTMLTexture){if("texElementImage2D"in i){const le=i.canvas;if(le.hasAttribute("layoutsubtree")||le.setAttribute("layoutsubtree","true"),ue.parentNode!==le){le.appendChild(ue),h.add(y),le.onpaint=Ie=>{const ke=Ie.changedElements;for(const fe of h)ke.includes(fe.image)&&(fe.needsUpdate=!0)},le.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,ue);else{const ke=i.RGBA,fe=i.RGBA,ut=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,ke,fe,ut,ue)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(vt.length>0){if(Tt&&Vt){const le=rn(vt[0]);t.texStorage2D(i.TEXTURE_2D,Pe,Oe,le.width,le.height)}for(let le=0,Ie=vt.length;le<Ie;le++)Ue=vt[le],Tt?k&&t.texSubImage2D(i.TEXTURE_2D,le,0,0,Ne,ft,Ue):t.texImage2D(i.TEXTURE_2D,le,Oe,Ne,ft,Ue);y.generateMipmaps=!1}else if(Tt){if(Vt){const le=rn(ue);t.texStorage2D(i.TEXTURE_2D,Pe,Oe,le.width,le.height)}k&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Ne,ft,ue)}else t.texImage2D(i.TEXTURE_2D,0,Oe,Ne,ft,ue);g(y)&&M(J),Ae.__version=Ee.version,y.onUpdate&&y.onUpdate(y)}P.__version=y.version}function Nt(P,y,z){if(y.image.length!==6)return;const J=ce(P,y),oe=y.source;t.bindTexture(i.TEXTURE_CUBE_MAP,P.__webglTexture,i.TEXTURE0+z);const Ee=n.get(oe);if(oe.version!==Ee.__version||J===!0){t.activeTexture(i.TEXTURE0+z);const Ae=un.getPrimaries(un.workingColorSpace),re=y.colorSpace===ro?null:un.getPrimaries(y.colorSpace),ue=y.colorSpace===ro||Ae===re?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,y.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,y.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ue);const Ne=y.isCompressedTexture||y.image[0].isCompressedTexture,ft=y.image[0]&&y.image[0].isDataTexture,Oe=[];for(let fe=0;fe<6;fe++)!Ne&&!ft?Oe[fe]=m(y.image[fe],!0,s.maxCubemapSize):Oe[fe]=ft?y.image[fe].image:y.image[fe],Oe[fe]=wn(y,Oe[fe]);const Ue=Oe[0],vt=o.convert(y.format,y.colorSpace),Tt=o.convert(y.type),Vt=_(y.internalFormat,vt,Tt,y.normalized,y.colorSpace),k=y.isVideoTexture!==!0,Pe=Ee.__version===void 0||J===!0,le=oe.dataReady;let Ie=E(y,Ue);Qt(i.TEXTURE_CUBE_MAP,y);let ke;if(Ne){k&&Pe&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Ie,Vt,Ue.width,Ue.height);for(let fe=0;fe<6;fe++){ke=Oe[fe].mipmaps;for(let ut=0;ut<ke.length;ut++){const ot=ke[ut];y.format!==Ki?vt!==null?k?le&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut,0,0,ot.width,ot.height,vt,ot.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut,Vt,ot.width,ot.height,0,ot.data):xt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):k?le&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut,0,0,ot.width,ot.height,vt,Tt,ot.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut,Vt,ot.width,ot.height,0,vt,Tt,ot.data)}}}else{if(ke=y.mipmaps,k&&Pe){ke.length>0&&Ie++;const fe=rn(Oe[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Ie,Vt,fe.width,fe.height)}for(let fe=0;fe<6;fe++)if(ft){k?le&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,Oe[fe].width,Oe[fe].height,vt,Tt,Oe[fe].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,Vt,Oe[fe].width,Oe[fe].height,0,vt,Tt,Oe[fe].data);for(let ut=0;ut<ke.length;ut++){const zn=ke[ut].image[fe].image;k?le&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut+1,0,0,zn.width,zn.height,vt,Tt,zn.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut+1,Vt,zn.width,zn.height,0,vt,Tt,zn.data)}}else{k?le&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,vt,Tt,Oe[fe]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,Vt,vt,Tt,Oe[fe]);for(let ut=0;ut<ke.length;ut++){const ot=ke[ut];k?le&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut+1,0,0,vt,Tt,ot.image[fe]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ut+1,Vt,vt,Tt,ot.image[fe])}}}g(y)&&M(i.TEXTURE_CUBE_MAP),Ee.__version=oe.version,y.onUpdate&&y.onUpdate(y)}P.__version=y.version}function bt(P,y,z,J,oe,Ee){const Ae=o.convert(z.format,z.colorSpace),re=o.convert(z.type),ue=_(z.internalFormat,Ae,re,z.normalized,z.colorSpace),Ne=n.get(y),ft=n.get(z);if(ft.__renderTarget=y,!Ne.__hasExternalTextures){const Oe=Math.max(1,y.width>>Ee),Ue=Math.max(1,y.height>>Ee);oe===i.TEXTURE_3D||oe===i.TEXTURE_2D_ARRAY?t.texImage3D(oe,Ee,ue,Oe,Ue,y.depth,0,Ae,re,null):t.texImage2D(oe,Ee,ue,Oe,Ue,0,Ae,re,null)}t.bindFramebuffer(i.FRAMEBUFFER,P),Gt(y)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,J,oe,ft.__webglTexture,0,Ut(y)):(oe===i.TEXTURE_2D||oe>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&oe<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,J,oe,ft.__webglTexture,Ee),t.bindFramebuffer(i.FRAMEBUFFER,null)}function xn(P,y,z){if(i.bindRenderbuffer(i.RENDERBUFFER,P),y.depthBuffer){const J=y.depthTexture,oe=J&&J.isDepthTexture?J.type:null,Ee=A(y.stencilBuffer,oe),Ae=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;Gt(y)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ut(y),Ee,y.width,y.height):z?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ut(y),Ee,y.width,y.height):i.renderbufferStorage(i.RENDERBUFFER,Ee,y.width,y.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Ae,i.RENDERBUFFER,P)}else{const J=y.textures;for(let oe=0;oe<J.length;oe++){const Ee=J[oe],Ae=o.convert(Ee.format,Ee.colorSpace),re=o.convert(Ee.type),ue=_(Ee.internalFormat,Ae,re,Ee.normalized,Ee.colorSpace);Gt(y)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ut(y),ue,y.width,y.height):z?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ut(y),ue,y.width,y.height):i.renderbufferStorage(i.RENDERBUFFER,ue,y.width,y.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Bt(P,y,z){const J=y.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,P),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const oe=n.get(y.depthTexture);if(oe.__renderTarget=y,(!oe.__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),J){if(oe.__webglInit===void 0&&(oe.__webglInit=!0,y.depthTexture.addEventListener("dispose",L)),oe.__webglTexture===void 0){oe.__webglTexture=i.createTexture(),t.bindTexture(i.TEXTURE_CUBE_MAP,oe.__webglTexture),Qt(i.TEXTURE_CUBE_MAP,y.depthTexture);const Ne=o.convert(y.depthTexture.format),ft=o.convert(y.depthTexture.type);let Oe;y.depthTexture.format===bo?Oe=i.DEPTH_COMPONENT24:y.depthTexture.format===ar&&(Oe=i.DEPTH24_STENCIL8);for(let Ue=0;Ue<6;Ue++)i.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Ue,0,Oe,y.width,y.height,0,Ne,ft,null)}}else he(y.depthTexture,0);const Ee=oe.__webglTexture,Ae=Ut(y),re=J?i.TEXTURE_CUBE_MAP_POSITIVE_X+z:i.TEXTURE_2D,ue=y.depthTexture.format===ar?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(y.depthTexture.format===bo)Gt(y)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ue,re,Ee,0,Ae):i.framebufferTexture2D(i.FRAMEBUFFER,ue,re,Ee,0);else if(y.depthTexture.format===ar)Gt(y)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ue,re,Ee,0,Ae):i.framebufferTexture2D(i.FRAMEBUFFER,ue,re,Ee,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function pe(P){const y=n.get(P),z=P.isWebGLCubeRenderTarget===!0;if(y.__boundDepthTexture!==P.depthTexture){const J=P.depthTexture;if(y.__depthDisposeCallback&&y.__depthDisposeCallback(),J){const oe=()=>{delete y.__boundDepthTexture,delete y.__depthDisposeCallback,J.removeEventListener("dispose",oe)};J.addEventListener("dispose",oe),y.__depthDisposeCallback=oe}y.__boundDepthTexture=J}if(P.depthTexture&&!y.__autoAllocateDepthBuffer)if(z)for(let J=0;J<6;J++)Bt(y.__webglFramebuffer[J],P,J);else{const J=P.texture.mipmaps;J&&J.length>0?Bt(y.__webglFramebuffer[0],P,0):Bt(y.__webglFramebuffer,P,0)}else if(z){y.__webglDepthbuffer=[];for(let J=0;J<6;J++)if(t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer[J]),y.__webglDepthbuffer[J]===void 0)y.__webglDepthbuffer[J]=i.createRenderbuffer(),xn(y.__webglDepthbuffer[J],P,!1);else{const oe=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ee=y.__webglDepthbuffer[J];i.bindRenderbuffer(i.RENDERBUFFER,Ee),i.framebufferRenderbuffer(i.FRAMEBUFFER,oe,i.RENDERBUFFER,Ee)}}else{const J=P.texture.mipmaps;if(J&&J.length>0?t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer===void 0)y.__webglDepthbuffer=i.createRenderbuffer(),xn(y.__webglDepthbuffer,P,!1);else{const oe=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ee=y.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,Ee),i.framebufferRenderbuffer(i.FRAMEBUFFER,oe,i.RENDERBUFFER,Ee)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function ve(P,y,z){const J=n.get(P);y!==void 0&&bt(J.__webglFramebuffer,P,P.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),z!==void 0&&pe(P)}function ge(P){const y=P.texture,z=n.get(P),J=n.get(y);P.addEventListener("dispose",v);const oe=P.textures,Ee=P.isWebGLCubeRenderTarget===!0,Ae=oe.length>1;if(Ae||(J.__webglTexture===void 0&&(J.__webglTexture=i.createTexture()),J.__version=y.version,r.memory.textures++),Ee){z.__webglFramebuffer=[];for(let re=0;re<6;re++)if(y.mipmaps&&y.mipmaps.length>0){z.__webglFramebuffer[re]=[];for(let ue=0;ue<y.mipmaps.length;ue++)z.__webglFramebuffer[re][ue]=i.createFramebuffer()}else z.__webglFramebuffer[re]=i.createFramebuffer()}else{if(y.mipmaps&&y.mipmaps.length>0){z.__webglFramebuffer=[];for(let re=0;re<y.mipmaps.length;re++)z.__webglFramebuffer[re]=i.createFramebuffer()}else z.__webglFramebuffer=i.createFramebuffer();if(Ae)for(let re=0,ue=oe.length;re<ue;re++){const Ne=n.get(oe[re]);Ne.__webglTexture===void 0&&(Ne.__webglTexture=i.createTexture(),r.memory.textures++)}if(P.samples>0&&Gt(P)===!1){z.__webglMultisampledFramebuffer=i.createFramebuffer(),z.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let re=0;re<oe.length;re++){const ue=oe[re];z.__webglColorRenderbuffer[re]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,z.__webglColorRenderbuffer[re]);const Ne=o.convert(ue.format,ue.colorSpace),ft=o.convert(ue.type),Oe=_(ue.internalFormat,Ne,ft,ue.normalized,ue.colorSpace,P.isXRRenderTarget===!0),Ue=Ut(P);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ue,Oe,P.width,P.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+re,i.RENDERBUFFER,z.__webglColorRenderbuffer[re])}i.bindRenderbuffer(i.RENDERBUFFER,null),P.depthBuffer&&(z.__webglDepthRenderbuffer=i.createRenderbuffer(),xn(z.__webglDepthRenderbuffer,P,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(Ee){t.bindTexture(i.TEXTURE_CUBE_MAP,J.__webglTexture),Qt(i.TEXTURE_CUBE_MAP,y);for(let re=0;re<6;re++)if(y.mipmaps&&y.mipmaps.length>0)for(let ue=0;ue<y.mipmaps.length;ue++)bt(z.__webglFramebuffer[re][ue],P,y,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+re,ue);else bt(z.__webglFramebuffer[re],P,y,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+re,0);g(y)&&M(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ae){for(let re=0,ue=oe.length;re<ue;re++){const Ne=oe[re],ft=n.get(Ne);let Oe=i.TEXTURE_2D;(P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(Oe=P.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Oe,ft.__webglTexture),Qt(Oe,Ne),bt(z.__webglFramebuffer,P,Ne,i.COLOR_ATTACHMENT0+re,Oe,0),g(Ne)&&M(Oe)}t.unbindTexture()}else{let re=i.TEXTURE_2D;if((P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(re=P.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(re,J.__webglTexture),Qt(re,y),y.mipmaps&&y.mipmaps.length>0)for(let ue=0;ue<y.mipmaps.length;ue++)bt(z.__webglFramebuffer[ue],P,y,i.COLOR_ATTACHMENT0,re,ue);else bt(z.__webglFramebuffer,P,y,i.COLOR_ATTACHMENT0,re,0);g(y)&&M(re),t.unbindTexture()}P.depthBuffer&&pe(P)}function Be(P){const y=P.textures;for(let z=0,J=y.length;z<J;z++){const oe=y[z];if(g(oe)){const Ee=S(P),Ae=n.get(oe).__webglTexture;t.bindTexture(Ee,Ae),M(Ee),t.unbindTexture()}}}const Fe=[],Et=[];function dt(P){if(P.samples>0){if(Gt(P)===!1){const y=P.textures,z=P.width,J=P.height;let oe=i.COLOR_BUFFER_BIT;const Ee=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ae=n.get(P),re=y.length>1;if(re)for(let Ne=0;Ne<y.length;Ne++)t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ne,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ne,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,Ae.__webglMultisampledFramebuffer);const ue=P.texture.mipmaps;ue&&ue.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ae.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ae.__webglFramebuffer);for(let Ne=0;Ne<y.length;Ne++){if(P.resolveDepthBuffer&&(P.depthBuffer&&(oe|=i.DEPTH_BUFFER_BIT),P.stencilBuffer&&P.resolveStencilBuffer&&(oe|=i.STENCIL_BUFFER_BIT)),re){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Ae.__webglColorRenderbuffer[Ne]);const ft=n.get(y[Ne]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,ft,0)}i.blitFramebuffer(0,0,z,J,0,0,z,J,oe,i.NEAREST),c===!0&&(Fe.length=0,Et.length=0,Fe.push(i.COLOR_ATTACHMENT0+Ne),P.depthBuffer&&P.resolveDepthBuffer===!1&&(Fe.push(Ee),Et.push(Ee),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,Et)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Fe))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),re)for(let Ne=0;Ne<y.length;Ne++){t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ne,i.RENDERBUFFER,Ae.__webglColorRenderbuffer[Ne]);const ft=n.get(y[Ne]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ne,i.TEXTURE_2D,ft,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ae.__webglMultisampledFramebuffer)}else if(P.depthBuffer&&P.resolveDepthBuffer===!1&&c){const y=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[y])}}}function Ut(P){return Math.min(s.maxSamples,P.samples)}function Gt(P){const y=n.get(P);return P.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function F(P){const y=r.render.frame;u.get(P)!==y&&(u.set(P,y),P.update())}function wn(P,y){const z=P.colorSpace,J=P.format,oe=P.type;return P.isCompressedTexture===!0||P.isVideoTexture===!0||z!==Ji&&z!==ro&&(un.getTransfer(z)===Dn?(J!==Ki||oe!==Yi)&&xt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Lt("WebGLTextures: Unsupported texture color space:",z)),y}function rn(P){return typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement?(l.width=P.naturalWidth||P.width,l.height=P.naturalHeight||P.height):typeof VideoFrame<"u"&&P instanceof VideoFrame?(l.width=P.displayWidth,l.height=P.displayHeight):(l.width=P.width,l.height=P.height),l}this.allocateTextureUnit=se,this.resetTextureUnits=ne,this.getTextureUnits=ae,this.setTextureUnits=V,this.setTexture2D=he,this.setTexture2DArray=me,this.setTexture3D=Re,this.setTextureCube=we,this.rebindTextures=ve,this.setupRenderTarget=ge,this.updateRenderTargetMipmap=Be,this.updateMultisampleRenderTarget=dt,this.setupDepthRenderbuffer=pe,this.setupFrameBufferTexture=bt,this.useMultisampledRTT=Gt,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function gT(i,e){function t(n,s=ro){let o;const r=un.getTransfer(s);if(n===Yi)return i.UNSIGNED_BYTE;if(n===Ad)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Rd)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Zm)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===$m)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Ym)return i.BYTE;if(n===Km)return i.SHORT;if(n===ic)return i.UNSIGNED_SHORT;if(n===Ed)return i.INT;if(n===Xs)return i.UNSIGNED_INT;if(n===cs)return i.FLOAT;if(n===So)return i.HALF_FLOAT;if(n===Jm)return i.ALPHA;if(n===jm)return i.RGB;if(n===Ki)return i.RGBA;if(n===bo)return i.DEPTH_COMPONENT;if(n===ar)return i.DEPTH_STENCIL;if(n===Cd)return i.RED;if(n===Pd)return i.RED_INTEGER;if(n===gr)return i.RG;if(n===Id)return i.RG_INTEGER;if(n===Ld)return i.RGBA_INTEGER;if(n===pl||n===ml||n===gl||n===xl)if(r===Dn)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(n===pl)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ml)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===gl)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===xl)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(n===pl)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ml)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===gl)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===xl)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===ph||n===mh||n===gh||n===xh)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(n===ph)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===mh)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===gh)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===xh)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===_h||n===vh||n===yh||n===Mh||n===Sh||n===Tl||n===bh)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(n===_h||n===vh)return r===Dn?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(n===yh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC;if(n===Mh)return o.COMPRESSED_R11_EAC;if(n===Sh)return o.COMPRESSED_SIGNED_R11_EAC;if(n===Tl)return o.COMPRESSED_RG11_EAC;if(n===bh)return o.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===Th||n===wh||n===Eh||n===Ah||n===Rh||n===Ch||n===Ph||n===Ih||n===Lh||n===Dh||n===Nh||n===Uh||n===Fh||n===Oh)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(n===Th)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===wh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Eh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Ah)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Rh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Ch)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ph)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ih)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Lh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Dh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Nh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Uh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Fh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Oh)return r===Dn?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Bh||n===kh||n===Hh)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(n===Bh)return r===Dn?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===kh)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Hh)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Gh||n===Vh||n===wl||n===zh)if(o=e.get("EXT_texture_compression_rgtc"),o!==null){if(n===Gh)return o.COMPRESSED_RED_RGTC1_EXT;if(n===Vh)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===wl)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===zh)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===sc?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const xT=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,_T=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class vT{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new l0(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new hs({vertexShader:xT,fragmentShader:_T,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new W(new vc(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class yT extends zo{constructor(e,t){super();const n=this;let s=null,o=1,r=null,a="local-floor",c=1,l=null,u=null,h=null,d=null,f=null,p=null;const x=typeof XRWebGLBinding<"u",m=new vT,g={},M=t.getContextAttributes();let S=null,_=null;const A=[],E=[],L=new _e;let v=null;const R=new Bi;R.viewport=new Bn;const D=new Bi;D.viewport=new Bn;const N=[R,D],B=new gy;let ne=null,ae=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ce){let Ce=A[ce];return Ce===void 0&&(Ce=new mu,A[ce]=Ce),Ce.getTargetRaySpace()},this.getControllerGrip=function(ce){let Ce=A[ce];return Ce===void 0&&(Ce=new mu,A[ce]=Ce),Ce.getGripSpace()},this.getHand=function(ce){let Ce=A[ce];return Ce===void 0&&(Ce=new mu,A[ce]=Ce),Ce.getHandSpace()};function V(ce){const Ce=E.indexOf(ce.inputSource);if(Ce===-1)return;const ye=A[Ce];ye!==void 0&&(ye.update(ce.inputSource,ce.frame,l||r),ye.dispatchEvent({type:ce.type,data:ce.inputSource}))}function se(){s.removeEventListener("select",V),s.removeEventListener("selectstart",V),s.removeEventListener("selectend",V),s.removeEventListener("squeeze",V),s.removeEventListener("squeezestart",V),s.removeEventListener("squeezeend",V),s.removeEventListener("end",se),s.removeEventListener("inputsourceschange",K);for(let ce=0;ce<A.length;ce++){const Ce=E[ce];Ce!==null&&(E[ce]=null,A[ce].disconnect(Ce))}ne=null,ae=null,m.reset();for(const ce in g)delete g[ce];e.setRenderTarget(S),f=null,d=null,h=null,s=null,_=null,Qt.stop(),n.isPresenting=!1,e.setPixelRatio(v),e.setSize(L.width,L.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ce){o=ce,n.isPresenting===!0&&xt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ce){a=ce,n.isPresenting===!0&&xt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||r},this.setReferenceSpace=function(ce){l=ce},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return h===null&&x&&(h=new XRWebGLBinding(s,t)),h},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function(ce){if(s=ce,s!==null){if(S=e.getRenderTarget(),s.addEventListener("select",V),s.addEventListener("selectstart",V),s.addEventListener("selectend",V),s.addEventListener("squeeze",V),s.addEventListener("squeezestart",V),s.addEventListener("squeezeend",V),s.addEventListener("end",se),s.addEventListener("inputsourceschange",K),M.xrCompatible!==!0&&await t.makeXRCompatible(),v=e.getPixelRatio(),e.getSize(L),x&&"createProjectionLayer"in XRWebGLBinding.prototype){let ye=null,ht=null,Nt=null;M.depth&&(Nt=M.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ye=M.stencil?ar:bo,ht=M.stencil?sc:Xs);const bt={colorFormat:t.RGBA8,depthFormat:Nt,scaleFactor:o};h=this.getBinding(),d=h.createProjectionLayer(bt),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),_=new zs(d.textureWidth,d.textureHeight,{format:Ki,type:Yi,depthTexture:new ia(d.textureWidth,d.textureHeight,ht,void 0,void 0,void 0,void 0,void 0,void 0,ye),stencilBuffer:M.stencil,colorSpace:e.outputColorSpace,samples:M.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const ye={antialias:M.antialias,alpha:!0,depth:M.depth,stencil:M.stencil,framebufferScaleFactor:o};f=new XRWebGLLayer(s,t,ye),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),_=new zs(f.framebufferWidth,f.framebufferHeight,{format:Ki,type:Yi,colorSpace:e.outputColorSpace,stencilBuffer:M.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}_.isXRRenderTarget=!0,this.setFoveation(c),l=null,r=await s.requestReferenceSpace(a),Qt.setContext(s),Qt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function K(ce){for(let Ce=0;Ce<ce.removed.length;Ce++){const ye=ce.removed[Ce],ht=E.indexOf(ye);ht>=0&&(E[ht]=null,A[ht].disconnect(ye))}for(let Ce=0;Ce<ce.added.length;Ce++){const ye=ce.added[Ce];let ht=E.indexOf(ye);if(ht===-1){for(let bt=0;bt<A.length;bt++)if(bt>=E.length){E.push(ye),ht=bt;break}else if(E[bt]===null){E[bt]=ye,ht=bt;break}if(ht===-1)break}const Nt=A[ht];Nt&&Nt.connect(ye)}}const he=new I,me=new I;function Re(ce,Ce,ye){he.setFromMatrixPosition(Ce.matrixWorld),me.setFromMatrixPosition(ye.matrixWorld);const ht=he.distanceTo(me),Nt=Ce.projectionMatrix.elements,bt=ye.projectionMatrix.elements,xn=Nt[14]/(Nt[10]-1),Bt=Nt[14]/(Nt[10]+1),pe=(Nt[9]+1)/Nt[5],ve=(Nt[9]-1)/Nt[5],ge=(Nt[8]-1)/Nt[0],Be=(bt[8]+1)/bt[0],Fe=xn*ge,Et=xn*Be,dt=ht/(-ge+Be),Ut=dt*-ge;if(Ce.matrixWorld.decompose(ce.position,ce.quaternion,ce.scale),ce.translateX(Ut),ce.translateZ(dt),ce.matrixWorld.compose(ce.position,ce.quaternion,ce.scale),ce.matrixWorldInverse.copy(ce.matrixWorld).invert(),Nt[10]===-1)ce.projectionMatrix.copy(Ce.projectionMatrix),ce.projectionMatrixInverse.copy(Ce.projectionMatrixInverse);else{const Gt=xn+dt,F=Bt+dt,wn=Fe-Ut,rn=Et+(ht-Ut),P=pe*Bt/F*Gt,y=ve*Bt/F*Gt;ce.projectionMatrix.makePerspective(wn,rn,P,y,Gt,F),ce.projectionMatrixInverse.copy(ce.projectionMatrix).invert()}}function we(ce,Ce){Ce===null?ce.matrixWorld.copy(ce.matrix):ce.matrixWorld.multiplyMatrices(Ce.matrixWorld,ce.matrix),ce.matrixWorldInverse.copy(ce.matrixWorld).invert()}this.updateCamera=function(ce){if(s===null)return;let Ce=ce.near,ye=ce.far;m.texture!==null&&(m.depthNear>0&&(Ce=m.depthNear),m.depthFar>0&&(ye=m.depthFar)),B.near=D.near=R.near=Ce,B.far=D.far=R.far=ye,(ne!==B.near||ae!==B.far)&&(s.updateRenderState({depthNear:B.near,depthFar:B.far}),ne=B.near,ae=B.far),B.layers.mask=ce.layers.mask|6,R.layers.mask=B.layers.mask&-5,D.layers.mask=B.layers.mask&-3;const ht=ce.parent,Nt=B.cameras;we(B,ht);for(let bt=0;bt<Nt.length;bt++)we(Nt[bt],ht);Nt.length===2?Re(B,R,D):B.projectionMatrix.copy(R.projectionMatrix),Xe(ce,B,ht)};function Xe(ce,Ce,ye){ye===null?ce.matrix.copy(Ce.matrixWorld):(ce.matrix.copy(ye.matrixWorld),ce.matrix.invert(),ce.matrix.multiply(Ce.matrixWorld)),ce.matrix.decompose(ce.position,ce.quaternion,ce.scale),ce.updateMatrixWorld(!0),ce.projectionMatrix.copy(Ce.projectionMatrix),ce.projectionMatrixInverse.copy(Ce.projectionMatrixInverse),ce.isPerspectiveCamera&&(ce.fov=na*2*Math.atan(1/ce.projectionMatrix.elements[5]),ce.zoom=1)}this.getCamera=function(){return B},this.getFoveation=function(){if(!(d===null&&f===null))return c},this.setFoveation=function(ce){c=ce,d!==null&&(d.fixedFoveation=ce),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=ce)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(B)},this.getCameraTexture=function(ce){return g[ce]};let $t=null;function hn(ce,Ce){if(u=Ce.getViewerPose(l||r),p=Ce,u!==null){const ye=u.views;f!==null&&(e.setRenderTargetFramebuffer(_,f.framebuffer),e.setRenderTarget(_));let ht=!1;ye.length!==B.cameras.length&&(B.cameras.length=0,ht=!0);for(let Bt=0;Bt<ye.length;Bt++){const pe=ye[Bt];let ve=null;if(f!==null)ve=f.getViewport(pe);else{const Be=h.getViewSubImage(d,pe);ve=Be.viewport,Bt===0&&(e.setRenderTargetTextures(_,Be.colorTexture,Be.depthStencilTexture),e.setRenderTarget(_))}let ge=N[Bt];ge===void 0&&(ge=new Bi,ge.layers.enable(Bt),ge.viewport=new Bn,N[Bt]=ge),ge.matrix.fromArray(pe.transform.matrix),ge.matrix.decompose(ge.position,ge.quaternion,ge.scale),ge.projectionMatrix.fromArray(pe.projectionMatrix),ge.projectionMatrixInverse.copy(ge.projectionMatrix).invert(),ge.viewport.set(ve.x,ve.y,ve.width,ve.height),Bt===0&&(B.matrix.copy(ge.matrix),B.matrix.decompose(B.position,B.quaternion,B.scale)),ht===!0&&B.cameras.push(ge)}const Nt=s.enabledFeatures;if(Nt&&Nt.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&x){h=n.getBinding();const Bt=h.getDepthInformation(ye[0]);Bt&&Bt.isValid&&Bt.texture&&m.init(Bt,s.renderState)}if(Nt&&Nt.includes("camera-access")&&x){e.state.unbindTexture(),h=n.getBinding();for(let Bt=0;Bt<ye.length;Bt++){const pe=ye[Bt].camera;if(pe){let ve=g[pe];ve||(ve=new l0,g[pe]=ve);const ge=h.getCameraImage(pe);ve.sourceTexture=ge}}}}for(let ye=0;ye<A.length;ye++){const ht=E[ye],Nt=A[ye];ht!==null&&Nt!==void 0&&Nt.update(ht,Ce,l||r)}$t&&$t(ce,Ce),Ce.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Ce}),p=null}const Qt=new A0;Qt.setAnimationLoop(hn),this.setAnimationLoop=function(ce){$t=ce},this.dispose=function(){}}}const MT=new Wt,N0=new Yt;N0.set(-1,0,0,0,1,0,0,0,1);function ST(i,e){function t(m,g){m.matrixAutoUpdate===!0&&m.updateMatrix(),g.value.copy(m.matrix)}function n(m,g){g.color.getRGB(m.fogColor.value,v0(i)),g.isFog?(m.fogNear.value=g.near,m.fogFar.value=g.far):g.isFogExp2&&(m.fogDensity.value=g.density)}function s(m,g,M,S,_){g.isNodeMaterial?g.uniformsNeedUpdate=!1:g.isMeshBasicMaterial?o(m,g):g.isMeshLambertMaterial?(o(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshToonMaterial?(o(m,g),h(m,g)):g.isMeshPhongMaterial?(o(m,g),u(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshStandardMaterial?(o(m,g),d(m,g),g.isMeshPhysicalMaterial&&f(m,g,_)):g.isMeshMatcapMaterial?(o(m,g),p(m,g)):g.isMeshDepthMaterial?o(m,g):g.isMeshDistanceMaterial?(o(m,g),x(m,g)):g.isMeshNormalMaterial?o(m,g):g.isLineBasicMaterial?(r(m,g),g.isLineDashedMaterial&&a(m,g)):g.isPointsMaterial?c(m,g,M,S):g.isSpriteMaterial?l(m,g):g.isShadowMaterial?(m.color.value.copy(g.color),m.opacity.value=g.opacity):g.isShaderMaterial&&(g.uniformsNeedUpdate=!1)}function o(m,g){m.opacity.value=g.opacity,g.color&&m.diffuse.value.copy(g.color),g.emissive&&m.emissive.value.copy(g.emissive).multiplyScalar(g.emissiveIntensity),g.map&&(m.map.value=g.map,t(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.bumpMap&&(m.bumpMap.value=g.bumpMap,t(g.bumpMap,m.bumpMapTransform),m.bumpScale.value=g.bumpScale,g.side===Ii&&(m.bumpScale.value*=-1)),g.normalMap&&(m.normalMap.value=g.normalMap,t(g.normalMap,m.normalMapTransform),m.normalScale.value.copy(g.normalScale),g.side===Ii&&m.normalScale.value.negate()),g.displacementMap&&(m.displacementMap.value=g.displacementMap,t(g.displacementMap,m.displacementMapTransform),m.displacementScale.value=g.displacementScale,m.displacementBias.value=g.displacementBias),g.emissiveMap&&(m.emissiveMap.value=g.emissiveMap,t(g.emissiveMap,m.emissiveMapTransform)),g.specularMap&&(m.specularMap.value=g.specularMap,t(g.specularMap,m.specularMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest);const M=e.get(g),S=M.envMap,_=M.envMapRotation;S&&(m.envMap.value=S,m.envMapRotation.value.setFromMatrix4(MT.makeRotationFromEuler(_)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(N0),m.reflectivity.value=g.reflectivity,m.ior.value=g.ior,m.refractionRatio.value=g.refractionRatio),g.lightMap&&(m.lightMap.value=g.lightMap,m.lightMapIntensity.value=g.lightMapIntensity,t(g.lightMap,m.lightMapTransform)),g.aoMap&&(m.aoMap.value=g.aoMap,m.aoMapIntensity.value=g.aoMapIntensity,t(g.aoMap,m.aoMapTransform))}function r(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,g.map&&(m.map.value=g.map,t(g.map,m.mapTransform))}function a(m,g){m.dashSize.value=g.dashSize,m.totalSize.value=g.dashSize+g.gapSize,m.scale.value=g.scale}function c(m,g,M,S){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.size.value=g.size*M,m.scale.value=S*.5,g.map&&(m.map.value=g.map,t(g.map,m.uvTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function l(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.rotation.value=g.rotation,g.map&&(m.map.value=g.map,t(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function u(m,g){m.specular.value.copy(g.specular),m.shininess.value=Math.max(g.shininess,1e-4)}function h(m,g){g.gradientMap&&(m.gradientMap.value=g.gradientMap)}function d(m,g){m.metalness.value=g.metalness,g.metalnessMap&&(m.metalnessMap.value=g.metalnessMap,t(g.metalnessMap,m.metalnessMapTransform)),m.roughness.value=g.roughness,g.roughnessMap&&(m.roughnessMap.value=g.roughnessMap,t(g.roughnessMap,m.roughnessMapTransform)),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)}function f(m,g,M){m.ior.value=g.ior,g.sheen>0&&(m.sheenColor.value.copy(g.sheenColor).multiplyScalar(g.sheen),m.sheenRoughness.value=g.sheenRoughness,g.sheenColorMap&&(m.sheenColorMap.value=g.sheenColorMap,t(g.sheenColorMap,m.sheenColorMapTransform)),g.sheenRoughnessMap&&(m.sheenRoughnessMap.value=g.sheenRoughnessMap,t(g.sheenRoughnessMap,m.sheenRoughnessMapTransform))),g.clearcoat>0&&(m.clearcoat.value=g.clearcoat,m.clearcoatRoughness.value=g.clearcoatRoughness,g.clearcoatMap&&(m.clearcoatMap.value=g.clearcoatMap,t(g.clearcoatMap,m.clearcoatMapTransform)),g.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=g.clearcoatRoughnessMap,t(g.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),g.clearcoatNormalMap&&(m.clearcoatNormalMap.value=g.clearcoatNormalMap,t(g.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(g.clearcoatNormalScale),g.side===Ii&&m.clearcoatNormalScale.value.negate())),g.dispersion>0&&(m.dispersion.value=g.dispersion),g.iridescence>0&&(m.iridescence.value=g.iridescence,m.iridescenceIOR.value=g.iridescenceIOR,m.iridescenceThicknessMinimum.value=g.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=g.iridescenceThicknessRange[1],g.iridescenceMap&&(m.iridescenceMap.value=g.iridescenceMap,t(g.iridescenceMap,m.iridescenceMapTransform)),g.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=g.iridescenceThicknessMap,t(g.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),g.transmission>0&&(m.transmission.value=g.transmission,m.transmissionSamplerMap.value=M.texture,m.transmissionSamplerSize.value.set(M.width,M.height),g.transmissionMap&&(m.transmissionMap.value=g.transmissionMap,t(g.transmissionMap,m.transmissionMapTransform)),m.thickness.value=g.thickness,g.thicknessMap&&(m.thicknessMap.value=g.thicknessMap,t(g.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=g.attenuationDistance,m.attenuationColor.value.copy(g.attenuationColor)),g.anisotropy>0&&(m.anisotropyVector.value.set(g.anisotropy*Math.cos(g.anisotropyRotation),g.anisotropy*Math.sin(g.anisotropyRotation)),g.anisotropyMap&&(m.anisotropyMap.value=g.anisotropyMap,t(g.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=g.specularIntensity,m.specularColor.value.copy(g.specularColor),g.specularColorMap&&(m.specularColorMap.value=g.specularColorMap,t(g.specularColorMap,m.specularColorMapTransform)),g.specularIntensityMap&&(m.specularIntensityMap.value=g.specularIntensityMap,t(g.specularIntensityMap,m.specularIntensityMapTransform))}function p(m,g){g.matcap&&(m.matcap.value=g.matcap)}function x(m,g){const M=e.get(g).light;m.referencePosition.value.setFromMatrixPosition(M.matrixWorld),m.nearDistance.value=M.shadow.camera.near,m.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function bT(i,e,t,n){let s={},o={},r=[];const a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function c(_,A){const E=A.program;n.uniformBlockBinding(_,E)}function l(_,A){let E=s[_.id];E===void 0&&(m(_),E=u(_),s[_.id]=E,_.addEventListener("dispose",M));const L=A.program;n.updateUBOMapping(_,L);const v=e.render.frame;o[_.id]!==v&&(d(_),o[_.id]=v)}function u(_){const A=h();_.__bindingPointIndex=A;const E=i.createBuffer(),L=_.__size,v=_.usage;return i.bindBuffer(i.UNIFORM_BUFFER,E),i.bufferData(i.UNIFORM_BUFFER,L,v),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,A,E),E}function h(){for(let _=0;_<a;_++)if(r.indexOf(_)===-1)return r.push(_),_;return Lt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(_){const A=s[_.id],E=_.uniforms,L=_.__cache;i.bindBuffer(i.UNIFORM_BUFFER,A);for(let v=0,R=E.length;v<R;v++){const D=E[v];if(Array.isArray(D))for(let N=0,B=D.length;N<B;N++)f(D[N],v,N,L);else f(D,v,0,L)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(_,A,E,L){if(x(_,A,E,L)===!0){const v=_.__offset,R=_.value;if(Array.isArray(R)){let D=0;for(let N=0;N<R.length;N++){const B=R[N],ne=g(B);p(B,_.__data,D),typeof B!="number"&&typeof B!="boolean"&&!B.isMatrix3&&!ArrayBuffer.isView(B)&&(D+=ne.storage/Float32Array.BYTES_PER_ELEMENT)}}else p(R,_.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,v,_.__data)}}function p(_,A,E){typeof _=="number"||typeof _=="boolean"?A[0]=_:_.isMatrix3?(A[0]=_.elements[0],A[1]=_.elements[1],A[2]=_.elements[2],A[3]=0,A[4]=_.elements[3],A[5]=_.elements[4],A[6]=_.elements[5],A[7]=0,A[8]=_.elements[6],A[9]=_.elements[7],A[10]=_.elements[8],A[11]=0):ArrayBuffer.isView(_)?A.set(new _.constructor(_.buffer,_.byteOffset,A.length)):_.toArray(A,E)}function x(_,A,E,L){const v=_.value,R=A+"_"+E;if(L[R]===void 0)return typeof v=="number"||typeof v=="boolean"?L[R]=v:ArrayBuffer.isView(v)?L[R]=v.slice():L[R]=v.clone(),!0;{const D=L[R];if(typeof v=="number"||typeof v=="boolean"){if(D!==v)return L[R]=v,!0}else{if(ArrayBuffer.isView(v))return!0;if(D.equals(v)===!1)return D.copy(v),!0}}return!1}function m(_){const A=_.uniforms;let E=0;const L=16;for(let R=0,D=A.length;R<D;R++){const N=Array.isArray(A[R])?A[R]:[A[R]];for(let B=0,ne=N.length;B<ne;B++){const ae=N[B],V=Array.isArray(ae.value)?ae.value:[ae.value];for(let se=0,K=V.length;se<K;se++){const he=V[se],me=g(he),Re=E%L,we=Re%me.boundary,Xe=Re+we;E+=we,Xe!==0&&L-Xe<me.storage&&(E+=L-Xe),ae.__data=new Float32Array(me.storage/Float32Array.BYTES_PER_ELEMENT),ae.__offset=E,E+=me.storage}}}const v=E%L;return v>0&&(E+=L-v),_.__size=E,_.__cache={},this}function g(_){const A={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(A.boundary=4,A.storage=4):_.isVector2?(A.boundary=8,A.storage=8):_.isVector3||_.isColor?(A.boundary=16,A.storage=12):_.isVector4?(A.boundary=16,A.storage=16):_.isMatrix3?(A.boundary=48,A.storage=48):_.isMatrix4?(A.boundary=64,A.storage=64):_.isTexture?xt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(_)?(A.boundary=16,A.storage=_.byteLength):xt("WebGLRenderer: Unsupported uniform value type.",_),A}function M(_){const A=_.target;A.removeEventListener("dispose",M);const E=r.indexOf(A.__bindingPointIndex);r.splice(E,1),i.deleteBuffer(s[A.id]),delete s[A.id],delete o[A.id]}function S(){for(const _ in s)i.deleteBuffer(s[_]);r=[],s={},o={}}return{bind:c,update:l,dispose:S}}const TT=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Is=null;function wT(){return Is===null&&(Is=new zl(TT,16,16,gr,So),Is.name="DFG_LUT",Is.minFilter=mi,Is.magFilter=mi,Is.wrapS=ks,Is.wrapT=ks,Is.generateMipmaps=!1,Is.needsUpdate=!0),Is}class ET{constructor(e={}){const{canvas:t=g_(),context:n=null,depth:s=!0,stencil:o=!1,alpha:r=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:h=!1,reversedDepthBuffer:d=!1,outputBufferType:f=Yi}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=r;const x=f,m=new Set([Ld,Id,Pd]),g=new Set([Yi,Xs,ic,sc,Ad,Rd]),M=new Uint32Array(4),S=new Int32Array(4),_=new I;let A=null,E=null;const L=[],v=[];let R=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Vs,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const D=this;let N=!1,B=null,ne=null,ae=null,V=null;this._outputColorSpace=Yn;let se=0,K=0,he=null,me=-1,Re=null;const we=new Bn,Xe=new Bn;let $t=null;const hn=new Qe(0);let Qt=0,ce=t.width,Ce=t.height,ye=1,ht=null,Nt=null;const bt=new Bn(0,0,ce,Ce),xn=new Bn(0,0,ce,Ce);let Bt=!1;const pe=new Gd;let ve=!1,ge=!1;const Be=new Wt,Fe=new I,Et=new Bn,dt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Ut=!1;function Gt(){return he===null?ye:1}let F=n;function wn(w,G){return t.getContext(w,G)}try{const w={alpha:!0,depth:s,stencil:o,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${bd}`),t.addEventListener("webglcontextlost",zn,!1),t.addEventListener("webglcontextrestored",Fn,!1),t.addEventListener("webglcontextcreationerror",Hi,!1),F===null){const G="webgl2";if(F=wn(G,w),F===null)throw wn(G)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(w){throw Lt("WebGLRenderer: "+w.message),w}let rn,P,y,z,J,oe,Ee,Ae,re,ue,Ne,ft,Oe,Ue,vt,Tt,Vt,k,Pe,le,Ie,ke,fe;function ut(){rn=new wb(F),rn.init(),Ie=new gT(F,rn),P=new xb(F,rn,e,Ie),y=new pT(F,rn),P.reversedDepthBuffer&&d&&y.buffers.depth.setReversed(!0),ne=F.createFramebuffer(),ae=F.createFramebuffer(),V=F.createFramebuffer(),z=new Rb(F),J=new eT,oe=new mT(F,rn,y,J,P,Ie,z),Ee=new Tb(D),Ae=new Ly(F),ke=new mb(F,Ae),re=new Eb(F,Ae,z,ke),ue=new Pb(F,re,Ae,ke,z),k=new Cb(F,P,oe),vt=new _b(J),Ne=new Q1(D,Ee,rn,P,ke,vt),ft=new ST(D,J),Oe=new nT,Ue=new cT(rn),Vt=new pb(D,Ee,y,ue,p,c),Tt=new fT(D,ue,P),fe=new bT(F,z,P,y),Pe=new gb(F,rn,z),le=new Ab(F,rn,z),z.programs=Ne.programs,D.capabilities=P,D.extensions=rn,D.properties=J,D.renderLists=Oe,D.shadowMap=Tt,D.state=y,D.info=z}ut(),x!==Yi&&(R=new Lb(x,t.width,t.height,a,s,o));const ot=new yT(D,F);this.xr=ot,this.getContext=function(){return F},this.getContextAttributes=function(){return F.getContextAttributes()},this.forceContextLoss=function(){const w=rn.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=rn.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return ye},this.setPixelRatio=function(w){w!==void 0&&(ye=w,this.setSize(ce,Ce,!1))},this.getSize=function(w){return w.set(ce,Ce)},this.setSize=function(w,G,ee=!0){if(ot.isPresenting){xt("WebGLRenderer: Can't change size while VR device is presenting.");return}ce=w,Ce=G,t.width=Math.floor(w*ye),t.height=Math.floor(G*ye),ee===!0&&(t.style.width=w+"px",t.style.height=G+"px"),R!==null&&R.setSize(t.width,t.height),this.setViewport(0,0,w,G)},this.getDrawingBufferSize=function(w){return w.set(ce*ye,Ce*ye).floor()},this.setDrawingBufferSize=function(w,G,ee){ce=w,Ce=G,ye=ee,t.width=Math.floor(w*ee),t.height=Math.floor(G*ee),this.setViewport(0,0,w,G)},this.setEffects=function(w){if(x===Yi){Lt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(w){for(let G=0;G<w.length;G++)if(w[G].isOutputPass===!0){xt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}R.setEffects(w||[])},this.getCurrentViewport=function(w){return w.copy(we)},this.getViewport=function(w){return w.copy(bt)},this.setViewport=function(w,G,ee,$){w.isVector4?bt.set(w.x,w.y,w.z,w.w):bt.set(w,G,ee,$),y.viewport(we.copy(bt).multiplyScalar(ye).round())},this.getScissor=function(w){return w.copy(xn)},this.setScissor=function(w,G,ee,$){w.isVector4?xn.set(w.x,w.y,w.z,w.w):xn.set(w,G,ee,$),y.scissor(Xe.copy(xn).multiplyScalar(ye).round())},this.getScissorTest=function(){return Bt},this.setScissorTest=function(w){y.setScissorTest(Bt=w)},this.setOpaqueSort=function(w){ht=w},this.setTransparentSort=function(w){Nt=w},this.getClearColor=function(w){return w.copy(Vt.getClearColor())},this.setClearColor=function(){Vt.setClearColor(...arguments)},this.getClearAlpha=function(){return Vt.getClearAlpha()},this.setClearAlpha=function(){Vt.setClearAlpha(...arguments)},this.clear=function(w=!0,G=!0,ee=!0){let $=0;if(w){let Y=!1;if(he!==null){const Ve=he.texture.format;Y=m.has(Ve)}if(Y){const Ve=he.texture.type,qe=g.has(Ve),He=Vt.getClearColor(),at=Vt.getClearAlpha(),pt=He.r,Ht=He.g,Xt=He.b;qe?(M[0]=pt,M[1]=Ht,M[2]=Xt,M[3]=at,F.clearBufferuiv(F.COLOR,0,M)):(S[0]=pt,S[1]=Ht,S[2]=Xt,S[3]=at,F.clearBufferiv(F.COLOR,0,S))}else $|=F.COLOR_BUFFER_BIT}G&&($|=F.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),ee&&($|=F.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),$!==0&&F.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(w){w.setRenderer(this),B=w},this.dispose=function(){t.removeEventListener("webglcontextlost",zn,!1),t.removeEventListener("webglcontextrestored",Fn,!1),t.removeEventListener("webglcontextcreationerror",Hi,!1),Vt.dispose(),Oe.dispose(),Ue.dispose(),J.dispose(),Ee.dispose(),ue.dispose(),ke.dispose(),fe.dispose(),Ne.dispose(),ot.dispose(),ot.removeEventListener("sessionstart",Wo),ot.removeEventListener("sessionend",wc),$s.stop()};function zn(w){w.preventDefault(),Cl("WebGLRenderer: Context Lost."),N=!0}function Fn(){Cl("WebGLRenderer: Context Restored."),N=!1;const w=z.autoReset,G=Tt.enabled,ee=Tt.autoUpdate,$=Tt.needsUpdate,Y=Tt.type;ut(),z.autoReset=w,Tt.enabled=G,Tt.autoUpdate=ee,Tt.needsUpdate=$,Tt.type=Y}function Hi(w){Lt("WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function Gi(w){const G=w.target;G.removeEventListener("dispose",Gi),Jl(G)}function Jl(w){jl(w),J.remove(w)}function jl(w){const G=J.get(w).programs;G!==void 0&&(G.forEach(function(ee){Ne.releaseProgram(ee)}),w.isShaderMaterial&&Ne.releaseShaderCache(w))}this.renderBufferDirect=function(w,G,ee,$,Y,Ve){G===null&&(G=dt);const qe=Y.isMesh&&Y.matrixWorld.determinantAffine()<0,He=Rc(w,G,ee,$,Y);y.setMaterial($,qe);let at=ee.index,pt=1;if($.wireframe===!0){if(at=re.getWireframeAttribute(ee),at===void 0)return;pt=2}const Ht=ee.drawRange,Xt=ee.attributes.position;let mt=Ht.start*pt,mn=(Ht.start+Ht.count)*pt;Ve!==null&&(mt=Math.max(mt,Ve.start*pt),mn=Math.min(mn,(Ve.start+Ve.count)*pt)),at!==null?(mt=Math.max(mt,0),mn=Math.min(mn,at.count)):Xt!=null&&(mt=Math.max(mt,0),mn=Math.min(mn,Xt.count));const Wn=mn-mt;if(Wn<0||Wn===1/0)return;ke.setup(Y,$,He,ee,at);let dn,Rt=Pe;if(at!==null&&(dn=Ae.get(at),Rt=le,Rt.setIndex(dn)),Y.isMesh)$.wireframe===!0?(y.setLineWidth($.wireframeLinewidth*Gt()),Rt.setMode(F.LINES)):Rt.setMode(F.TRIANGLES);else if(Y.isLine){let gi=$.linewidth;gi===void 0&&(gi=1),y.setLineWidth(gi*Gt()),Y.isLineSegments?Rt.setMode(F.LINES):Y.isLineLoop?Rt.setMode(F.LINE_LOOP):Rt.setMode(F.LINE_STRIP)}else Y.isPoints?Rt.setMode(F.POINTS):Y.isSprite&&Rt.setMode(F.TRIANGLES);if(Y.isBatchedMesh)if(rn.get("WEBGL_multi_draw"))Rt.renderMultiDraw(Y._multiDrawStarts,Y._multiDrawCounts,Y._multiDrawCount);else{const gi=Y._multiDrawStarts,Je=Y._multiDrawCounts,ni=Y._multiDrawCount,cn=at?Ae.get(at).bytesPerElement:1,wi=J.get($).currentProgram.getUniforms();for(let Di=0;Di<ni;Di++)wi.setValue(F,"_gl_DrawID",Di),Rt.render(gi[Di]/cn,Je[Di])}else if(Y.isInstancedMesh)Rt.renderInstances(mt,Wn,Y.count);else if(ee.isInstancedBufferGeometry){const gi=ee._maxInstanceCount!==void 0?ee._maxInstanceCount:1/0,Je=Math.min(ee.instanceCount,gi);Rt.renderInstances(mt,Wn,Je)}else Rt.render(mt,Wn)};function Tc(w,G,ee){w.transparent===!0&&w.side===xi&&w.forceSinglePass===!1?(w.side=Ii,w.needsUpdate=!0,Mr(w,G,ee),w.side=Mo,w.needsUpdate=!0,Mr(w,G,ee),w.side=xi):Mr(w,G,ee)}this.compile=function(w,G,ee=null){ee===null&&(ee=w),E=Ue.get(ee),E.init(G),v.push(E),ee.traverseVisible(function(Y){Y.isLight&&Y.layers.test(G.layers)&&(E.pushLight(Y),Y.castShadow&&E.pushShadow(Y))}),w!==ee&&w.traverseVisible(function(Y){Y.isLight&&Y.layers.test(G.layers)&&(E.pushLight(Y),Y.castShadow&&E.pushShadow(Y))}),E.setupLights();const $=new Set;return w.traverse(function(Y){if(!(Y.isMesh||Y.isPoints||Y.isLine||Y.isSprite))return;const Ve=Y.material;if(Ve)if(Array.isArray(Ve))for(let qe=0;qe<Ve.length;qe++){const He=Ve[qe];Tc(He,ee,Y),$.add(He)}else Tc(Ve,ee,Y),$.add(Ve)}),E=v.pop(),$},this.compileAsync=function(w,G,ee=null){const $=this.compile(w,G,ee);return new Promise(Y=>{function Ve(){if($.forEach(function(qe){J.get(qe).currentProgram.isReady()&&$.delete(qe)}),$.size===0){Y(w);return}setTimeout(Ve,10)}rn.get("KHR_parallel_shader_compile")!==null?Ve():setTimeout(Ve,10)})};let Zs=null;function xa(w){Zs&&Zs(w)}function Wo(){$s.stop()}function wc(){$s.start()}const $s=new A0;$s.setAnimationLoop(xa),typeof self<"u"&&$s.setContext(self),this.setAnimationLoop=function(w){Zs=w,ot.setAnimationLoop(w),w===null?$s.stop():$s.start()},ot.addEventListener("sessionstart",Wo),ot.addEventListener("sessionend",wc),this.render=function(w,G){if(G!==void 0&&G.isCamera!==!0){Lt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;B!==null&&B.renderStart(w,G);const ee=ot.enabled===!0&&ot.isPresenting===!0,$=R!==null&&(he===null||ee)&&R.begin(D,he);if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),G.parent===null&&G.matrixWorldAutoUpdate===!0&&G.updateMatrixWorld(),ot.enabled===!0&&ot.isPresenting===!0&&(R===null||R.isCompositing()===!1)&&(ot.cameraAutoUpdate===!0&&ot.updateCamera(G),G=ot.getCamera()),w.isScene===!0&&w.onBeforeRender(D,w,G,he),E=Ue.get(w,v.length),E.init(G),E.state.textureUnits=oe.getTextureUnits(),v.push(E),Be.multiplyMatrices(G.projectionMatrix,G.matrixWorldInverse),pe.setFromProjectionMatrix(Be,Gs,G.reversedDepth),ge=this.localClippingEnabled,ve=vt.init(this.clippingPlanes,ge),A=Oe.get(w,L.length),A.init(),L.push(A),ot.enabled===!0&&ot.isPresenting===!0){const qe=D.xr.getDepthSensingMesh();qe!==null&&_a(qe,G,-1/0,D.sortObjects)}_a(w,G,0,D.sortObjects),A.finish(),D.sortObjects===!0&&A.sort(ht,Nt,G.reversedDepth),Ut=ot.enabled===!1||ot.isPresenting===!1||ot.hasDepthSensing()===!1,Ut&&Vt.addToRenderList(A,w),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),ve===!0&&vt.beginShadows();const Y=E.state.shadowsArray;if(Tt.render(Y,w,G),ve===!0&&vt.endShadows(),($&&R.hasRenderPass())===!1){const qe=A.opaque,He=A.transmissive;if(E.setupLights(),G.isArrayCamera){const at=G.cameras;if(He.length>0)for(let pt=0,Ht=at.length;pt<Ht;pt++){const Xt=at[pt];va(qe,He,w,Xt)}Ut&&Vt.render(w);for(let pt=0,Ht=at.length;pt<Ht;pt++){const Xt=at[pt];Ao(A,w,Xt,Xt.viewport)}}else He.length>0&&va(qe,He,w,G),Ut&&Vt.render(w),Ao(A,w,G)}he!==null&&K===0&&(oe.updateMultisampleRenderTarget(he),oe.updateRenderTargetMipmap(he)),$&&R.end(D),w.isScene===!0&&w.onAfterRender(D,w,G),ke.resetDefaultState(),me=-1,Re=null,v.pop(),v.length>0?(E=v[v.length-1],oe.setTextureUnits(E.state.textureUnits),ve===!0&&vt.setGlobalState(D.clippingPlanes,E.state.camera)):E=null,L.pop(),L.length>0?A=L[L.length-1]:A=null,B!==null&&B.renderEnd()};function _a(w,G,ee,$){if(w.visible===!1)return;if(w.layers.test(G.layers)){if(w.isGroup)ee=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(G);else if(w.isLightProbeGrid)E.pushLightProbeGrid(w);else if(w.isLight)E.pushLight(w),w.castShadow&&E.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||pe.intersectsSprite(w)){$&&Et.setFromMatrixPosition(w.matrixWorld).applyMatrix4(Be);const qe=ue.update(w),He=w.material;He.visible&&A.push(w,qe,He,ee,Et.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||pe.intersectsObject(w))){const qe=ue.update(w),He=w.material;if($&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Et.copy(w.boundingSphere.center)):(qe.boundingSphere===null&&qe.computeBoundingSphere(),Et.copy(qe.boundingSphere.center)),Et.applyMatrix4(w.matrixWorld).applyMatrix4(Be)),Array.isArray(He)){const at=qe.groups;for(let pt=0,Ht=at.length;pt<Ht;pt++){const Xt=at[pt],mt=He[Xt.materialIndex];mt&&mt.visible&&A.push(w,qe,mt,ee,Et.z,Xt)}}else He.visible&&A.push(w,qe,He,ee,Et.z,null)}}const Ve=w.children;for(let qe=0,He=Ve.length;qe<He;qe++)_a(Ve[qe],G,ee,$)}function Ao(w,G,ee,$){const{opaque:Y,transmissive:Ve,transparent:qe}=w;E.setupLightsView(ee),ve===!0&&vt.setGlobalState(D.clippingPlanes,ee),$&&y.viewport(we.copy($)),Y.length>0&&yr(Y,G,ee),Ve.length>0&&yr(Ve,G,ee),qe.length>0&&yr(qe,G,ee),y.buffers.depth.setTest(!0),y.buffers.depth.setMask(!0),y.buffers.color.setMask(!0),y.setPolygonOffset(!1)}function va(w,G,ee,$){if((ee.isScene===!0?ee.overrideMaterial:null)!==null)return;if(E.state.transmissionRenderTarget[$.id]===void 0){const mt=rn.has("EXT_color_buffer_half_float")||rn.has("EXT_color_buffer_float");E.state.transmissionRenderTarget[$.id]=new zs(1,1,{generateMipmaps:!0,type:mt?So:Yi,minFilter:Hs,samples:Math.max(4,P.samples),stencilBuffer:o,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:un.workingColorSpace})}const Ve=E.state.transmissionRenderTarget[$.id],qe=$.viewport||we;Ve.setSize(qe.z*D.transmissionResolutionScale,qe.w*D.transmissionResolutionScale);const He=D.getRenderTarget(),at=D.getActiveCubeFace(),pt=D.getActiveMipmapLevel();D.setRenderTarget(Ve),D.getClearColor(hn),Qt=D.getClearAlpha(),Qt<1&&D.setClearColor(16777215,.5),D.clear(),Ut&&Vt.render(ee);const Ht=D.toneMapping;D.toneMapping=Vs;const Xt=$.viewport;if($.viewport!==void 0&&($.viewport=void 0),E.setupLightsView($),ve===!0&&vt.setGlobalState(D.clippingPlanes,$),yr(w,ee,$),oe.updateMultisampleRenderTarget(Ve),oe.updateRenderTargetMipmap(Ve),rn.has("WEBGL_multisampled_render_to_texture")===!1){let mt=!1;for(let mn=0,Wn=G.length;mn<Wn;mn++){const dn=G[mn],{object:Rt,geometry:gi,material:Je,group:ni}=dn;if(Je.side===xi&&Rt.layers.test($.layers)){const cn=Je.side;Je.side=Ii,Je.needsUpdate=!0,ya(Rt,ee,$,gi,Je,ni),Je.side=cn,Je.needsUpdate=!0,mt=!0}}mt===!0&&(oe.updateMultisampleRenderTarget(Ve),oe.updateRenderTargetMipmap(Ve))}D.setRenderTarget(He,at,pt),D.setClearColor(hn,Qt),Xt!==void 0&&($.viewport=Xt),D.toneMapping=Ht}function yr(w,G,ee){const $=G.isScene===!0?G.overrideMaterial:null;for(let Y=0,Ve=w.length;Y<Ve;Y++){const qe=w[Y],{object:He,geometry:at,group:pt}=qe;let Ht=qe.material;Ht.allowOverride===!0&&$!==null&&(Ht=$),He.layers.test(ee.layers)&&ya(He,G,ee,at,Ht,pt)}}function ya(w,G,ee,$,Y,Ve){w.onBeforeRender(D,G,ee,$,Y,Ve),w.modelViewMatrix.multiplyMatrices(ee.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),Y.onBeforeRender(D,G,ee,$,w,Ve),Y.transparent===!0&&Y.side===xi&&Y.forceSinglePass===!1?(Y.side=Ii,Y.needsUpdate=!0,D.renderBufferDirect(ee,G,$,Y,w,Ve),Y.side=Mo,Y.needsUpdate=!0,D.renderBufferDirect(ee,G,$,Y,w,Ve),Y.side=xi):D.renderBufferDirect(ee,G,$,Y,w,Ve),w.onAfterRender(D,G,ee,$,Y,Ve)}function Mr(w,G,ee){G.isScene!==!0&&(G=dt);const $=J.get(w),Y=E.state.lights,Ve=E.state.shadowsArray,qe=Y.state.version,He=Ne.getParameters(w,Y.state,Ve,G,ee,E.state.lightProbeGridArray),at=Ne.getProgramCacheKey(He);let pt=$.programs;$.environment=w.isMeshStandardMaterial||w.isMeshLambertMaterial||w.isMeshPhongMaterial?G.environment:null,$.fog=G.fog;const Ht=w.isMeshStandardMaterial||w.isMeshLambertMaterial&&!w.envMap||w.isMeshPhongMaterial&&!w.envMap;$.envMap=Ee.get(w.envMap||$.environment,Ht),$.envMapRotation=$.environment!==null&&w.envMap===null?G.environmentRotation:w.envMapRotation,pt===void 0&&(w.addEventListener("dispose",Gi),pt=new Map,$.programs=pt);let Xt=pt.get(at);if(Xt!==void 0){if($.currentProgram===Xt&&$.lightsStateVersion===qe)return Ac(w,He),Xt}else He.uniforms=Ne.getUniforms(w),B!==null&&w.isNodeMaterial&&B.build(w,ee,He),w.onBeforeCompile(He,D),Xt=Ne.acquireProgram(He,at),pt.set(at,Xt),$.uniforms=He.uniforms;const mt=$.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(mt.clippingPlanes=vt.uniform),Ac(w,He),$.needsLights=eu(w),$.lightsStateVersion=qe,$.needsLights&&(mt.ambientLightColor.value=Y.state.ambient,mt.lightProbe.value=Y.state.probe,mt.directionalLights.value=Y.state.directional,mt.directionalLightShadows.value=Y.state.directionalShadow,mt.spotLights.value=Y.state.spot,mt.spotLightShadows.value=Y.state.spotShadow,mt.rectAreaLights.value=Y.state.rectArea,mt.ltc_1.value=Y.state.rectAreaLTC1,mt.ltc_2.value=Y.state.rectAreaLTC2,mt.pointLights.value=Y.state.point,mt.pointLightShadows.value=Y.state.pointShadow,mt.hemisphereLights.value=Y.state.hemi,mt.directionalShadowMatrix.value=Y.state.directionalShadowMatrix,mt.spotLightMatrix.value=Y.state.spotLightMatrix,mt.spotLightMap.value=Y.state.spotLightMap,mt.pointShadowMatrix.value=Y.state.pointShadowMatrix),$.lightProbeGrid=E.state.lightProbeGridArray.length>0,$.currentProgram=Xt,$.uniformsList=null,Xt}function Ec(w){if(w.uniformsList===null){const G=w.currentProgram.getUniforms();w.uniformsList=_l.seqWithValue(G.seq,w.uniforms)}return w.uniformsList}function Ac(w,G){const ee=J.get(w);ee.outputColorSpace=G.outputColorSpace,ee.batching=G.batching,ee.batchingColor=G.batchingColor,ee.instancing=G.instancing,ee.instancingColor=G.instancingColor,ee.instancingMorph=G.instancingMorph,ee.skinning=G.skinning,ee.morphTargets=G.morphTargets,ee.morphNormals=G.morphNormals,ee.morphColors=G.morphColors,ee.morphTargetsCount=G.morphTargetsCount,ee.numClippingPlanes=G.numClippingPlanes,ee.numIntersection=G.numClipIntersection,ee.vertexAlphas=G.vertexAlphas,ee.vertexTangents=G.vertexTangents,ee.toneMapping=G.toneMapping}function Xo(w,G){if(w.length===0)return null;if(w.length===1)return w[0].texture!==null?w[0]:null;_.setFromMatrixPosition(G.matrixWorld);for(let ee=0,$=w.length;ee<$;ee++){const Y=w[ee];if(Y.texture!==null&&Y.boundingBox.containsPoint(_))return Y}return null}function Rc(w,G,ee,$,Y){G.isScene!==!0&&(G=dt),oe.resetTextureUnits();const Ve=G.fog,qe=$.isMeshStandardMaterial||$.isMeshLambertMaterial||$.isMeshPhongMaterial?G.environment:null,He=he===null?D.outputColorSpace:he.isXRRenderTarget===!0?he.texture.colorSpace:un.workingColorSpace,at=$.isMeshStandardMaterial||$.isMeshLambertMaterial&&!$.envMap||$.isMeshPhongMaterial&&!$.envMap,pt=Ee.get($.envMap||qe,at),Ht=$.vertexColors===!0&&!!ee.attributes.color&&ee.attributes.color.itemSize===4,Xt=!!ee.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),mt=!!ee.morphAttributes.position,mn=!!ee.morphAttributes.normal,Wn=!!ee.morphAttributes.color;let dn=Vs;$.toneMapped&&(he===null||he.isXRRenderTarget===!0)&&(dn=D.toneMapping);const Rt=ee.morphAttributes.position||ee.morphAttributes.normal||ee.morphAttributes.color,gi=Rt!==void 0?Rt.length:0,Je=J.get($),ni=E.state.lights;if(ve===!0&&(ge===!0||w!==Re)){const An=w===Re&&$.id===me;vt.setState($,w,An)}let cn=!1;$.version===Je.__version?(Je.needsLights&&Je.lightsStateVersion!==ni.state.version||Je.outputColorSpace!==He||Y.isBatchedMesh&&Je.batching===!1||!Y.isBatchedMesh&&Je.batching===!0||Y.isBatchedMesh&&Je.batchingColor===!0&&Y.colorTexture===null||Y.isBatchedMesh&&Je.batchingColor===!1&&Y.colorTexture!==null||Y.isInstancedMesh&&Je.instancing===!1||!Y.isInstancedMesh&&Je.instancing===!0||Y.isSkinnedMesh&&Je.skinning===!1||!Y.isSkinnedMesh&&Je.skinning===!0||Y.isInstancedMesh&&Je.instancingColor===!0&&Y.instanceColor===null||Y.isInstancedMesh&&Je.instancingColor===!1&&Y.instanceColor!==null||Y.isInstancedMesh&&Je.instancingMorph===!0&&Y.morphTexture===null||Y.isInstancedMesh&&Je.instancingMorph===!1&&Y.morphTexture!==null||Je.envMap!==pt||$.fog===!0&&Je.fog!==Ve||Je.numClippingPlanes!==void 0&&(Je.numClippingPlanes!==vt.numPlanes||Je.numIntersection!==vt.numIntersection)||Je.vertexAlphas!==Ht||Je.vertexTangents!==Xt||Je.morphTargets!==mt||Je.morphNormals!==mn||Je.morphColors!==Wn||Je.toneMapping!==dn||Je.morphTargetsCount!==gi||!!Je.lightProbeGrid!=E.state.lightProbeGridArray.length>0)&&(cn=!0):(cn=!0,Je.__version=$.version);let wi=Je.currentProgram;cn===!0&&(wi=Mr($,G,Y),B&&$.isNodeMaterial&&B.onUpdateProgram($,wi,Je));let Di=!1,ji=!1,Js=!1;const En=wi.getUniforms(),$n=Je.uniforms;if(y.useProgram(wi.program)&&(Di=!0,ji=!0,Js=!0),$.id!==me&&(me=$.id,ji=!0),Je.needsLights){const An=Xo(E.state.lightProbeGridArray,Y);Je.lightProbeGrid!==An&&(Je.lightProbeGrid=An,ji=!0)}if(Di||Re!==w){y.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),En.setValue(F,"projectionMatrix",w.projectionMatrix),En.setValue(F,"viewMatrix",w.matrixWorldInverse);const ds=En.map.cameraPosition;ds!==void 0&&ds.setValue(F,Fe.setFromMatrixPosition(w.matrixWorld)),P.logarithmicDepthBuffer&&En.setValue(F,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&En.setValue(F,"isOrthographic",w.isOrthographicCamera===!0),Re!==w&&(Re=w,ji=!0,Js=!0)}if(Je.needsLights&&(ni.state.directionalShadowMap.length>0&&En.setValue(F,"directionalShadowMap",ni.state.directionalShadowMap,oe),ni.state.spotShadowMap.length>0&&En.setValue(F,"spotShadowMap",ni.state.spotShadowMap,oe),ni.state.pointShadowMap.length>0&&En.setValue(F,"pointShadowMap",ni.state.pointShadowMap,oe)),Y.isSkinnedMesh){En.setOptional(F,Y,"bindMatrix"),En.setOptional(F,Y,"bindMatrixInverse");const An=Y.skeleton;An&&(An.boneTexture===null&&An.computeBoneTexture(),En.setValue(F,"boneTexture",An.boneTexture,oe))}Y.isBatchedMesh&&(En.setOptional(F,Y,"batchingTexture"),En.setValue(F,"batchingTexture",Y._matricesTexture,oe),En.setOptional(F,Y,"batchingIdTexture"),En.setValue(F,"batchingIdTexture",Y._indirectTexture,oe),En.setOptional(F,Y,"batchingColorTexture"),Y._colorsTexture!==null&&En.setValue(F,"batchingColorTexture",Y._colorsTexture,oe));const Qi=ee.morphAttributes;if((Qi.position!==void 0||Qi.normal!==void 0||Qi.color!==void 0)&&k.update(Y,ee,wi),(ji||Je.receiveShadow!==Y.receiveShadow)&&(Je.receiveShadow=Y.receiveShadow,En.setValue(F,"receiveShadow",Y.receiveShadow)),($.isMeshStandardMaterial||$.isMeshLambertMaterial||$.isMeshPhongMaterial)&&$.envMap===null&&G.environment!==null&&($n.envMapIntensity.value=G.environmentIntensity),$n.dfgLUT!==void 0&&($n.dfgLUT.value=wT()),ji){if(En.setValue(F,"toneMappingExposure",D.toneMappingExposure),Je.needsLights&&Ql($n,Js),Ve&&$.fog===!0&&ft.refreshFogUniforms($n,Ve),ft.refreshMaterialUniforms($n,$,ye,Ce,E.state.transmissionRenderTarget[w.id]),Je.needsLights&&Je.lightProbeGrid){const An=Je.lightProbeGrid;$n.probesSH.value=An.texture,$n.probesMin.value.copy(An.boundingBox.min),$n.probesMax.value.copy(An.boundingBox.max),$n.probesResolution.value.copy(An.resolution)}_l.upload(F,Ec(Je),$n,oe)}if($.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(_l.upload(F,Ec(Je),$n,oe),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&En.setValue(F,"center",Y.center),En.setValue(F,"modelViewMatrix",Y.modelViewMatrix),En.setValue(F,"normalMatrix",Y.normalMatrix),En.setValue(F,"modelMatrix",Y.matrixWorld),$.uniformsGroups!==void 0){const An=$.uniformsGroups;for(let ds=0,As=An.length;ds<As;ds++){const qo=An[ds];fe.update(qo,wi),fe.bind(qo,wi)}}return wi}function Ql(w,G){w.ambientLightColor.needsUpdate=G,w.lightProbe.needsUpdate=G,w.directionalLights.needsUpdate=G,w.directionalLightShadows.needsUpdate=G,w.pointLights.needsUpdate=G,w.pointLightShadows.needsUpdate=G,w.spotLights.needsUpdate=G,w.spotLightShadows.needsUpdate=G,w.rectAreaLights.needsUpdate=G,w.hemisphereLights.needsUpdate=G}function eu(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return se},this.getActiveMipmapLevel=function(){return K},this.getRenderTarget=function(){return he},this.setRenderTargetTextures=function(w,G,ee){const $=J.get(w);$.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,$.__autoAllocateDepthBuffer===!1&&($.__useRenderToTexture=!1),J.get(w.texture).__webglTexture=G,J.get(w.depthTexture).__webglTexture=$.__autoAllocateDepthBuffer?void 0:ee,$.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,G){const ee=J.get(w);ee.__webglFramebuffer=G,ee.__useDefaultFramebuffer=G===void 0},this.setRenderTarget=function(w,G=0,ee=0){he=w,se=G,K=ee;let $=null,Y=!1,Ve=!1;if(w){const He=J.get(w);if(He.__useDefaultFramebuffer!==void 0){y.bindFramebuffer(F.FRAMEBUFFER,He.__webglFramebuffer),we.copy(w.viewport),Xe.copy(w.scissor),$t=w.scissorTest,y.viewport(we),y.scissor(Xe),y.setScissorTest($t),me=-1;return}else if(He.__webglFramebuffer===void 0)oe.setupRenderTarget(w);else if(He.__hasExternalTextures)oe.rebindTextures(w,J.get(w.texture).__webglTexture,J.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const Ht=w.depthTexture;if(He.__boundDepthTexture!==Ht){if(Ht!==null&&J.has(Ht)&&(w.width!==Ht.image.width||w.height!==Ht.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");oe.setupDepthRenderbuffer(w)}}const at=w.texture;(at.isData3DTexture||at.isDataArrayTexture||at.isCompressedArrayTexture)&&(Ve=!0);const pt=J.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(pt[G])?$=pt[G][ee]:$=pt[G],Y=!0):w.samples>0&&oe.useMultisampledRTT(w)===!1?$=J.get(w).__webglMultisampledFramebuffer:Array.isArray(pt)?$=pt[ee]:$=pt,we.copy(w.viewport),Xe.copy(w.scissor),$t=w.scissorTest}else we.copy(bt).multiplyScalar(ye).floor(),Xe.copy(xn).multiplyScalar(ye).floor(),$t=Bt;if(ee!==0&&($=ne),y.bindFramebuffer(F.FRAMEBUFFER,$)&&y.drawBuffers(w,$),y.viewport(we),y.scissor(Xe),y.setScissorTest($t),Y){const He=J.get(w.texture);F.framebufferTexture2D(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_CUBE_MAP_POSITIVE_X+G,He.__webglTexture,ee)}else if(Ve){const He=G;for(let at=0;at<w.textures.length;at++){const pt=J.get(w.textures[at]);F.framebufferTextureLayer(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0+at,pt.__webglTexture,ee,He)}}else if(w!==null&&ee!==0){const He=J.get(w.texture);F.framebufferTexture2D(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_2D,He.__webglTexture,ee)}me=-1},this.readRenderTargetPixels=function(w,G,ee,$,Y,Ve,qe,He=0){if(!(w&&w.isWebGLRenderTarget)){Lt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let at=J.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&qe!==void 0&&(at=at[qe]),at){y.bindFramebuffer(F.FRAMEBUFFER,at);try{const pt=w.textures[He],Ht=pt.format,Xt=pt.type;if(w.textures.length>1&&F.readBuffer(F.COLOR_ATTACHMENT0+He),!P.textureFormatReadable(Ht)){Lt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!P.textureTypeReadable(Xt)){Lt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}G>=0&&G<=w.width-$&&ee>=0&&ee<=w.height-Y&&F.readPixels(G,ee,$,Y,Ie.convert(Ht),Ie.convert(Xt),Ve)}finally{const pt=he!==null?J.get(he).__webglFramebuffer:null;y.bindFramebuffer(F.FRAMEBUFFER,pt)}}},this.readRenderTargetPixelsAsync=async function(w,G,ee,$,Y,Ve,qe,He=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let at=J.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&qe!==void 0&&(at=at[qe]),at)if(G>=0&&G<=w.width-$&&ee>=0&&ee<=w.height-Y){y.bindFramebuffer(F.FRAMEBUFFER,at);const pt=w.textures[He],Ht=pt.format,Xt=pt.type;if(w.textures.length>1&&F.readBuffer(F.COLOR_ATTACHMENT0+He),!P.textureFormatReadable(Ht))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!P.textureTypeReadable(Xt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const mt=F.createBuffer();F.bindBuffer(F.PIXEL_PACK_BUFFER,mt),F.bufferData(F.PIXEL_PACK_BUFFER,Ve.byteLength,F.STREAM_READ),F.readPixels(G,ee,$,Y,Ie.convert(Ht),Ie.convert(Xt),0);const mn=he!==null?J.get(he).__webglFramebuffer:null;y.bindFramebuffer(F.FRAMEBUFFER,mn);const Wn=F.fenceSync(F.SYNC_GPU_COMMANDS_COMPLETE,0);return F.flush(),await x_(F,Wn,4),F.bindBuffer(F.PIXEL_PACK_BUFFER,mt),F.getBufferSubData(F.PIXEL_PACK_BUFFER,0,Ve),F.deleteBuffer(mt),F.deleteSync(Wn),Ve}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,G=null,ee=0){const $=Math.pow(2,-ee),Y=Math.floor(w.image.width*$),Ve=Math.floor(w.image.height*$),qe=G!==null?G.x:0,He=G!==null?G.y:0;oe.setTexture2D(w,0),F.copyTexSubImage2D(F.TEXTURE_2D,ee,0,0,qe,He,Y,Ve),y.unbindTexture()},this.copyTextureToTexture=function(w,G,ee=null,$=null,Y=0,Ve=0){let qe,He,at,pt,Ht,Xt,mt,mn,Wn;const dn=w.isCompressedTexture?w.mipmaps[Ve]:w.image;if(ee!==null)qe=ee.max.x-ee.min.x,He=ee.max.y-ee.min.y,at=ee.isBox3?ee.max.z-ee.min.z:1,pt=ee.min.x,Ht=ee.min.y,Xt=ee.isBox3?ee.min.z:0;else{const $n=Math.pow(2,-Y);qe=Math.floor(dn.width*$n),He=Math.floor(dn.height*$n),w.isDataArrayTexture?at=dn.depth:w.isData3DTexture?at=Math.floor(dn.depth*$n):at=1,pt=0,Ht=0,Xt=0}$!==null?(mt=$.x,mn=$.y,Wn=$.z):(mt=0,mn=0,Wn=0);const Rt=Ie.convert(G.format),gi=Ie.convert(G.type);let Je;G.isData3DTexture?(oe.setTexture3D(G,0),Je=F.TEXTURE_3D):G.isDataArrayTexture||G.isCompressedArrayTexture?(oe.setTexture2DArray(G,0),Je=F.TEXTURE_2D_ARRAY):(oe.setTexture2D(G,0),Je=F.TEXTURE_2D),y.activeTexture(F.TEXTURE0),y.pixelStorei(F.UNPACK_FLIP_Y_WEBGL,G.flipY),y.pixelStorei(F.UNPACK_PREMULTIPLY_ALPHA_WEBGL,G.premultiplyAlpha),y.pixelStorei(F.UNPACK_ALIGNMENT,G.unpackAlignment);const ni=y.getParameter(F.UNPACK_ROW_LENGTH),cn=y.getParameter(F.UNPACK_IMAGE_HEIGHT),wi=y.getParameter(F.UNPACK_SKIP_PIXELS),Di=y.getParameter(F.UNPACK_SKIP_ROWS),ji=y.getParameter(F.UNPACK_SKIP_IMAGES);y.pixelStorei(F.UNPACK_ROW_LENGTH,dn.width),y.pixelStorei(F.UNPACK_IMAGE_HEIGHT,dn.height),y.pixelStorei(F.UNPACK_SKIP_PIXELS,pt),y.pixelStorei(F.UNPACK_SKIP_ROWS,Ht),y.pixelStorei(F.UNPACK_SKIP_IMAGES,Xt);const Js=w.isDataArrayTexture||w.isData3DTexture,En=G.isDataArrayTexture||G.isData3DTexture;if(w.isDepthTexture){const $n=J.get(w),Qi=J.get(G),An=J.get($n.__renderTarget),ds=J.get(Qi.__renderTarget);y.bindFramebuffer(F.READ_FRAMEBUFFER,An.__webglFramebuffer),y.bindFramebuffer(F.DRAW_FRAMEBUFFER,ds.__webglFramebuffer);for(let As=0;As<at;As++)Js&&(F.framebufferTextureLayer(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,J.get(w).__webglTexture,Y,Xt+As),F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,J.get(G).__webglTexture,Ve,Wn+As)),F.blitFramebuffer(pt,Ht,qe,He,mt,mn,qe,He,F.DEPTH_BUFFER_BIT,F.NEAREST);y.bindFramebuffer(F.READ_FRAMEBUFFER,null),y.bindFramebuffer(F.DRAW_FRAMEBUFFER,null)}else if(Y!==0||w.isRenderTargetTexture||J.has(w)){const $n=J.get(w),Qi=J.get(G);y.bindFramebuffer(F.READ_FRAMEBUFFER,ae),y.bindFramebuffer(F.DRAW_FRAMEBUFFER,V);for(let An=0;An<at;An++)Js?F.framebufferTextureLayer(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,$n.__webglTexture,Y,Xt+An):F.framebufferTexture2D(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_2D,$n.__webglTexture,Y),En?F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,Qi.__webglTexture,Ve,Wn+An):F.framebufferTexture2D(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_2D,Qi.__webglTexture,Ve),Y!==0?F.blitFramebuffer(pt,Ht,qe,He,mt,mn,qe,He,F.COLOR_BUFFER_BIT,F.NEAREST):En?F.copyTexSubImage3D(Je,Ve,mt,mn,Wn+An,pt,Ht,qe,He):F.copyTexSubImage2D(Je,Ve,mt,mn,pt,Ht,qe,He);y.bindFramebuffer(F.READ_FRAMEBUFFER,null),y.bindFramebuffer(F.DRAW_FRAMEBUFFER,null)}else En?w.isDataTexture||w.isData3DTexture?F.texSubImage3D(Je,Ve,mt,mn,Wn,qe,He,at,Rt,gi,dn.data):G.isCompressedArrayTexture?F.compressedTexSubImage3D(Je,Ve,mt,mn,Wn,qe,He,at,Rt,dn.data):F.texSubImage3D(Je,Ve,mt,mn,Wn,qe,He,at,Rt,gi,dn):w.isDataTexture?F.texSubImage2D(F.TEXTURE_2D,Ve,mt,mn,qe,He,Rt,gi,dn.data):w.isCompressedTexture?F.compressedTexSubImage2D(F.TEXTURE_2D,Ve,mt,mn,dn.width,dn.height,Rt,dn.data):F.texSubImage2D(F.TEXTURE_2D,Ve,mt,mn,qe,He,Rt,gi,dn);y.pixelStorei(F.UNPACK_ROW_LENGTH,ni),y.pixelStorei(F.UNPACK_IMAGE_HEIGHT,cn),y.pixelStorei(F.UNPACK_SKIP_PIXELS,wi),y.pixelStorei(F.UNPACK_SKIP_ROWS,Di),y.pixelStorei(F.UNPACK_SKIP_IMAGES,ji),Ve===0&&G.generateMipmaps&&F.generateMipmap(Je),y.unbindTexture()},this.initRenderTarget=function(w){J.get(w).__webglFramebuffer===void 0&&oe.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?oe.setTextureCube(w,0):w.isData3DTexture?oe.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?oe.setTexture2DArray(w,0):oe.setTexture2D(w,0),y.unbindTexture()},this.resetState=function(){se=0,K=0,he=null,y.reset(),ke.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Gs}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=un._getDrawingBufferColorSpace(e),t.unpackColorSpace=un._getUnpackColorSpace()}}class Kl extends W{constructor(){const e=Kl.SkyShader,t=new hs({name:e.name,uniforms:y0.clone(e.uniforms),vertexShader:e.vertexShader,fragmentShader:e.fragmentShader,side:Ii,depthWrite:!1});super(new fn(1,1,1),t),this.isSky=!0}}Kl.SkyShader={name:"SkyShader",uniforms:{turbidity:{value:2},rayleigh:{value:1},mieCoefficient:{value:.005},mieDirectionalG:{value:.8},sunPosition:{value:new I},up:{value:new I(0,1,0)},cloudScale:{value:2e-4},cloudSpeed:{value:1e-4},cloudCoverage:{value:.4},cloudDensity:{value:.4},cloudElevation:{value:.5},showSunDisc:{value:1},time:{value:0}},vertexShader:`
		uniform vec3 sunPosition;
		uniform float rayleigh;
		uniform float turbidity;
		uniform float mieCoefficient;
		uniform vec3 up;

		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		// constants for atmospheric scattering
		const float e = 2.71828182845904523536028747135266249775724709369995957;
		const float pi = 3.141592653589793238462643383279502884197169;

		// wavelength of used primaries, according to preetham
		const vec3 lambda = vec3( 680E-9, 550E-9, 450E-9 );
		// this pre-calculation replaces older TotalRayleigh(vec3 lambda) function:
		// (8.0 * pow(pi, 3.0) * pow(pow(n, 2.0) - 1.0, 2.0) * (6.0 + 3.0 * pn)) / (3.0 * N * pow(lambda, vec3(4.0)) * (6.0 - 7.0 * pn))
		const vec3 totalRayleigh = vec3( 5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5 );

		// mie stuff
		// K coefficient for the primaries
		const float v = 4.0;
		const vec3 K = vec3( 0.686, 0.678, 0.666 );
		// MieConst = pi * pow( ( 2.0 * pi ) / lambda, vec3( v - 2.0 ) ) * K
		const vec3 MieConst = vec3( 1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14 );

		// earth shadow hack
		// cutoffAngle = pi / 1.95;
		const float cutoffAngle = 1.6110731556870734;
		const float steepness = 1.5;
		const float EE = 1000.0;

		float sunIntensity( float zenithAngleCos ) {
			zenithAngleCos = clamp( zenithAngleCos, -1.0, 1.0 );
			return EE * max( 0.0, 1.0 - pow( e, -( ( cutoffAngle - acos( zenithAngleCos ) ) / steepness ) ) );
		}

		vec3 totalMie( float T ) {
			float c = ( 0.2 * T ) * 10E-18;
			return 0.434 * c * MieConst;
		}

		void main() {

			vec4 worldPosition = modelMatrix * vec4( position, 1.0 );
			vWorldPosition = worldPosition.xyz;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			gl_Position.z = gl_Position.w; // set z to camera.far

			vSunDirection = normalize( sunPosition );

			vSunE = sunIntensity( dot( vSunDirection, up ) );

			vSunfade = 1.0 - clamp( 1.0 - exp( ( sunPosition.y / 450000.0 ) ), 0.0, 1.0 );

			float rayleighCoefficient = rayleigh - ( 1.0 * ( 1.0 - vSunfade ) );

			// extinction (absorption + out scattering)
			// rayleigh coefficients
			vBetaR = totalRayleigh * rayleighCoefficient;

			// mie coefficients
			vBetaM = totalMie( turbidity ) * mieCoefficient;

		}`,fragmentShader:`
		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		uniform float mieDirectionalG;
		uniform vec3 up;
		uniform float cloudScale;
		uniform float cloudSpeed;
		uniform float cloudCoverage;
		uniform float cloudDensity;
		uniform float cloudElevation;
		uniform float showSunDisc;
		uniform float time;

		// Cloud noise functions
		float hash( vec2 p ) {
			return fract( sin( dot( p, vec2( 127.1, 311.7 ) ) ) * 43758.5453123 );
		}

		float noise( vec2 p ) {
			vec2 i = floor( p );
			vec2 f = fract( p );
			f = f * f * ( 3.0 - 2.0 * f );
			float a = hash( i );
			float b = hash( i + vec2( 1.0, 0.0 ) );
			float c = hash( i + vec2( 0.0, 1.0 ) );
			float d = hash( i + vec2( 1.0, 1.0 ) );
			return mix( mix( a, b, f.x ), mix( c, d, f.x ), f.y );
		}

		float fbm( vec2 p ) {
			float value = 0.0;
			float amplitude = 0.5;
			for ( int i = 0; i < 5; i ++ ) {
				value += amplitude * noise( p );
				p *= 2.0;
				amplitude *= 0.5;
			}
			return value;
		}

		// constants for atmospheric scattering
		const float pi = 3.141592653589793238462643383279502884197169;

		const float n = 1.0003; // refractive index of air
		const float N = 2.545E25; // number of molecules per unit volume for air at 288.15K and 1013mb (sea level -45 celsius)

		// optical length at zenith for molecules
		const float rayleighZenithLength = 8.4E3;
		const float mieZenithLength = 1.25E3;
		// 66 arc seconds -> degrees, and the cosine of that
		const float sunAngularDiameterCos = 0.999956676946448443553574619906976478926848692873900859324;

		// 3.0 / ( 16.0 * pi )
		const float THREE_OVER_SIXTEENPI = 0.05968310365946075;
		// 1.0 / ( 4.0 * pi )
		const float ONE_OVER_FOURPI = 0.07957747154594767;

		float rayleighPhase( float cosTheta ) {
			return THREE_OVER_SIXTEENPI * ( 1.0 + pow( cosTheta, 2.0 ) );
		}

		float hgPhase( float cosTheta, float g ) {
			float g2 = pow( g, 2.0 );
			float inverse = 1.0 / pow( 1.0 - 2.0 * g * cosTheta + g2, 1.5 );
			return ONE_OVER_FOURPI * ( ( 1.0 - g2 ) * inverse );
		}

		void main() {

			vec3 direction = normalize( vWorldPosition - cameraPosition );

			// optical length
			// cutoff angle at 90 to avoid singularity in next formula.
			float zenithAngle = acos( max( 0.0, dot( up, direction ) ) );
			float inverse = 1.0 / ( cos( zenithAngle ) + 0.15 * pow( 93.885 - ( ( zenithAngle * 180.0 ) / pi ), -1.253 ) );
			float sR = rayleighZenithLength * inverse;
			float sM = mieZenithLength * inverse;

			// combined extinction factor
			vec3 Fex = exp( -( vBetaR * sR + vBetaM * sM ) );

			// in scattering
			float cosTheta = dot( direction, vSunDirection );

			float rPhase = rayleighPhase( cosTheta * 0.5 + 0.5 );
			vec3 betaRTheta = vBetaR * rPhase;

			float mPhase = hgPhase( cosTheta, mieDirectionalG );
			vec3 betaMTheta = vBetaM * mPhase;

			vec3 Lin = pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * ( 1.0 - Fex ), vec3( 1.5 ) );
			Lin *= mix( vec3( 1.0 ), pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * Fex, vec3( 1.0 / 2.0 ) ), clamp( pow( 1.0 - dot( up, vSunDirection ), 5.0 ), 0.0, 1.0 ) );

			// nightsky
			float theta = acos( direction.y ); // elevation --> y-axis, [-pi/2, pi/2]
			float phi = atan( direction.z, direction.x ); // azimuth --> x-axis [-pi/2, pi/2]
			vec2 uv = vec2( phi, theta ) / vec2( 2.0 * pi, pi ) + vec2( 0.5, 0.0 );
			vec3 L0 = vec3( 0.1 ) * Fex;

			// composition + solar disc
			float sundisc = smoothstep( sunAngularDiameterCos, sunAngularDiameterCos + 0.00002, cosTheta ) * showSunDisc;
			L0 += ( vSunE * 19000.0 * Fex ) * sundisc;

			vec3 texColor = ( Lin + L0 ) * 0.04 + vec3( 0.0, 0.0003, 0.00075 );

			// Clouds
			if ( direction.y > 0.0 && cloudCoverage > 0.0 ) {

				// Project to cloud plane (higher elevation = clouds appear lower/closer)
				float elevation = mix( 1.0, 0.1, cloudElevation );
				vec2 cloudUV = direction.xz / ( direction.y * elevation );
				cloudUV *= cloudScale;
				cloudUV += time * cloudSpeed;

				// Multi-octave noise for fluffy clouds
				float cloudNoise = fbm( cloudUV * 1000.0 );
				cloudNoise += 0.5 * fbm( cloudUV * 2000.0 + 3.7 );
				cloudNoise = cloudNoise * 0.5 + 0.5;

				// Apply coverage threshold
				float cloudMask = smoothstep( 1.0 - cloudCoverage, 1.0 - cloudCoverage + 0.3, cloudNoise );

				// Fade clouds near horizon (adjusted by elevation)
				float horizonFade = smoothstep( 0.0, 0.1 + 0.2 * cloudElevation, direction.y );
				cloudMask *= horizonFade;

				// Cloud lighting based on sun position
				float sunInfluence = dot( direction, vSunDirection ) * 0.5 + 0.5;
				float daylight = max( 0.0, vSunDirection.y * 2.0 );

				// Base cloud color affected by atmosphere
				vec3 atmosphereColor = Lin * 0.04;
				vec3 cloudColor = mix( vec3( 0.3 ), vec3( 1.0 ), daylight );
				cloudColor = mix( cloudColor, atmosphereColor + vec3( 1.0 ), sunInfluence * 0.5 );
				cloudColor *= vSunE * 0.00002;

				// Blend clouds with sky
				texColor = mix( texColor, cloudColor, cloudMask * cloudDensity );

			}

			gl_FragColor = vec4( texColor, 1.0 );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>

		}`};function om(i,e){if(e===o_)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===Xh||e===e0){let t=i.getIndex();if(t===null){const r=[],a=i.getAttribute("position");if(a!==void 0){for(let c=0;c<a.count;c++)r.push(c);i.setIndex(r),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}const n=t.count-2,s=[];if(e===Xh)for(let r=1;r<=n;r++)s.push(t.getX(0)),s.push(t.getX(r)),s.push(t.getX(r+1));else for(let r=0;r<n;r++)r%2===0?(s.push(t.getX(r)),s.push(t.getX(r+1)),s.push(t.getX(r+2))):(s.push(t.getX(r+2)),s.push(t.getX(r+1)),s.push(t.getX(r)));s.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const o=i.clone();return o.setIndex(s),o.clearGroups(),o}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}function AT(i){const e=new Map,t=new Map,n=i.clone();return U0(i,n,function(s,o){e.set(o,s),t.set(s,o)}),n.traverse(function(s){if(!s.isSkinnedMesh)return;const o=s,r=e.get(s),a=r.skeleton.bones;o.skeleton=r.skeleton.clone(),o.bindMatrix.copy(r.bindMatrix),o.skeleton.bones=a.map(function(c){return t.get(c)}),o.bind(o.skeleton,o.bindMatrix)}),n}function U0(i,e,t){t(i,e);for(let n=0;n<i.children.length;n++)U0(i.children[n],e.children[n],t)}class F0 extends fa{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new LT(t)}),this.register(function(t){return new DT(t)}),this.register(function(t){return new VT(t)}),this.register(function(t){return new zT(t)}),this.register(function(t){return new WT(t)}),this.register(function(t){return new UT(t)}),this.register(function(t){return new FT(t)}),this.register(function(t){return new OT(t)}),this.register(function(t){return new BT(t)}),this.register(function(t){return new IT(t)}),this.register(function(t){return new kT(t)}),this.register(function(t){return new NT(t)}),this.register(function(t){return new GT(t)}),this.register(function(t){return new HT(t)}),this.register(function(t){return new CT(t)}),this.register(function(t){return new rm(t,an.EXT_MESHOPT_COMPRESSION)}),this.register(function(t){return new rm(t,an.KHR_MESHOPT_COMPRESSION)}),this.register(function(t){return new XT(t)})}load(e,t,n,s){const o=this;let r;if(this.resourcePath!=="")r=this.resourcePath;else if(this.path!==""){const l=Za.extractUrlBase(e);r=Za.resolveURL(l,this.path)}else r=Za.extractUrlBase(e);this.manager.itemStart(e);const a=function(l){s?s(l):console.error(l),o.manager.itemError(e),o.manager.itemEnd(e)},c=new b0(this.manager);c.setPath(this.path),c.setResponseType("arraybuffer"),c.setRequestHeader(this.requestHeader),c.setWithCredentials(this.withCredentials),c.load(e,function(l){try{o.parse(l,r,function(u){t(u),o.manager.itemEnd(e)},a)}catch(u){a(u)}},n,a)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,s){let o;const r={},a={},c=new TextDecoder;if(typeof e=="string")o=JSON.parse(e);else if(e instanceof ArrayBuffer)if(c.decode(new Uint8Array(e,0,4))===O0){try{r[an.KHR_BINARY_GLTF]=new qT(e)}catch(h){s&&s(h);return}o=JSON.parse(r[an.KHR_BINARY_GLTF].content)}else o=JSON.parse(c.decode(e));else o=e;if(o.asset===void 0||o.asset.version[0]<2){s&&s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const l=new ow(o,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let u=0;u<this.pluginCallbacks.length;u++){const h=this.pluginCallbacks[u](l);h.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),a[h.name]=h,r[h.name]=!0}if(o.extensionsUsed)for(let u=0;u<o.extensionsUsed.length;++u){const h=o.extensionsUsed[u],d=o.extensionsRequired||[];switch(h){case an.KHR_MATERIALS_UNLIT:r[h]=new PT;break;case an.KHR_DRACO_MESH_COMPRESSION:r[h]=new YT(o,this.dracoLoader);break;case an.KHR_TEXTURE_TRANSFORM:r[h]=new KT;break;case an.KHR_MESH_QUANTIZATION:r[h]=new ZT;break;default:d.indexOf(h)>=0&&a[h]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+h+'".')}}l.setExtensions(r),l.setPlugins(a),l.parse(n,s)}parseAsync(e,t){const n=this;return new Promise(function(s,o){n.parse(e,t,s,o)})}}function RT(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}function ui(i,e,t){const n=i.json.materials[e];return n.extensions&&n.extensions[t]?n.extensions[t]:null}const an={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",KHR_MESHOPT_COMPRESSION:"KHR_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class CT{constructor(e){this.parser=e,this.name=an.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const e=this.parser,t=this.parser.json.nodes||[];for(let n=0,s=t.length;n<s;n++){const o=t[n];o.extensions&&o.extensions[this.name]&&o.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,o.extensions[this.name].light)}}_loadLight(e){const t=this.parser,n="light:"+e;let s=t.cache.get(n);if(s)return s;const o=t.json,c=((o.extensions&&o.extensions[this.name]||{}).lights||[])[e];let l;const u=new Qe(16777215);c.color!==void 0&&u.setRGB(c.color[0],c.color[1],c.color[2],Ji);const h=c.range!==void 0?c.range:0;switch(c.type){case"directional":l=new E0(u),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new w0(u),l.distance=h;break;case"spot":l=new uy(u),l.distance=h,c.spot=c.spot||{},c.spot.innerConeAngle=c.spot.innerConeAngle!==void 0?c.spot.innerConeAngle:0,c.spot.outerConeAngle=c.spot.outerConeAngle!==void 0?c.spot.outerConeAngle:Math.PI/4,l.angle=c.spot.outerConeAngle,l.penumbra=1-c.spot.innerConeAngle/c.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+c.type)}return l.position.set(0,0,0),Ns(l,c),c.intensity!==void 0&&(l.intensity=c.intensity),l.name=t.createUniqueName(c.name||"light_"+e),s=Promise.resolve(l),t.cache.add(n,s),s}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){const t=this,n=this.parser,o=n.json.nodes[e],a=(o.extensions&&o.extensions[this.name]||{}).light;return a===void 0?null:this._loadLight(a).then(function(c){return n._getNodeRef(t.cache,a,c)})}}class PT{constructor(){this.name=an.KHR_MATERIALS_UNLIT}getMaterialType(){return bn}extendParams(e,t,n){const s=[];e.color=new Qe(1,1,1),e.opacity=1;const o=t.pbrMetallicRoughness;if(o){if(Array.isArray(o.baseColorFactor)){const r=o.baseColorFactor;e.color.setRGB(r[0],r[1],r[2],Ji),e.opacity=r[3]}o.baseColorTexture!==void 0&&s.push(n.assignTexture(e,"map",o.baseColorTexture,Yn))}return Promise.all(s)}}class IT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);return n===null||n.emissiveStrength!==void 0&&(t.emissiveIntensity=n.emissiveStrength),Promise.resolve()}}class LT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];if(n.clearcoatFactor!==void 0&&(t.clearcoat=n.clearcoatFactor),n.clearcoatTexture!==void 0&&s.push(this.parser.assignTexture(t,"clearcoatMap",n.clearcoatTexture)),n.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=n.clearcoatRoughnessFactor),n.clearcoatRoughnessTexture!==void 0&&s.push(this.parser.assignTexture(t,"clearcoatRoughnessMap",n.clearcoatRoughnessTexture)),n.clearcoatNormalTexture!==void 0&&(s.push(this.parser.assignTexture(t,"clearcoatNormalMap",n.clearcoatNormalTexture)),n.clearcoatNormalTexture.scale!==void 0)){const o=n.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new _e(o,o)}return Promise.all(s)}}class DT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_DISPERSION}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);return n===null||(t.dispersion=n.dispersion!==void 0?n.dispersion:0),Promise.resolve()}}class NT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];return n.iridescenceFactor!==void 0&&(t.iridescence=n.iridescenceFactor),n.iridescenceTexture!==void 0&&s.push(this.parser.assignTexture(t,"iridescenceMap",n.iridescenceTexture)),n.iridescenceIor!==void 0&&(t.iridescenceIOR=n.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),n.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=n.iridescenceThicknessMinimum),n.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=n.iridescenceThicknessMaximum),n.iridescenceThicknessTexture!==void 0&&s.push(this.parser.assignTexture(t,"iridescenceThicknessMap",n.iridescenceThicknessTexture)),Promise.all(s)}}class UT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_SHEEN}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];if(t.sheenColor=new Qe(0,0,0),t.sheenRoughness=0,t.sheen=1,n.sheenColorFactor!==void 0){const o=n.sheenColorFactor;t.sheenColor.setRGB(o[0],o[1],o[2],Ji)}return n.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=n.sheenRoughnessFactor),n.sheenColorTexture!==void 0&&s.push(this.parser.assignTexture(t,"sheenColorMap",n.sheenColorTexture,Yn)),n.sheenRoughnessTexture!==void 0&&s.push(this.parser.assignTexture(t,"sheenRoughnessMap",n.sheenRoughnessTexture)),Promise.all(s)}}class FT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];return n.transmissionFactor!==void 0&&(t.transmission=n.transmissionFactor),n.transmissionTexture!==void 0&&s.push(this.parser.assignTexture(t,"transmissionMap",n.transmissionTexture)),Promise.all(s)}}class OT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_VOLUME}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];t.thickness=n.thicknessFactor!==void 0?n.thicknessFactor:0,n.thicknessTexture!==void 0&&s.push(this.parser.assignTexture(t,"thicknessMap",n.thicknessTexture)),t.attenuationDistance=n.attenuationDistance||1/0;const o=n.attenuationColor||[1,1,1];return t.attenuationColor=new Qe().setRGB(o[0],o[1],o[2],Ji),Promise.all(s)}}class BT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_IOR}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);return n===null||(t.ior=n.ior!==void 0?n.ior:1.5,t.ior===0&&(t.ior=1e3)),Promise.resolve()}}class kT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_SPECULAR}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];t.specularIntensity=n.specularFactor!==void 0?n.specularFactor:1,n.specularTexture!==void 0&&s.push(this.parser.assignTexture(t,"specularIntensityMap",n.specularTexture));const o=n.specularColorFactor||[1,1,1];return t.specularColor=new Qe().setRGB(o[0],o[1],o[2],Ji),n.specularColorTexture!==void 0&&s.push(this.parser.assignTexture(t,"specularColorMap",n.specularColorTexture,Yn)),Promise.all(s)}}class HT{constructor(e){this.parser=e,this.name=an.EXT_MATERIALS_BUMP}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];return t.bumpScale=n.bumpFactor!==void 0?n.bumpFactor:1,n.bumpTexture!==void 0&&s.push(this.parser.assignTexture(t,"bumpMap",n.bumpTexture)),Promise.all(s)}}class GT{constructor(e){this.parser=e,this.name=an.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){return ui(this.parser,e,this.name)!==null?pi:null}extendMaterialParams(e,t){const n=ui(this.parser,e,this.name);if(n===null)return Promise.resolve();const s=[];return n.anisotropyStrength!==void 0&&(t.anisotropy=n.anisotropyStrength),n.anisotropyRotation!==void 0&&(t.anisotropyRotation=n.anisotropyRotation),n.anisotropyTexture!==void 0&&s.push(this.parser.assignTexture(t,"anisotropyMap",n.anisotropyTexture)),Promise.all(s)}}class VT{constructor(e){this.parser=e,this.name=an.KHR_TEXTURE_BASISU}loadTexture(e){const t=this.parser,n=t.json,s=n.textures[e];if(!s.extensions||!s.extensions[this.name])return null;const o=s.extensions[this.name],r=t.options.ktx2Loader;if(!r){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,o.source,r)}}class zT{constructor(e){this.parser=e,this.name=an.EXT_TEXTURE_WEBP}loadTexture(e){const t=this.name,n=this.parser,s=n.json,o=s.textures[e];if(!o.extensions||!o.extensions[t])return null;const r=o.extensions[t],a=s.images[r.source];let c=n.textureLoader;if(a.uri){const l=n.options.manager.getHandler(a.uri);l!==null&&(c=l)}return n.loadTextureImage(e,r.source,c)}}class WT{constructor(e){this.parser=e,this.name=an.EXT_TEXTURE_AVIF}loadTexture(e){const t=this.name,n=this.parser,s=n.json,o=s.textures[e];if(!o.extensions||!o.extensions[t])return null;const r=o.extensions[t],a=s.images[r.source];let c=n.textureLoader;if(a.uri){const l=n.options.manager.getHandler(a.uri);l!==null&&(c=l)}return n.loadTextureImage(e,r.source,c)}}class rm{constructor(e,t){this.name=t,this.parser=e}loadBufferView(e){const t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){const s=n.extensions[this.name],o=this.parser.getDependency("buffer",s.buffer),r=this.parser.options.meshoptDecoder;if(!r||!r.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return o.then(function(a){const c=s.byteOffset||0,l=s.byteLength||0,u=s.count,h=s.byteStride,d=new Uint8Array(a,c,l);return r.decodeGltfBufferAsync?r.decodeGltfBufferAsync(u,h,d,s.mode,s.filter).then(function(f){return f.buffer}):r.ready.then(function(){const f=new ArrayBuffer(u*h);return r.decodeGltfBuffer(new Uint8Array(f),u,h,d,s.mode,s.filter),f})})}else return null}}class XT{constructor(e){this.name=an.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){const t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;const s=t.meshes[n.mesh];for(const l of s.primitives)if(l.mode!==ss.TRIANGLES&&l.mode!==ss.TRIANGLE_STRIP&&l.mode!==ss.TRIANGLE_FAN&&l.mode!==void 0)return null;const r=n.extensions[this.name].attributes,a=[],c={};for(const l in r)a.push(this.parser.getDependency("accessor",r[l]).then(u=>(c[l]=u,c[l])));return a.length<1?null:(a.push(this.parser.createNodeMesh(e)),Promise.all(a).then(l=>{const u=l.pop(),h=u.isGroup?u.children:[u],d=l[0].count,f=[];for(const p of h){const x=new Wt,m=new I,g=new ci,M=new I(1,1,1),S=new di(p.geometry,p.material,d);for(let _=0;_<d;_++)c.TRANSLATION&&m.fromBufferAttribute(c.TRANSLATION,_),c.ROTATION&&g.fromBufferAttribute(c.ROTATION,_),c.SCALE&&M.fromBufferAttribute(c.SCALE,_),S.setMatrixAt(_,x.compose(m,g,M));for(const _ in c)if(_==="_COLOR_0"){const A=c[_];S.instanceColor=new Yh(A.array,A.itemSize,A.normalized)}else _!=="TRANSLATION"&&_!=="ROTATION"&&_!=="SCALE"&&p.geometry.setAttribute(_,c[_]);kn.prototype.copy.call(S,p),this.parser.assignFinalMaterial(S),f.push(S)}return u.isGroup?(u.clear(),u.add(...f),u):f[0]}))}}const O0="glTF",La=12,am={JSON:1313821514,BIN:5130562};class qT{constructor(e){this.name=an.KHR_BINARY_GLTF,this.content=null,this.body=null;const t=new DataView(e,0,La),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==O0)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const s=this.header.length-La,o=new DataView(e,La);let r=0;for(;r<s;){const a=o.getUint32(r,!0);r+=4;const c=o.getUint32(r,!0);if(r+=4,c===am.JSON){const l=new Uint8Array(e,La+r,a);this.content=n.decode(l)}else if(c===am.BIN){const l=La+r;this.body=e.slice(l,l+a)}r+=a}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class YT{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=an.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){const n=this.json,s=this.dracoLoader,o=e.extensions[this.name].bufferView,r=e.extensions[this.name].attributes,a={},c={},l={};for(const u in r){const h=td[u]||u.toLowerCase();a[h]=r[u]}for(const u in e.attributes){const h=td[u]||u.toLowerCase();if(r[u]!==void 0){const d=n.accessors[e.attributes[u]],f=Kr[d.componentType];l[h]=f.name,c[h]=d.normalized===!0}}return t.getDependency("bufferView",o).then(function(u){return new Promise(function(h,d){s.decodeDracoFile(u,function(f){for(const p in f.attributes){const x=f.attributes[p],m=c[p];m!==void 0&&(x.normalized=m)}h(f)},a,l,Ji,d)})})}}class KT{constructor(){this.name=an.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}}class ZT{constructor(){this.name=an.KHR_MESH_QUANTIZATION}}class B0 extends ua{constructor(e,t,n,s){super(e,t,n,s)}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,o=e*s*3+s;for(let r=0;r!==s;r++)t[r]=n[o+r];return t}interpolate_(e,t,n,s){const o=this.resultBuffer,r=this.sampleValues,a=this.valueSize,c=a*2,l=a*3,u=s-t,h=(n-t)/u,d=h*h,f=d*h,p=e*l,x=p-l,m=-2*f+3*d,g=f-d,M=1-m,S=g-d+h;for(let _=0;_!==a;_++){const A=r[x+_+a],E=r[x+_+c]*u,L=r[p+_+a],v=r[p+_]*u;o[_]=M*A+S*E+m*L+g*v}return o}}const $T=new ci;class JT extends B0{interpolate_(e,t,n,s){const o=super.interpolate_(e,t,n,s);return $T.fromArray(o).normalize().toArray(o),o}}const ss={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},Kr={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},cm={9728:vi,9729:mi,9984:qm,9985:fl,9986:Na,9987:Hs},lm={33071:ks,33648:bl,10497:mr},qu={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},td={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},No={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},jT={CUBICSPLINE:void 0,LINEAR:rc,STEP:oc},Yu={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function QT(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new lt({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:Mo})),i.DefaultMaterial}function Qo(i,e,t){for(const n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Ns(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function ew(i,e,t){let n=!1,s=!1,o=!1;for(let l=0,u=e.length;l<u;l++){const h=e[l];if(h.POSITION!==void 0&&(n=!0),h.NORMAL!==void 0&&(s=!0),h.COLOR_0!==void 0&&(o=!0),n&&s&&o)break}if(!n&&!s&&!o)return Promise.resolve(i);const r=[],a=[],c=[];for(let l=0,u=e.length;l<u;l++){const h=e[l];if(n){const d=h.POSITION!==void 0?t.getDependency("accessor",h.POSITION):i.attributes.position;r.push(d)}if(s){const d=h.NORMAL!==void 0?t.getDependency("accessor",h.NORMAL):i.attributes.normal;a.push(d)}if(o){const d=h.COLOR_0!==void 0?t.getDependency("accessor",h.COLOR_0):i.attributes.color;c.push(d)}}return Promise.all([Promise.all(r),Promise.all(a),Promise.all(c)]).then(function(l){const u=l[0],h=l[1],d=l[2];return n&&(i.morphAttributes.position=u),s&&(i.morphAttributes.normal=h),o&&(i.morphAttributes.color=d),i.morphTargetsRelative=!0,i})}function tw(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){const t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,s=t.length;n<s;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function nw(i){let e;const t=i.extensions&&i.extensions[an.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+Ku(t.attributes):e=i.indices+":"+Ku(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,s=i.targets.length;n<s;n++)e+=":"+Ku(i.targets[n]);return e}function Ku(i){let e="";const t=Object.keys(i).sort();for(let n=0,s=t.length;n<s;n++)e+=t[n]+":"+i[t[n]]+";";return e}function nd(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function iw(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":i.search(/\.ktx2($|\?)/i)>0||i.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const sw=new Wt;class ow{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new RT,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,s=-1,o=!1,r=-1;if(typeof navigator<"u"&&typeof navigator.userAgent<"u"){const a=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(a)===!0;const c=a.match(/Version\/(\d+)/);s=n&&c?parseInt(c[1],10):-1,o=a.indexOf("Firefox")>-1,r=o?a.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&s<17||o&&r<98?this.textureLoader=new ay(this.options.manager):this.textureLoader=new py(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new b0(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){const n=this,s=this.json,o=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(r){return r._markDefs&&r._markDefs()}),Promise.all(this._invokeAll(function(r){return r.beforeRoot&&r.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(r){const a={scene:r[0][s.scene||0],scenes:r[0],animations:r[1],cameras:r[2],asset:s.asset,parser:n,userData:{}};return Qo(o,a,s),Ns(a,s),Promise.all(n._invokeAll(function(c){return c.afterRoot&&c.afterRoot(a)})).then(function(){for(const c of a.scenes)c.updateMatrixWorld();e(a)})}).catch(t)}_markDefs(){const e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let s=0,o=t.length;s<o;s++){const r=t[s].joints;for(let a=0,c=r.length;a<c;a++)e[r[a]].isBone=!0}for(let s=0,o=e.length;s<o;s++){const r=e[s];r.mesh!==void 0&&(this._addNodeRef(this.meshCache,r.mesh),r.skin!==void 0&&(n[r.mesh].isSkinnedMesh=!0)),r.camera!==void 0&&this._addNodeRef(this.cameraCache,r.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;const s=n.clone(),o=(r,a)=>{const c=this.associations.get(r);c!=null&&this.associations.set(a,c);for(const[l,u]of r.children.entries())o(u,a.children[l])};return o(n,s),s.name+="_instance_"+e.uses[t]++,s}_invokeOne(e){const t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){const s=e(t[n]);if(s)return s}return null}_invokeAll(e){const t=Object.values(this.plugins);t.unshift(this);const n=[];for(let s=0;s<t.length;s++){const o=e(t[s]);o&&n.push(o)}return n}getDependency(e,t){const n=e+":"+t;let s=this.cache.get(n);if(!s){switch(e){case"scene":s=this.loadScene(t);break;case"node":s=this._invokeOne(function(o){return o.loadNode&&o.loadNode(t)});break;case"mesh":s=this._invokeOne(function(o){return o.loadMesh&&o.loadMesh(t)});break;case"accessor":s=this.loadAccessor(t);break;case"bufferView":s=this._invokeOne(function(o){return o.loadBufferView&&o.loadBufferView(t)});break;case"buffer":s=this.loadBuffer(t);break;case"material":s=this._invokeOne(function(o){return o.loadMaterial&&o.loadMaterial(t)});break;case"texture":s=this._invokeOne(function(o){return o.loadTexture&&o.loadTexture(t)});break;case"skin":s=this.loadSkin(t);break;case"animation":s=this._invokeOne(function(o){return o.loadAnimation&&o.loadAnimation(t)});break;case"camera":s=this.loadCamera(t);break;default:if(s=this._invokeOne(function(o){return o!=this&&o.getDependency&&o.getDependency(e,t)}),!s)throw new Error("Unknown type: "+e);break}this.cache.add(n,s)}return s}getDependencies(e){let t=this.cache.get(e);if(!t){const n=this,s=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(s.map(function(o,r){return n.getDependency(e,r)})),this.cache.add(e,t)}return t}loadBuffer(e){const t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[an.KHR_BINARY_GLTF].body);const s=this.options;return new Promise(function(o,r){n.load(Za.resolveURL(t.uri,s.path),o,void 0,function(){r(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){const t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){const s=t.byteLength||0,o=t.byteOffset||0;return n.slice(o,o+s)})}loadAccessor(e){const t=this,n=this.json,s=this.json.accessors[e];if(s.bufferView===void 0&&s.sparse===void 0){const r=qu[s.type],a=Kr[s.componentType],c=s.normalized===!0,l=new a(s.count*r);return Promise.resolve(new Li(l,r,c))}const o=[];return s.bufferView!==void 0?o.push(this.getDependency("bufferView",s.bufferView)):o.push(null),s.sparse!==void 0&&(o.push(this.getDependency("bufferView",s.sparse.indices.bufferView)),o.push(this.getDependency("bufferView",s.sparse.values.bufferView))),Promise.all(o).then(function(r){const a=r[0],c=qu[s.type],l=Kr[s.componentType],u=l.BYTES_PER_ELEMENT,h=u*c,d=s.byteOffset||0,f=s.bufferView!==void 0?n.bufferViews[s.bufferView].byteStride:void 0,p=s.normalized===!0;let x,m;if(f&&f!==h){const g=Math.floor(d/f),M="InterleavedBuffer:"+s.bufferView+":"+s.componentType+":"+g+":"+s.count;let S=t.cache.get(M);S||(x=new l(a,g*f,s.count*f/u),S=new j_(x,f/u),t.cache.add(M,S)),m=new kd(S,c,d%f/u,p)}else a===null?x=new l(s.count*c):x=new l(a,d,s.count*c),m=new Li(x,c,p);if(s.sparse!==void 0){const g=qu.SCALAR,M=Kr[s.sparse.indices.componentType],S=s.sparse.indices.byteOffset||0,_=s.sparse.values.byteOffset||0,A=new M(r[1],S,s.sparse.count*g),E=new l(r[2],_,s.sparse.count*c);a!==null&&(m=new Li(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let L=0,v=A.length;L<v;L++){const R=A[L];if(m.setX(R,E[L*c]),c>=2&&m.setY(R,E[L*c+1]),c>=3&&m.setZ(R,E[L*c+2]),c>=4&&m.setW(R,E[L*c+3]),c>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=p}return m})}loadTexture(e){const t=this.json,n=this.options,o=t.textures[e].source,r=t.images[o];let a=this.textureLoader;if(r.uri){const c=n.manager.getHandler(r.uri);c!==null&&(a=c)}return this.loadTextureImage(e,o,a)}loadTextureImage(e,t,n){const s=this,o=this.json,r=o.textures[e],a=o.images[t],c=(a.uri||a.bufferView)+":"+r.sampler;if(this.textureCache[c])return this.textureCache[c];const l=this.loadImageSource(t,n).then(function(u){u.flipY=!1,u.name=r.name||a.name||"",u.name===""&&typeof a.uri=="string"&&a.uri.startsWith("data:image/")===!1&&(u.name=a.uri);const d=(o.samplers||{})[r.sampler]||{};return u.magFilter=cm[d.magFilter]||mi,u.minFilter=cm[d.minFilter]||Hs,u.wrapS=lm[d.wrapS]||mr,u.wrapT=lm[d.wrapT]||mr,u.generateMipmaps=!u.isCompressedTexture&&u.minFilter!==vi&&u.minFilter!==mi,s.associations.set(u,{textures:e}),u}).catch(function(){return null});return this.textureCache[c]=l,l}loadImageSource(e,t){const n=this,s=this.json,o=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(h=>h.clone());const r=s.images[e],a=self.URL||self.webkitURL;let c=r.uri||"",l=!1;if(r.bufferView!==void 0)c=n.getDependency("bufferView",r.bufferView).then(function(h){l=!0;const d=new Blob([h],{type:r.mimeType});return c=a.createObjectURL(d),c});else if(r.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");const u=Promise.resolve(c).then(function(h){return new Promise(function(d,f){let p=d;t.isImageBitmapLoader===!0&&(p=function(x){const m=new bi(x);m.needsUpdate=!0,d(m)}),t.load(Za.resolveURL(h,o.path),p,void 0,f)})}).then(function(h){return l===!0&&a.revokeObjectURL(c),Ns(h,r),h.userData.mimeType=r.mimeType||iw(r.uri),h}).catch(function(h){throw console.error("THREE.GLTFLoader: Couldn't load texture",c),h});return this.sourceCache[e]=u,u}assignTexture(e,t,n,s){const o=this;return this.getDependency("texture",n.index).then(function(r){if(!r)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(r=r.clone(),r.channel=n.texCoord),o.extensions[an.KHR_TEXTURE_TRANSFORM]){const a=n.extensions!==void 0?n.extensions[an.KHR_TEXTURE_TRANSFORM]:void 0;if(a){const c=o.associations.get(r);r=o.extensions[an.KHR_TEXTURE_TRANSFORM].extendTexture(r,a),o.associations.set(r,c)}}return s!==void 0&&(r.colorSpace=s),e[t]=r,r})}assignFinalMaterial(e){const t=e.geometry;let n=e.material;const s=t.attributes.tangent===void 0,o=t.attributes.color!==void 0,r=t.attributes.normal===void 0;if(e.isPoints){const a="PointsMaterial:"+n.uuid;let c=this.cache.get(a);c||(c=new zd,Ts.prototype.copy.call(c,n),c.color.copy(n.color),c.map=n.map,c.sizeAttenuation=!1,this.cache.add(a,c)),n=c}else if(e.isLine){const a="LineBasicMaterial:"+n.uuid;let c=this.cache.get(a);c||(c=new Vd,Ts.prototype.copy.call(c,n),c.color.copy(n.color),c.map=n.map,this.cache.add(a,c)),n=c}if(s||o||r){let a="ClonedMaterial:"+n.uuid+":";s&&(a+="derivative-tangents:"),o&&(a+="vertex-colors:"),r&&(a+="flat-shading:");let c=this.cache.get(a);c||(c=n.clone(),o&&(c.vertexColors=!0),r&&(c.flatShading=!0),s&&(c.normalScale&&(c.normalScale.y*=-1),c.clearcoatNormalScale&&(c.clearcoatNormalScale.y*=-1)),this.cache.add(a,c),this.associations.set(c,this.associations.get(n))),n=c}e.material=n}getMaterialType(){return lt}loadMaterial(e){const t=this,n=this.json,s=this.extensions,o=n.materials[e];let r;const a={},c=o.extensions||{},l=[];if(c[an.KHR_MATERIALS_UNLIT]){const h=s[an.KHR_MATERIALS_UNLIT];r=h.getMaterialType(),l.push(h.extendParams(a,o,t))}else{const h=o.pbrMetallicRoughness||{};if(a.color=new Qe(1,1,1),a.opacity=1,Array.isArray(h.baseColorFactor)){const d=h.baseColorFactor;a.color.setRGB(d[0],d[1],d[2],Ji),a.opacity=d[3]}h.baseColorTexture!==void 0&&l.push(t.assignTexture(a,"map",h.baseColorTexture,Yn)),a.metalness=h.metallicFactor!==void 0?h.metallicFactor:1,a.roughness=h.roughnessFactor!==void 0?h.roughnessFactor:1,h.metallicRoughnessTexture!==void 0&&(l.push(t.assignTexture(a,"metalnessMap",h.metallicRoughnessTexture)),l.push(t.assignTexture(a,"roughnessMap",h.metallicRoughnessTexture))),r=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(e,a)})))}o.doubleSided===!0&&(a.side=xi);const u=o.alphaMode||Yu.OPAQUE;if(u===Yu.BLEND?(a.transparent=!0,a.depthWrite=!1):(a.transparent=!1,u===Yu.MASK&&(a.alphaTest=o.alphaCutoff!==void 0?o.alphaCutoff:.5)),o.normalTexture!==void 0&&r!==bn&&(l.push(t.assignTexture(a,"normalMap",o.normalTexture)),a.normalScale=new _e(1,1),o.normalTexture.scale!==void 0)){const h=o.normalTexture.scale;a.normalScale.set(h,h)}if(o.occlusionTexture!==void 0&&r!==bn&&(l.push(t.assignTexture(a,"aoMap",o.occlusionTexture)),o.occlusionTexture.strength!==void 0&&(a.aoMapIntensity=o.occlusionTexture.strength)),o.emissiveFactor!==void 0&&r!==bn){const h=o.emissiveFactor;a.emissive=new Qe().setRGB(h[0],h[1],h[2],Ji)}return o.emissiveTexture!==void 0&&r!==bn&&l.push(t.assignTexture(a,"emissiveMap",o.emissiveTexture,Yn)),Promise.all(l).then(function(){const h=new r(a);return o.name&&(h.name=o.name),Ns(h,o),t.associations.set(h,{materials:e}),o.extensions&&Qo(s,h,o),h})}createUniqueName(e){const t=Rn.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){const t=this,n=this.extensions,s=this.primitiveCache;function o(a){return n[an.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a,t).then(function(c){return um(c,a,t)})}const r=[];for(let a=0,c=e.length;a<c;a++){const l=e[a],u=nw(l),h=s[u];if(h)r.push(h.promise);else{let d;l.extensions&&l.extensions[an.KHR_DRACO_MESH_COMPRESSION]?d=o(l):d=um(new Tn,l,t),s[u]={primitive:l,promise:d},r.push(d)}}return Promise.all(r)}loadMesh(e){const t=this,n=this.json,s=this.extensions,o=n.meshes[e],r=o.primitives,a=[];for(let c=0,l=r.length;c<l;c++){const u=r[c].material===void 0?QT(this.cache):this.getDependency("material",r[c].material);a.push(u)}return a.push(t.loadGeometries(r)),Promise.all(a).then(function(c){const l=c.slice(0,c.length-1),u=c[c.length-1],h=[];for(let f=0,p=u.length;f<p;f++){const x=u[f],m=r[f];let g;const M=l[f];if(m.mode===ss.TRIANGLES||m.mode===ss.TRIANGLE_STRIP||m.mode===ss.TRIANGLE_FAN||m.mode===void 0)g=o.isSkinnedMesh===!0?new nv(x,M):new W(x,M),g.isSkinnedMesh===!0&&g.normalizeSkinWeights(),m.mode===ss.TRIANGLE_STRIP?g.geometry=om(g.geometry,e0):m.mode===ss.TRIANGLE_FAN&&(g.geometry=om(g.geometry,Xh));else if(m.mode===ss.LINES)g=new cv(x,M);else if(m.mode===ss.LINE_STRIP)g=new Wl(x,M);else if(m.mode===ss.LINE_LOOP)g=new lv(x,M);else if(m.mode===ss.POINTS)g=new a0(x,M);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(g.geometry.morphAttributes).length>0&&tw(g,o),g.name=t.createUniqueName(o.name||"mesh_"+e),Ns(g,o),m.extensions&&Qo(s,g,m),t.assignFinalMaterial(g),h.push(g)}for(let f=0,p=h.length;f<p;f++)t.associations.set(h[f],{meshes:e,primitives:f});if(h.length===1)return o.extensions&&Qo(s,h[0],o),h[0];const d=new pn;o.extensions&&Qo(s,d,o),t.associations.set(d,{meshes:e});for(let f=0,p=h.length;f<p;f++)d.add(h[f]);return d})}loadCamera(e){let t;const n=this.json.cameras[e],s=n[n.type];if(!s){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Bi(Ui.radToDeg(s.yfov),s.aspectRatio||1,s.znear||1,s.zfar||2e6):n.type==="orthographic"&&(t=new Xl(-s.xmag,s.xmag,s.ymag,-s.ymag,s.znear,s.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Ns(t,n),Promise.resolve(t)}loadSkin(e){const t=this.json.skins[e],n=[];for(let s=0,o=t.joints.length;s<o;s++)n.push(this._loadNodeShallow(t.joints[s]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(s){const o=s.pop(),r=s,a=[],c=[];for(let l=0,u=r.length;l<u;l++){const h=r[l];if(h){a.push(h);const d=new Wt;o!==null&&d.fromArray(o.array,l*16),c.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[l])}return new Hd(a,c)})}loadAnimation(e){const t=this.json,n=this,s=t.animations[e],o=s.name?s.name:"animation_"+e,r=[],a=[],c=[],l=[],u=[];for(let h=0,d=s.channels.length;h<d;h++){const f=s.channels[h],p=s.samplers[f.sampler],x=f.target,m=x.node,g=s.parameters!==void 0?s.parameters[p.input]:p.input,M=s.parameters!==void 0?s.parameters[p.output]:p.output;x.node!==void 0&&(r.push(this.getDependency("node",m)),a.push(this.getDependency("accessor",g)),c.push(this.getDependency("accessor",M)),l.push(p),u.push(x))}return Promise.all([Promise.all(r),Promise.all(a),Promise.all(c),Promise.all(l),Promise.all(u)]).then(function(h){const d=h[0],f=h[1],p=h[2],x=h[3],m=h[4],g=[];for(let S=0,_=d.length;S<_;S++){const A=d[S],E=f[S],L=p[S],v=x[S],R=m[S];if(A===void 0)continue;A.updateMatrix&&A.updateMatrix();const D=n._createAnimationTracks(A,E,L,v,R);if(D)for(let N=0;N<D.length;N++)g.push(D[N])}const M=new Jh(o,void 0,g);return Ns(M,s),M})}createNodeMesh(e){const t=this.json,n=this,s=t.nodes[e];return s.mesh===void 0?null:n.getDependency("mesh",s.mesh).then(function(o){const r=n._getNodeRef(n.meshCache,s.mesh,o);return s.weights!==void 0&&r.traverse(function(a){if(a.isMesh)for(let c=0,l=s.weights.length;c<l;c++)a.morphTargetInfluences[c]=s.weights[c]}),r})}loadNode(e){const t=this.json,n=this,s=t.nodes[e],o=n._loadNodeShallow(e),r=[],a=s.children||[];for(let l=0,u=a.length;l<u;l++)r.push(n.getDependency("node",a[l]));const c=s.skin===void 0?Promise.resolve(null):n.getDependency("skin",s.skin);return Promise.all([o,Promise.all(r),c]).then(function(l){const u=l[0],h=l[1],d=l[2];d!==null&&u.traverse(function(f){f.isSkinnedMesh&&f.bind(d,sw)});for(let f=0,p=h.length;f<p;f++)u.add(h[f]);if(u.userData.pivot!==void 0&&h.length>0){const f=u.userData.pivot,p=h[0];u.pivot=new I().fromArray(f),u.position.x-=f[0],u.position.y-=f[1],u.position.z-=f[2],p.position.set(0,0,0),delete u.userData.pivot}return u})}_loadNodeShallow(e){const t=this.json,n=this.extensions,s=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];const o=t.nodes[e],r=o.name?s.createUniqueName(o.name):"",a=[],c=s._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(e)});return c&&a.push(c),o.camera!==void 0&&a.push(s.getDependency("camera",o.camera).then(function(l){return s._getNodeRef(s.cameraCache,o.camera,l)})),s._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(e)}).forEach(function(l){a.push(l)}),this.nodeCache[e]=Promise.all(a).then(function(l){let u;if(o.isBone===!0?u=new r0:l.length>1?u=new pn:l.length===1?u=l[0]:u=new kn,u!==l[0])for(let h=0,d=l.length;h<d;h++)u.add(l[h]);if(o.name&&(u.userData.name=o.name,u.name=r),Ns(u,o),o.extensions&&Qo(n,u,o),o.matrix!==void 0){const h=new Wt;h.fromArray(o.matrix),u.applyMatrix4(h)}else o.translation!==void 0&&u.position.fromArray(o.translation),o.rotation!==void 0&&u.quaternion.fromArray(o.rotation),o.scale!==void 0&&u.scale.fromArray(o.scale);if(!s.associations.has(u))s.associations.set(u,{});else if(o.mesh!==void 0&&s.meshCache.refs[o.mesh]>1){const h=s.associations.get(u);s.associations.set(u,{...h})}return s.associations.get(u).nodes=e,u}),this.nodeCache[e]}loadScene(e){const t=this.extensions,n=this.json.scenes[e],s=this,o=new pn;n.name&&(o.name=s.createUniqueName(n.name)),Ns(o,n),n.extensions&&Qo(t,o,n);const r=n.nodes||[],a=[];for(let c=0,l=r.length;c<l;c++)a.push(s.getDependency("node",r[c]));return Promise.all(a).then(function(c){for(let u=0,h=c.length;u<h;u++){const d=c[u];d.parent!==null?o.add(AT(d)):o.add(d)}const l=u=>{const h=new Map;for(const[d,f]of s.associations)(d instanceof Ts||d instanceof bi)&&h.set(d,f);return u.traverse(d=>{const f=s.associations.get(d);f!=null&&h.set(d,f)}),h};return s.associations=l(o),o})}_createAnimationTracks(e,t,n,s,o){const r=[],a=e.name?e.name:e.uuid,c=[];function l(f){f.morphTargetInfluences&&c.push(f.name?f.name:f.uuid)}No[o.path]===No.weights?(l(e),e.isGroup&&e.children.forEach(l)):c.push(a);let u;switch(No[o.path]){case No.weights:u=dc;break;case No.rotation:u=fc;break;case No.translation:case No.scale:u=Ul;break;default:switch(n.itemSize){case 1:u=dc;break;case 2:case 3:default:u=Ul;break}break}const h=s.interpolation!==void 0?jT[s.interpolation]:rc,d=this._getArrayFromAccessor(n);for(let f=0,p=c.length;f<p;f++){const x=new u(c[f]+"."+No[o.path],t.array,d,h);s.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(x),r.push(x)}return r}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){const n=nd(t.constructor),s=new Float32Array(t.length);for(let o=0,r=t.length;o<r;o++)s[o]=t[o]*n;t=s}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){const s=this instanceof fc?JT:B0;return new s(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function rw(i,e,t){const n=e.attributes,s=new qs;if(n.POSITION!==void 0){const a=t.json.accessors[n.POSITION],c=a.min,l=a.max;if(c!==void 0&&l!==void 0){if(s.set(new I(c[0],c[1],c[2]),new I(l[0],l[1],l[2])),a.normalized){const u=nd(Kr[a.componentType]);s.min.multiplyScalar(u),s.max.multiplyScalar(u)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const o=e.targets;if(o!==void 0){const a=new I,c=new I;for(let l=0,u=o.length;l<u;l++){const h=o[l];if(h.POSITION!==void 0){const d=t.json.accessors[h.POSITION],f=d.min,p=d.max;if(f!==void 0&&p!==void 0){if(c.setX(Math.max(Math.abs(f[0]),Math.abs(p[0]))),c.setY(Math.max(Math.abs(f[1]),Math.abs(p[1]))),c.setZ(Math.max(Math.abs(f[2]),Math.abs(p[2]))),d.normalized){const x=nd(Kr[d.componentType]);c.multiplyScalar(x)}a.max(c)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(a)}i.boundingBox=s;const r=new Ys;s.getCenter(r.center),r.radius=s.min.distanceTo(s.max)/2,i.boundingSphere=r}function um(i,e,t){const n=e.attributes,s=[];function o(r,a){return t.getDependency("accessor",r).then(function(c){i.setAttribute(a,c)})}for(const r in n){const a=td[r]||r.toLowerCase();a in i.attributes||s.push(o(n[r],a))}if(e.indices!==void 0&&!i.index){const r=t.getDependency("accessor",e.indices).then(function(a){i.setIndex(a)});s.push(r)}return un.workingColorSpace!==Ji&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${un.workingColorSpace}" not supported.`),Ns(i,e),rw(i,e,t),Promise.all(s).then(function(){return e.targets!==void 0?ew(i,e.targets,t):i})}const pc=Object.freeze({hipFov:75,adsFov:52,transitionSpeed:14,lookSensitivity:.58,hipWeaponPosition:Object.freeze([0,0,0]),adsWeaponPosition:Object.freeze([0,-5,-58]),weaponAimAxis:Object.freeze([.84,.54,0]),adsWeaponRotation:Object.freeze([0,0,0]),adsWeaponScale:1,weapons:Object.freeze({"focusing-crystal-staff":Object.freeze({adsFov:46,adsWeaponPosition:Object.freeze([0,-7,-72]),weaponAimAxis:Object.freeze([.8,.72,0])}),"thunderclap-gauntlet":Object.freeze({adsFov:56,adsWeaponPosition:Object.freeze([0,-8,-46]),weaponAimAxis:Object.freeze([1,0,0]),adsWeaponScale:1.08}),"arcane-spellbook":Object.freeze({adsFov:54,adsWeaponPosition:Object.freeze([0,-6,-52]),weaponAimAxis:Object.freeze([1,0,0])}),"enchanted-bow":Object.freeze({adsFov:48,adsWeaponPosition:Object.freeze([0,-6,-66]),weaponAimAxis:Object.freeze([0,1,0])}),"chaos-orb":Object.freeze({adsFov:54,adsWeaponPosition:Object.freeze([0,-3,-51]),weaponAimAxis:Object.freeze([1,0,0]),adsWeaponScale:.96})})});function Qd(i){return{...pc,...pc.weapons[i]||{}}}function aw(i,e,t,n=pc.transitionSpeed){const s=e?1:0;if(t<=0)return i;const o=i+(s-i)*(1-Math.exp(-n*t));return Math.abs(s-o)<1e-4?s:Math.max(0,Math.min(1,o))}const jt=1024,gn=576;var vm;const ef=/^((?!chrome|chromium|android).)*safari/i.test(((vm=globalThis.navigator)==null?void 0:vm.userAgent)||"");function k0(i,e,t=!1){return ef&&!t?Promise.resolve(null):new Promise(n=>{new F0().load(i,n,void 0,s=>{console.warn(e,s),n(null)})})}const hm=k0("/models/wizard-advanced-animations.glb?v=20260917-mixamo-movement-v1","Advanced wizard model could not load; using the built-in fallback."),dm=k0("/models/shovel.glb?v=20260907","Shovel model could not load; using the built-in shovel."),cw=["fairy_fizz","golden_wizard_cake","healing_leaves","small_protection_potion","great_protection_potion","tier_i_attack_scroll","tier_ii_attack_scroll","common_rune","rare_rune","super_rare_rune","epic_rune","legendary_rune","catalyst_shards","elemental_essences","burst_runes","cosmic_orbs","calamity_cores"],H0=new Map,lw=new F0;if(!ef)for(const i of cw)lw.load(`/models/items/${i}.glb`,({scene:e})=>{const t=new qs().setFromObject(e),n=t.getSize(new I),s=t.getCenter(new I),o=new pn;e.position.sub(s),o.add(e),o.scale.setScalar(32/Math.max(n.x,n.y,n.z,.001)),H0.set(i,o)},void 0,e=>{console.warn(`Item model ${i} could not load; using the pickup fallback.`,e)});function uw(i){var t;return i.lootType==="mana-ammunition"?{catalyst:"catalyst_shards",elemental:"elemental_essences",burst:"burst_runes",cosmic:"cosmic_orbs",calamity:"calamity_cores"}[i.ammoType]:i.lootType==="tier-scroll"?(i.tier??((t=on[i.attackId])==null?void 0:t.tier))===1?"tier_i_attack_scroll":"tier_ii_attack_scroll":{"fairy-fizz":"fairy_fizz","golden-wizard-cake":"golden_wizard_cake","healing-leaves":"healing_leaves","small-protection-potion":"small_protection_potion","greater-protection-potion":"great_protection_potion"}[i.attackId]||`${(i.rarity||"common").replaceAll("-","_")}_rune`}function id(i,e,t){const n=Math.max(0,Math.min(1,(i-e)/(t-e)));return n*n*(3-2*n)}const Zu=new Qe(13220497),fm=new Qe(13151608),vl=new Qe(9598290),$u=new Qe(6850651),pm=new Qe(4155204),Oa=new Qe(6908001),mm=new Qe(14936038),oo=(i,e,t,n)=>n.copy(i).lerp(e,Math.max(0,Math.min(1,t)));function Ls(i,e,t){const n=Math.sin(i*.0021+.7)*Math.cos(e*.0025-1.2),s=Math.sin(i*.0093-2.4)*Math.cos(e*.0107+.3);return t.offsetHSL(0,0,n*.025+s*.014),t}function hw(i,e,t,n){const s=lr(i,e).distance;if(s<310&&t>4){const o=1-id(s,95,310);return Ls(i,e,oo($u,vl,.45+o*.4,n))}return t<5?Ls(i,e,n.copy(Zu)):_s(i,e)==="desert"?t<60?Ls(i,e,oo(Zu,fm,(t-5)/55,n)):t<340?Ls(i,e,oo(fm,vl,(t-60)/280,n)):t<640?Ls(i,e,oo(vl,Oa,(t-340)/300,n)):Ls(i,e,oo(Oa,mm,(t-640)/300,n)):t<45?Ls(i,e,oo(Zu,$u,(t-5)/40,n)):t<380?Ls(i,e,oo($u,pm,(t-45)/335,n)):t<760?Ls(i,e,oo(pm,Oa,(t-380)/380,n)):Ls(i,e,oo(Oa,mm,(t-760)/300,n))}function sd(i,{safeMode:e=!1}={}){const t=new ET({canvas:i,antialias:!e,powerPreference:e?"low-power":"high-performance",preserveDrawingBuffer:!1});t.outputColorSpace=Yn,t.toneMapping=wd,t.toneMappingExposure=1.06,t.shadowMap.enabled=!e,t.shadowMap.type=Va;const n=new K_;n.background=new Qe("#9ac8df"),n.fog=null;const s=new Bi(75,jt/gn,1,13e3);s.position.set(0,560,420),s.lookAt(0,0,0);let o=75;function r(b){o=b}n.add(new fy(14214635,.5));const a=new I(700,520,470),c=a.clone().normalize(),l=9e3,u=new Kl;u.scale.setScalar(10500);const h=u.material.uniforms;h.turbidity.value=4.8,h.rayleigh.value=2.15,h.mieCoefficient.value=.0045,h.mieDirectionalG.value=.82,h.sunPosition.value.copy(c),u.material.depthWrite=!1,n.add(u);const d=new E0(16773075,2.55);d.position.copy(a),d.castShadow=!0,d.shadow.mapSize.set(2048,2048),d.shadow.bias=-8e-5,d.shadow.normalBias=.025;const f=d.shadow.camera;f.left=-900,f.right=900,f.top=900,f.bottom=-900,f.near=50,f.far=2600;const p=new kn;n.add(p),d.target=p,n.add(d),n.add(new cy(13232117,5398850,1.05));const x=new W(new Zn(560,24,24),new bn({color:16774079,fog:!1})),m=new W(new Zn(1100,24,24),new bn({color:16770447,transparent:!0,opacity:.35,fog:!1,blending:Ci,depthWrite:!1}));n.add(x),n.add(m);const g=new pn;g.name="FloatingPortalArena";const M=new lt({color:7829385,roughness:.82,metalness:.08}),S=new lt({color:3421508,roughness:.9}),_=new W(new Ot(Un.platformRadius,Un.platformRadius*.9,34,96),M);_.position.y=Un.platformHeight-17,_.castShadow=!0,_.receiveShadow=!0,g.add(_);for(const b of[145,275,390,505]){const T=new W(new ai(b,b===505?7:3.5,8,128),new bn({color:b===505?9133302:6219775,transparent:!0,opacity:b===505?.85:.52}));T.rotation.x=Math.PI/2,T.position.y=Un.platformHeight+2,g.add(T)}const A=[],E=Un.portalOuterWidth/2,L=32,v=E-L;for(let b=0;b<Un.portalCount;b++){const T=b/Un.portalCount*Math.PI*2,U=new pn;U.position.set(Math.cos(T)*Un.portalRing,Un.platformHeight,Math.sin(T)*Un.portalRing),U.rotation.y=-T+Math.PI/2;for(const Ke of[-1,1]){const je=new W(new fn(52,300,52),S);je.position.set(Ke*v,150,0),je.castShadow=!0,U.add(je);const tt=new W(new fn(72,25,66),M);tt.position.set(Ke*v,300,0),U.add(tt)}const H=new W(new ai(v,L,14,52,Math.PI),S);H.position.y=299,U.add(H);const O=new hs({uniforms:{uTime:{value:0},uColor:{value:new Qe(8141549)},uOpen:{value:.15},uSeed:{value:b*1.731}},vertexShader:`
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,fragmentShader:`
        uniform float uTime;
        uniform float uOpen;
        uniform float uSeed;
        uniform vec3 uColor;
        varying vec2 vUv;

        void main() {
          vec2 p = (vUv - 0.5) * vec2(2.0, 3.1);
          float radius = length(p);
          float angle = atan(p.y, p.x);
          float spiralA = sin(angle * 6.0 - radius * 13.0 + uTime * 3.6 + uSeed);
          float spiralB = sin(angle * -4.0 - radius * 18.0 - uTime * 2.7 - uSeed);
          float current = 0.5 + 0.28 * spiralA + 0.22 * spiralB;
          float lightning = pow(max(0.0, sin(angle * 11.0 + radius * 27.0 - uTime * 7.0)), 12.0);
          float center = 1.0 - smoothstep(0.0, 0.42, radius);
          vec3 cyan = vec3(0.25, 0.9, 1.0);
          vec3 color = mix(uColor * 0.55, cyan, center * 0.7 + lightning * 0.45);
          color *= 0.72 + current * 0.8 + lightning * 1.4;
          float alpha = uOpen * (0.46 + current * 0.38 + lightning * 0.45 + center * 0.32);
          gl_FragColor = vec4(color, clamp(alpha, 0.05, 0.94));
        }
      `,transparent:!0,side:xi,blending:Ci,depthWrite:!1,toneMapped:!1}),q=v-L-6,te=new Nl;te.moveTo(-q,3),te.lineTo(-q,299),te.absarc(0,299,q,Math.PI,0,!0),te.lineTo(q,3),te.closePath();const Q=new W(new Kd(te,32),O);Q.position.z=1,U.add(Q);const Z=new bn({color:8141549,transparent:!0,opacity:.78,blending:Ci,depthWrite:!1,toneMapped:!1}),Se=(Ke,je)=>{const tt=[];for(let ie=0;ie<52;ie++){const de=ie/51,nt=Ke*(de*Math.PI*4.2+je),wt=94*(1-de*.82);tt.push(new I(Math.cos(nt)*wt,Math.sin(nt)*wt,4))}const Mn=new W(new Ka(new er(tt),80,4.5,7,!1),Z.clone());return Mn.position.y=245,Mn},be=Se(1,b*.7),Le=Se(-1,b*.9+1.6);Le.scale.setScalar(.72),U.add(be,Le);const et=[];for(let Ke=0;Ke<30;Ke++){const je=Math.sin((Ke+1)*19.17+b)*q*.82,tt=18+(Ke*67+b*31)%350;et.push(je,tt,7)}const gt=new Tn;gt.setAttribute("position",new Dt(et,3));const Te=new a0(gt,new zd({color:10218239,size:6,transparent:!0,opacity:.8,blending:Ci,depthWrite:!1,toneMapped:!1}));U.add(Te),g.add(U),A.push({group:U,energy:Q,swirl:be,counterSwirl:Le,sparks:Te,material:O})}for(let b=0;b<18;b++){const T=b/18*Math.PI*2+b%2*.13,U=465+b%4*32,H=new W(new Xa(24+b%3*9,0),S);H.position.set(Math.cos(T)*U,Un.platformHeight-45-b%5*28,Math.sin(T)*U),H.rotation.set(b*.7,b*.43,b*.29),g.add(H)}for(const b of[Math.PI/4,3*Math.PI/4,5*Math.PI/4,7*Math.PI/4]){const T=new W(new Ot(16,5,680,12,1,!0),new bn({color:6347007,transparent:!0,opacity:.4,side:xi,blending:Ci,depthWrite:!1}));T.position.set(Math.cos(b)*475,Un.platformHeight-355,Math.sin(b)*475),g.add(T)}n.add(g);function R(b,T,U=185,H=255){const O=new Uint8Array(b*b*4);let q=T>>>0;const te=()=>(q=q*1664525+1013904223>>>0)/4294967296;for(let Z=0;Z<b;Z++)for(let Se=0;Se<b;Se++){const be=Math.sin(Se/b*Math.PI*8+Math.sin(Z/b*Math.PI*4))*.24+Math.cos(Z/b*Math.PI*10-Math.sin(Se/b*Math.PI*6))*.2,Le=(te()-.5)*.3,et=Ui.clamp(.56+be+Le,0,1),gt=Math.round(Ui.lerp(U,H,et)),Te=(Z*b+Se)*4;O[Te]=gt,O[Te+1]=gt,O[Te+2]=gt,O[Te+3]=255}const Q=new zl(O,b,b,Ki);return Q.wrapS=Q.wrapT=mr,Q.minFilter=Hs,Q.magFilter=mi,Q.anisotropy=Math.min(8,t.capabilities.getMaxAnisotropy()),Q.needsUpdate=!0,Q}let D,N,B;ne(),ae();function ne(){const b=(Cn.radius+4e3)*2,T=260,U=new vc(b,b,T,T);U.rotateX(-Math.PI/2);const H=U.attributes.position,O=new Float32Array(H.count*3),q=new Qe;for(let Le=0;Le<H.count;Le++){const et=H.getX(Le),gt=H.getZ(Le),Te=De(et,gt);H.setY(Le,Te),hw(et,gt,Te,q),O[Le*3]=q.r,O[Le*3+1]=q.g,O[Le*3+2]=q.b}U.setAttribute("color",new Li(O,3)),U.computeVertexNormals();const te=U.attributes.normal,Q=U.attributes.color;for(let Le=0;Le<H.count;Le++){const et=1-id(te.getY(Le),.56,.93);if(et<=.02)continue;q.fromBufferAttribute(Q,Le);const gt=_s(H.getX(Le),H.getZ(Le))==="desert"?vl:Oa;q.lerp(gt,et*.58),Q.setXYZ(Le,q.r,q.g,q.b)}Q.needsUpdate=!0;const Z=R(256,1906916655,230,255);Z.repeat.set(175,175),Z.colorSpace=Yn;const Se=Z.clone();Se.colorSpace=ro,Se.needsUpdate=!0;const be=new W(U,new lt({vertexColors:!0,map:Z,bumpMap:Se,bumpScale:3.6,roughness:.96,metalness:0,envMapIntensity:.28}));be.receiveShadow=!0,n.add(be),N=R(192,289712759,95,255),N.repeat.set(90,90),B=new pi({color:2325407,roughness:.1,metalness:0,clearcoat:.95,clearcoatRoughness:.1,ior:1.333,reflectivity:.82,envMapIntensity:1.45,bumpMap:N,bumpScale:8,transparent:!0,opacity:.92,side:xi,depthWrite:!1}),D=new W(new ir(Cn.radius+9e3,160),B),D.rotation.x=-Math.PI/2,D.position.y=0,n.add(D)}function ae(){const b=Ga.map(([Te,Ke])=>new I(Te,0,Ke)),T=new er(b,!1,"centripetal",.45),U=150,H=[],O=[],q=[],te=[],Q=[];for(let Te=0;Te<=U;Te++){const Ke=Te/U,je=T.getPoint(Ke),tt=T.getTangent(Ke).normalize(),Mn=-tt.z,ie=tt.x,de=115+32*Math.sin(Ke*Math.PI*5.3)+34*Ke,nt=De(je.x,je.z)+10;for(const wt of[-1,1])H.push(je.x+Mn*de*wt,nt,je.z+ie*de*wt),O.push(Ke*18,wt<0?0:1);if(te.push(new I(je.x-Mn*(de+4),nt+2,je.z-ie*(de+4))),Q.push(new I(je.x+Mn*(de+4),nt+2,je.z+ie*(de+4))),Te<U){const wt=Te*2;q.push(wt,wt+2,wt+1,wt+1,wt+2,wt+3)}}const Z=new Tn;Z.setAttribute("position",new Dt(H,3)),Z.setAttribute("uv",new Dt(O,2)),Z.setIndex(q),Z.computeVertexNormals();const Se=new W(Z,B);Se.receiveShadow=!0,n.add(Se);const be=new bn({color:11131359,transparent:!0,opacity:.42});for(const Te of[te,Q]){const Ke=new W(new Ka(new er(Te),120,3.2,6,!1),be);n.add(Ke)}const Le=De(yt.pond.x,yt.pond.y)+24,et=new W(new ir(yt.pond.r,64),B);et.rotation.x=-Math.PI/2,et.position.set(yt.pond.x,Le,yt.pond.y),et.receiveShadow=!0,n.add(et);const gt=new W(new ai(yt.pond.r*.97,9,8,96),new lt({color:7373146,roughness:1}));gt.rotation.x=-Math.PI/2,gt.position.copy(et.position).add(new I(0,2,0)),n.add(gt)}e?V():(he(),K(),se());function V(){const b=nh(),T=b.filter(Te=>!Te.soft&&Te.kind!=="house"),U=b.filter(Te=>Te.kind==="house"),H=new Ot(1,1,1,7),O=new fn(1,1,1),q=new wp({color:5269315}),te=new wp({color:10122836}),Q=new di(H,q,T.length),Z=new di(O,te,U.length),Se=new Wt,be=new I,Le=new ci,et=new I,gt=new I(0,1,0);T.forEach((Te,Ke)=>{const je=Math.max(24,Te.top||Te.s||Te.r*2||50),tt=Math.max(8,Te.r||Te.s||16);be.set(Te.x,Ba(Te)+je/2,Te.y),Le.setFromAxisAngle(gt,Te.rot||Te.ry||0),et.set(tt,je,tt),Se.compose(be,Le,et),Q.setMatrixAt(Ke,Se)}),U.forEach((Te,Ke)=>{const je=Math.max(80,Te.h||Te.top*.65||180);be.set(Te.x,Ba(Te)+je/2,Te.y),Le.setFromAxisAngle(gt,-Te.angle||0),et.set(Te.w||Te.hw*2,je,Te.d||Te.hd*2),Se.compose(be,Le,et),Z.setMatrixAt(Ke,Se)}),Q.receiveShadow=!1,Z.receiveShadow=!1,n.add(Q,Z)}function se(){let b=2654435761;const T=()=>(b=b*1664525+1013904223>>>0)/4294967296,U=Math.PI*2,H=Cn.radius-120,O=new Wt,q=new ci,te=new I,Q=new I,Z=new I(0,1,0),Se=new I(0,0,1),be=(j,Me)=>{const xe=[];for(let _t=0;_t<j;_t++){const Ft=T()*U,It=Math.sqrt(T())*H,st=Math.cos(Ft)*It,ln=Math.sin(Ft)*It,yn=De(st,ln);Me(st,ln,yn)&&xe.push([st,yn,ln,T(),T()])}return xe},Le=(j,Me,xe)=>{if(xe<12||xe>380||lr(j,Me).distance<280||Math.hypot(j-yt.pond.x,Me-yt.pond.y)<yt.pond.r)return!1;const _t=_s(j,Me);return _t==="grass"||_t==="farm"||_t==="forest"||_t==="coast"},et=R(128,1662625117,170,255);et.repeat.set(28,3),et.colorSpace=Yn;const gt=new lt({color:9269323,map:et,bumpMap:et,bumpScale:2.2,roughness:1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),Te=(j,Me,xe)=>{const _t=Math.hypot(j,Me)||1,Ft=j/_t,It=Me/_t,st=-It,ln=Ft,yn=86,Ln=[],Vn=[];for(let si=0;si<=yn;si++){const Vi=si/yn,zi=Math.sin(Vi*Math.PI)*(120*Math.sin(Vi*Math.PI*(2.1+xe*.13)+xe)+46*Math.sin(Vi*Math.PI*7.2+xe*.7)),Wi=430,js=Wi+(_t-Wi)*Vi,Lc=Ft*js+st*zi,nu=It*js+ln*zi,Dc=42+18*(.5+.5*Math.sin(Vi*18+xe));for(const ts of[-1,1]){const ns=Lc+st*Dc*ts,Ma=nu+ln*Dc*ts;Ln.push(ns,De(ns,Ma)+4,Ma)}if(si<yn){const ts=si*2;Vn.push(ts,ts+2,ts+1,ts+1,ts+2,ts+3)}}const tn=new Tn;tn.setAttribute("position",new Dt(Ln,3)),tn.setIndex(Vn),tn.computeVertexNormals();const Sn=new W(tn,gt);Sn.receiveShadow=!0,n.add(Sn)};fi.forEach((j,Me)=>Te(j.x,j.y,Me));const Ke=(j,Me,xe,_t,Ft)=>{const It=xe-j,st=_t-Me,ln=Math.hypot(It,st)||1,yn=It/ln,Vn=-(st/ln),tn=yn,Sn=Math.max(24,Math.ceil(ln/95)),si=[],Vi=[];for(let Wi=0;Wi<=Sn;Wi++){const js=Wi/Sn,Lc=Math.sin(js*Math.PI)*(75*Math.sin(js*Math.PI*3.2+Ft*1.7)+28*Math.sin(js*Math.PI*8.4+Ft)),nu=j+It*js+Vn*Lc,Dc=Me+st*js+tn*Lc,ts=24+7*Math.sin(js*14+Ft);for(const ns of[-1,1]){const Ma=nu+Vn*ts*ns,yf=Dc+tn*ts*ns;si.push(Ma,De(Ma,yf)+4.5,yf)}if(Wi<Sn){const ns=Wi*2;Vi.push(ns,ns+2,ns+1,ns+1,ns+2,ns+3)}}const es=new Tn;es.setAttribute("position",new Dt(si,3)),es.setIndex(Vi),es.computeVertexNormals();const zi=new W(es,gt);zi.receiveShadow=!0,n.add(zi)},je=fi.find(j=>j.biome==="forest"),tt=fi.find(j=>j.biome==="mountain"),Mn=fi.find(j=>j.biome==="farm"),ie=fi.find(j=>j.biome==="desert"),de=fi.find(j=>j.biome==="coast");Ke(je.x,je.y,tt.x-500,tt.y+650,10),Ke(tt.x+900,tt.y+900,-700,-1800,11),Ke(Mn.x,Mn.y,yt.pond.x,yt.pond.y,12),Ke(Mn.x+500,Mn.y+600,yt.mine.x,yt.mine.y,13),Ke(yt.mine.x,yt.mine.y+700,ie.x,ie.y,14),Ke(ie.x-800,ie.y-400,-2100,2700,15),Ke(de.x+500,de.y-500,-850,1150,16);const nt=[16777215,16769357,16739179,11827455,7059199,16752451].map(j=>new Qe(j)),wt=be(6e3,Le),ct=new di(new Ot(.8,1.1,12,4),new lt({color:4160565,roughness:1}),wt.length),Mt=new di(new Xa(2.2,0),new lt({roughness:.7}),wt.length);wt.forEach((j,Me)=>{const xe=.7+j[3]*1.1;q.identity(),te.set(j[0],j[1]+6*xe,j[2]),Q.set(xe,xe,xe),O.compose(te,q,Q),ct.setMatrixAt(Me,O),te.y=j[1]+14*xe,O.compose(te,q,Q),Mt.setMatrixAt(Me,O),Mt.setColorAt(Me,nt[j[4]*nt.length|0])}),ct.instanceMatrix.needsUpdate=!0,Mt.instanceMatrix.needsUpdate=!0,Mt.instanceColor.needsUpdate=!0,n.add(ct),n.add(Mt);const qt=[],en=[];for(let j=0;j<3;j++){const Me=j/3*Math.PI,xe=Math.cos(Me)*3.2,_t=Math.sin(Me)*3.2,Ft=-Math.sin(Me)*2,It=Math.cos(Me)*2,st=qt.length/3;qt.push(-xe,-11,-_t,xe,-11,_t,xe*.12+Ft,11,_t*.12+It,-xe*.12+Ft,11,-_t*.12+It),en.push(st,st+1,st+2,st,st+2,st+3)}const St=new Tn;St.setAttribute("position",new Dt(qt,3)),St.setIndex(en),St.computeVertexNormals();const Pn=be(14e3,Le),Jn=new di(St,new lt({color:5207101,roughness:.95,side:xi}),Pn.length);Pn.forEach((j,Me)=>{te.set(j[0],j[1]+11,j[2]),Q.set(.7+j[3]*1.1,.65+j[4]*1.15,.7+j[3]*1.1),q.setFromAxisAngle(Z,j[4]*U),O.compose(te,q,Q),Jn.setMatrixAt(Me,O)}),Jn.instanceMatrix.needsUpdate=!0,n.add(Jn);const kt=be(4e3,(j,Me,xe)=>xe>8&&xe<900),Hn=new di(new sr(1,0),new lt({color:9077879,roughness:1}),kt.length);kt.forEach((j,Me)=>{const xe=3+j[3]*7;te.set(j[0],j[1]+xe*.4,j[2]),Q.set(xe,xe*.6,xe),q.setFromEuler(new ws(j[3]*3,j[4]*3,j[3]*2)),O.compose(te,q,Q),Hn.setMatrixAt(Me,O)}),Hn.instanceMatrix.needsUpdate=!0,n.add(Hn);const On=be(2400,(j,Me,xe)=>_s(j,Me)==="forest"&&xe>15&&xe<520),qn=new di(new Ot(1.5,2,8,6),new lt({color:15261639,roughness:1}),On.length),_n=new di(new Zn(4.5,8,5,0,U,0,Math.PI/2),new lt({roughness:.85}),On.length),jn=[13192e3,14719550,9397693].map(j=>new Qe(j));On.forEach((j,Me)=>{const xe=.7+j[3]*1.1;q.setFromAxisAngle(Z,j[4]*U),Q.setScalar(xe),te.set(j[0],j[1]+4*xe,j[2]),O.compose(te,q,Q),qn.setMatrixAt(Me,O),te.y=j[1]+8*xe,O.compose(te,q,Q),_n.setMatrixAt(Me,O),_n.setColorAt(Me,jn[j[4]*jn.length|0])}),qn.instanceMatrix.needsUpdate=!0,_n.instanceMatrix.needsUpdate=!0,_n.instanceColor.needsUpdate=!0,n.add(qn),n.add(_n);const Ye=be(650,(j,Me,xe)=>_s(j,Me)==="forest"&&xe>15&&xe<520),Ze=new di(new Ot(1,1,1,8),new lt({color:6308649,roughness:1}),Ye.length),At=new ci().setFromAxisAngle(Se,Math.PI/2);Ye.forEach((j,Me)=>{const xe=5+j[3]*7,_t=45+j[4]*70;te.set(j[0],j[1]+xe,j[2]),Q.set(xe,_t,xe),q.setFromAxisAngle(Z,j[4]*U).multiply(At),O.compose(te,q,Q),Ze.setMatrixAt(Me,O)}),Ze.instanceMatrix.needsUpdate=!0,n.add(Ze);const zt=be(4500,(j,Me,xe)=>xe>3&&xe<85&&Math.hypot(j,Me)>Cn.radius*.82),Jt=new di(new Fi(2.8,34,4),new lt({color:11904603,roughness:1}),zt.length);zt.forEach((j,Me)=>{te.set(j[0],j[1]+17,j[2]),Q.set(.7+j[3],.65+j[4]*1.2,.7+j[3]),q.setFromAxisAngle(Z,j[4]*U),O.compose(te,q,Q),Jt.setMatrixAt(Me,O)}),Jt.instanceMatrix.needsUpdate=!0,n.add(Jt);const Qn=be(3e3,(j,Me,xe)=>_s(j,Me)==="desert"&&xe>5&&xe<500),Gn=new di(new gs(1,0),new lt({color:8941636,roughness:1}),Qn.length);Qn.forEach((j,Me)=>{const xe=5+j[3]*12;te.set(j[0],j[1]+xe*.45,j[2]),Q.set(xe*1.5,xe*.55,xe*1.2),q.setFromAxisAngle(Z,j[4]*U),O.compose(te,q,Q),Gn.setMatrixAt(Me,O)}),Gn.instanceMatrix.needsUpdate=!0,n.add(Gn);const In=be(1200,(j,Me,xe)=>_s(j,Me)==="mountain"&&xe>360&&xe<1250),ei=new di(new Fi(1,1,5),new lt({color:9427199,emissive:2245734,roughness:.3}),In.length);In.forEach((j,Me)=>{const xe=4+j[3]*8,_t=16+j[4]*28;te.set(j[0],j[1]+_t/2,j[2]),Q.set(xe,_t,xe),q.setFromAxisAngle(Z,j[3]*U),O.compose(te,q,Q),ei.setMatrixAt(Me,O)}),ei.instanceMatrix.needsUpdate=!0,n.add(ei);const Ei=new lt({color:16777215,roughness:1,fog:!1,transparent:!0,opacity:.9});for(let j=0;j<16;j++){const Me=new pn,xe=3+(T()*4|0);for(let It=0;It<xe;It++){const st=new W(new Zn(200+T()*320,16,10),Ei);st.position.set((T()-.5)*650,(T()-.5)*110,(T()-.5)*650),st.scale.y=.55,Me.add(st)}const _t=T()*U,Ft=1200+T()*Cn.radius;Me.position.set(Math.cos(_t)*Ft,2300+T()*800,Math.sin(_t)*Ft),n.add(Me)}const X=28,$e=new di(new Ot(2.4,3.2,58,6),new lt({color:4207142,roughness:.9}),X),Pt=new di(new Zn(6,8,8),new lt({color:16767352,emissive:9063186,emissiveIntensity:1.4,roughness:.45}),X),vn=new di(new fn(2,30,14),new lt({color:7358648,roughness:.8}),X);for(let j=0;j<X;j++){const Me=j/X*U,xe=438+j%2*20,_t=Math.cos(Me)*xe,Ft=Math.sin(Me)*xe,It=De(_t,Ft);q.setFromAxisAngle(Z,-Me),Q.setScalar(1),te.set(_t,It+29,Ft),O.compose(te,q,Q),$e.setMatrixAt(j,O),te.y=It+62,O.compose(te,q,Q),Pt.setMatrixAt(j,O),te.set(_t+Math.cos(Me)*9,It+43,Ft+Math.sin(Me)*9),O.compose(te,q,Q),vn.setMatrixAt(j,O)}$e.instanceMatrix.needsUpdate=!0,Pt.instanceMatrix.needsUpdate=!0,vn.instanceMatrix.needsUpdate=!0,n.add($e),n.add(Pt),n.add(vn);const Xn=fi.find(j=>j.biome==="farm"),ri=new lt({color:7031340,roughness:1}),ii=new lt({color:10207034,roughness:.9}),it=new lt({color:14205274,roughness:1}),Zt=new lt({color:8016432,roughness:1});for(let j=0;j<6;j++){const Me=T()*U,xe=T()*1500,_t=Xn.x+Math.cos(Me)*xe,Ft=Xn.y+Math.sin(Me)*xe,It=De(_t,Ft);if(It<12||Math.hypot(_t-yt.pond.x,Ft-yt.pond.y)<yt.pond.r+320)continue;const st=new pn,ln=220+T()*160,yn=150+T()*140,Ln=new W(new fn(ln,6,yn),ri);Ln.position.y=3,Ln.receiveShadow=!0,st.add(Ln);const Vn=Math.floor(ln/26);for(let tn=0;tn<Vn;tn++){const Sn=new W(new fn(9,14,yn*.9),ii);Sn.position.set(-ln/2+16+tn*26,12,0),st.add(Sn)}for(const tn of[-1,1]){const Sn=new W(new fn(ln+24,7,7),Zt);Sn.position.set(0,22,tn*(yn/2+10)),Sn.castShadow=!0,st.add(Sn)}for(const tn of[-1,1]){const Sn=new W(new fn(7,7,yn+24),Zt);Sn.position.set(tn*(ln/2+10),22,0),Sn.castShadow=!0,st.add(Sn)}for(const tn of[-1,1])for(const Sn of[-1,1]){const si=new W(new fn(9,38,9),Zt);si.position.set(tn*(ln/2+10),19,Sn*(yn/2+10)),si.castShadow=!0,st.add(si)}st.position.set(_t,It,Ft),st.rotation.y=T()*U,n.add(st)}for(let j=0;j<9;j++){const Me=T()*U,xe=T()*1600,_t=Xn.x+Math.cos(Me)*xe,Ft=Xn.y+Math.sin(Me)*xe,It=De(_t,Ft);if(It<12)continue;const st=new W(new Ot(22,22,32,10),it);st.rotation.z=Math.PI/2,st.position.set(_t,It+22,Ft),st.castShadow=!0,n.add(st)}}function K(){const b=new pn,T=(it,Zt)=>new I(it,De(it,Zt),Zt),U=new lt({color:13287334,roughness:.9}),H=new lt({color:10129273,roughness:.9}),O=new lt({color:3820428,roughness:.7}),q=new lt({color:7031340,roughness:.9}),te=new lt({color:15790056,roughness:.8}),Q=new lt({color:11683119,roughness:.8}),Z=new lt({color:6119780,roughness:.96}),Se=new lt({color:15001314,roughness:.9}),be=new lt({color:10968369,roughness:1}),Le=new lt({color:12876611,roughness:1}),et=new lt({color:723724,roughness:1}),gt=new lt({color:3422267,roughness:.55,metalness:.6}),Te=(it,Zt,j,Me,xe,_t)=>{const Ft=new W(new Ot(Me,Me*1.05,xe,12),U);Ft.position.set(it,Zt+xe/2,j),Ft.castShadow=!0,b.add(Ft);const It=new W(new Fi(Me*1.35,Me*2.4,12),_t);It.position.set(it,Zt+xe+Me*1.2,j),It.castShadow=!0,b.add(It)},Ke=T(0,0),je=340,tt=new W(new Ot(je,je,90,40,1,!0),H);tt.material.side=xi,tt.position.set(Ke.x,Ke.y+45,Ke.z),tt.castShadow=!0,b.add(tt);for(let it=0;it<8;it++){const Zt=it/8*Math.PI*2;Te(Ke.x+Math.cos(Zt)*je,Ke.y,Ke.z+Math.sin(Zt)*je,34,120,O)}Te(Ke.x,Ke.y,Ke.z,70,240,O),Te(Ke.x+110,Ke.y,Ke.z+60,46,170,O),Te(Ke.x-110,Ke.y,Ke.z-60,46,170,O);const Mn=fi.find(it=>it.biome==="mountain"),ie=[[-1100,220,280,720],[-720,-440,360,930],[-280,160,310,820],[180,-520,390,1020],[620,80,300,780],[1050,-360,345,890],[-850,880,270,650],[-300,820,350,850],[300,900,290,690],[820,700,320,760],[-1250,-650,240,580],[1250,400,250,620]];for(let it=0;it<ie.length;it++){const[Zt,j,Me,xe]=ie[it],_t=Mn.x+Zt,Ft=Mn.y+j,It=De(_t,Ft),st=new W(new Fi(Me,xe,8,5),Z);st.position.set(_t,It+xe/2-35,Ft),st.rotation.y=it*1.71,st.scale.z=.72+it%3*.12,st.castShadow=!0,st.receiveShadow=!0,b.add(st);const ln=xe*.3,yn=new W(new Fi(Me*.34,ln,8,2),Se);yn.position.set(_t,It+xe-ln*.42-35,Ft),yn.rotation.y=st.rotation.y,yn.scale.z=st.scale.z,yn.castShadow=!0,b.add(yn)}const de=new er(Ga.map(([it,Zt])=>new I(it,0,Zt)),!1,"centripetal",.45),nt=(it,Zt)=>{const j=de.getPoint(it),Me=de.getTangent(it).normalize(),xe=-Me.z,_t=Me.x,Ft=-Math.atan2(_t,xe),It=De(j.x,j.z)+30,st=Zt?H:q,ln=new W(new fn(390,18,92),st);ln.position.set(j.x,It,j.z),ln.rotation.y=Ft,ln.castShadow=!0,ln.receiveShadow=!0,b.add(ln);for(const yn of[-1,1]){const Ln=new W(new fn(390,16,10),st);Ln.position.set(j.x+Me.x*yn*45,It+17,j.z+Me.z*yn*45),Ln.rotation.y=Ft,Ln.castShadow=!0,b.add(Ln)}};nt(.57,!0),nt(.74,!0),nt(.88,!1);const wt=fi.find(it=>it.biome==="coast"),ct=Math.hypot(wt.x,wt.y)||1,Mt=wt.x/ct*(ct+1400),qt=wt.y/ct*(ct+1400),en=T(Mt,qt);for(let it=0;it<5;it++){const Zt=new W(new Ot(16-it*2,18-it*2,44,12),it%2?Q:te);Zt.position.set(en.x,en.y+22+it*44,en.z),Zt.castShadow=!0,b.add(Zt)}const St=new W(new Ot(12,12,26,12),H);St.position.set(en.x,en.y+22+220+13,en.z),b.add(St);const Pn=new W(new Zn(9,12,12),new bn({color:16773808}));Pn.position.copy(St.position),b.add(Pn);const Jn=fi.find(it=>it.biome==="farm"),kt=T(Jn.x,Jn.y),Hn=new W(new Ot(34,46,150,12),te);Hn.position.set(kt.x,kt.y+75,kt.z),Hn.castShadow=!0,b.add(Hn);const On=new W(new Fi(50,50,12),Q);On.position.set(kt.x,kt.y+175,kt.z),b.add(On);const qn=new pn;qn.position.set(kt.x,kt.y+150,kt.z+48);for(let it=0;it<4;it++){const Zt=new W(new fn(14,120,4),q);Zt.position.y=60;const j=new pn;j.rotation.z=it/4*Math.PI*2,j.add(Zt),qn.add(j)}b.add(qn);const _n=new _e(-5900,-900).normalize(),jn=Math.atan2(_n.x,_n.y);for(const[it,Zt,j,Me,xe]of[[-430,-280,420,360,500],[520,260,360,310,430]]){const _t=yt.mine.x+it,Ft=yt.mine.y+Zt,It=De(_t,Ft),st=new W(new Xa(1,1),Z);st.position.set(_t,It+Me*.36,Ft),st.scale.set(j,Me,xe),st.rotation.set(.15,it*.001,-.08),st.castShadow=!0,st.receiveShadow=!0,b.add(st);const ln=new W(new ir(82,28),et);ln.position.set(_t+_n.x*xe*.78,It+78,Ft+_n.y*xe*.78),ln.rotation.y=jn,b.add(ln);const yn=720,Ln=ln.position.x+_n.x*yn*.5,Vn=ln.position.z+_n.y*yn*.5,tn=-Math.atan2(_n.y,_n.x),Sn=-_n.y,si=_n.x;for(const es of[-1,1]){const zi=new W(new fn(yn,5,7),gt);zi.position.set(Ln+Sn*es*25,It+10,Vn+si*es*25),zi.rotation.y=tn,zi.castShadow=!0,b.add(zi)}for(let es=0;es<14;es++){const zi=es/13*yn,Wi=new W(new fn(8,7,78),q);Wi.position.set(ln.position.x+_n.x*zi,It+6,ln.position.z+_n.y*zi),Wi.rotation.y=tn,Wi.castShadow=!0,b.add(Wi)}const Vi=new W(new fn(80,48,62),gt);Vi.position.set(Ln,It+39,Vn),Vi.rotation.y=tn,Vi.castShadow=!0,b.add(Vi)}const Ye=fi.find(it=>it.biome==="desert");for(const[it,Zt,j,Me]of[[-1700,450,340,620],[-700,1180,280,500],[450,600,390,690],[1450,1300,260,470],[1550,-200,310,560]]){const xe=Ye.x+it,_t=Ye.y+Zt,Ft=De(xe,_t),It=new W(new Ot(j*.72,j,Me*.72,9,4),be);It.position.set(xe,Ft+Me*.36,_t),It.rotation.y=it*.002,It.castShadow=!0,It.receiveShadow=!0,b.add(It);const st=new W(new Ot(j*.58,j*.72,Me*.28,9,2),Le);st.position.set(xe,Ft+Me*.86,_t),st.rotation.y=It.rotation.y,st.castShadow=!0,b.add(st)}const Ze=wt.x-120,At=wt.y+920;for(const it of[-260,0,260]){const Zt=new W(new fn(150,18,620),q);Zt.position.set(Ze+it,20,At+260),Zt.castShadow=!0,Zt.receiveShadow=!0,b.add(Zt);for(const j of[-1,1])for(const Me of[-1,0,1]){const xe=new W(new Ot(9,11,75,10),q);xe.position.set(Ze+it+j*64,4,At+260+Me*260),xe.castShadow=!0,b.add(xe)}}const zt=new pn,Jt=new W(new Fi(72,260,4),q);Jt.rotation.z=Math.PI/2,Jt.rotation.y=Math.PI/4,Jt.scale.z=.52,zt.add(Jt);const Qn=new W(new Ot(5,7,190,10),q);Qn.position.y=85,zt.add(Qn);const Gn=new Tn;Gn.setAttribute("position",new Dt([0,165,0,0,35,0,0,35,105],3)),Gn.setIndex([0,1,2]),Gn.computeVertexNormals();const In=te.clone();In.side=xi;const ei=new W(Gn,In);zt.add(ei),zt.position.set(Ze-520,35,At+520),zt.rotation.y=-.6,b.add(zt);const Ei=De(yt.islet.x,yt.islet.y),X=new W(new fn(250,135,190),q);X.position.set(yt.islet.x,Ei+67,yt.islet.y),X.castShadow=!0,b.add(X);const $e=new W(new Fi(180,115,4),O);$e.position.set(yt.islet.x,Ei+190,yt.islet.y),$e.rotation.y=Math.PI/4,$e.scale.z=.78,$e.castShadow=!0,b.add($e);const Pt=new W(new fn(110,16,520),q);Pt.position.set(yt.islet.x+120,18,yt.islet.y-390),Pt.castShadow=!0,b.add(Pt);const vn=Ye.x+850,Xn=Ye.y+1750,ri=De(vn,Xn);for(const it of[-1,1])for(const Zt of[-1,1]){const j=new W(new Ot(5,7,180,8),gt);j.position.set(vn+it*42,ri+90,Xn+Zt*42),j.rotation.z=it*.05,b.add(j)}const ii=new W(new Ot(72,72,92,16),gt);ii.position.set(vn,ri+210,Xn),ii.castShadow=!0,b.add(ii),n.add(b)}function he(){const b=new pn,T=R(128,3030854937,145,255);T.repeat.set(3,10),T.colorSpace=Yn;const U=R(128,2291247681,170,255);U.repeat.set(7,6),U.colorSpace=Yn;const H=R(128,562012952,238,255);H.repeat.set(8,5),H.colorSpace=Yn;const O=R(128,1998535762,216,255);O.repeat.set(12,8),O.colorSpace=Yn;const q=new lt({color:5912868,map:T,bumpMap:T,bumpScale:2.8,roughness:1}),te=[3563317,4353340,3103293,5796676].map(X=>new lt({color:X,roughness:.88})),Q=[7631982,6646115,8090986,6252136].map(X=>new lt({color:X,map:U,bumpMap:U,bumpScale:3.2,roughness:.98})),Z=[13482132,12099694,14206882,11046755].map(X=>new lt({color:X,map:H,bumpMap:H,bumpScale:.65,roughness:.92})),Se=[8141614,9062959,5911888,3359061].map(X=>new lt({color:X,map:O,bumpMap:O,bumpScale:1.25,roughness:.9})),be=new lt({color:2759184,roughness:.9}),Le=new lt({color:6446680,map:U,bumpMap:U,bumpScale:3,roughness:1}),et=new lt({color:2767442,roughness:.35,metalness:.3,emissive:1054760}),gt=new lt({color:16766851,emissive:7157517,emissiveIntensity:1.2,roughness:.5}),Te=new lt({color:5012029,roughness:.85}),Ke=new Ot(7,9,95,14),je=new Ot(4.5,5,34,12),tt=new Ot(4.2,8,100,12,5),Mn=new Ot(2,4,42,10),ie=new Fi(40,84,14,3),de=new sr(1,1),nt=new sr(1,1),wt=new sr(1,1),ct=new fn(1,1,1),Mt=new fn(1,1,1),qt=new Zn(7,16,12),en=(X,$e,Pt)=>{const vn=new Nl;vn.moveTo(-$e/2,0),vn.lineTo($e/2,0),vn.lineTo(0,Pt),vn.closePath();const Xn=new qd(vn,{depth:X,steps:1,bevelEnabled:!0,bevelSegments:2,bevelSize:7,bevelThickness:5});return Xn.translate(0,0,-X/2),Xn.rotateY(Math.PI/2),Xn.computeVertexNormals(),Xn},St=nh(),Pn=St.filter(X=>X.kind==="tree"),Jn=X=>{const $e=_s(X.x,X.y);return $e==="mountain"||$e==="forest"&&X.leaf%2===0},kt=[0,0,0,0],Hn=[0,0,0,0];let On=0;for(const X of Pn)Jn(X)?kt[X.leaf]+=4:(Hn[X.leaf]+=5,On+=2);const qn=new di(tt,q,Pn.length),_n=new di(Mn,q,On),jn=kt.map((X,$e)=>new di(ie,te[$e],X)),Ye=Hn.map((X,$e)=>new di(de,te[$e],X)),Ze=new kn,At=new kn,zt=new Wt,Jt=[0,0,0,0],Qn=[0,0,0,0];let Gn=0,In=0;const ei=(X,$e,Pt,vn,Xn)=>{At.position.set(Pt[0],Pt[1],Pt[2]),At.rotation.set(vn[0],vn[1],vn[2]),At.scale.set(Xn[0],Xn[1],Xn[2]),At.updateMatrix(),zt.multiplyMatrices(Ze.matrix,At.matrix),X.setMatrixAt($e,zt)},Ei=[[-20,120,-12,42,35,38],[22,126,-8,45,39,41],[-8,143,20,43,40,40],[18,151,15,39,36,38],[0,169,0,42,40,42]];for(const X of Pn)if(Ze.position.set(X.x,De(X.x,X.y),X.y),Ze.rotation.set(0,X.rot,0),Ze.scale.setScalar(X.scale),Ze.updateMatrix(),ei(qn,Gn++,[0,50,0],[0,0,0],[1,1,1]),Jn(X)){const $e=jn[X.leaf];for(let Pt=0;Pt<4;Pt++){const vn=1-Pt*.13;ei($e,Jt[X.leaf]++,[0,84+Pt*29,0],[0,X.rot*(Pt+1)*.37,0],[vn,1-Pt*.08,vn])}}else{for(const Pt of[-1,1])ei(_n,In++,[Pt*12,83,Pt*5],[Pt*.18,0,Pt*.72],[1,1,1]);const $e=Ye[X.leaf];for(const[Pt,vn,Xn,ri,ii,it]of Ei)ei($e,Qn[X.leaf]++,[Pt,vn,Xn],[X.rot*.17,X.rot*.51+vn,X.rot*.11],[ri,ii,it])}for(const X of[qn,_n,...jn,...Ye])X.instanceMatrix.needsUpdate=!0,X.castShadow=!0,X.receiveShadow=!0,b.add(X);for(const X of St)if(X.kind!=="tree"&&!X.landmark){if(X.kind==="house"){const $e=new pn,Pt=Math.cos(-X.angle),vn=Math.sin(-X.angle),Xn=Ba(X);let ri=1/0;for(const Ln of[-X.hw,0,X.hw])for(const Vn of[-X.hd,0,X.hd]){const tn=De(X.x+Ln*Pt+Vn*vn,X.y-Ln*vn+Vn*Pt);tn<ri&&(ri=tn)}const ii=new W(ct,Z[X.wall]);ii.scale.set(X.w,X.h,X.d),ii.position.y=X.h/2,ii.castShadow=!0,ii.receiveShadow=!0,$e.add(ii);const it=new W(en(X.w+46,X.d+54,X.h*.7),Se[X.roof]);it.position.y=X.h,it.castShadow=!0,it.receiveShadow=!0,$e.add(it);const Zt=new W(new Ot(8,8,X.w+58,12),Se[X.roof]);Zt.rotation.z=Math.PI/2,Zt.position.y=X.h*1.7+1,Zt.castShadow=!0,$e.add(Zt);const j=new W(ct,Le);j.scale.set(42,X.h*.62,42),j.position.set(X.w*.28,X.h+X.h*.18,-X.d*.18),j.castShadow=!0,$e.add(j);const Me=new W(ct,Le);Me.scale.set(54,14,54),Me.position.set(X.w*.28,X.h+X.h*.5,-X.d*.18),Me.castShadow=!0,$e.add(Me);for(const Ln of[-1,1])for(const Vn of[-1,1]){const tn=new W(ct,be);tn.scale.set(12,X.h+8,12),tn.position.set(Ln*(X.w/2+3),X.h/2,Vn*(X.d/2+3)),tn.castShadow=!0,$e.add(tn)}const xe=new W(Mt,be);xe.scale.set(46,92,8),xe.position.set(0,46,X.d/2+3),$e.add(xe);for(const Ln of[-1,1]){const Vn=new W(ct,Le);Vn.scale.set(9,105,11),Vn.position.set(Ln*29,52,X.d/2+7),$e.add(Vn)}const _t=new W(ct,Le);_t.scale.set(67,10,11),_t.position.set(0,102,X.d/2+7),$e.add(_t);const Ft=new W(ct,Le);Ft.scale.set(130,12,54),Ft.position.set(0,6,X.d/2+22),Ft.castShadow=!0,$e.add(Ft);const It=new W(qt,gt);It.position.set(45,105,X.d/2+9),$e.add(It);const st=new W(ct,Le);st.scale.set(X.w+12,16,X.d+12),st.position.y=X.h*.5,st.castShadow=!0,$e.add(st);for(const Ln of[.16,.34,.66,.84])for(const Vn of[-1,1]){const tn=new W(ct,be);tn.scale.set(X.w+7,5,7),tn.position.set(0,X.h*Ln,Vn*(X.d/2+3)),tn.castShadow=!0,$e.add(tn)}for(const Ln of[X.h*.26,X.h*.74]){for(const Vn of[1,-1])for(const tn of[-.28,.28]){const Sn=new W(ct,Le);Sn.scale.set(62,74,8),Sn.position.set(X.w*tn,Ln,Vn*(X.d/2+3)),Sn.castShadow=!0,$e.add(Sn);const si=new W(ct,et);si.scale.set(48,60,6),si.position.set(X.w*tn,Ln,Vn*(X.d/2+8)),$e.add(si)}for(const Vn of[1,-1])for(const tn of[-.28,.28]){const Sn=new W(ct,Le);Sn.scale.set(8,74,62),Sn.position.set(Vn*(X.w/2+3),Ln,X.d*tn),Sn.castShadow=!0,$e.add(Sn);const si=new W(ct,et);si.scale.set(6,60,48),si.position.set(Vn*(X.w/2+8),Ln,X.d*tn),$e.add(si)}}const ln=Xn-ri+40,yn=new W(ct,Le);yn.scale.set(X.w,ln,X.d),yn.position.y=-ln/2,yn.castShadow=!0,$e.add(yn),$e.position.set(X.x,Xn,X.y),$e.rotation.y=-X.angle,b.add($e)}else if(X.kind==="rock"){const $e=Q[Math.abs(Math.floor(X.rx*17))%Q.length],Pt=new W(nt,$e);Pt.scale.set(X.s,X.s*X.sy,X.s),Pt.position.set(X.x,De(X.x,X.y)+X.s*.3,X.y),Pt.rotation.set(X.rx,X.ry,X.rz),Pt.castShadow=!0,Pt.receiveShadow=!0,b.add(Pt)}else if(X.kind==="bush"){const $e=new pn;for(const[Pt,vn,Xn,ri]of[[-.55,.55,0,.8],[.5,.58,-.15,.88],[.05,.82,.35,.95]]){const ii=new W(wt,te[X.leaf]);ii.position.set(Pt*X.s,vn*X.s,Xn*X.s),ii.scale.set(X.s*ri,X.s*ri*.72,X.s*ri),ii.castShadow=!0,$e.add(ii)}$e.position.set(X.x,De(X.x,X.y),X.y),$e.rotation.y=X.rot,b.add($e)}else if(X.kind==="cactus"){const $e=new pn,Pt=new W(Ke,Te);Pt.position.y=47,Pt.castShadow=!0,$e.add(Pt);for(let vn=0;vn<X.arms;vn++){const Xn=vn%2===0?1:-1,ri=new pn;ri.position.set(0,34+vn*12,0),ri.rotation.y=Xn>0?0:Math.PI;const ii=new W(je,Te);ii.rotation.z=Math.PI/2,ii.position.set(11,0,0),ri.add(ii);const it=new W(je,Te);it.position.set(22,15,0),it.scale.set(1,.9,1),ri.add(it),ri.children.forEach(Zt=>Zt.castShadow=!0),$e.add(ri)}$e.position.set(X.x,De(X.x,X.y),X.y),$e.scale.setScalar(X.scale),$e.rotation.y=X.rot,b.add($e)}}n.add(b)}const me=new W(new ai(1,.012,10,96),new bn({color:12616956}));me.rotation.x=-Math.PI/2,me.position.y=1,n.add(me);const Re=new W(new Ot(1,1,300,96,1,!0),new bn({color:8141549,transparent:!0,opacity:.12,side:Ii}));Re.position.y=150,n.add(Re);const we=new Map;let Xe=null;hm.then(b=>{if(!b)return;Xe=b;const T=[...we.values()].find(U=>U.isPlayer);T&&Gi(T)});const $t=1.3,hn=R(96,1657580819,235,255);hn.repeat.set(5,9),hn.colorSpace=Yn;const Qt=new pi({color:14460798,roughness:.72,sheen:.12,sheenColor:new Qe(16762790)}),ce=new pi({color:2103855,roughness:.62,clearcoat:.22,clearcoatRoughness:.65}),Ce=new lt({color:1382442,roughness:.92}),ye=new lt({color:2761504,roughness:.4}),ht=new lt({color:4863268,roughness:.9}),Nt=new Zn(1.5,8,8),bt=new Ot(3.6,3.2,10,14),xn=new Ot(3,2.6,10,14),Bt=new Ot(3.7,3.25,11,20),pe=new Ot(3.35,2.85,11,20),ve=new Ot(2.8,2.4,10,14),ge=new Ot(2.3,2,10,14),Be=new Ot(3.7,3.05,12,24),Fe=new Ot(3.15,2.65,12,24),Et=new Zn(3.12,20,14),dt=new Ll(2.55,4.2,8,18),Ut=new Zn(2.8,10,10),Gt=new Ot(2.6,2.9,5,8),F=new fn(9,8,15),wn=new Zn(.95,8,8),rn=new Zn(1.2,8,8),P=new lt({color:13938487,emissive:4863752,roughness:.4,metalness:.6}),y=new lt({color:7036234,roughness:.95}),z=new gs(.9),J=new ai(3.4,1,6,20,Math.PI*1.55),oe=new Qe(463919),Ee=new Qe(398387);function Ae(b,T,U,H){const O=-U/2,q=U/2,te=-H/2,Q=H/2,Z=T/2,Se=b/2,be=[te,O,-Z,te,O,Z,te,q,-Se,te,q,Se,Q,O,-Z,Q,O,Z,Q,q,-Se,Q,q,Se],Le=[0,2,1,1,2,3,4,5,6,5,7,6,0,4,2,2,4,6,1,3,5,3,7,5,2,6,3,3,6,7,0,1,4,1,5,4],et=new Tn;return et.setAttribute("position",new Dt(be,3)),et.setIndex(Le),et.computeVertexNormals(),et}const re=Ae(7.5,9.2,23,2.1),ue=Ae(6.8,8.2,21,1.7),Ne=Ae(5.6,6.8,20,1.5);function ft(){const b=[new _e(7.5,-11),new _e(7.8,-8),new _e(8.5,-3),new _e(9.2,3),new _e(10.8,7.5),new _e(10.4,9.5),new _e(8.3,11)],T=new Yd(b,32);return T.computeVertexNormals(),T}function Oe(){const b=new er([new I(0,62,0),new I(-.4,71,0),new I(-1.2,81,-1.2),new I(-3.5,90,-4.2),new I(-7.2,97,-9),new I(-10.5,101,-13)],!1,"centripetal",.45),T=28,U=24,H=b.computeFrenetFrames(T,!1),O=[],q=[],te=[];for(let Z=0;Z<=T;Z++){const Se=Z/T,be=b.getPointAt(Se),Le=H.normals[Z],et=H.binormals[Z],gt=.28+8.9*Math.pow(1-Se,.86);for(let Te=0;Te<U;Te++){const Ke=Te/U*Math.PI*2,je=Math.cos(Ke),tt=Math.sin(Ke);O.push(be.x+Le.x*je*gt+et.x*tt*gt,be.y+Le.y*je*gt+et.y*tt*gt,be.z+Le.z*je*gt+et.z*tt*gt),q.push(Te/U,Se*3)}}for(let Z=0;Z<T;Z++)for(let Se=0;Se<U;Se++){const be=(Se+1)%U,Le=Z*U+Se,et=Z*U+be,gt=(Z+1)*U+Se,Te=(Z+1)*U+be;te.push(Le,gt,et,et,gt,Te)}const Q=new Tn;return Q.setAttribute("position",new Dt(O,3)),Q.setAttribute("uv",new Dt(q,2)),Q.setIndex(te),Q.computeVertexNormals(),Q}const Ue=ft(),vt=Oe(),Tt=new lt({color:7287317,roughness:.78}),Vt=new pi({color:2504022,roughness:.35,metalness:.76}),k=new pi({color:12372188,roughness:.24,metalness:.82}),Pe=new pi({color:3477597,roughness:.72,clearcoat:.2}),le=new lt({color:5217343,roughness:.8}),Ie=new Map;function ke(b){return Ie.has(b)||Ie.set(b,new bn({color:b,transparent:!0,opacity:.9,blending:Ci,depthWrite:!1,toneMapped:!1})),Ie.get(b)}function fe(b,T,U,H,O,q=12){const te=new I().subVectors(U,T),Q=te.length(),Z=new W(new Ot(H,H*1.06,Q,q),O);return Z.position.copy(T).add(U).multiplyScalar(.5),Z.quaternion.setFromUnitVectors(xa,te.normalize()),Z.castShadow=!0,b.add(Z),Z}function ut(b){const T=new pn;T.name=`HeldBaseWeapon:${b}`;const U=ke(4581375),H=ke(11885055);if(b==="focusing-crystal-staff"){fe(T,new I(-.22,-.18,0),new I(.58,.54,0),.024,Tt);const O=new W(new gs(.115,1),H);O.position.set(.64,.61,0),O.scale.set(.68,1.45,.68),T.add(O);for(const q of[-1,1])fe(T,new I(.48,.45,0),new I(.64,.59,q*.1),.015,k,8)}else if(b==="thunderclap-gauntlet"){const O=new W(new Ot(.12,.16,.42,10),Vt);O.rotation.z=Math.PI/2,O.position.set(-.06,.02,0),T.add(O);const q=new W(new fn(.23,.2,.22),Vt);q.position.set(.19,.02,0),q.rotation.z=-.16,T.add(q);for(let Q=0;Q<4;Q++){const Z=new W(new gs(.055),P);Z.position.set(.28,.08,(Q-1.5)*.055),T.add(Z)}const te=new W(new ai(.105,.018,7,24),U);te.position.set(.03,.14,0),te.rotation.x=Math.PI/2,T.add(te)}else if(b==="arcane-spellbook"){const O=new W(new fn(.34,.43,.11),Pe);O.position.set(.22,.14,.08),O.rotation.z=-.18,O.castShadow=!0,T.add(O);const q=new W(new fn(.29,.37,.115),new lt({color:14207649,roughness:.9}));q.position.copy(O.position),q.rotation.copy(O.rotation),q.scale.set(.91,.91,.9),T.add(q);const te=new W(new gs(.07),U);te.position.set(.26,.16,.155),T.add(te);for(const Q of[[.08,-.01],[.37,-.01],[.08,.31],[.37,.31]]){const Z=new W(new fn(.06,.06,.14),P);Z.position.set(Q[0],Q[1],.08),T.add(Z)}}else if(b==="enchanted-bow"){const O=new er([new I(-.05,-.42,0),new I(.17,-.24,0),new I(.05,0,0),new I(.17,.24,0),new I(-.05,.42,0)]),q=new W(new Ka(O,24,.025,8,!1),Tt);q.castShadow=!0,T.add(q);const te=new Tn().setFromPoints([new I(-.05,-.42,0),new I(.04,0,0),new I(-.05,.42,0)]);T.add(new Wl(te,new Vd({color:7536541})));for(const Q of[-.3,.3]){const Z=new W(new Zn(.05,8,6),le);Z.position.set(.11,Q,.025),Z.scale.set(1.7,.65,.35),T.add(Z)}}else if(b==="chaos-orb"){const O=new W(new sr(.19,2),H);O.position.set(.28,.2,0),T.add(O);for(const q of[0,Math.PI/2]){const te=new W(new ai(.27,.018,6,28),U);te.position.copy(O.position),te.rotation.x=q,te.rotation.y=q*.55,T.add(te)}for(let q=0;q<5;q++){const te=new W(new gs(.045),H),Q=q/5*Math.PI*2;te.position.set(.28+Math.cos(Q)*.34,.2+Math.sin(Q)*.34,.04),T.add(te)}}else{fe(T,new I(-.03,-.05,0),new I(.52,.31,0),.023,Tt);for(const q of[.12,.3,.47]){const te=new W(new ai(.032,.006,5,12),P);te.position.set(q,q*.62-.05,0),te.rotation.x=Math.PI/2,T.add(te)}const O=new W(new gs(.075),U);O.position.set(.56,.35,0),T.add(O)}return T.traverse(O=>{O.isMesh&&(O.castShadow=!0)}),T}function ot(){const b=new pn;b.name="HeldShovel";const T=new W(new Ot(.026,.034,.58,10),new lt({color:7025949,roughness:.78}));T.rotation.z=-.22,T.position.set(.05,-.08,0),b.add(T);const U=new W(new ai(.075,.014,6,14),new lt({color:12157506,metalness:.5,roughness:.38}));U.rotation.y=Math.PI/2,U.position.set(-.015,.18,0),b.add(U);const H=new W(new Fi(.15,.22,4),new pi({color:10332861,metalness:.8,roughness:.28,clearcoat:.35}));H.rotation.z=-.22,H.position.set(.18,-.39,0),H.scale.set(.7,1,.22),b.add(H);const O=new W(new gs(.045),ke(4581375));return O.position.set(.12,-.33,.045),b.add(O),b.traverse(q=>{q.isMesh&&(q.castShadow=!0)}),b}function zn(b,T){if(b){b.heldWeapon&&(b.heldWeapon.visible=!T);for(const U of b.heldWeaponParts||[])U.visible=!T;b.shovel&&(b.shovel.visible=!!T)}}function Fn(b,T,U="apprentice-wand"){const H=new pn,O=new pn;H.name=T?"PlayerWizardModel":"BotWizardModel",O.name="WizardAnimationRig";const q=new Qe(b),te=T?oe.clone():q.clone(),Q=new pi({color:te.clone().multiplyScalar(T?1.15:.75),map:hn,bumpMap:hn,bumpScale:.18,roughness:T?.88:.6,metalness:T?.05:0,sheen:.35,sheenColor:te.clone().multiplyScalar(1.8),sheenRoughness:.8}),Z=[];for(const Ye of[-1,1]){const Ze=new pn;Ze.name=Ye<0?"LeftHip":"RightHip",Ze.position.set(0,22,Ye*(T?5.5:4.8));const At=new W(T?Bt:bt,Ce);At.position.y=T?-5.5:-5,At.castShadow=!0,Ze.add(At);const zt=new pn;zt.name=Ye<0?"LeftKnee":"RightKnee",zt.position.y=T?-11:-10;const Jt=new W(T?pe:xn,ce);Jt.position.y=T?-5.5:-5,Jt.castShadow=!0,zt.add(Jt);const Qn=new pn;Qn.name=Ye<0?"LeftAnkle":"RightAnkle",Qn.position.y=T?-11:-10;const Gn=new W(dt,ce);Gn.position.set(2,T?-.25:-.5,0),Gn.rotation.z=Math.PI/2,T||Gn.scale.setScalar(.86),Gn.castShadow=!0,Qn.add(Gn),zt.add(Qn),Ze.add(zt),O.add(Ze),Z.push({hip:Ze,knee:zt,ankle:Qn})}const Se=new W(F,ce);Se.position.y=T?23:22,Se.castShadow=!0,O.add(Se);const be=new pi({color:te,map:hn,bumpMap:hn,bumpScale:.2,roughness:T?.95:.85,emissive:te.clone().multiplyScalar(T?.16:.1),sheen:.28,sheenColor:te.clone().multiplyScalar(1.6),sheenRoughness:.84}),Le=new W(T?Ue:new Ot(8.2,7.1,20,16),be);if(Le.name=T?"FittedWizardCoat":"BotRobe",Le.position.y=T?37:36,Le.scale.set(T?.78:.82,1,T?1.15:1.08),Le.castShadow=!0,O.add(Le),!T)for(const Ye of[-1,1])for(const Ze of[-1,1]){const At=new W(Ne,be);At.position.set(Ze*5.85,15,Ye*3.45),At.rotation.x=Ye*.012,At.castShadow=!0,O.add(At)}const et=T?new lt({color:2103055,roughness:.8,metalness:.15}):P,gt=T?8.8:7.8,Te=new W(new Ot(gt,gt,3,16),et);if(Te.position.y=26,Te.scale.set(.85,1,1),O.add(Te),T){const Ye=new W(new ai(2.8,.65,7,18),P);Ye.position.set(7.5,26,0),Ye.rotation.y=Math.PI/2,O.add(Ye);for(const Ze of[-1,1]){const At=new W(new Ot(.5,.5,19,7),P);At.position.set(7.35,37.5,Ze*4.5),O.add(At)}}const Ke=T?[[7.3,43,1.8],[7.4,36,-2.5],[7.2,23,1.8],[7.2,14,-2.4],[7.1,46,-1.8],[7.3,29,2.8]]:[[8.4,40,1.5],[9.6,33,-2],[11.1,22,1.5],[12.1,16,-2],[7.9,45,-1.5],[10.2,28,2.5]];for(const[Ye,Ze,At]of Ke){const zt=new W(z,P);zt.position.set(Ye,Ze,At),O.add(zt)}if(T){const Ye=new lt({color:Ee,roughness:.96,emissive:new Qe(132883),side:xi});for(const In of[-1,1]){const ei=new W(re,Ye);ei.position.set(-6.7,14.5,In*4.55),ei.rotation.x=In*.018,ei.castShadow=!0,O.add(ei);const Ei=new W(ue,be);Ei.position.set(6.35,15.5,In*4.15),Ei.rotation.x=In*.015,Ei.castShadow=!0,O.add(Ei);const X=new W(new fn(.7,1.2,8.3),P);X.position.set(-7.8,3.05,In*4.55),O.add(X);const $e=new W(new fn(.7,1.2,7.5),P);$e.position.set(7.25,5.05,In*4.15),O.add($e)}const Ze=new W(new fn(2,12,18.5),Ye);Ze.position.set(-6.8,39.5,0),Ze.castShadow=!0,O.add(Ze);const At=new W(new Ot(8.5,10.2,3,24,1,!0),Ye);At.position.set(-.8,45.5,0),At.scale.set(.82,1,1),At.castShadow=!0,O.add(At);const zt=new W(new ai(9.15,.55,6,28),P);zt.rotation.x=Math.PI/2,zt.position.set(-.8,47,0),zt.scale.set(.82,1,1),O.add(zt);for(const In of[-1,1]){const ei=new W(new fn(.65,22,.75),P);ei.position.set(-7.8,14.5,In*.55),O.add(ei)}const Jt=new W(J,P);Jt.position.set(-7.9,37,0),Jt.rotation.y=-Math.PI/2,Jt.rotation.z=-.25,Jt.scale.setScalar(1.45),O.add(Jt);const Qn=new W(new ai(5.2,.42,6,32),P);Qn.position.set(-7.85,36.5,0),Qn.rotation.y=-Math.PI/2,O.add(Qn);for(const[In,ei,Ei,X]of[[-7.8,45,-6,1.25],[-7.8,42,6.5,1.05],[-7.85,32,-6.5,1.2],[-7.85,21,5.5,1.35],[-7.85,11,-4.5,1.05],[-7.85,15,7,.9]]){const $e=new W(z,P);$e.position.set(In,ei,Ei),$e.scale.setScalar(X*2.15),O.add($e)}const Gn=new W(J,P);Gn.position.set(7.35,36,-3.8),Gn.rotation.y=Math.PI/2,Gn.scale.setScalar(.8),O.add(Gn)}const je=[];for(const Ye of[-1,1]){const Ze=new pn;Ze.name=Ye<0?"LeftShoulder":"RightShoulder",Ze.position.set(.4,43.5,Ye*(T?12.3:9.2)),Ze.rotation.x=-Ye*.13;const At=new W(new Zn(T?4:3.5,T?24:12,T?16:10),Q);T&&(At.scale.set(.92,.78,1.16),At.position.y=-.65),At.castShadow=!0,Ze.add(At);const zt=new W(T?Be:ve,Q);zt.position.y=T?-6:-5,zt.castShadow=!0,Ze.add(zt);const Jt=new pn;if(Jt.name=Ye<0?"LeftElbow":"RightElbow",Jt.position.y=T?-12:-10,T){const In=new W(Et,Q);In.scale.set(.96,.82,1),In.castShadow=!0,Jt.add(In)}const Qn=new W(T?Fe:ge,Q);if(Qn.position.y=T?-6:-5,Qn.castShadow=!0,Jt.add(Qn),T){const In=new W(new ai(2.75,.5,6,18),P);In.rotation.x=Math.PI/2,In.position.y=-11.35,Jt.add(In)}const Gn=new W(Ut,Qt);Gn.position.y=T?-12.5:-10,T&&Gn.scale.set(1.18,1.05,.82),Jt.add(Gn),Ze.add(Jt),O.add(Ze),je.push({shoulder:Ze,elbow:Jt})}const tt=T?32:24,Mn=T?33:25,ie=new pn;ie.name="FallbackHeldWeaponGroup";const de=T?-12.5:-10;ie.position.set(0,de,0),je[1].elbow.add(ie);const nt=new W(new Ot(1.35,1.75,tt,10),new lt({color:3877402,emissive:2365968}));nt.name="FallbackHeldWeapon";const wt=[ie,nt];if(nt.rotation.z=Math.PI/2,nt.position.set(T?17:13,0,0),ie.add(nt),T)for(const Ye of[7,16,25]){const Ze=new W(new ai(1.75,.35,5,12),P);Ze.rotation.y=Math.PI/2,Ze.position.set(Ye,0,0),ie.add(Ze),wt.push(Ze)}const ct=new W(new Zn(2.6,12,12),new bn({color:16773824}));ct.position.set(Mn,0,0),ie.add(ct),wt.push(ct);const Mt=new W(new Zn(5,12,12),new bn({color:16769162,transparent:!0,opacity:.4,blending:Ci,depthWrite:!1,fog:!1}));if(Mt.position.copy(ct.position),ie.add(Mt),wt.push(Mt),T){const Ye=new w0(16763228,2.2,115,2);Ye.position.copy(ct.position),ie.add(Ye),wt.push(Ye)}const qt=ot();qt.position.set(13,de,0),qt.rotation.z=-.72,qt.userData.restRotationZ=qt.rotation.z,qt.userData.restPositionX=qt.position.x,qt.scale.setScalar(T?1.45:1.1),qt.visible=!1,je[1].elbow.add(qt);const en=new W(T?new Ot(3.15,3.45,9,18):Gt,Qt);T||en.scale.set(1.05,1.35,1.05),en.position.y=T?50:48.5,en.castShadow=!0,O.add(en);const St=new pn;St.name="HeadAndHat",St.position.y=T?4:2,O.add(St);const Pn=new W(new Zn(7.5,18,18),Qt);Pn.position.y=54,Pn.scale.set(T?1.02:.98,T?1.14:1.08,T?.92:.94),St.add(Pn);for(const Ye of[-1,1]){const Ze=new W(wn,ye);Ze.position.set(6.9,54.4,Ye*2.7),St.add(Ze)}const Jn=new W(rn,Qt);Jn.position.set(7.6,52.9,0),St.add(Jn);const kt=new W(new Fi(T?4.7:4.4,T?10:9,T?18:14),y);if(kt.position.set(T?5.2:4.7,T?49:48.2,0),kt.rotation.x=Math.PI,kt.castShadow=!0,St.add(kt),T)for(const Ye of[-1,1]){const Ze=new W(new Zn(3.4,10,10),y);Ze.position.set(5.6,49,Ye*4.8),Ze.scale.set(1,1.25,.8),St.add(Ze);const At=new W(new Ll(.9,3,5,8),y);At.position.set(7.1,50.8,Ye*1.7),At.rotation.x=Math.PI/2,At.rotation.z=Ye*.35,St.add(At)}const Hn=new W(new Zn(7.9,16,16),ht);if(Hn.position.set(-1.1,55.4,0),Hn.scale.set(1.02,.95,.9),Hn.castShadow=!0,St.add(Hn),T)for(const[Ye,Ze,At,zt]of[[-5.8,56,-5.2,1.1],[-6.8,52,-5.8,1],[-6.4,48,-5.2,.95],[-5.8,56,5.2,1.1],[-6.8,52,5.8,1],[-6.4,48,5.2,.95],[-7.4,54,0,1.15]]){const Jt=new W(new Zn(2.5,9,9),ht);Jt.position.set(Ye,Ze,At),Jt.scale.setScalar(zt),Jt.castShadow=!0,St.add(Jt)}for(const Ye of[-1,1]){const Ze=new W(Nt,Qt);Ze.position.set(0,53.6,Ye*7.3),St.add(Ze)}const On=new pi({color:te.clone().multiplyScalar(T?.88:.65),map:hn,bumpMap:hn,bumpScale:T?.22:.1,roughness:T?.95:.85,sheen:T?.32:.12,sheenColor:te.clone().multiplyScalar(1.7),sheenRoughness:.82,side:xi}),qn=new W(new Fi(T?18:13,T?3:4,28),On);if(qn.position.y=61,qn.castShadow=!0,St.add(qn),T){const Ye=new W(vt,On);Ye.name="BentWizardHat",Ye.castShadow=!0,St.add(Ye);const Ze=new W(new ai(9.15,.85,7,30),P);Ze.position.y=63.2,Ze.rotation.x=Math.PI/2,St.add(Ze);const At=new W(new ai(17.6,.65,6,40),P);At.position.y=60.8,At.rotation.x=Math.PI/2,St.add(At)}else{const Ye=new W(new Fi(8.5,34,18),On);Ye.position.y=78,Ye.castShadow=!0,St.add(Ye)}const _n=T?[[-8,70,-2],[-7.2,78,3],[-6,86,-1.5],[-7.2,94,1]]:[[6.5,64,1.5],[5.5,70,-1.5],[3.8,78,1],[2.2,85,-1]];for(const[Ye,Ze,At]of _n){const zt=new W(z,P);zt.position.set(Ye,Ze,At),T&&zt.scale.setScalar(2.1),St.add(zt)}if(T){const Ye=new W(new ai(Ct.radius+7,1.25,8,32),new bn({color:13938487,transparent:!0,opacity:.5}));Ye.rotation.x=-Math.PI/2,Ye.position.y=1.5,O.add(Ye)}T?O.scale.set(1.5,1.65,1.5):O.scale.setScalar($t);const jn=new W(new ir(T?25:18,32),new bn({color:462872,transparent:!0,opacity:T?.3:.24,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));return jn.rotation.x=-Math.PI/2,jn.position.y=1.2,H.add(jn),H.add(O),n.add(H),{group:H,robe:Le,robeColor:te,legs:Z,arms:je,pelvis:Se,body:O,contact:jn,isPlayer:T,baseWeaponId:U,heldWeapon:ie,heldWeaponParts:wt,shovel:qt}}function Hi(b){let T=we.get(b.id);if(T&&T.baseWeaponId!==b.baseWeaponId&&(Cc(T),n.remove(T.group),we.delete(b.id),T=null),!T){T=Fn(b.color,b.isPlayer,b.baseWeaponId);const U=new pn,H=new W(new ai(38,2.6,7,48),new bn({color:9133302,transparent:!0,opacity:.72,blending:Ci,depthWrite:!1}));H.rotation.x=Math.PI/2,H.position.y=26,U.add(H);for(let O=0;O<14;O++){const q=new W(new Zn(1.8+O%3,8,6),new bn({color:O%2?6333946:12616956,transparent:!0,opacity:.78,blending:Ci,depthWrite:!1}));q.userData.angle=O/14*Math.PI*2,q.userData.phase=O%5*.7,U.add(q)}U.visible=!1,T.group.add(U),T.slowFallAura=U,T.dead=!1,T.diggingMode=!1,T.diggingAction=!1,we.set(b.id,T),b.isPlayer&&Xe&&Gi(T)}return zn(T,T.diggingMode),T}function Gi(b){var Q;if(!Xe||b.advancedModel)return;Cc(b);const T=Xe.scene;T.name="AdvancedWizardGLB",T.position.set(0,0,0),T.rotation.set(0,0,0),T.scale.set(74,74,74*.84);const U=[],H=[];T.traverse(Z=>{if((Z.name.startsWith("WizardWand")||Z.name.startsWith("WandGrip")||Z.name.startsWith("WandGem")||Z.name.startsWith("HeldBaseWeapon:"))&&H.push(Z),!Z.isMesh)return;Z.castShadow=!0,Z.receiveShadow=!0;const Se=Array.isArray(Z.material)?Z.material:[Z.material];for(const be of Se)be!=null&&be.color&&(be.name==="LinenTunic"||be.name==="LinenCuffs"||be.name==="OliveTrousers"||be.name==="OliveCuffs")&&U.push({material:be,base:be.color.clone()})});for(const Z of H)Z.name.startsWith("HeldBaseWeapon:")?(Q=Z.parent)==null||Q.remove(Z):Z.visible=!1;b.body.visible=!1,b.group.add(T);const O=ut(b.baseWeaponId),q=T.getObjectByName("hand.R");if(q){T.updateMatrixWorld(!0),q.updateMatrixWorld(!0);const Z=new I(.095,.9,.31);T.localToWorld(Z),q.worldToLocal(Z),O.position.copy(Z);const Se=T.getWorldQuaternion(new ci),be=q.getWorldQuaternion(new ci).invert();O.quaternion.copy(be.multiply(Se)),q.add(O)}else O.position.set(.095,.9,.31),T.add(O);if(b.heldWeapon=O,dm.then(Z=>{if(!Z||!b.advancedModel)return;const Se=Z.scene.clone(!0);Se.name="HeldShovelBlender",Se.scale.setScalar(.19),Se.rotation.set(0,0,-.86),Se.position.set(.095,.9,.31),Se.traverse(Le=>{Le.isMesh&&(Le.castShadow=!0,Le.receiveShadow=!0)});const be=q||T;b.shovel&&be.remove(b.shovel),be.add(Se),b.shovel=Se,Se.userData.restRotationZ=Se.rotation.z,Se.userData.restPositionX=Se.position.x,zn(b,b.diggingMode)}),b.shovelLoad=dm,q){const Z=b.shovel;Z&&(q.add(Z),Z.position.set(.095,.9,.31),Z.scale.setScalar(.19),Z.rotation.set(0,0,-.86),Z.userData.restRotationZ=Z.rotation.z,Z.userData.restPositionX=Z.position.x)}b.advancedModel=T,b.advancedTintMaterials=U,b.advancedMixer=new Cy(T),b.advancedActions=new Map;for(const Z of Xe.animations){const Se=b.advancedMixer.clipAction(Z);b.advancedActions.set(Z.name,Se)}const te=b.advancedActions.get("Idle");te&&(te.setLoop(Wh,1/0),te.play(),b.advancedAction=te,b.advancedActionName="Idle")}function Jl(b,T){var te,Q;if(b.advancedActionName===T)return;const U=((te=b.advancedActions)==null?void 0:te.get(T))||((Q=b.advancedActions)==null?void 0:Q.get("Idle"));if(!U)return;const H=b.advancedAction,O=T==="Cast"||T==="JumpUp"||T==="JumpDown",q=T.startsWith("Jump")?.08:.24;U.reset(),U.enabled=!0,U.setEffectiveWeight(1),U.setLoop(O?Qm:Wh,O?1:1/0),U.clampWhenFinished=O,U.fadeIn(q).play(),H&&H!==U&&H.fadeOut(q),b.advancedAction=U,b.advancedActionName=T}function jl(b,T,U){const H=T.x-(b.prevX??T.x),O=T.y-(b.prevY??T.y);b.prevX=T.x,b.prevY=T.y,Math.hypot(H,O)/Math.max(U,.001)>20?b.motionHold=.14:b.motionHold=Math.max(0,(b.motionHold??0)-U);const te=b.motionHold>0?1:0,Q=te>(b.motionBlend??0)?11:6;b.motionBlend=(b.motionBlend??0)+(te-(b.motionBlend??0))*(1-Math.exp(-Q*U));let Z="Idle";T.climbState==="wall"?Z="Climb":T.slashTimer>0||(T.castTimer||0)>0?Z="Cast":(T.jumpH||0)>1?(T.jumpV||0)>110?Z="JumpUp":(T.jumpV||0)<-110?Z="JumpDown":Z="JumpAir":b.motionBlend>.08&&(Z=T.running?"Run":"Walk"),Jl(b,Z),b.advancedMixer.timeScale=Z==="Run"?1.05:Z==="Walk"?.82+b.motionBlend*.18:Z==="JumpUp"?4.2:Z==="JumpAir"?3:Z==="JumpDown"?9.5:Z==="Climb"&&T.climbBlocked?0:1,b.advancedMixer.update(U),b.group.position.y=De(T.x,T.y)+(T.climbH||0)+(T.flyH||0)+(T.jumpH||0)+(T.openingH||0)}function Tc(b,T,U){const H=T.x-(b.prevX??T.x),O=T.y-(b.prevY??T.y);b.prevX=T.x,b.prevY=T.y;const q=Math.hypot(H,O)/Math.max(U,.001);q>20?b.motionHold=.14:b.motionHold=Math.max(0,(b.motionHold??0)-U);const te=b.motionHold>0?1:0,Q=b.walkAmt=(b.walkAmt??0)+(te-(b.walkAmt??0))*(1-Math.exp(-(te>(b.walkAmt??0)?11:6)*U)),Z=Math.max(0,Math.min(1,(q-Ct.speed*.82)/(Ct.runSpeed-Ct.speed*.82))),Se=5.7+Z*3.1;b.walkPhase=(b.walkPhase??0)+U*Se*Q;const be=30,Le=(De(T.x+be,T.y)-De(T.x-be,T.y))/(2*be),et=(De(T.x,T.y+be)-De(T.x,T.y-be))/(2*be),gt=Math.hypot(Le,et),Te=T.climbState==="wall",Ke=(T.jumpH||0)>0,je=Te?1:Ke?0:id(gt,.4,.75)*Q,tt=b.climbAmt=(b.climbAmt??0)+(je-(b.climbAmt??0))*(1-Math.exp(-12*U)),Mn=Te?T.climbBlocked?0:T.wantClimb?5.2:-3.8:je>0?4.4:0;b.climbPhase=(b.climbPhase??0)+U*Mn;const ie=(Mt,qt,en)=>Mt+(qt-Mt)*en;for(let Mt=0;Mt<2;Mt++){const qt=Mt===0?-1:1,en=b.walkPhase+(Mt===0?0:Math.PI),St=Math.sin(en),Pn=Math.cos(en),Jn=Math.max(0,Math.sin(en+.48));let Hn=(.48+Z*.2)*St*Q,On=-(.1+Jn*(.76+Z*.24))*Q,qn=(.08*Pn+.24*Jn-.1*Math.max(0,-St))*Q,_n=-qt*.13,jn=-(.34+Z*.16)*St*Q,Ye=-(.22+.22*Math.max(0,-St))*Q;if(tt>.001){const zt=.5+.5*Math.sin(b.climbPhase+(Mt===0?0:Math.PI)),Jt=1-zt;Hn=ie(Hn,-.45+1.8*zt,tt),On=ie(On,-.2-1.65*zt,tt),qn=ie(qn,.18+.28*zt,tt),jn=ie(jn,2.35+.7*Jt,tt),_n=ie(_n,-qt*(.08+.2*Jt),tt),Ye=ie(Ye,-1.15+.95*Jt,tt)}const Ze=Math.max(0,Math.min(1,(T.jumpH||0)/14));if(Ze>0){const At=(T.jumpV||0)>0?1:0;Hn=ie(Hn,.3+qt*.08,Ze),On=ie(On,-.75-At*.45,Ze),qn=ie(qn,.2,Ze),jn=ie(jn,-qt*.32,Ze),Ye=ie(Ye,-.35,Ze)}b.legs[Mt].hip.rotation.z=Hn,b.legs[Mt].knee.rotation.z=On,b.legs[Mt].ankle.rotation.z=qn,b.arms[Mt].shoulder.rotation.x=_n,b.arms[Mt].shoulder.rotation.z=jn,b.arms[Mt].elbow.rotation.z=Ye}const de=Q*(1-tt)*(1-Math.min(1,(T.jumpH||0)/8));b.body.rotation.x=Math.cos(b.climbPhase)*.045*tt+Math.cos(b.walkPhase)*.018*de,b.body.rotation.y=Math.sin(b.climbPhase)*.07*tt+Math.sin(b.walkPhase)*.045*de,b.body.rotation.z=-tt*.27+Math.sin(b.climbPhase)*.09*tt-(.025+Z*.035)*de,b.body.position.z=Math.sin(b.walkPhase)*.34*de,b.pelvis.rotation.y=-Math.sin(b.walkPhase)*.055*de,b.pelvis.rotation.z=Math.cos(b.walkPhase)*.025*de;const nt=(.5-.5*Math.cos(b.walkPhase*2))*(1.35+Z*.5)*Q*(1-tt*.8),wt=(.5-.5*Math.cos(b.climbPhase*2))*5.5*tt;b.group.position.y=De(T.x,T.y)+(T.climbH||0)+(T.flyH||0)+(T.jumpH||0)+(T.openingH||0)+nt+wt;const ct=b.arms[1];if(tt<.45&&T.slashTimer>0){const Mt=1-T.slashTimer/Fs.slash.duration;ct.shoulder.rotation.z=2.3-2.5*Mt,ct.shoulder.rotation.x=-.9+1.8*Mt,ct.elbow.rotation.z=-.25}else if(tt<.45){const Mt=T.castTimer||0;Mt>0&&(ct.shoulder.rotation.z=ct.shoulder.rotation.z*(1-Mt)+1.5*Mt,ct.elbow.rotation.z=ct.elbow.rotation.z*(1-Mt)+0*Mt)}}const Zs=[],xa=new I(0,1,0),Wo=new I,wc=new Ot(1,1,1,12),$s=new Ot(1.7,1.7,1,12);function _a(b){for(;Zs.length<b;){const T=new pn,U=new W(wc,new bn({color:16777215,toneMapped:!1})),H=new W($s,new bn({color:16777215,transparent:!0,opacity:.26,blending:Ci,depthWrite:!1,toneMapped:!1}));T.add(U),T.add(H),T.userData.core=U,T.userData.glow=H,n.add(T),Zs.push(T)}for(let T=0;T<Zs.length;T++)Zs[T].visible=T<b;return Zs}const Ao=[];let va=null;const yr=new Zd(2.2,0),ya=[new bn({color:new Qe(16758062).multiplyScalar(1.8),blending:Ci,transparent:!0,opacity:.95,depthWrite:!1,toneMapped:!1}),new bn({color:new Qe(16773544).multiplyScalar(2.2),blending:Ci,transparent:!0,opacity:.95,depthWrite:!1,toneMapped:!1})];function Mr(b){let T=Ao.find(U=>!U.active);if(!T&&Ao.length<96){const U=new W(yr,ya[b%ya.length]);U.visible=!1,n.add(U),T={mesh:U,active:!1,life:0,maxLife:0,vx:0,vy:0,vz:0},Ao.push(T)}return T||(T=Ao.reduce((U,H)=>H.life<U.life?H:U)),T}function Ec(b){const T=b.worldZ??De(b.x,b.y)+(b.z||0);for(let U=0;U<8;U++){const H=Mr(U),O=Math.random()*Math.PI*2,q=75+Math.random()*95,te=.3+Math.random()*.7;H.active=!0,H.life=H.maxLife=.16+Math.random()*.16,H.vx=Math.cos(O)*q*(1-te*.35),H.vy=q*te,H.vz=Math.sin(O)*q*(1-te*.35),H.mesh.position.set(b.x,T,b.y),H.mesh.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3),H.mesh.scale.setScalar(1),H.mesh.visible=!0}}function Ac(b,T){for(const U of Ao)if(U.active){if(U.life-=T,U.life<=0){U.active=!1,U.mesh.visible=!1;continue}U.vy-=360*T,U.mesh.position.x+=U.vx*T,U.mesh.position.y+=U.vy*T,U.mesh.position.z+=U.vz*T,U.mesh.rotation.x+=14*T,U.mesh.rotation.z+=18*T,U.mesh.scale.setScalar(Math.max(.08,U.life/U.maxLife))}if(b!==va){va=b;for(const U of b||[])(U.type==="hit"||U.type==="block"||U.type==="dig")&&Ec(U)}}const Xo=[];let Rc=null;const Ql=new Ot(1,1,1,10),eu=new Zn(1,18,10);function w(b,T=.72,U=!1){return new bn({color:new Qe(b||"#67e8f9").multiplyScalar(1.8),transparent:!0,opacity:T,wireframe:U,blending:Ci,depthWrite:!1,toneMapped:!1})}function G(b){const T=De(b.x,b.y)+(b.z||55),U=b.endZ!=null?De(b.x,b.y)+b.endZ:De(b.endX,b.endY)+55,H=new I(b.x,T,b.y),O=new I(b.endX,U,b.endY),q=O.clone().sub(H),te=Math.max(1,q.length()),Q=new W(Ql,w(b.color,.9));Q.position.copy(H).add(O).multiplyScalar(.5),Q.quaternion.setFromUnitVectors(xa,q.normalize()),Q.scale.set(b.width||3,te,b.width||3),n.add(Q),Xo.push({mesh:Q,life:.14,maxLife:.14,grow:!1})}function ee(b){const T=b.radius||b.range||90,U=b.worldZ??De(b.x,b.y)+35,H=new W(eu,w(b.color,.58,!0));H.position.set(b.x,U,b.y),H.scale.setScalar(T*.18),n.add(H),Xo.push({mesh:H,life:.34,maxLife:.34,grow:!0,radius:T})}function $(b,T){for(let U=Xo.length-1;U>=0;U--){const H=Xo[U];if(H.life-=T,H.life<=0){n.remove(H.mesh),H.mesh.material.dispose(),Xo.splice(U,1);continue}const O=H.life/H.maxLife;if(H.mesh.material.opacity=O*.75,H.grow){const q=1-O;H.mesh.scale.setScalar(H.radius*(.18+q*.82))}}if(b!==Rc){Rc=b;for(const U of b||[])U.type==="beam"||U.type==="chain"||U.type==="grapple"?G(U):(U.type==="nova"||U.type==="explosion"||U.type==="shield"||U.type==="blink")&&ee(U)}}const Y=[];function Ve(b){for(;Y.length<b;){const T=new W(new ir(1,24,-Fs.slash.arc/2,Fs.slash.arc),new bn({color:Fs.slash.color,transparent:!0,opacity:.4,side:xi}));T.rotation.x=-Math.PI/2,n.add(T),Y.push(T)}for(let T=0;T<Y.length;T++)Y[T].visible=T<b;return Y}const qe=[],He=new gs(12,1),at=new ai(19,1.6,7,28);function pt(b){for(;qe.length<b;){const T=new pn,U=new W(He,new bn({color:16777215,toneMapped:!1})),H=new W(at,new bn({color:16777215,transparent:!0,opacity:.72,blending:Ci,depthWrite:!1,toneMapped:!1}));H.rotation.x=Math.PI/2;const O=H.clone();O.material=H.material.clone(),O.rotation.set(Math.PI/2,Math.PI/2,0),T.add(U,H,O),T.userData={core:U,ring:H,tierRing:O},n.add(T),qe.push(T)}for(let T=0;T<qe.length;T++)qe[T].visible=T<b;return qe}const Ht={dist:178,side:.51,anchor:90,drop:.2},Xt={dist:44,side:.84,anchor:72,drop:.02},mt=20;let mn=0,Wn=-.26,dn=0;const Rt=new I().copy(s.position),gi=new I,Je=new I,ni=new I,cn=new I,wi=new I,Di=new I,ji=new I,Js=new I,En=new I,$n=new I(0,0,-1),Qi=new ci,An=new ci,ds=new ci,As=new ci,qo=new ws;let tu=!1;function Cc(b){var U;const T=b==null?void 0:b.weaponPose;T&&((U=T.anchor.parent)==null||U.remove(T.anchor),T.weapon.parent===n&&n.remove(T.weapon),b.weaponPose=null)}function ag(b){var O;const T=b==null?void 0:b.heldWeapon;if(!(T!=null&&T.parent))return null;if(((O=b.weaponPose)==null?void 0:O.weapon)===T)return b.weaponPose;Cc(b);const U=T.parent,H=new kn;return H.name=`HipWeaponAnchor:${b.baseWeaponId}`,H.position.copy(T.position),H.quaternion.copy(T.quaternion),H.scale.copy(T.scale),U.add(H),U.updateMatrixWorld(!0),T.updateMatrixWorld(!0),n.attach(T),b.weaponPose={weapon:T,anchor:H},b.weaponPose}function pf(b,T){if(!(b!=null&&b.isPlayer)||!b.heldWeapon)return;const U=ag(b);if(!U)return;const{weapon:H,anchor:O}=U,q=Qd(b.baseWeaponId);O.updateWorldMatrix(!0,!1),O.getWorldPosition(cn),O.getWorldQuaternion(Qi),O.getWorldScale(ji),Di.fromArray(q.hipWeaponPosition).applyQuaternion(Qi),cn.add(Di),wi.fromArray(q.adsWeaponPosition).applyQuaternion(s.quaternion).add(s.position);const te=Math.max(0,Math.min(1,T.castTimer||0))*dn;Di.set(0,0,te*7).applyQuaternion(s.quaternion),wi.add(Di),En.fromArray(q.weaponAimAxis).normalize(),ds.setFromUnitVectors(En,$n),qo.set(...q.adsWeaponRotation),As.setFromEuler(qo),An.copy(s.quaternion).multiply(ds).multiply(As),te>0&&(qo.set(-te*.055,0,0),An.multiply(As.setFromEuler(qo))),Js.copy(ji).multiplyScalar(q.adsWeaponScale),H.position.lerpVectors(cn,wi,dn),H.quaternion.slerpQuaternions(Qi,An,dn),H.scale.lerpVectors(ji,Js,dn),H.visible=b.group.visible&&!b.diggingMode&&!b.dead}function cg(b,T,U){if(!U)return;ni.subVectors(T,b);const H=ni.length();if(H<1)return;const O=Math.ceil(H/22);let q=1;for(let te=1;te<=O;te++){const Q=te/O,Z=b.x+ni.x*Q,Se=b.y+ni.y*Q,be=b.z+ni.z*Q;if(Gl(Z,be,Se,mt,U)){q=Math.max(0,Q-mt/H);break}}q<1&&T.set(b.x+ni.x*q,b.y+ni.y*q,b.z+ni.z*q)}function lg(b,T){mn=b,Wn=T}function ug(b){dn=Ui.clamp(b,0,1)}function mf(b,T,U){var Ei,X,$e;const H=b.wizards.find(Pt=>Pt.isPlayer&&Pt.playerIndex===U);if(!H)return;const O=De(H.x,H.y)+(H.climbH||0)+(H.flyH||0)+(H.jumpH||0)+(H.openingH||0);p.position.set(H.x,O,H.y),d.position.set(H.x+a.x,a.y+O,H.y+a.z),x.position.set(H.x+c.x*l,c.y*l,H.y+c.z*l),m.position.copy(x.position);const q=Math.cos(mn),te=Math.sin(mn),Q=-Math.sin(mn),Z=Math.cos(mn),Se=Math.cos(Wn),be=Math.sin(Wn),Le=q*Se,et=te*Se,gt=-q*be,Te=Se,Ke=-te*be;let je=Ui.lerp(Ht.dist,Xt.dist,dn),tt=Ui.lerp(Ht.side,Xt.side,dn),Mn=Ui.lerp(Ht.drop,Xt.drop,dn);const ie=((Ei=b.opening)==null?void 0:Ei.phase)==="countdown"||((X=b.opening)==null?void 0:X.phase)==="choose";ie&&!H.slowFalling?(je=205,tt=.18,Mn=.34):H.slowFalling&&(je=250,tt=.36,Mn=.25);const de=Ui.clamp(Wn/(Math.PI/3),0,1),nt=Ui.lerp(Ht.anchor,Xt.anchor,dn)+de*55,wt=O+nt,ct=-be+Te*Mn;if(ct<0){const Pt=(wt-(O+45))/-ct;je=Math.min(je,Math.max(72,Pt))}const Mt=je*tt,qt=je*Mn,en=new I(H.x-Le*je+Q*Mt+gt*qt,wt-be*je+Te*qt,H.y-et*je+Z*Mt+Ke*qt);!tu||ie||Rt.distanceTo(en)>1500?(Rt.copy(en),tu=!0):Rt.lerp(en,1-Math.exp(-18*T));const St=Ui.lerp(18,29,dn);Je.set(H.x+Q*St,wt,H.y+Z*St);const Jn=(($e=b.opening)==null?void 0:$e.phase)&&b.opening.phase!=="complete"?[]:H.climbOver?[H.climbOver,...H.climbNearby||[]]:b.obstacles;cg(Je,Rt,Jn);let kt=De(Rt.x,Rt.z)+45;Rt.y<kt&&(Rt.y=kt);const Hn=O+90;let On=H.x-Rt.x,qn=Hn-Rt.y,_n=H.y-Rt.z,jn=On*Le+qn*be+_n*et;const Ye=Ui.lerp(42,8,dn);if(jn<Ye){const Pt=(Ye-jn)/Math.max(.2,Se);Rt.x-=q*Pt,Rt.z-=te*Pt,kt=De(Rt.x,Rt.z)+45,Rt.y<kt&&(Rt.y=kt),On=H.x-Rt.x,qn=Hn-Rt.y,_n=H.y-Rt.z,jn=On*Le+qn*be+_n*et}s.position.copy(Rt),u.position.copy(s.position),gi.set(Rt.x+Le*600,Rt.y+be*600,Rt.z+et*600),s.lookAt(gi);const Ze=On*gt+qn*Te+_n*Ke,At=On*Q+_n*Z,zt=.72,Jt=Math.max(1,jn),Qn=Ui.radToDeg(2*Math.atan(Math.abs(Ze)/(Jt*zt))),Gn=Ui.radToDeg(2*Math.atan(Math.abs(At)/(Jt*zt*s.aspect))),In=1-dn,ei=Math.min(115,Math.max(o,Ui.lerp(o,Qn,In),Ui.lerp(o,Gn,In)));Math.abs(s.fov-ei)>.01&&(s.fov=ei,s.updateProjectionMatrix())}function gf(b,T,U=0){var Ke,je,tt,Mn;mf(b,T,U);const H=((Ke=b.opening)==null?void 0:Ke.phase)&&b.opening.phase!=="complete";if(g.visible=!!H,H)for(let ie=0;ie<A.length;ie++){const de=A[ie],nt=b.opening.portals[ie],wt=jr[nt.destination];de.material.uniforms.uColor.value.set(wt.color),de.material.uniforms.uTime.value=b.opening.elapsed+ie*.41,de.swirl.material.color.set(wt.color),de.counterSwirl.material.color.set(wt.color),de.sparks.material.color.set(wt.color);const ct=b.opening.phase==="choose",Mt=nt.unstable?.5+Math.sin(b.opening.elapsed*8+ie)*.5:1;de.material.uniforms.uOpen.value=ct?.72+Mt*.18:.12,de.swirl.material.opacity=ct?.68:.16,de.counterSwirl.material.opacity=ct?.5:.1,de.sparks.material.opacity=ct?.9:.18,de.swirl.rotation.z+=T*(nt.unstable?4.8:2.2)*(ie%2?-1:1),de.counterSwirl.rotation.z-=T*(nt.unstable?3.9:1.7)*(ie%2?-1:1);const qt=de.sparks.geometry.attributes.position;for(let St=0;St<qt.count;St++){let Pn=qt.getY(St)+T*(34+St%7*5);Pn>292&&(Pn=12+St%5*7),qt.setY(St,Pn)}qt.needsUpdate=!0;const en=.985+Math.sin(b.opening.elapsed*4.2+ie)*.015;de.energy.scale.set(en,1,1)}N&&(N.offset.x=(N.offset.x+T*.004)%1,N.offset.y=(N.offset.y+T*.0025)%1);const O=b.storm.radius,q=De(b.storm.cx,b.storm.cy);me.scale.set(O,O,1),me.position.set(b.storm.cx,q+2,b.storm.cy),Re.scale.set(O,1,O),Re.position.set(b.storm.cx,q+150,b.storm.cy);const te=O<260;me.material.color.set(te?16281969:12616956),Re.material.color.set(te?15680580:8141549);const Q=new Set;for(const ie of b.wizards){Q.add(ie.id);const de=Hi(ie);if(de.shovel)if(de.diggingTime=(de.diggingTime||0)+T,de.diggingAction){const nt=Math.sin(de.diggingTime*19)*.42;de.shovel.rotation.z=(de.shovel.userData.restRotationZ??-.86)+nt,de.shovel.position.x=(de.shovel.userData.restPositionX??.095)+Math.max(0,-nt)*.08}else de.shovel.rotation.z=de.shovel.userData.restRotationZ??-.86,de.shovel.position.x=de.shovel.userData.restPositionX??.095;if(ie.alive){const nt=ie.x-(de.renderX??ie.x),wt=ie.y-(de.renderY??ie.y);if(de.renderX===void 0||Math.hypot(nt,wt)>420)de.renderX=ie.x,de.renderY=ie.y;else{const en=1-Math.exp(-22*T);de.renderX+=nt*en,de.renderY+=wt*en}de.group.position.set(de.renderX,De(ie.x,ie.y)+(ie.openingH||0),de.renderY),de.group.rotation.set(0,-ie.heading,0),de.group.visible=!0,de.group.scale.setScalar(1),de.dead=!1;const ct=Math.max(0,ie.health)/Ct.maxHealth;if(de.robe.material.color.copy(de.robeColor).multiplyScalar(.5+.5*ct),de.advancedModel){jl(de,ie,T);for(const en of de.advancedTintMaterials)en.material.color.copy(en.base).multiplyScalar(.65+.35*ct)}else Tc(de,ie,T);if(pf(de,ie),de.slowFallAura&&(de.slowFallAura.visible=!!ie.slowFalling,ie.slowFalling)){de.slowFallAura.rotation.y+=T*1.8;const en=((je=b.opening)==null?void 0:je.elapsed)||0;for(let St=1;St<de.slowFallAura.children.length;St++){const Pn=de.slowFallAura.children[St],Jn=Pn.userData.angle+en*(1.5+St%3*.25),kt=24+St%4*7;Pn.position.set(Math.cos(Jn)*kt,10+(en*55+Pn.userData.phase*31)%110,Math.sin(Jn)*kt)}}const Mt=De(ie.x,ie.y),qt=Math.max(0,de.group.position.y-Mt);de.contact.position.y=Mt-de.group.position.y+1.2,de.contact.material.opacity=(ie.isPlayer?.3:.24)*Math.max(0,1-qt/180),de.contact.visible=qt<180}else de.dead||(de.dead=!0,de.popT=0);if(de.dead){(tt=de.weaponPose)!=null&&tt.weapon&&(de.weaponPose.weapon.visible=!1),de.popT+=T;const nt=Math.max(0,1-de.popT/.4);de.group.scale.setScalar(nt),de.group.position.y=De(ie.x,ie.y)+de.popT*40,nt<=0&&(de.group.visible=!1)}}for(const[ie,de]of we)Q.has(ie)||(Cc(de),n.remove(de.group),we.delete(ie));const Z=(b.attackPickups||[]).filter(ie=>ie.collectedBy==null),Se=pt(Z.length),be=b.time+(((Mn=b.opening)==null?void 0:Mn.elapsed)||0);Z.forEach((ie,de)=>{var Hn,On;const nt=Se[de],wt=on[ie.attackId],ct=ie.lootType==="weapon-upgrade-rune",Mt=ie.lootType==="mana-ammunition",qt=ie.lootType==="tier-scroll",en=((Hn=Kn[ie.rarity])==null?void 0:Hn.color)||Kn.common.color,St=Mt?((On=$i[ie.ammoType])==null?void 0:On.color)||"#67e8f9":ct?"#fbbf24":(wt==null?void 0:wt.color)||"#67e8f9";nt.position.set(ie.x,De(ie.x,ie.y)+34+Math.sin(be*2.2+de)*7,ie.y),nt.rotation.y+=T*(ct?2.4:qt?1.9:Mt?2.1:1.2),nt.scale.setScalar(ct?1.28:qt?1.18:Mt?.82:1),nt.userData.core.material.color.set(Mt?St:en).multiplyScalar(1.8),nt.userData.ring.material.color.set(Mt?St:en).multiplyScalar(1.3),nt.userData.tierRing.material.color.set(St).multiplyScalar(1.3);const Pn=uw(ie),Jn=H0.get(Pn),kt=nt.userData;kt.modelName!==Pn&&(kt.model&&nt.remove(kt.model),kt.model=null,kt.modelName=Pn),!kt.model&&Jn&&(kt.model=Jn.clone(!0),kt.model.name=`pickup-model:${Pn}`,nt.add(kt.model)),kt.core.visible=!kt.model,kt.ring.position.y=kt.model?-23:0,kt.ring.material.opacity=kt.model?.3:.72,kt.tierRing.visible=!kt.model&&(ct||qt)});const Le=_a(b.spells.length);b.spells.forEach((ie,de)=>{const nt=Le[de],wt=ie.originGround??De(ie.originX??ie.x,ie.originY??ie.y);if(nt.position.set(ie.x,(ie.z??22)+wt,ie.y),ie.kind==="trap"||ie.kind==="zone"){nt.quaternion.identity();const ct=ie.kind==="zone"?ie.radius:ie.explosionRadius*.45;nt.scale.set(ct,ie.kind==="zone"?1.2:2.5,ct)}else{Wo.set(ie.vx,ie.vz||0,ie.vy);const ct=Wo.length()||1;Wo.multiplyScalar(1/ct),nt.quaternion.setFromUnitVectors(xa,Wo);const Mt=ie.trail||Math.max(18,Math.min(76,ct/65));nt.scale.set(ie.radius*.55,Mt,ie.radius*.55)}nt.userData.core.material.color.set(ie.color).multiplyScalar(2.4),nt.userData.glow.material.color.set(ie.color).multiplyScalar(1.45)});const et=b.wizards.filter(ie=>ie.alive&&ie.slashTimer>0),gt=Ve(et.length),Te=Fs.slash.duration;et.forEach((ie,de)=>{var qt;const nt=gt[de],wt=1-ie.slashTimer/Te,ct=Math.cos(ie.heading),Mt=Math.sin(ie.heading);nt.position.set(ie.x+ct*22,46+De(ie.x,ie.y)+(ie.climbH||0)+(ie.flyH||0)+(ie.jumpH||0),ie.y+Mt*22),nt.scale.setScalar(52),nt.rotation.set(0,-ie.heading,0),nt.rotateX(Math.PI/2),nt.rotateZ(-2.1+2.6*wt),nt.material.color.set(((qt=on[ie.attack])==null?void 0:qt.color)||Fs.slash.color),nt.material.opacity=.6*(ie.slashTimer/Te)}),Ac(b.events,T),$(b.events,T)}function hg(b,T,U=0){mf(b,T,U);const H=b.wizards.find(O=>O.isPlayer&&O.playerIndex===U);if(H){const O=Hi(H);O.group.rotation.set(0,-H.heading,0),pf(O,H)}}const Yo=new Py,dg=new Uo(new I(0,1,0),0),Ko=new I,Pc=new I,xf=new WeakMap;function _f(b){let T=xf.get(b);return T===void 0&&(T=De(b.x,b.y),xf.set(b,T)),T}function fg(b,T){return Yo.setFromCamera({x:b,y:T},s),Yo.ray.intersectPlane(dg,Ko)?{x:Ko.x,y:Ko.z}:null}function vf(b,T,U,H,O,q){const te=Yo.ray,Q=te.origin.x-b,Z=te.origin.z-T,Se=te.direction.x,be=te.direction.z,Le=Se*Se+be*be;let et=q;if(Le>1e-8){const gt=2*(Q*Se+Z*be),Te=Q*Q+Z*Z-U*U,Ke=gt*gt-4*Le*Te;if(Ke>=0){const je=Math.sqrt(Ke);for(const tt of[(-gt-je)/(2*Le),(-gt+je)/(2*Le)]){if(tt<=1||tt>=et)continue;const Mn=te.origin.y+te.direction.y*tt;Mn>=H&&Mn<=O&&(et=tt)}}}if(Math.abs(te.direction.y)>1e-8)for(const gt of[H,O]){const Te=(gt-te.origin.y)/te.direction.y;if(Te<=1||Te>=et)continue;const Ke=Q+Se*Te,je=Z+be*Te;Ke*Ke+je*je<=U*U&&(et=Te)}return et}function pg(b,T){const U=Yo.ray,H=Math.cos(b.angle),O=Math.sin(b.angle),q=(U.origin.x-b.x)*H+(U.origin.z-b.y)*O,te=-(U.origin.x-b.x)*O+(U.origin.z-b.y)*H,Q=U.direction.x*H+U.direction.z*O,Z=-U.direction.x*O+U.direction.z*H,Se=_f(b);let be=1,Le=T;for(const[et,gt,Te,Ke]of[[q,Q,-b.hw,b.hw],[U.origin.y,U.direction.y,Se,Se+b.top],[te,Z,-b.hd,b.hd]]){if(Math.abs(gt)<1e-8){if(et<Te||et>Ke)return T;continue}let je=(Te-et)/gt,tt=(Ke-et)/gt;if(je>tt&&([je,tt]=[tt,je]),be=Math.max(be,je),Le=Math.min(Le,tt),be>Le)return T}return be}function mg(b){const T=Yo.ray,U=q=>(T.at(q,Pc),Pc.y-Math.max(0,De(Pc.x,Pc.z)));let H=1,O=U(H);for(let q=41;q<=b;q+=40){const te=U(q);if(O>0&&te<=0){let Q=H,Z=q;for(let Se=0;Se<9;Se++){const be=(Q+Z)*.5;U(be)>0?Q=be:Z=be}return Z}H=q,O=te}return b}function gg(b,T=0){Yo.setFromCamera({x:0,y:0},s);const U=Math.min(s.far-s.near,_i.speed*_i.life);let H=mg(U),O=null;const q=b==null?void 0:b.wizards.find(Q=>Q.isPlayer&&Q.playerIndex===T);for(const Q of(b==null?void 0:b.wizards)||[]){if(!Q.alive||Q===q)continue;const Z=De(Q.x,Q.y)+(Q.climbH||0)+(Q.flyH||0)+(Q.jumpH||0),Se=vf(Q.x,Q.y,Ct.radius,Z,Z+(Q.bodyHeight||dr),H);Se<H&&(H=Se,O=Q.id)}for(const Q of(b==null?void 0:b.obstacles)||[]){if(Q.soft)continue;let Z;if(Q.kind==="house")Z=pg(Q,H);else{const Se=_f(Q);Z=vf(Q.x,Q.y,Q.r,Se,Se+Q.top,H)}Z<H&&(H=Z,O=null)}Yo.ray.at(H,Ko);const te=q?De(q.x,q.y):0;return{x:Ko.x,y:Ko.z,z:Ko.y-te,targetId:O}}const Ic=new I;function xg(b,T,U=0){return Ic.set(b,U,T).project(s),{x:(Ic.x*.5+.5)*jt,y:(-Ic.y*.5+.5)*gn,visible:Ic.z<1}}function _g(b,T){const U=Math.min(e?1:1.25,window.devicePixelRatio||1);t.setPixelRatio(U),t.setSize(b,T,!1),s.aspect=b/T,s.updateProjectionMatrix()}function vg(){t.render(n,s)}function yg(b=!0){t.dispose(),b&&t.forceContextLoss()}async function Mg(b,T=0){!e&&!ef&&await Promise.race([hm,new Promise(U=>window.setTimeout(U,6e3))]),tu=!1,gf(b,0,T)}return{prepareMatch:Mg,update:gf,updateOpeningCamera:hg,render:vg,resize:_g,setAim:lg,setFov:r,setAdsAmount:ug,setDiggingMode(b){for(const T of we.values())T.diggingMode=!!b,zn(T,!!b)},setDiggingAction(b){for(const T of we.values())T.isPlayer&&(T.diggingAction=!!b)},screenToWorld:fg,crosshairTarget:gg,worldToScreen:xg,groundHeight:De,dispose:yg}}if(window.location.hostname==="127.0.0.1"){const i=new URL(window.location.href);i.hostname="localhost",window.location.replace(i)}const ma=document.getElementById("menu"),Mc=document.getElementById("settings"),Sc=document.getElementById("weapon-select"),Ge=document.getElementById("game-screen"),Ti=document.getElementById("game"),dw=document.getElementById("hud"),C=dw.getContext("2d"),gm=document.getElementById("bots-picker"),od=document.getElementById("weapon-grid"),ur=document.getElementById("confirm-weapon"),fw=document.getElementById("settings-button"),pw=document.getElementById("settings-back"),G0=document.getElementById("fullscreen-button"),$a=document.getElementById("setting-graphics"),Wr=document.getElementById("setting-sensitivity"),V0=document.getElementById("setting-sensitivity-value"),rd=document.getElementById("setting-invert-y"),Ja=document.getElementById("setting-reduced-motion"),z0=["master","music","effects"].map(i=>({input:document.getElementById(`setting-${i}`),output:document.getElementById(`setting-${i}-value`),key:`wandwars-${i}-volume`})),Ju=document.getElementById("keybinds"),mw=document.getElementById("reset-keybinds"),Ms=(i,e)=>{try{const t=localStorage.getItem(i);return t??e}catch{return e}},To=(i,e)=>{try{localStorage.setItem(i,String(e))}catch{}},ad={moveForward:"KeyW",moveBack:"KeyS",moveLeft:"KeyA",moveRight:"KeyD",sprint:"ShiftLeft",jump:"Space",pickup:"KeyF",map:"KeyE",dig:"KeyQ",slot1:"Digit1",slot2:"Digit2",slot3:"Digit3",slot4:"Digit4",slot5:"Digit5",slot6:"Digit6",slot7:"Digit7",slot8:"Digit8",slot9:"Digit9",menu:"Escape",restart:"KeyR"},gw={moveForward:"Move forward",moveBack:"Move backward",moveLeft:"Move left",moveRight:"Move right",sprint:"Sprint",jump:"Jump",pickup:"Pick up",map:"Open map",dig:"Digging mode",slot1:"Attack slot 1",slot2:"Attack slot 2",slot3:"Attack slot 3",slot4:"Attack slot 4",slot5:"Attack slot 5",slot6:"Attack slot 6",slot7:"Attack slot 7",slot8:"Attack slot 8",slot9:"Attack slot 9",menu:"Open menu",restart:"Restart after defeat"},xw={0:"Left click",1:"Middle click",2:"Right click"};let ho=(()=>{try{return{...ad,...JSON.parse(Ms("wandwars-key-bindings","{}"))}}catch{return{...ad}}})(),go={cast:Number(Ms("wandwars-mouse-cast","0")),aim:Number(Ms("wandwars-mouse-aim","2"))},fo=null,tf=Number(Ms("wandwars-mouse-sensitivity","100"))/100,Fl=Ms("wandwars-invert-y","false")==="true";const cd=new URLSearchParams(window.location.search).get("graphics"),_w=/^((?!chrome|chromium|android).)*safari/i.test(navigator.userAgent),Go=_w;let ra=Go||(cd?cd==="safe":Ms("wandwars-graphics","detailed")==="safe"),oi=document.getElementById("start-loading");oi||(oi=document.createElement("div"),oi.id="start-loading",oi.setAttribute("role","status"),oi.setAttribute("aria-live","polite"),oi.hidden=!0,oi.innerHTML=`
    <span class="loading-rune" aria-hidden="true">✦</span>
    <strong>Preparing the Island…</strong>
    <small>Building the detailed world. The portals will open when it is ready.</small>
  `,document.getElementById("stage").append(oi));document.documentElement.dataset.attackCount=String(Object.keys(on).length);document.documentElement.dataset.attackKinds=String(new Set(Object.values(on).map(i=>i.kind)).size);let ld=9,ja=null,ao=null,We=null,rt=null,ko=!1,Zr=0,ud=0,Hr=0,bs=!1,yl=Ct.maxHealth,_r=0,Us=0;var hl,ym;const nf=((ym=(hl=globalThis.crypto)==null?void 0:hl.randomUUID)==null?void 0:ym.call(hl))||`${Date.now()}-${Math.random().toString(36).slice(2)}`,xo=!Go&&typeof BroadcastChannel=="function"?new BroadcastChannel("wandwars-active-match"):null;let hd=0,Ol=0,mc=!1;function sf(){Ge.hidden||mc||(mc=!0,Us++,ko=!1,cancelAnimationFrame(Zr),Ge.dataset.starting="recovering",Ge.dataset.graphicsContext="lost",oi.hidden=!1,oi.querySelector("strong").textContent="Restoring the Island…",oi.querySelector("small").textContent="The browser paused the 3D world. WandWars is rebuilding it automatically.",window.clearTimeout(Ol),Ol=window.setTimeout(()=>{const i=new URL(window.location.href);if(i.searchParams.get("graphicsRecovery")!=="1"){i.searchParams.set("graphics","safe"),i.searchParams.set("graphicsRecovery","1"),i.searchParams.set("version","blue-screen-recovery-20260906"),window.location.replace(i);return}Ge.dataset.starting="failed",oi.querySelector("strong").textContent="Graphics Need a Fresh Tab",oi.querySelector("small").textContent="Close the other WandWars tab, then reload this page."},3500))}function vw(i){i.preventDefault(),console.warn("[graphics] WebGL context lost; starting automatic recovery"),ra=!0,sf()}function yw(){console.info("[graphics] WebGL context restored"),window.clearTimeout(Ol),!(!mc||Ge.hidden)&&(We==null||We.dispose(!1),We=null,mc=!1,Ge.dataset.graphicsContext="restored",window.setTimeout(()=>cf(1),150))}Ti.addEventListener("webglcontextlost",vw,!1);Ti.addEventListener("webglcontextrestored",yw,!1);const ki=new Set;let Ss=0,_o=-.26,Vo=!1,Bl=!1,aa=!1,ca=0;const Mw=650;let $r=!1,ls=!1,ga=!1,wo=-1,Zi=!1;const rr=vo-1;let tr=0,Ml=0,Qa=0,Bs=null,hr=0;const Sw=35,bw=120,Tw=180;let Eo=!1,Oo=0,ec=pc.hipFov,Jr=!1;const xm=Math.PI/3,ww=.0028,ju=.05,Ew=1,Aw=Un.countdown+Un.chooseTime,Rw=.9;function os(i,e){return ho[i]===e.code}function W0(i,e){return os("moveForward",{code:e})||i==="ArrowUp"?"up":os("moveBack",{code:e})||i==="ArrowDown"?"down":os("moveLeft",{code:e})||i==="ArrowLeft"?"left":os("moveRight",{code:e})||i==="ArrowRight"?"right":null}function X0(i){var n,s,o,r,a,c;const e=W0(i.key,i.code);if(e){ki.add(e),i.preventDefault();return}if(os("sprint",i)){i.repeat||(ki.has("run")?ki.delete("run"):ki.add("run")),i.preventDefault();return}if(os("jump",i)){i.repeat||(Bl=!0),i.preventDefault();return}if(os("pickup",i)){i.repeat||(aa=!0,ca=performance.now()+Mw),i.preventDefault();return}if(os("map",i)){!i.repeat&&rt&&($r=!$r,Ge.dataset.mapOpen=String($r)),i.preventDefault();return}if(os("dig",i)){!i.repeat&&rt&&li().alive&&!bs&&(ls=!ls,Vo=!1,Eo=!1,ga=!1,(n=We==null?void 0:We.setDiggingMode)==null||n.call(We,ls),(s=We==null?void 0:We.setDiggingAction)==null||s.call(We,!1),Ge.dataset.diggingMode=String(ls)),i.preventDefault();return}const t=(o=Object.entries(ho).find(([l,u])=>l.startsWith("slot")&&u===i.code))==null?void 0:o[0];if(t){const l=Number(t.slice(4))-1,u=(c=(a=(r=rt==null?void 0:rt.wizards)==null?void 0:r[0])==null?void 0:a.attackSlots)==null?void 0:c[l];if(rt!=null&&rt.sandbox&&l===rr&&!u){wo=l,Zi=!Zi,Ge.dataset.hotbarSlot=String(l+1);return}l<vo&&u&&of(l);return}os("restart",i)?bs&&og():os("menu",i)&&bc()}function q0(i){const e=W0(i.key,i.code);e&&ki.delete(e),os("menu",i)&&!Ge.hidden&&bc()}function Y0(){tr=0,Ml=0,Qa=0}function of(i){wo=(i+vo)%vo,Zi=!1,Ge&&(Ge.dataset.hotbarSlot=String(wo+1))}function K0(i){var l,u,h,d,f,p;if(i.preventDefault(),clearTimeout(Qa),Qa=window.setTimeout(()=>{tr=0,Qa=0},Tw),i.deltaY===0)return;const e=i.deltaMode===WheelEvent.DOM_DELTA_LINE?16:i.deltaMode===WheelEvent.DOM_DELTA_PAGE?100:1;if(tr+=i.deltaY*e,Math.abs(tr)<Sw)return;const t=performance.now();if(Ml>0&&t-Ml<bw)return;const n=tr>0?1:-1,s=Zi?rr:wo,o=(l=rt==null?void 0:rt.wizards)==null?void 0:l[0],r=[];for(let x=0;x<vo;x++)(u=o==null?void 0:o.attackSlots)!=null&&u[x]&&r.push(x);if(rt!=null&&rt.sandbox&&!((h=o==null?void 0:o.attackSlots)!=null&&h[rr])&&!r.includes(rr)&&r.push(rr),!r.length){tr=0;return}let a=r.indexOf(s);a<0&&(a=n>0?-1:0);const c=r[(a+n+r.length)%r.length];of(c),rt!=null&&rt.sandbox&&c===rr&&!((p=(f=(d=rt.wizards)==null?void 0:d[0])==null?void 0:f.attackSlots)!=null&&p[c])&&(Zi=!0),tr=0,Ml=t}function rf(i){const e=1+(pc.lookSensitivity-1)*Oo,t=ww*tf*e;Ss+=(i.movementX||0)*t;const n=(i.movementY||0)*t*(Fl?-1:1);_o=Math.max(-xm,Math.min(xm,_o-n))}function Z0(){if(!(Jr||!Ti.requestPointerLock)){Ge.dataset.pointerLockRequested="true";try{const i=Ti.requestPointerLock();i&&i.catch&&i.catch(()=>{})}catch{}}}function $0(){const i=Jr;Jr=document.pointerLockElement===Ti,i&&!Jr&&!Ge.hidden&&bc()}function J0(i){var e;rf(i),Z0(),ls?(Vo=!1,Eo=!1,i.button===go.cast&&(ga=!0,(e=We==null?void 0:We.setDiggingAction)==null||e.call(We,!0),Ge.dataset.diggingAction="true")):i.button===go.aim?Eo=!0:i.button===go.cast&&(Vo=!0)}function j0(i){var e;i.button===go.aim&&(Eo=!1),i.button===go.cast&&(Vo=!1,ga=!1,(e=We==null?void 0:We.setDiggingAction)==null||e.call(We,!1),Ge.dataset.diggingAction="false")}function Q0(){Eo=!1,Vo=!1}function eg(i){i.preventDefault()}function Cw(){var h,d,f;const i=(ki.has("up")?1:0)-(ki.has("down")?1:0),e=(ki.has("right")?1:0)-(ki.has("left")?1:0),t=Math.cos(Ss),n=Math.sin(Ss),s=-Math.sin(Ss),o=Math.cos(Ss),r=We.crosshairTarget(rt,0),a=Zi?Math.cos(_o):1,c=Bl;Bl=!1;const l=aa&&performance.now()<=ca;l||(aa=!1,ca=0);const u=((f=(d=(h=rt==null?void 0:rt.wizards)==null?void 0:h[0])==null?void 0:d.attackSlots)==null?void 0:f[wo])||null;return{dx:t*i*a+s*e,dy:n*i*a+o*e,yaw:Ss,aimX:r.x,aimY:r.y,aimZ:r.z,aimTargetId:r.targetId,attack:u,cast:Vo&&!ls,dig:ga&&ls,up:ki.has("up"),run:ki.has("run"),jump:c,pickup:l,flying:Zi,flyUp:Zi?i*Math.sin(_o):0}}function li(){return rt.wizards[0]}function dd(i,e,t,n,s,o){C.fillStyle="rgba(0,0,0,0.55)",C.fillRect(i-1,e-1,t+2,n+2),C.fillStyle=o,C.fillRect(i,e,t*Math.max(0,s),n)}function Pw(){for(const i of rt.wizards){if(!i.alive||i.isPlayer)continue;const e=We.worldToScreen(i.x,i.y,122+We.groundHeight(i.x,i.y)+(i.climbH||0)+(i.flyH||0)+(i.jumpH||0));if(!e.visible||e.x<-40||e.x>jt+40)continue;const t=42;dd(e.x-t/2,e.y,t,5,i.health/Ct.maxHealth,"#f87171")}}function Iw(i){if(!i.alive)return;const e=We.worldToScreen(i.x,i.y,170+We.groundHeight(i.x,i.y)+(i.climbH||0)+(i.flyH||0)+(i.jumpH||0)+(i.openingH||0));if(!e.visible||e.x<-40||e.x>jt+40||e.y<-20||e.y>gn+20)return;const t=46,n=5,s=e.x-t/2,o=e.y,r=Math.max(0,Math.min(1,i.stamina/Ds.max));C.save(),C.fillStyle="rgba(5, 8, 18, 0.72)",C.fillRect(s-2,o-2,t+4,n+4),C.fillStyle="rgba(255, 255, 255, 0.2)",C.fillRect(s,o,t,n),C.fillStyle="#ffffff",C.fillRect(s,o,t*r,n),C.restore()}function Lw(){const e=jt-78-22,t=124,n=(r,a)=>({x:e+r/Cn.radius*78,y:t+a/Cn.radius*78});C.save(),C.beginPath(),C.arc(e,t,78,0,Math.PI*2),C.fillStyle="rgba(10,10,26,0.72)",C.fill(),C.strokeStyle="#3a3560",C.lineWidth=2,C.stroke();const s=rt.storm;C.beginPath();const o=n(s.cx,s.cy);C.arc(o.x,o.y,s.radius/Cn.radius*78,0,Math.PI*2),C.strokeStyle=s.radius<260?"#f87171":"#c084fc",C.lineWidth=1.5,C.stroke();for(const r of rt.wizards){if(!r.alive)continue;const a=n(r.x,r.y);C.beginPath(),C.arc(a.x,a.y,r.isPlayer?3.5:2.5,0,Math.PI*2),C.fillStyle=r.isPlayer?"#ffffff":r.color,C.fill()}C.restore()}function Dw(){var r;const i=jt/2,e=gn/2+10,t=Math.min(gn*.39,jt*.31),n=(a,c)=>({x:i+a/Cn.radius*t,y:e+c/Cn.radius*t}),s={castle:"#7c6bb3",highlands:"#316c53",harvest:"#8a7a38",harbor:"#356c88","desert-town":"#9b6332",mine:"#555766"};C.save(),C.fillStyle="rgba(5, 8, 22, 0.94)",C.fillRect(0,0,jt,gn),C.textAlign="center",C.fillStyle="#fff4c4",C.font="900 28px Georgia, serif",C.fillText("WANDWARS ISLAND",i,39),C.fillStyle="#9fb0d1",C.font="bold 12px system-ui, sans-serif",C.fillText("E · CLOSE MAP",i,60),C.beginPath(),C.arc(i,e,t+11,0,Math.PI*2),C.fillStyle="#174c67",C.fill(),C.beginPath(),C.arc(i,e,t,0,Math.PI*2),C.fillStyle="#486a3e",C.fill(),C.clip();for(const a of Qr){const c=n(a.x,a.y);C.beginPath(),C.arc(c.x,c.y,Math.max(25,a.radius/Cn.radius*t),0,Math.PI*2),C.fillStyle=`${s[a.id]||"#556b4b"}cc`,C.fill()}C.strokeStyle="rgba(226,232,240,0.12)",C.lineWidth=1;for(const a of[-.5,0,.5])C.beginPath(),C.moveTo(i-t,e+t*a),C.lineTo(i+t,e+t*a),C.stroke(),C.beginPath(),C.moveTo(i+t*a,e-t),C.lineTo(i+t*a,e+t),C.stroke();for(const a of rt.attackPickups||[]){if(a.collectedBy!=null)continue;const c=n(a.x,a.y);C.fillStyle=((r=Kn[a.rarity])==null?void 0:r.color)||Kn.common.color,C.fillRect(c.x-1.5,c.y-1.5,3,3)}const o=n(rt.storm.cx,rt.storm.cy);C.beginPath(),C.arc(o.x,o.y,rt.storm.radius/Cn.radius*t,0,Math.PI*2),C.strokeStyle=rt.storm.radius<260?"#f87171":"#d8b4fe",C.lineWidth=3,C.stroke();for(const a of rt.wizards){if(!a.alive)continue;const c=n(a.x,a.y);a.isPlayer?(C.save(),C.translate(c.x,c.y),C.rotate(a.heading),C.beginPath(),C.moveTo(10,0),C.lineTo(-7,-6),C.lineTo(-4,0),C.lineTo(-7,6),C.closePath(),C.fillStyle="#ffffff",C.shadowColor="#38bdf8",C.shadowBlur=8,C.fill(),C.restore()):(C.beginPath(),C.arc(c.x,c.y,3,0,Math.PI*2),C.fillStyle="#f87171",C.fill())}C.restore(),C.save(),C.textAlign="center",C.font="bold 11px system-ui, sans-serif";for(const a of Qr){const c=n(a.x,a.y);C.fillStyle="#ffffff",C.shadowColor="#07101c",C.shadowBlur=5,C.fillText(a.name,c.x,c.y-12)}C.fillStyle="#e2e8f0",C.font="900 15px system-ui, sans-serif",C.fillText("N",i,e-t-16),C.textAlign="left",C.fillStyle="#ffffff",C.fillText("▲ You",30,gn-54),C.fillStyle="#f87171",C.fillText("● Bots",30,gn-30),C.textAlign="right",C.fillStyle="#d8b4fe",C.fillText("Storm circle",jt-30,gn-42),C.restore()}const fd=6,xs=48,tg=6,Nw=22,Gr=fd*xs+(fd-1)*tg,Uw=()=>jt-Nw-Gr,Fw=()=>gn-xs-18,Ow={projectile:"✦",beam:"━",melee:"╱",nova:"◎",heal:"+",shield:"◇",dash:"»",trap:"△",grapple:"⌁",movement:"»",summon:"♜",utility:"◆"};function Bw(i){var o,r;const e=Uw(),t=Fw();for(let a=0;a<fd;a++){const c=e+a*(xs+tg),l=((o=i.attackSlots)==null?void 0:o[a])||null,u=l?on[l]:null,h=u?cr(i,u.id):null,d=h?Kn[h]:null,f=rt.sandbox&&a===rr&&!u,p=!Zi&&!!u&&wo===a||f&&Zi,x=c+xs/2;if(C.fillStyle="rgba(10,10,26,0.72)",C.fillRect(c,t,xs,xs),u)C.globalAlpha=.9,C.fillStyle=u.color,C.beginPath(),C.arc(x,t+xs/2+4,12,0,Math.PI*2),C.fill(),C.globalAlpha=1,C.fillStyle="#ffffff",C.font="900 14px system-ui, sans-serif",C.textAlign="center",C.fillText(Ow[u.kind]||"✦",x,t+xs/2+9);else if(f){const g=t+xs/2+5;C.globalAlpha=Zi?1:.8,C.strokeStyle="#7dd3fc",C.lineWidth=3;for(const M of[0,7])C.beginPath(),C.moveTo(x-10,g+M),C.lineTo(x,g-8+M),C.lineTo(x+10,g+M),C.stroke();C.globalAlpha=1}const m=f?"#7dd3fc":(d==null?void 0:d.color)||null;C.lineWidth=p?2.5:1,C.strokeStyle=p?m:u||f?"#3a3560":"#262441",C.strokeRect(c,t,xs,xs),C.textAlign="left",C.fillStyle=p?"#ffffff":u||f?"#cbd5e1":"#4b5573",C.font="bold 12px system-ui, sans-serif",C.fillText(String(a+1),c+5,t+15)}if(C.textAlign="right",C.font="bold 13px system-ui, sans-serif",Zi)C.fillStyle="#7dd3fc",C.fillText("✈ Flying — look up/down + W · 6 to land",e+Gr,t-9);else{const a=(r=i.attackSlots)==null?void 0:r[wo],c=a?on[a]:null;if(c){const l=cr(i,a),u=Kn[l],h=md(i,a),d=c.ammoType?$i[c.ammoType]:null,f=c.consumable?"one use":c.manaPerSecond?`${c.manaPerSecond} ${(d==null?void 0:d.name)||"mana"}/s`:c.manaPerProjectile?`${c.manaPerProjectile} ${(d==null?void 0:d.name)||"mana"}/shot`:`${h.manaCost} ${(d==null?void 0:d.name)||"mana"}`;C.fillStyle=u.color,C.fillText(`${u.name} · ${c.name} · ${f}`,e+Gr,t-9)}else C.fillStyle="#94a3b8",C.fillText("Empty — find an attack on the island",e+Gr,t-9)}const n=e+Gr-190,s=t-106;if(C.fillStyle="rgba(5, 10, 30, 0.82)",C.fillRect(n-8,s-17,198,82),C.fillStyle="#e2e8f0",C.font="900 10px system-ui, sans-serif",C.textAlign="left",C.fillText("MANA POUCH",n,s-5),Ha.forEach((a,c)=>{var d;const l=$i[a],u=Math.floor(((d=i.manaPouch)==null?void 0:d[a])||0),h=s+8+c*11;C.fillStyle=l.color,C.fillRect(n,h-7,5,5),C.font="bold 9px system-ui, sans-serif",C.fillText(l.name,n+9,h-2),C.textAlign="right",C.fillText(`${u}/${l.max}`,n+182,h-2),C.textAlign="left"}),i.itemUse){const a=on[i.itemUse.attackId],c=1-i.itemUse.remaining/Math.max(.001,i.itemUse.total),l=e+Gr-190,u=s-31;C.fillStyle="rgba(5, 10, 30, 0.88)",C.fillRect(l-8,u-17,198,25),C.fillStyle="#29344f",C.fillRect(l,u,182,5),C.fillStyle=(a==null?void 0:a.color)||"#ffffff",C.fillRect(l,u,182*c,5),C.fillStyle="#ffffff",C.font="bold 10px system-ui, sans-serif",C.textAlign="left",C.fillText(`USING ${(a==null?void 0:a.name)||"ITEM"} · ${i.itemUse.remaining.toFixed(1)}s`,l,u-5)}}function kw(){const i=jt/2,e=gn/2;C.save(),C.strokeStyle=ls?"#fbbf24":"rgba(226,232,240,0.9)",C.lineWidth=2,C.beginPath(),C.arc(i,e,9,0,Math.PI*2),C.moveTo(i-15,e),C.lineTo(i-5,e),C.moveTo(i+5,e),C.lineTo(i+15,e),C.moveTo(i,e-15),C.lineTo(i,e-5),C.moveTo(i,e+5),C.lineTo(i,e+15),C.stroke(),C.restore()}function Hw(){if(!ls)return;C.save();const i=282,e=jt/2-i/2,t=24;C.fillStyle="rgba(45, 25, 10, 0.9)",C.fillRect(e,t,i,48),C.strokeStyle="#fbbf24",C.lineWidth=2,C.strokeRect(e,t,i,48),C.textAlign="center",C.fillStyle="#fde68a",C.font="900 17px system-ui, sans-serif",C.fillText("⛏ DIGGING MODE",jt/2,t+20),C.fillStyle="#fef3c7",C.font="12px system-ui, sans-serif",C.fillText("Q to return to weapons",jt/2,t+39),C.restore()}function Gw(i){var c;const e=_d(rt,i);if(!e||Math.hypot(i.x-e.x,i.y-e.y)>Hl+Ct.radius)return;const n=Kn[e.rarity]||Kn.common;let s;if(e.lootType==="mana-ammunition"){const l=$i[e.ammoType];if(!l)return;s=`[F] COLLECT · +${e.amount} ${l.name}`}else if(e.lootType==="weapon-upgrade-rune")s=i.baseWeaponRarity==="legendary"?`${n.name} Weapon Upgrade Rune · Weapon already Legendary`:`[F] UPGRADE WEAPON · ${n.name} Weapon Upgrade Rune`;else{const l=on[e.attackId];if(!l)return;const u=l.scope==="tier"?Am(i,e.attackId):e.attackId,h=on[u]||l;let d="PICK UP";if(l.scope==="tier"&&i.tierAttackId)d="ABSORB MANA";else if((c=i.attackInventory)!=null&&c.includes(u)){const p=cr(i,u),x=Object.keys(Kn);d=x.indexOf(e.rarity)>x.indexOf(p)?"UPGRADE":"ALREADY OWNED"}const f=l.scope==="tier"?`Tier ${l.tier} Attack Scroll · `:"";s=d==="ALREADY OWNED"?`${n.name} ${h.name} · Already owned`:`[F] ${d} · ${f}${n.name} ${h.name}`}C.save(),C.font="bold 15px system-ui, sans-serif",C.textAlign="center";const o=Math.min(520,C.measureText(s).width+34),r=jt/2-o/2,a=gn-126;C.fillStyle="rgba(7, 10, 28, 0.86)",C.fillRect(r,a,o,36),C.strokeStyle=n.color,C.lineWidth=2,C.strokeRect(r,a,o,36),C.fillStyle=n.color,C.fillText(s,jt/2,a+23),C.restore()}function Vw(){const i=rt.opening,e=li();if(C.save(),C.textAlign="center",C.shadowColor="#4c1d95",C.shadowBlur=18,i.phase==="countdown")C.fillStyle="#f5f3ff",C.font="900 86px system-ui, sans-serif",C.fillText(`${Math.max(1,Math.ceil(i.timer))}`,jt/2,150),C.font="bold 24px system-ui, sans-serif",C.fillText("PORTALS OPENING",jt/2,194);else if(i.phase==="choose"){const t=i.timer>Un.chooseTime-1.2;C.fillStyle=t?"#facc15":"#f5f3ff",C.font=`900 ${t?46:31}px system-ui, sans-serif`,C.fillText(t?"PORTALS OPEN":"CHOOSE A PORTAL",jt/2,72),C.fillStyle="#facc15",C.font="900 30px system-ui, sans-serif",C.fillText(`${Math.ceil(i.timer)}s`,jt/2,110);let n=null,s=1/0;for(const o of i.portals){const r=Math.hypot(e.x-o.x,e.y-o.y);r<s&&(n=o,s=r)}if(n){const o=jr[n.destination];C.fillStyle=o.color,C.font="bold 20px system-ui, sans-serif",C.fillText(`${n.unstable?"⚠ Unstable portal":"Nearest portal"}: ${o.name}`,jt/2,gn-62)}C.fillStyle="#e2e8f0",C.font="14px system-ui, sans-serif",C.fillText("Run through an archway to choose your landing area",jt/2,gn-34)}else e.slowFalling&&(C.fillStyle="#c4b5fd",C.font="900 34px system-ui, sans-serif",C.fillText("SLOW-FALL SPELL",jt/2,70),C.fillStyle="#f5f3ff",C.font="bold 18px system-ui, sans-serif",C.fillText(`Altitude: ${Math.ceil(e.openingH)} · WASD to steer`,jt/2,103));C.restore()}function zw(){var o,r,a;if(C.clearRect(0,0,jt,gn),$r){Dw(),Qu();return}if((o=rt.opening)!=null&&o.phase&&rt.opening.phase!=="complete"&&!li().openingLanded){Vw(),Qu();return}Pw();const i=li();Iw(i);const e=rt.wizards.filter(c=>c.alive).length;C.fillStyle="#e2e8f0",C.font="bold 22px system-ui, sans-serif",C.textAlign="left",C.fillText(`Alive: ${e}`,20,34);const t=fr[i.baseWeaponId];if(t){const c=Kn[i.baseWeaponRarity]||Kn.common;C.fillStyle=c.color,C.font="bold 13px system-ui, sans-serif",C.fillText(`🔒 ${c.name} ${t.name}`,20,56)}C.textAlign="right",C.font="bold 15px system-ui, sans-serif",rt.sandbox?(C.fillStyle="#7dd3fc",C.fillText("🧪 Sandbox — free roam",jt-20,30)):rt.time<rs.shrinkDelay?(C.fillStyle="#a3aed0",C.fillText(`Storm closes in ${Math.ceil(rs.shrinkDelay-rt.time)}s`,jt-20,30)):(C.fillStyle="#f0abfc",C.fillText("⚡ The storm is closing",jt-20,30)),C.textAlign="left",C.font="bold 14px system-ui, sans-serif",C.fillStyle=i.alive?"#e2e8f0":"#f87171",C.fillText(i.alive?"You":"You (down)",20,gn-62),dd(20,gn-55,240,14,Math.max(0,i.health)/Ct.maxHealth,"#4ade80"),C.fillStyle="#06060f",C.font="bold 11px system-ui, sans-serif",C.fillText(`${Math.max(0,Math.ceil(i.health))}`,26,gn-44);const n=Math.max(0,Math.min(100,i.shield||0));dd(20,gn-36,240,11,n/100,"#38bdf8"),C.strokeStyle="#7dd3fc",C.lineWidth=1,C.strokeRect(20.5,gn-35.5,239,10),C.fillStyle=n>20?"#082f49":"#bae6fd",C.font="bold 9px system-ui, sans-serif",C.fillText(`${Math.ceil(n)}`,26,gn-27),Bw(i),Lw(),i.alive&&!bs&&kw(),i.alive&&!bs&&Hw(),i.alive&&!bs&&Gw(i);const s=i.tierAttackId?(r=on[i.tierAttackId])==null?void 0:r.name:null;C.textAlign="left",C.font="12px system-ui, sans-serif",C.fillStyle="#9fb0d1",C.fillText(`Attack inventory: ${((a=i.attackInventory)==null?void 0:a.length)||0}${s?` · Tier: ${s}`:""}`,20,gn-78),Bs&&hr>0&&(C.save(),C.textAlign="center",C.font="bold 17px system-ui, sans-serif",C.fillStyle=Bs.color||(Bs.compatible?"#86efac":"#fbbf24"),C.shadowColor=Bs.color||(Bs.compatible?"#166534":"#92400e"),C.shadowBlur=12,C.fillText(Bs.text,jt/2,130),C.restore()),C.textAlign="center",C.font="12px system-ui, sans-serif",C.fillStyle="rgba(148,163,184,0.7)",C.fillText(ls?"WASD walk · Shift run · Space jump · F pick up · E map · Q weapon mode":Jr?"WASD walk · Shift run · Space jump · F pick up · E map · Q dig · Mouse look · Click cast · Right-click ADS":"Click to lock mouse · WASD walk · Shift run · Space jump · F pick up · E map · Q dig · Right-click ADS",jt/2,gn-14),Qu(),bs&&Ww()}function Qu(){if(_r<=.001)return;const i=Math.min(1,_r),e=135,t=(a,c,l,u,h)=>{C.fillStyle=a,C.fillRect(c,l,u,h)};C.save(),C.globalCompositeOperation="source-over";const n=C.createLinearGradient(0,0,e,0);n.addColorStop(0,`rgba(185, 12, 22, ${.78*i})`),n.addColorStop(1,"rgba(185, 12, 22, 0)"),t(n,0,0,e,gn);const s=C.createLinearGradient(jt,0,jt-e,0);s.addColorStop(0,`rgba(185, 12, 22, ${.78*i})`),s.addColorStop(1,"rgba(185, 12, 22, 0)"),t(s,jt-e,0,e,gn);const o=C.createLinearGradient(0,0,0,e);o.addColorStop(0,`rgba(220, 24, 32, ${.68*i})`),o.addColorStop(1,"rgba(220, 24, 32, 0)"),t(o,0,0,jt,e);const r=C.createLinearGradient(0,gn,0,gn-e);r.addColorStop(0,`rgba(155, 5, 16, ${.72*i})`),r.addColorStop(1,"rgba(155, 5, 16, 0)"),t(r,0,gn-e,jt,e),C.restore()}function Ww(){const i=li(),e=rt.playerWon&&i.alive;C.save(),C.fillStyle="rgba(6,6,15,0.8)",C.fillRect(0,0,jt,gn),C.textAlign="center";const t=e?"#facc15":"#f87171";C.fillStyle=t,C.shadowColor=t,C.shadowBlur=24,C.font="bold 52px system-ui, sans-serif",C.fillText(e?"VICTORY ROYALE!":"DEFEATED",jt/2,gn/2-20),C.shadowBlur=0,C.fillStyle="#e2e8f0",C.font="22px system-ui, sans-serif";const n=rt.wizards.length;C.fillText(e?`Winner of ${n}`:`You placed #${i.placement} of ${n}`,jt/2,gn/2+22),C.fillStyle="#a3aed0",C.font="16px system-ui, sans-serif",C.fillText("Press R to play again · Esc for menu",jt/2,gn/2+58),C.restore()}function Xw(){var i,e,t;for(const n of rt.events||[]){if(n.wizardId!==li().id)continue;if(["attack-pickup","mana-pickup","weapon-upgrade"].includes(n.type)&&(aa=!1,ca=0),n.type==="weapon-upgrade"){const o=Kn[n.rarity]||Kn.common;Bs={compatible:!0,color:o.color,text:n.upgraded?`Base weapon upgraded to ${o.name}`:"Base weapon is already Legendary"},hr=3.2;continue}if(n.type==="mana-pickup"){const o=$i[n.ammoType];Bs={compatible:!0,color:o==null?void 0:o.color,text:`+${Math.floor(n.amount)} ${(o==null?void 0:o.name)||"mana ammunition"}`},hr=3.2;continue}if(n.type!=="attack-pickup")continue;const s=on[n.attackId];if(s){if(n.equipped){const o=li().attackSlots.indexOf(n.attackId);!li().attackSlots[wo]&&o>=0&&of(o)}Bs={compatible:!0,color:n.rarity?(i=Kn[n.rarity])==null?void 0:i.color:null,text:n.convertedToMana?`Tier scroll converted into +${n.manaEnergy} ${((e=$i[s.ammoType])==null?void 0:e.name)||"mana ammunition"}`:`${n.upgraded?"Upgraded":"Picked up"} ${n.rarity?`${Kn[n.rarity].name} `:""}${s.name}${n.equipped?" — equipped":""}${n.tierClaimed?` · +${n.manaEnergy} ${((t=$i[s.ammoType])==null?void 0:t.name)||"mana ammunition"}`:""}`},hr=3.2}}}function _m(i,e=!1){var o;Hr=Math.min(e?Aw:Ew,Hr+i);let n=Cw();for(;Hr>=ju&&!bs;){if(Lx(rt,[n],ju),Xw(),Hr-=ju,(!li().alive||rt.over)&&(bs=!0),e&&((o=rt.opening)==null?void 0:o.phase)==="complete"){Hr=0;break}(n.jump||n.pickup)&&(n={...n,jump:!1,pickup:!1})}li().staminaExhausted&&ki.delete("run");const s=Math.max(0,li().health);if(s<yl-.01){const r=yl-s;_r=Math.min(1,_r+.34+r/Ct.maxHealth*2.2)}yl=s}function ng(i){var a,c,l,u,h,d;if(!ko)return;const e=Math.max(0,(i-ud)/1e3),t=Math.min(.1,e);ud=i;const n=Qd(ao);Oo=aw(Oo,Eo,t,n.transitionSpeed),ec=n.hipFov+(n.adsFov-n.hipFov)*Oo,We.setFov(ec),We.setAdsAmount(Oo),We.setAim(Ss,_o);const s=(a=rt.opening)==null?void 0:a.phase,o=!bs&&s&&s!=="complete";if(o){const f=s==="countdown"?Math.min(e,Rw):e;_m(f,!0)}if(s==="countdown"&&((c=rt.opening)==null?void 0:c.phase)==="countdown"?We.updateOpeningCamera(rt,t,0):We.update(rt,t,0),!bs&&!o&&_m(e),Ge.dataset.openingPhase=((l=rt.opening)==null?void 0:l.phase)||"none",Ge.dataset.openingTimer=String(((u=rt.opening)==null?void 0:u.timer)||0),((h=rt.opening)==null?void 0:h.phase)==="countdown"){const f=String(Math.max(1,Math.ceil(rt.opening.timer))),p=((d=Ge.dataset.countdownSeen)==null?void 0:d.split(",").filter(Boolean))||[];p.at(-1)!==f&&(Ge.dataset.countdownSeen=[...p,f].join(","))}Ge.dataset.playerLanded=String(!!li().openingLanded),Ge.dataset.playerAlive=String(!!li().alive),Ge.dataset.matchOver=String(!!rt.over),Ge.dataset.playerX=String(li().x),Ge.dataset.playerY=String(li().y),Ge.dataset.cameraYaw=String(Ss),Ge.dataset.cameraPitch=String(_o),Ge.dataset.adsHeld=String(Eo),Ge.dataset.adsAmount=Oo.toFixed(4),Ge.dataset.fov=ec.toFixed(3),Ge.dataset.playerHeading=String(li().heading),hr=Math.max(0,hr-t),_r=Math.max(0,_r-t*1.35);try{We.render()}catch(f){console.error("[graphics] frame render failed",f),sf();return}zw(),Zr=requestAnimationFrame(ng)}function af(){const i=Ti.clientWidth||jt,e=Ti.clientHeight||gn;We.resize(i,e)}function qw(){if(!We)try{We=sd(Ti,{safeMode:ra}),We.resize(jt,gn),Ge.dataset.safeGraphics=String(ra),Ge.dataset.graphicsContext="ok",console.info("[start-match] island renderer prewarmed during weapon selection")}catch(i){We=null,console.warn("[start-match] renderer prewarm deferred",i)}}function cf(i=0){if(!ao||!fr[ao])return;const e=!!We,t=++Us;Ge.dataset.starting="true",Ge.dataset.openingPhase="preparing",Ge.dataset.openingTimer="0",delete Ge.dataset.startError,mc=!1,window.clearTimeout(Ol),Ge.dataset.graphicsContext="ok",oi.hidden=e,oi.querySelector("strong").textContent="Preparing the Island…",oi.querySelector("small").textContent="Building the detailed world. The portals will open when it is ready.",console.info("[start-match] preparing detailed island",{bots:ld,baseWeapon:ao}),window.setTimeout(async()=>{var s,o;if(t!==Us||Ge.hidden)return;const n=performance.now();try{if(rt=$g({players:1,bots:ld,opening:!1,baseWeapon:ao}),!We)try{const l=ra||i>0;We=sd(Ti,{safeMode:l}),Ge.dataset.safeGraphics=String(l)}catch(l){console.warn("[start-match] normal renderer unavailable; using safe 3D graphics",l),We=sd(Ti,{safeMode:!0}),Ge.dataset.safeGraphics="true"}if(bs=!1,yl=Ct.maxHealth,_r=0,ki.clear(),Vo=!1,Bl=!1,aa=!1,ca=0,ls=!1,ga=!1,Ss=rt.wizards[0].heading,_o=-.26,Eo=!1,Oo=0,ec=Qd(ao).hipFov,wo=-1,Zi=!1,$r=!1,Ge.dataset.hotbarSlot="none",Ge.dataset.mapOpen="false",Ge.dataset.diggingMode="false",Ge.dataset.diggingAction="false",(s=We.setDiggingMode)==null||s.call(We,!1),(o=We.setDiggingAction)==null||o.call(We,!1),Bs=null,hr=0,Y0(),Hr=0,af(),await We.prepareMatch(rt,0),t!==Us||Ge.hidden)return;We.setAim(Ss,_o),We.setFov(ec),We.setAdsAmount(0),We.update(rt,0,0);try{We.render()}catch(l){console.error("[graphics] first render failed",l),sf();return}if(t!==Us||Ge.hidden)return;ko=!0;let r=!1,a=0;const c=(l=performance.now())=>{r||t!==Us||Ge.hidden||!ko||(r=!0,window.clearTimeout(a),Ge.dataset.countdownSeen="",Ge.dataset.starting="false",Ge.dataset.openingPhase=rt.opening.phase,Ge.dataset.openingTimer=String(rt.opening.timer),Ge.dataset.playerLanded=String(!!li().openingLanded),Ge.dataset.playerAlive=String(!!li().alive),Ge.dataset.matchOver=String(!!rt.over),Ge.dataset.playerX=String(li().x),Ge.dataset.playerY=String(li().y),Ge.dataset.cameraYaw=String(Ss),Ge.dataset.cameraPitch=String(_o),Ge.dataset.playerHeading=String(li().heading),oi.hidden=!0,ud=l,Zr=requestAnimationFrame(ng),console.info("[start-match] ready",{milliseconds:Math.round(performance.now()-n)}))};a=window.setTimeout(()=>c(),1200),Zr=requestAnimationFrame(()=>{t!==Us||Ge.hidden||!ko||(Zr=requestAnimationFrame(c))})}catch(r){if(console.error("[start-match] failed",r),i<1&&t===Us&&!Ge.hidden){We&&(We.dispose(!0),We=null),oi.querySelector("strong").textContent="Restarting the Island…",oi.querySelector("small").textContent="The 3D renderer was interrupted. Retrying automatically in safe graphics mode.",window.setTimeout(()=>{t!==Us||Ge.hidden||(Ge.dataset.safeGraphics="true",cf(i+1))},800);return}Ge.dataset.starting="failed",Ge.dataset.startError=r instanceof Error?r.message:String(r),oi.querySelector("strong").textContent="The Island Could Not Start",oi.querySelector("small").textContent="Return to the menu and try again. The error has been recorded."}},e?0:80)}function Yw(){xo==null||xo.postMessage({type:"match-started",tabId:nf}),ma.hidden=!0,Sc.hidden=!0,Ge.hidden=!1,Ge.dataset.baseWeapon=ao,window.addEventListener("keydown",X0),window.addEventListener("keyup",q0),window.addEventListener("resize",af),Ti.addEventListener("mousemove",rf),Ti.addEventListener("mousedown",J0),Ti.addEventListener("contextmenu",eg),window.addEventListener("wheel",K0,{passive:!1}),window.addEventListener("mouseup",j0),window.addEventListener("blur",Q0),document.addEventListener("pointerlockchange",$0),Ge.dataset.pointerLockRequested="false",Go||Z0(),cf(),Ti.focus()}function Zl(i=!1){var e,t;Us++,ko=!1,cancelAnimationFrame(Zr),window.removeEventListener("keydown",X0),window.removeEventListener("keyup",q0),window.removeEventListener("resize",af),Ti.removeEventListener("mousemove",rf),Ti.removeEventListener("mousedown",J0),Ti.removeEventListener("contextmenu",eg),window.removeEventListener("wheel",K0),window.removeEventListener("mouseup",j0),window.removeEventListener("blur",Q0),document.removeEventListener("pointerlockchange",$0),document.pointerLockElement&&document.exitPointerLock(),Jr=!1,ki.clear(),Vo=!1,Eo=!1,Oo=0,aa=!1,ca=0,ls=!1,ga=!1,(e=We==null?void 0:We.setDiggingMode)==null||e.call(We,!1),(t=We==null?void 0:We.setDiggingAction)==null||t.call(We,!1),$r=!1,Ge.dataset.mapOpen="false",Ge.dataset.diggingMode="false",Ge.dataset.diggingAction="false",clearTimeout(Qa),Y0(),oi.hidden=!0,Ge.dataset.starting="false",Ge.dataset.pointerLockRequested="false",Ge.hidden=!0,i&&We&&(We.dispose(),We=null)}function ig(){ja=null,ao=null;for(const i of od.querySelectorAll(".weapon-card"))i.setAttribute("aria-selected","false");ur.hidden=!0,ur.disabled=!0,ur.textContent="Confirm Weapon"}function sg(){Zl(!0),ig(),Sc.hidden=!0,ma.hidden=!1,Ge.dataset.inactiveTab="true"}xo==null||xo.addEventListener("message",i=>{var e;!["match-preparing","match-started"].includes((e=i.data)==null?void 0:e.type)||i.data.tabId===nf||sg()});function Kw(){window.clearTimeout(hd),!(!document.hidden||!ko)&&(hd=window.setTimeout(()=>{document.hidden&&ko&&sg()},15e3))}document.addEventListener("visibilitychange",()=>{document.hidden?Kw():window.clearTimeout(hd)});window.addEventListener("pagehide",()=>{We&&(We.dispose(),We=null)});function og(){Zl(),Mc.hidden=!0,xo==null||xo.postMessage({type:"match-preparing",tabId:nf}),ma.hidden=!0,Sc.hidden=!1,ig(),Go||window.setTimeout(qw,0)}function bc(){Zl(),Sc.hidden=!0,Mc.hidden=!0,ma.hidden=!1}function Zw(i){const e={Escape:"Esc",Space:"Space",ShiftLeft:"Left Shift",ShiftRight:"Right Shift",ControlLeft:"Left Ctrl",ControlRight:"Right Ctrl",AltLeft:"Left Alt",AltRight:"Right Alt",Tab:"Tab",Backspace:"Backspace"};return e[i]?e[i]:i.startsWith("Key")?i.slice(3):i.startsWith("Digit")?i.slice(5):i.startsWith("Numpad")?`Num ${i.slice(6)}`:i||"Unassigned"}function rg(){To("wandwars-key-bindings",JSON.stringify(ho))}function gc(){Ju.replaceChildren();for(const[i,e]of Object.entries(gw)){const t=document.createElement("div");t.className="keybind-row";const n=document.createElement("span");n.textContent=e;const s=document.createElement("button");s.type="button",s.className="keybind-button",s.textContent=(fo==null?void 0:fo.action)===i?"Press a key…":Zw(ho[i]),s.addEventListener("click",()=>{fo={action:i},gc()}),t.append(n,s),Ju.append(t)}for(const[i,e]of[["cast","Cast spell"],["aim","Aim / zoom"]]){const t=document.createElement("div");t.className="keybind-row";const n=document.createElement("span");n.textContent=e;const s=document.createElement("select");s.className="keybind-select";for(const[o,r]of Object.entries(xw)){const a=document.createElement("option");a.value=o,a.textContent=r,s.append(a)}s.value=String(go[i]),s.addEventListener("change",()=>{go[i]=Number(s.value),To(`wandwars-mouse-${i}`,s.value)}),t.append(n,s),Ju.append(t)}}function $w(i){var s;if(!fo||Mc.hidden)return!1;if(i.preventDefault(),i.stopPropagation(),i.code==="Escape")return fo=null,gc(),!0;const{action:e}=fo,t=ho[e],n=(s=Object.entries(ho).find(([o,r])=>o!==e&&r===i.code))==null?void 0:s[0];return ho[e]=i.code,n&&(ho[n]=t),fo=null,rg(),gc(),!0}function $l(){const i=Ms("wandwars-graphics",cd==="safe"?"safe":"detailed");$a.value=Go||i==="safe"?"safe":"detailed",ra=Go||$a.value==="safe";const e=Math.round(tf*100);Wr.value=String(Math.max(25,Math.min(200,e))),V0.value=`${Wr.value}%`,rd.checked=Fl,Ja.checked=Ms("wandwars-reduced-motion","false")==="true",document.documentElement.dataset.reducedMotion=String(Ja.checked);for(const{input:t,output:n,key:s}of z0){const o=s.endsWith("master-volume")?"80":s.endsWith("music-volume")?"70":"85";t.value=Ms(s,o),n.value=`${t.value}%`}go={cast:Number(Ms("wandwars-mouse-cast","0")),aim:Number(Ms("wandwars-mouse-aim","2"))},gc(),G0.textContent=document.fullscreenElement?"⛶ Exit Fullscreen":"⛶ Fullscreen"}function Jw(){Zl(),ma.hidden=!0,Sc.hidden=!0,Mc.hidden=!1,$l()}function jw(){Mc.hidden=!0,ma.hidden=!1}for(const i of gm.querySelectorAll("button[data-bots]"))i.addEventListener("click",()=>{ld=Number(i.dataset.bots);for(const e of gm.querySelectorAll("button[data-bots]"))e.setAttribute("aria-pressed",String(e===i))});for(const i of od.querySelectorAll(".weapon-card[data-weapon]"))i.addEventListener("click",()=>{const e=i.dataset.weapon;if(fr[e]){ja=e;for(const t of od.querySelectorAll(".weapon-card"))t.setAttribute("aria-selected",String(t===i));ur.hidden=!1,ur.disabled=!1,ur.textContent=`Confirm ${fr[e].name}`}});ur.addEventListener("click",()=>{!ja||!fr[ja]||(ao=ja,Yw())});document.getElementById("play").addEventListener("click",og);document.getElementById("weapon-back").addEventListener("click",bc);document.getElementById("back").addEventListener("click",bc);fw.addEventListener("click",Jw);pw.addEventListener("click",jw);window.addEventListener("keydown",$w,!0);mw.addEventListener("click",()=>{ho={...ad},go={cast:0,aim:2},fo=null,rg(),To("wandwars-mouse-cast","0"),To("wandwars-mouse-aim","2"),gc()});Wr.addEventListener("input",()=>{tf=Number(Wr.value)/100,V0.value=`${Wr.value}%`,To("wandwars-mouse-sensitivity",Wr.value)});rd.addEventListener("change",()=>{Fl=rd.checked,To("wandwars-invert-y",Fl)});Ja.addEventListener("change",()=>{document.documentElement.dataset.reducedMotion=String(Ja.checked),To("wandwars-reduced-motion",Ja.checked)});for(const{input:i,output:e,key:t}of z0)i.addEventListener("input",()=>{e.value=`${i.value}%`,To(t,i.value)});$a.addEventListener("change",()=>{const i=$a.value==="safe"?"safe":"detailed";ra=Go||i==="safe",Go&&($a.value="safe"),To("wandwars-graphics",i)});G0.addEventListener("click",async()=>{try{document.fullscreenElement?await document.exitFullscreen():await document.documentElement.requestFullscreen()}catch{}$l()});document.addEventListener("fullscreenchange",$l);$l();
